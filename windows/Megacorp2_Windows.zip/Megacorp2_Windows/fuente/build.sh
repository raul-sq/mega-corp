#!/bin/sh
# Compilación cruzada desde Linux (zig: pip install ziglang)
# Requiere las cabeceras de https://github.com/floooh/chips (commit 9e88298) en ./chips
python3 -m ziglang cc -target x86_64-windows-gnu -O2 -s -I./chips \
  '-DGAME_TITLE="Megacorp (Parte 2) - Dinamic 1987 - ZX Spectrum 48K"' \
  -Wl,--subsystem,windows -o Megacorp2.exe win_main.c emu.c data_ram2.c \
  -lwinmm -lgdi32 -luser32
