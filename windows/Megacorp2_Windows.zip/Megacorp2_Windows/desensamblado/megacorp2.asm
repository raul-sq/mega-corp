; ============================================================================
;  MEGACORP (2ª parte) - Dinamic Software, 1987 - ZX Spectrum 48K
;  Autores: N. Lecuona y L. Franco
;  Desensamblado generado a partir de "Megacorp - Part 2.tzx"
; ----------------------------------------------------------------------------
;  Estructura de la cinta (idéntica a la 1ª parte):
;    Bloque 0/1  Programa BASIC "MEGACORP2" (44 bytes):
;                10 BORDER 0: PAPER 0: INK 0: POKE 23624,0: CLEAR 23999:
;                   LOAD "" CODE
;    Bloque 2/3  Bytes "megacode": 49152 bytes en 16384 ($4000-$FFFF),
;                volcado completo de la RAM (pantalla de carga incluida).
;
;  Arranque: el bloque de 48K sobrescribe la pila durante la carga
;  ($053F, $053F, $1B76); la ROM vuelve al intérprete BASIC, que ejecuta
;  el programa incluido en el volcado:
;                1 SAVE "vars" CODE 23552,447: RANDOMIZE USR 34104
;  El juego empieza en $8538 (34104).
;
;  Motor: aventura creada con GAC (Graphic Adventure Creator). El código
;  del motor ($6318-$95DD) es prácticamente idéntico al de la 1ª parte
;  (12994 de 12998 bytes iguales); lo que cambia es la base de datos de la
;  aventura (textos, gráficos, diccionario y condiciones).
;    Diccionario: tablas de 3 bytes [código][índice palabra][flags]
;    en $A54F, ($A521) y ($A51F); almacén de palabras en ($A531),
;    cada palabra = [longitud][letras]. Comparación de palabras en $79E3.
;    Búfer de la línea de entrada: $5B00.
;
;  Al empezar, el juego pide la clave obtenida al final de la 1ª parte
;  ("INTRODUZCA LA CLAVE"). La clave es: REBECA
;
;  Este listado parte del estado de la memoria al llegar a $8538 y cubre
;  $5C00-$FFFF. La separación código/datos se hizo con un mapa de ejecución
;  real (carga, clave y varias órdenes); las rutinas que no se llegaron a
;  ejecutar pueden aparecer como DEFB.
;
;  Verificación: reensamblado (skool2bin) = memoria original, 0 bytes
;  de diferencia.
;  Herramientas: SkoolKit (tap2sna, sna2ctl, sna2skool, skool2asm).
; ============================================================================

  ORG $5C00

; Data block at 5C00
  DEFB $FF,$00,$19,$20,$FF,$00,$23,$0D
  DEFB $0D,$23,$05,$00,$00,$00,$10,$00
  DEFB $01,$00,$06,$00,$0B,$00,$01,$00
  DEFB $01,$00,$06,$00,$10,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$FF,$FB
  DEFB $40,$05,$FF,$CC,$01,$BC,$5D,$BC
  DEFB $5D,$00,$00,$00,$FF,$01,$00,$02
  DEFB $07,$01,$00,$FB,$5C,$00,$00,$B6
  DEFB $5C,$B6,$5C,$CB,$5C,$FB,$5C,$CA
  DEFB $5C,$FC,$5C,$FD,$5C,$FA,$5C,$FD
  DEFB $00,$FF,$5C,$FF,$5C,$FF,$5C,$2D
  DEFB $92,$5C,$08,$02,$00,$00,$FE,$FF
  DEFB $01,$00,$00,$00,$B6,$1A,$81,$96
  DEFB $08,$24,$00,$58,$FF,$00,$00,$21
  DEFB $00,$5B,$21,$17,$00,$40,$E0,$50
  DEFB $21,$18,$21,$17,$01,$07,$00,$07
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$0A,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$BF,$5D,$FF,$FF,$F4,$09
  DEFB $A8,$10,$4B,$F4,$09,$C4,$15,$53
  DEFB $81,$0F,$C4,$15,$52,$F4,$09,$C4
  DEFB $15,$50,$80,$00,$01,$2C,$00,$F8

; Message at 5CD0
  DEFM "\"vars\""

; Data block at 5CD6
  DEFB $AF

; Message at 5CD7
  DEFM "23552"

; Data block at 5CDC
  DEFB $0E,$00,$00,$00,$5C,$00

; Message at 5CE2
  DEFM ",447"

; Data block at 5CE6
  DEFB $0E,$00,$00,$BF,$01,$00,$3A,$F9
  DEFB $C0

; Message at 5CEF
  DEFM "34104"

; Data block at 5CF4
  DEFB $0E,$00,$00,$38,$85,$00,$0D,$80
  DEFB $F7,$0D,$80,$00,$00,$38,$85,$00

; Message at 5D04
  DEFM "      "

; Data block at 5D0A
  DEFB $BF,$01,$00,$5C,$00,$80,$00,$00
  DEFB $00,$5C,$00,$00,$00,$BF,$01,$00
  DEFB $BF,$01,$00,$3A,$F9,$C0

; Message at 5D20
  DEFM "34104"

; Data block at 5D25
  DEFB $0E,$00,$00,$38,$85,$00,$0D,$80
  DEFB $00,$00,$00,$0A,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$E0,$57,$71
  DEFB $0E,$00,$01,$30,$0D,$F3,$0D,$DB
  DEFB $02,$4D,$00,$F3,$0D,$CE,$0B,$E2
  DEFB $50,$CE,$0B,$E3,$50,$1E,$17,$DC
  DEFB $0A,$CE,$0B,$E4,$50,$1D,$17,$DB
  DEFB $02,$4D,$00,$07,$00,$00,$00,$F7
  DEFB $5A,$5C,$07,$B7,$2D,$FF,$5C,$FA
  DEFB $5C,$38,$85

; Message at 5DA8
  DEFM "+-e3"

; Data block at 5DAC
  DEFB $00,$00,$ED,$10,$0D,$00,$09,$00
  DEFB $85,$1C,$10,$1C,$52,$1B,$76,$1B
  DEFB $00,$00,$00,$00

; Message at 5DC0
  DEFM "8DDDDDDDDDDD(("

; Data block at 5DCE
  DEFB $10,$10,$3F,$3F,$00,$00,$00,$00
  DEFB $00,$00,$FF,$FF,$00,$00,$00,$00
  DEFB $00,$00,$FC,$FC,$00,$00,$00,$00
  DEFB $00,$00,$FF,$FF,$FF,$FF,$FF,$FF
  DEFB $FF,$FF,$08,$0C,$0E,$FF,$FF,$0E
  DEFB $0C,$08,$18,$3C,$7E,$FF,$18,$18
  DEFB $18,$18,$18,$18,$18,$18,$FF,$7E
  DEFB $3C,$18,$00,$3C,$66,$C3,$C3,$66
  DEFB $3C,$00,$00,$3C,$7E,$FF,$FF,$7E
  DEFB $3C,$00

; Message at 5E18
  DEFM ">>>"

; Data block at 5E1B
  DEFB $FF

; Message at 5E1C
  DEFM "ancha calle de la Ciudad.Al Sur esta el embarcadero.Salidas: Nort"
  DEFM "e,Este.********************************"

; Data block at 5E84
  DEFB $FF

; Message at 5E85
  DEFM "na y L.Franco        --- PULSE UNA TECLA ---                     "
  DEFM "                    DINAMIC SOFTWARE 1987                        "
  DEFM "              "

; Data block at 5F15
  DEFB $FF,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$D5,$3C,$B2,$3C,$68
  DEFB $FF,$45,$20,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00

; Routine at 6318
;
; Used by the routines at 7C3F and 81E1.
  JP $7157                ; Jump to 7157

; Data block at 631B
  DEFB $C3,$DA,$71

; Routine at 631E
;
; Used by the routines at 7666, 778A, 815B, 8171, 81BE, 81E1, 886C and 95D5.
  JP $6E75                ; Jump to 6E75

; Routine at 6321
;
; Used by the routine at 778A.
  JP $7136                ; Jump to 7136

; Routine at 6324
;
; Used by the routines at 7C3F and 81E1.
  JP $71C6                ; Jump to 71C6

; Routine at 6327
;
; Used by the routines at 7C3F and 81E1.
  JP $71AA                ; Jump to 71AA

; Data block at 632A
  DEFB $C3,$E1,$6D

; Routine at 632D
;
; Used by the routine at 7202.
  JP $643C                ; Jump to 643C

; Routine at 6330
;
; Used by the routines at 7B3F and 7C3F.
  JP $714F                ; Jump to 714F

; Routine at 6333
;
; Used by the routine at 7B3F.
  JP $7194                ; Jump to 7194

; Routine at 6336
;
; Used by the routine at 7649.
  JP $68C2                ; Jump to 68C2

; Data block at 6339
  DEFB $C3,$35,$65,$C3,$E3,$71,$80,$70
  DEFB $80,$70,$FF,$00,$FF,$00,$00,$00
  DEFB $00,$18,$5E,$00,$00,$00,$02,$40
  DEFB $9C,$00,$00,$56,$63,$1F,$01,$0C
  DEFB $00,$00,$00,$00,$00,$00,$01,$00
  DEFB $00,$00,$07

; Routine at 6364
  LD HL,$0000             ; HL=$0000
  JR $6371                ; Jump to 6371

; Routine at 6369
  LD HL,$FFAA             ; HL=$FFAA
  JR $6371                ; Jump to 6371

; Routine at 636E
;
; Used by the routine at 6CE8.
  LD HL,$00FF             ; HL=$00FF
; This entry point is used by the routines at 6364 and 6369.
  LD ($6343),HL           ; POKE $6343,L; POKE $6344,H
  LD DE,($6341)           ; E=PEEK $6341; D=PEEK $6342
  PUSH DE                 ; Push DE onto the stack
  CALL $64D9              ; CALL 64D9
  POP BC                  ; Pop last item from stack into BC
  RET NZ                  ; Return if the zero flag is not set
  PUSH BC                 ; Push BC onto the stack
  JR $6388                ; Jump to 6388

; Routine at 6381
  PUSH DE                 ; Push DE onto the stack
  CALL $64D9              ; CALL 64D9
  POP BC                  ; Pop last item from stack into BC
  JR NZ,$6393             ; Jump to 6393 if the zero flag is not set
; This entry point is used by the routine at 636E.
  PUSH BC                 ; Push BC onto the stack
  CALL $63A5              ; CALL 63A5
  POP DE                  ; Pop last item from stack into DE
  INC D                   ; D=D+1
  LD A,D                  ; A=D
  CP $B0                  ; Set the zero flag if A=$B0, or the carry flag if
                          ; A<$B0
  JR C,$6381              ; Jump to 6381 if A<$B0
  POP DE                  ; Pop last item from stack into DE
  DEC D                   ; D=D-1
  LD A,D                  ; A=D
  CP $30                  ; Set the zero flag if A=$30, or the carry flag if
                          ; A<$30
  RET C                   ; Return if A<$30
  PUSH DE                 ; Push DE onto the stack
  CALL $64D9              ; CALL 64D9
  POP BC                  ; Pop last item from stack into BC
  RET NZ                  ; Return if the zero flag is not set
  PUSH BC                 ; Push BC onto the stack
  CALL $63A5              ; CALL 63A5
  JR $6393                ; Jump to 6393

; Routine at 63A5
;
; Used by the routine at 6381.
  PUSH BC                 ; Push BC onto the stack
  LD HL,($6343)           ; L=PEEK $6343; H=PEEK $6344
  LD A,L                  ; A=L
  BIT 0,B                 ; Set the zero flag if bit 0 of B is 0
  JR Z,$63AF              ; Jump to 63AF if bit 0 of B is reset
  XOR H                   ; A=A^H
  LD ($6345),A            ; POKE $6345,A
  DEC C                   ; C=C-1
  LD A,C                  ; A=C
  INC A                   ; A=A+1
  CALL NZ,$63DF           ; CALL 63DF if A>0
  POP BC                  ; Pop last item from stack into BC
  JP $63BC                ; Jump to 63BC
  CALL $64EB              ; CALL 64EB
  LD B,A                  ; B=A
  XOR A                   ; A=0
  INC B                   ; B=B+1
  SCF                     ; Set the carry flag
  RLA                     ; Rotate A left through the carry flag
  DJNZ $63C3              ; Decrement B and jump to 63C3 if B>0
  LD B,A                  ; B=A
  CALL $6425              ; CALL 6425
  BIT 0,C                 ; Set the zero flag if bit 0 of C is 0
  RET Z                   ; Return if bit 0 of C is reset
  INC HL                  ; HL=HL+1
  LD A,L                  ; A=L
  AND $1F                 ; Reset bits 5, 6 and 7 of A
  RET Z                   ; Return if A=0
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$6423             ; Jump to 6423 if A>0
  LD A,($6345)            ; A=PEEK $6345
  LD (HL),A               ; POKE HL,A
  CALL $6434              ; CALL 6434
  JR $63CD                ; Jump to 63CD

; Routine at 63DF
;
; Used by the routine at 63A5.
  CALL $64EB              ; CALL 64EB
  LD B,A                  ; B=A
  XOR A                   ; A=0
  INC B                   ; B=B+1
  SCF                     ; Set the carry flag
  RLA                     ; Rotate A left through the carry flag
  DJNZ $63E6              ; Decrement B and jump to 63E6 if B>0
  LD B,A                  ; B=A
  CALL $6406              ; CALL 6406
  BIT 7,C                 ; Set the zero flag if bit 7 of C is 0
  RET Z                   ; Return if bit 7 of C is reset
  DEC HL                  ; HL=HL-1
  LD A,L                  ; A=L
  AND $1F                 ; Reset bits 5, 6 and 7 of A
  CP $1F                  ; Set the zero flag if A=$1F, or the carry flag if
                          ; A<$1F
  RET Z                   ; Return if A=$1F
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$6404             ; Jump to 6404 if A>0
  LD A,($6345)            ; A=PEEK $6345
  LD (HL),A               ; POKE HL,A
  CALL $6434              ; CALL 6434
  JR $63F0                ; Jump to 63F0
  LD B,$01                ; B=$01
  LD C,$00                ; C=$00
  LD A,B                  ; A=B
  AND (HL)                ; A=A&PEEK HL
  JR NZ,$6413             ; Jump to 6413 if A>0
  LD A,B                  ; A=B
  OR C                    ; A=A|C
  LD C,A                  ; C=A
  SLA B                   ; Shift B left (copying bit 7 into the carry flag,
                          ; and resetting bit 0)
  JR NC,$6408             ; Jump to 6408 if the carry flag is not set
; This entry point is used by the routine at 6423.
  LD A,($6345)            ; A=PEEK $6345
  AND C                   ; A=A&C
  LD B,A                  ; B=A
  LD A,C                  ; A=C
  CPL                     ; A=$FF-A
  AND (HL)                ; A=A&PEEK HL
  OR B                    ; A=A|B
  LD (HL),A               ; POKE HL,A
  LD A,C                  ; A=C
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  CALL NZ,$6434           ; CALL 6434 if A>0
  RET                     ; Return

; Routine at 6423
;
; Used by the routine at 63A5.
  LD B,$80                ; B=$80
; This entry point is used by the routine at 63A5.
  LD C,$00                ; C=$00
  LD A,B                  ; A=B
  AND (HL)                ; A=A&PEEK HL
  JR NZ,$6413             ; Jump to 6413 if A>0
  LD A,B                  ; A=B
  OR C                    ; A=A|C
  LD C,A                  ; C=A
  SRL B                   ; Shift B right (copying bit 0 into the carry flag,
                          ; and resetting bit 7)
  JR C,$6413              ; Jump to 6413 if the carry flag is set
  JR $6427                ; Jump to 6427

; Routine at 6434
;
; Used by the routines at 63A5 and 63DF.
  PUSH HL                 ; Push HL onto the stack
  PUSH BC                 ; Push BC onto the stack
  CALL $64C0              ; CALL 64C0
  POP BC                  ; Pop last item from stack into BC
  POP HL                  ; Pop last item from stack into HL
  RET                     ; Return

; Routine at 643C
;
; Used by the routines at 632D and 648A.
  BIT 7,D                 ; Set the zero flag if bit 7 of D is 0
  JR NZ,$6449             ; Jump to 6449 if bit 7 of D is set
  LD A,D                  ; A=D
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$644C              ; Jump to 644C if A=0
  LD DE,$00FF             ; DE=$00FF
  JR $644C                ; Jump to 644C
  LD DE,$0000             ; DE=$0000
  BIT 7,H                 ; Set the zero flag if bit 7 of H is 0
  JR NZ,$6462             ; Jump to 6462 if bit 7 of H is set
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$6459              ; Jump to 6459 if A=0
  LD HL,$00AF             ; HL=$00AF
  JR $6465                ; Jump to 6465
  LD A,L                  ; A=L
  CP $B0                  ; Set the zero flag if A=$B0, or the carry flag if
                          ; A<$B0
  JR NC,$6454             ; Jump to 6454 if A>=$B0
  CP $30                  ; Set the zero flag if A=$30, or the carry flag if
                          ; A<$30
  JR NC,$6465             ; Jump to 6465 if A>=$30
  LD HL,$0030             ; HL=$0030
  LD BC,($5C7D)           ; C=PEEK $5C7D; B=PEEK $5C7E
  PUSH BC                 ; Push BC onto the stack
  LD A,E                  ; A=E
  SUB C                   ; A=A-C
  LD E,$01                ; E=$01
  JR Z,$6475              ; Jump to 6475 if the zero flag is set
  JR NC,$6476             ; Jump to 6476 if the carry flag is not set
  NEG                     ; A=$100-A
  DEC E                   ; E=E-1
  DEC E                   ; E=E-1
  LD C,A                  ; C=A
  LD A,L                  ; A=L
  SUB B                   ; A=A-B
  LD D,$01                ; D=$01
  JR Z,$6482              ; Jump to 6482 if the zero flag is set
  JR NC,$6483             ; Jump to 6483 if the carry flag is not set
  NEG                     ; A=$100-A
  DEC D                   ; D=D-1
  DEC D                   ; D=D-1
  LD B,A                  ; B=A
  CALL $24BA              ; CALL 24BA
  POP BC                  ; Pop last item from stack into BC
  JR $649F                ; Jump to 649F

; Routine at 648A
  LD HL,($633F)           ; L=PEEK $633F; H=PEEK $6340
  LD ($5C7D),HL           ; POKE $5C7D,L; POKE $5C7E,H
  LD HL,($6341)           ; L=PEEK $6341; H=PEEK $6342
; This entry point is used by the routine at 6516.
  XOR A                   ; A=0
  LD D,A                  ; D=A
  LD E,L                  ; E=L
  LD L,H                  ; L=H
  LD H,A                  ; H=A
  JP $643C                ; Jump to 643C

; Routine at 649B
;
; Used by the routine at 6BA8.
  LD BC,($6341)           ; C=PEEK $6341; B=PEEK $6342
; This entry point is used by the routine at 643C.
  LD HL,($5C8D)           ; L=PEEK $5C8D; H=PEEK $5C8E
  LD ($5C8F),HL           ; POKE $5C8F,L; POKE $5C90,H
  JP $22E5                ; Jump to 22E5

; Routine at 64A8
;
; Used by the routine at 6CB7.
  LD HL,$5800             ; HL=$5800
  LD DE,$A1FD             ; DE=$A1FD
  LD BC,$0200             ; BC=$0200
  LDIR                    ; POKE DE,PEEK HL; HL=HL+1; DE=DE+1; BC=BC-1; repeat
                          ; until BC=0
  RET                     ; Return

; Data block at 64B4
  DEFB $21,$FD,$A1,$11,$00,$58,$01,$00
  DEFB $02,$ED,$B0,$C9

; Routine at 64C0
;
; Used by the routine at 6434.
  LD A,H                  ; A=H
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  AND $03                 ; Keep only bits 0 and 1 of A
  ADD A,$58               ; A=A+$58
  LD H,A                  ; H=A
  LD A,($5C8E)            ; A=PEEK $5C8E
  LD B,A                  ; B=A
  CPL                     ; A=$FF-A
  LD C,A                  ; C=A
  LD A,($5C8D)            ; A=PEEK $5C8D
  AND C                   ; A=A&C
  LD C,A                  ; C=A
  LD A,B                  ; A=B
  AND (HL)                ; A=A&PEEK HL
  OR C                    ; A=A|C
  LD (HL),A               ; POKE HL,A
  RET                     ; Return

; Routine at 64D9
;
; Used by the routines at 636E and 6381.
  LD A,$AF                ; A=$AF
  SUB D                   ; A=A-D
  LD C,E                  ; C=E
  CALL $64EE              ; CALL 64EE
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  ADD A,$46               ; A=A+$46
  LD ($64E9),A            ; POKE $64E9,A
  BIT 0,(HL)              ; Set the zero flag if bit 0 of (HL) is 0
  RET                     ; Return

; Routine at 64EB
;
; Used by the routines at 63A5 and 63DF.
  LD A,$AF                ; A=$AF
  SUB B                   ; A=A-B
; This entry point is used by the routine at 64D9.
  CALL $22B0              ; CALL 22B0
  SUB $07                 ; A=A-$07
  NEG                     ; A=$100-A
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET                     ; Return

; Routine at 64F7
  LD DE,($633F)           ; E=PEEK $633F; D=PEEK $6340
  LD HL,($6341)           ; L=PEEK $6341; H=PEEK $6342
  PUSH DE                 ; Push DE onto the stack
  LD C,L                  ; C=L
  LD B,D                  ; B=D
  PUSH BC                 ; Push BC onto the stack
  PUSH BC                 ; Push BC onto the stack
  PUSH HL                 ; Push HL onto the stack
  PUSH HL                 ; Push HL onto the stack
  LD C,E                  ; C=E
  LD B,H                  ; B=H
  PUSH BC                 ; Push BC onto the stack
  PUSH BC                 ; Push BC onto the stack
  PUSH DE                 ; Push DE onto the stack
  LD B,$04                ; B=$04
  POP HL                  ; Pop last item from stack into HL
  POP DE                  ; Pop last item from stack into DE
  PUSH BC                 ; Push BC onto the stack
  CALL $6516              ; CALL 6516
  POP BC                  ; Pop last item from stack into BC
  DJNZ $650C              ; Decrement B and jump to 650C if B>0
  RET                     ; Return

; Routine at 6516
;
; Used by the routine at 64F7.
  LD ($5C7D),DE           ; POKE $5C7D,E; POKE $5C7E,D
  JP $6493                ; Jump to 6493

; Routine at 651D
  XOR A                   ; A=0
  LD HL,($633F)           ; L=PEEK $633F; H=PEEK $6340
  LD E,H                  ; E=H
  LD H,A                  ; H=A
  LD D,A                  ; D=A
  LD ($A53B),HL           ; POKE $A53B,L; POKE $A53C,H
  LD ($A53D),DE           ; POKE $A53D,E; POKE $A53E,D
  LD DE,($6341)           ; E=PEEK $6341; D=PEEK $6342
  LD L,D                  ; L=D
  LD H,A                  ; H=A
  LD D,A                  ; D=A
  JP $88FE                ; Jump to 88FE

; Data block at 6535
  DEFB $DD,$E5,$3E,$01,$D3,$FE,$CD

; Message at 653C
  DEFM "Ep>"

; Data block at 653F
  DEFB $07,$CD,$A1,$70,$CD,$5D,$67,$CD
  DEFB $40,$6F,$CD,$38,$66,$CD,$4B,$66
  DEFB $CD,$23,$67,$CD,$A8,$64,$AF

; Message at 6556
  DEFM "2cc>"

; Data block at 655A
  DEFB $01,$CD,$F2,$6A,$CD,$95

; Message at 6560
  DEFM "f:j"

; Data block at 6563
  DEFB $5C,$F5,$CB,$DF,$32,$6A,$5C,$CD

; Message at 656B
  DEFM "Wqo"

; Data block at 656E
  DEFB $F1,$32,$6A,$5C,$7D,$21,$8F,$65
  DEFB $BE,$28,$09,$34,$28,$10,$35,$23
  DEFB $23,$23,$18,$F4,$23,$7E,$23,$66
  DEFB $6F,$01,$59,$65,$C5,$E9,$35,$18
  DEFB $CA,$43,$F0,$65,$47,$1E,$66,$35
  DEFB $13,$69,$36,$18,$69,$37,$1D

; Message at 659D
  DEFM "i8\"i"

; Data block at 65A1
  DEFB $F2,$27,$69,$F1,$2C,$69,$F0,$31
  DEFB $69,$F3,$36,$69,$7F,$3B,$69,$0F

; Message at 65B1
  DEFM "[iWbiZhi%pi'"

; Data block at 65BD
  DEFB $7D

; Message at 65BE
  DEFM "i&li("

; Data block at 65C3
  DEFB $81,$69,$49,$23

; Message at 65C7
  DEFM "jP+jV3jB;jTCjD"

; Data block at 65D5
  DEFB $FD,$6A,$45,$DA,$6B,$46,$0B

; Message at 65DC
  DEFM "kA kS'kM"

; Data block at 65E4
  DEFB $EE,$6B,$52,$D0

; Message at 65E8
  DEFM "kL.k"

; Data block at 65EC
  DEFB $FC,$1D,$67,$FF,$ED

; Message at 65F1
  DEFM "KAc>"

; Data block at 65F5
  DEFB $AF,$90,$E6,$F8,$26,$16,$CB,$27
  DEFB $CB,$14,$CB,$27,$CB,$14,$CB,$39
  DEFB $CB,$39,$CB,$39,$81,$6F,$7E,$F5
  DEFB $CB,$FE,$CD,$15,$66,$F1,$77,$C9
  DEFB $AF,$DB,$FE,$F6,$E0,$3C,$20,$F8
  DEFB $C9,$0E,$10,$21,$00

; Message at 6622
  DEFM "X>8"

; Data block at 6625
  DEFB $06,$20,$77,$23,$EE,$40,$10,$FA
  DEFB $EE,$40,$0D,$20,$F3,$CD,$15,$66
  DEFB $C3,$B4,$64,$21,$80

; Message at 663A
  DEFM "X\"?c\"Ac> 2"

; Data block at 6644
  DEFB $DF,$6D,$AF

; Message at 6647
  DEFM "2Lc"

; Data block at 664A
  DEFB $C9

; Routine at 664B
;
; Used by the routine at 6CB7.
  LD A,$01                ; A=$01
  CALL $6AF2              ; CALL 6AF2
  LD A,$0F                ; A=$0F
  LD ($5C48),A            ; POKE $5C48,A
  CALL $6F35              ; CALL 6F35
  LD A,($634C)            ; A=PEEK $634C
  ADD A,$02               ; A=A+$02
  LD ($6DD6),A            ; POKE $6DD6,A
  CALL $6678              ; CALL 6678
  LD ($6D92),A            ; POKE $6D92,A
  CALL $667E              ; CALL 667E
  LD ($6D94),A            ; POKE $6D94,A
  LD HL,$6D91             ; HL=$6D91
  CALL $66F9              ; CALL 66F9
  CALL $670D              ; CALL 670D
  JP $6695                ; Jump to 6695

; Routine at 6678
;
; Used by the routine at 664B.
  LD A,($5C8D)            ; A=PEEK $5C8D
  AND $07                 ; Keep only bits 0, 1 and 2 of A
  RET                     ; Return

; Routine at 667E
;
; Used by the routine at 664B.
  LD A,($5C8D)            ; A=PEEK $5C8D
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  AND $07                 ; Keep only bits 0, 1 and 2 of A
  RET                     ; Return

; Data block at 6687
  DEFB $3E,$16,$D7,$3E,$03,$D7,$78,$D7
  DEFB $06,$00,$CD,$1B,$1A,$C9,$AF,$CD
  DEFB $9E,$71,$3E,$01,$CD,$F2,$6A,$21
  DEFB $E7,$66,$CD,$F9,$66,$06,$0E

; Message at 66A6
  DEFM ":AcO"

; Data block at 66AA
  DEFB $CD,$87,$66,$06,$12

; Message at 66AF
  DEFM ":Bc"

; Data block at 66B2
  DEFB $D6,$30,$4F,$CD,$87,$66,$3E,$16
  DEFB $D7,$3E,$03,$D7,$3E,$18,$D7

; Message at 66C1
  DEFM ":cc!"

; Data block at 66C5
  DEFB $D3,$66,$85,$6F,$30,$01,$24,$7E
  DEFB $D7,$3E,$02,$C3,$F2

; Message at 66D2
  DEFM "j TDEFASMRL??????IPVB"

; Data block at 66E7
  DEFB $16,$03,$0E

; Message at 66EA
  DEFM "       "

; Data block at 66F1
  DEFB $FF,$E5,$3E,$01,$CD,$F2,$6A,$E1

; Routine at 66F9
;
; Used by the routines at 664B and 71AA.
  LD A,(HL)               ; A=PEEK HL
  CP $FF                  ; Set the zero flag if A=$FF, or the carry flag if
                          ; A<$FF
  RET Z                   ; Return if A=$FF
  CP $0A                  ; Set the zero flag if A=$0A, or the carry flag if
                          ; A<$0A
  JR NZ,$6706             ; Jump to 6706 if A<>$0A
  CALL $6E75              ; CALL 6E75
  JR $6709                ; Jump to 6709
  CALL $70AA              ; CALL 70AA
  INC HL                  ; HL=HL+1
  JR $66F9                ; Jump to 66F9

; Data block at 670C
  DEFB $C9,$3E,$16,$D7,$3E,$03,$D7,$3E
  DEFB $1C,$D7,$ED

; Message at 6717
  DEFM "KFc"

; Data block at 671A
  DEFB $C3,$1B,$1A,$CD,$A1,$67,$CD,$07
  DEFB $68,$3E,$01,$CD,$F2,$6A,$21,$BA
  DEFB $6A,$CD,$F9,$66,$CD,$04,$8A,$38
  DEFB $03,$C3,$E4,$6B,$E5

; Message at 6737
  DEFM "\"Fc"

; Data block at 673A
  DEFB $D1,$CD

; Message at 673C
  DEFM "Ph(;"

; Data block at 6740
  DEFB $DD,$E5,$E1,$23,$23,$23,$23,$23
  DEFB $0B,$0B,$0B,$0B,$0B,$11,$18,$5E
  DEFB $ED,$B0,$DD,$7E,$04

; Message at 6755
  DEFM "2Ic>"

; Data block at 6759
  DEFB $FF,$C3,$A1,$6C

; Routine at 675D
;
; Used by the routine at 68C2.
  LD L,$38                ; L=$38
  LD H,$00                ; H=$00
  LD ($5C8D),HL           ; POKE $5C8D,L; POKE $5C8E,H
  LD ($5C8F),HL           ; POKE $5C8F,L; POKE $5C90,H
  LD HL,$5C91             ; HL=$5C91
  RES 0,(HL)              ; Reset bit 0 of (HL)
  RES 2,(HL)              ; Reset bit 2 of (HL)
  LD HL,$7080             ; HL=$7080
  LD ($633F),HL           ; POKE $633F,L; POKE $6340,H
  LD ($6341),HL           ; POKE $6341,L; POKE $6342,H
  XOR A                   ; A=0
  JP $719E                ; Jump to 719E

; Data block at 677B
  DEFB $2A,$33,$A5,$01,$0A,$00,$09,$38
  DEFB $42,$01,$05,$00,$2A,$31,$A5,$CD

; Message at 678B
  DEFM "oh++s"

; Data block at 6790
  DEFB $23,$72,$23,$36,$05,$AF,$23,$77
  DEFB $23,$77,$23,$77,$23,$77,$AF,$18
  DEFB $B4,$ED

; Message at 67A2
  DEFM "[Fc"

; Data block at 67A5
  DEFB $CD,$95

; Message at 67A7
  DEFM "h*Jc"

; Data block at 67AB
  DEFB $11,$0E,$5E,$A7,$ED,$52,$ED,$5B
  DEFB $33,$A5,$19,$D0,$F1,$21,$CC,$67
  DEFB $CD,$F2,$66,$CD

; Message at 67BF
  DEFM "Wq>"

; Data block at 67C2
  DEFB $11,$C3,$75,$6E,$CD,$B8,$67,$C3
  DEFB $E4,$6B,$16,$07,$00

; Message at 67CF
  DEFM "You have run out of memory..."

; Data block at 67EC
  DEFB $FF,$16,$07,$00

; Message at 67F0
  DEFM "Picture buffer full..."

; Data block at 6806
  DEFB $FF,$3E,$FF,$CD,$A1,$6C,$DD,$2A
  DEFB $31,$A5,$DD,$2B,$DD,$2B,$11,$18
  DEFB $5E

; Message at 6817
  DEFM "*Jc"

; Data block at 681A
  DEFB $A7,$ED,$52,$C8

; Message at 681E
  DEFM "DM!"

; Data block at 6821
  DEFB $05,$00,$09,$C5,$44,$4D,$CD,$6F
  DEFB $68,$C1,$DD,$75,$02,$DD,$74,$03

; Message at 6831
  DEFM "*Fc"

; Data block at 6834
  DEFB $DD,$75,$00,$DD,$74,$01

; Message at 683A
  DEFM ":Ic"

; Data block at 683D
  DEFB $DD,$77,$04,$DD,$E5,$E1,$23,$23
  DEFB $23,$23,$23,$EB,$ED,$B0,$AF,$12
  DEFB $13,$12,$C9

; Routine at 6850
;
; Used by the routine at 6C61.
  LD IX,($A52F)           ; IXl=PEEK $A52F; IXh=PEEK $A530
  LD L,(IX+$00)           ; L=PEEK (IX+$00)
  LD H,(IX+$01)           ; H=PEEK (IX+$01)
  LD A,H                  ; A=H
  OR L                    ; A=A|L
  RET Z                   ; Return if A=0
  LD C,(IX+$02)           ; C=PEEK (IX+$02)
  LD B,(IX+$03)           ; B=PEEK (IX+$03)
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,DE               ; HL=HL-carry-DE
  JR Z,$686C              ; Jump to 686C if HL=0
  ADD IX,BC               ; IX=IX+BC
  JR $6854                ; Jump to 6854
  XOR A                   ; A=0
  INC A                   ; A=A+1
  RET                     ; Return

; Data block at 686F
  DEFB $E5,$D5,$C5,$2A,$31,$A5,$E5,$09
  DEFB $22,$31,$A5,$2A,$33,$A5,$E5,$09
  DEFB $22,$33,$A5,$23,$EB,$E1,$C1,$23
  DEFB $E5,$A7,$ED

; Message at 688A
  DEFM "BDM"

; Data block at 688D
  DEFB $03,$E1,$ED,$B8,$C1,$D1,$E1,$C9
  DEFB $CD,$50,$68,$C8,$DD,$E5,$E1,$E5
  DEFB $09,$E5

; Message at 689F
  DEFM "T]*3"

; Data block at 68A3
  DEFB $A5,$A7,$ED,$52,$23,$23,$E5,$2A
  DEFB $31,$A5,$A7,$ED

; Message at 68AF
  DEFM "B\"1"

; Data block at 68B2
  DEFB $A5,$2A,$33,$A5,$A7,$ED

; Message at 68B8
  DEFM "B\"3"

; Data block at 68BB
  DEFB $A5,$C1,$E1,$D1,$ED,$B0,$C9

; Routine at 68C2
;
; Used by the routine at 6336.
  LD A,$C9                ; A=$C9
  LD ($64A8),A            ; POKE $64A8,A
  LD ($6BA8),A            ; POKE $6BA8,A
  LD ($664B),A            ; POKE $664B,A
  CALL $675D              ; CALL 675D
  CALL $6F40              ; CALL 6F40
  CALL $6C37              ; CALL 6C37
  CALL $675D              ; CALL 675D
  LD A,$21                ; A=$21
  LD ($64A8),A            ; POKE $64A8,A
  LD A,$3E                ; A=$3E
  LD ($6BA8),A            ; POKE $6BA8,A
  LD ($664B),A            ; POKE $664B,A
  RET                     ; Return

; Data block at 68E7
  DEFB $C5,$3E,$01,$CD,$9E,$71,$CD,$0F
  DEFB $69,$CD,$B4,$64,$C1

; Message at 68F4
  DEFM "*Ac"

; Data block at 68F7
  DEFB $7D,$81,$CB,$79,$28,$01,$3F,$38
  DEFB $01,$6F,$7C,$80,$FE,$B0,$30,$05
  DEFB $FE,$30,$38,$01

; Message at 690B
  DEFM "g\"Ac"

; Data block at 690F
  DEFB $CD,$9B,$64,$C9,$01,$FF,$00,$18
  DEFB $CF,$01,$00,$FF,$18,$CA,$01,$00
  DEFB $01,$18,$C5,$01,$01,$00,$18,$C0
  DEFB $01,$F8,$00,$18,$BB,$01,$00,$F8
  DEFB $18,$B6,$01,$00,$08,$18,$B1,$01
  DEFB $08,$00,$18,$AC

; Message at 693B
  DEFM ":Hc"

; Data block at 693E
  DEFB $A7,$C8

; Message at 6940
  DEFM "*Jc"

; Data block at 6943
  DEFB $E5,$CD,$70,$69,$D1,$21,$17,$63
  DEFB $A7,$ED

; Message at 694D
  DEFM "RDM*Jc"

; Data block at 6953
  DEFB $EB,$ED,$B0

; Message at 6956
  DEFM "!Ic5"

; Data block at 695A
  DEFB $C9

; Message at 695B
  DEFM ":Hc2Ic"

; Data block at 6961
  DEFB $C9

; Message at 6962
  DEFM ":Ic"

; Data block at 6965
  DEFB $C3,$A1,$6C,$AF,$C3,$A1,$6C,$06
  DEFB $05,$18,$02,$06,$01

; Message at 6972
  DEFM ":Hc"

; Data block at 6975
  DEFB $90,$D2,$A1,$6C,$AF,$C3,$A1,$6C
  DEFB $06,$05,$18,$02,$06,$01

; Message at 6983
  DEFM ":Hc"

; Data block at 6986
  DEFB $80,$D2,$A1,$6C,$3E,$FF,$C3,$A1
  DEFB $6C,$CD,$85,$6C,$C5,$E5,$3E,$01
  DEFB $CD,$F2,$6A,$E1,$CD,$F9,$66,$1E
  DEFB $01,$21,$00,$5B,$36,$00,$CD,$8A
  DEFB $82,$C1,$38,$09

; Message at 69AA
  DEFM "!Ic5+5"

; Data block at 69B0
  DEFB $C3,$4B,$66,$11,$00,$5B,$EB,$7E
  DEFB $D6,$30,$FE,$0A,$30,$EC,$77,$79
  DEFB $FE,$12,$38,$0A,$7E,$FE,$08,$28
  DEFB $05,$E6,$0E,$C2,$AA,$69,$7E,$71
  DEFB $23

; Message at 69D1
  DEFM "Gy= "

; Data block at 69D5
  DEFB $11,$11,$01,$5B,$78,$12,$CD,$37
  DEFB $6D,$CD,$4B,$66,$01,$02,$00,$C3
  DEFB $05,$6A,$70,$23,$36,$FF,$3E,$02
  DEFB $CD,$F2,$6A,$21,$00,$5B,$CD,$F9
  DEFB $66,$2A,$8F,$5C,$22,$8D,$5C,$01
  DEFB $02,$00,$CD,$05,$6A,$C3

; Message at 6A03
  DEFM "Kf!Hc:"

; Unused
  DEFS $01

; Message at 6A0A
  DEFM "[2cc:Ic"

; Data block at 6A11
  DEFB $BE,$C4,$D7,$6A,$21,$00,$5B,$ED

; Message at 6A19
  DEFM "[Jc"

; Data block at 6A1C
  DEFB $ED,$B0,$ED

; Message at 6A1F
  DEFM "SJc"

; Data block at 6A22
  DEFB $C9

; Message at 6A23
  DEFM "!Kj"

; Data block at 6A26
  DEFB $0E,$10,$C3,$8F,$69,$21,$60,$6A
  DEFB $0E,$11,$C3,$8F

; Message at 6A32
  DEFM "i!wj"

; Data block at 6A36
  DEFB $0E,$12,$C3,$8F,$69,$21,$8C,$6A
  DEFB $0E,$13,$C3,$8F,$69,$21,$A2,$6A
  DEFB $0E,$01,$C3,$8F,$69,$16,$07,$00

; Message at 6A4E
  DEFM "Which ink?(0..9) "

; Data block at 6A5F
  DEFB $FF,$16,$07,$00

; Message at 6A63
  DEFM "Which paper?(0..9) "

; Data block at 6A76
  DEFB $FF,$16,$07,$00

; Message at 6A7A
  DEFM "Flash?(0,1 or 8) "

; Data block at 6A8B
  DEFB $FF,$16,$07,$00

; Message at 6A8F
  DEFM "Bright?(0,1 or 8) "

; Data block at 6AA1
  DEFB $FF,$16,$07,$00

; Message at 6AA5
  DEFM "Which border?(0..7) "

; Data block at 6AB9
  DEFB $FF,$16,$07,$00

; Message at 6ABD
  DEFM "Which picture number ?..."

; Data block at 6AD6
  DEFB $FF,$C5,$21,$17,$63,$A7,$ED

; Message at 6ADD
  DEFM "BT]"

; Data block at 6AE0
  DEFB $ED

; Message at 6AE1
  DEFM "KJc"

; Data block at 6AE4
  DEFB $A7,$ED

; Message at 6AE6
  DEFM "BDM!"

; Data block at 6AEA
  DEFB $17,$63,$EB,$03,$ED,$B8,$C1,$C9

; Routine at 6AF2
;
; Used by the routines at 664B and 7043.
  LD HL,$6352             ; HL=$6352
  LD D,(HL)               ; D=PEEK HL
  LD (HL),A               ; POKE HL,A
  PUSH DE                 ; Push DE onto the stack
  CALL $1601              ; CALL 1601
  POP AF                  ; Pop last item from stack into AF
  RET                     ; Return

; Data block at 6AFD
  DEFB $CD,$85,$6C,$3E,$02,$32,$00,$5B
  DEFB $CD,$A8,$6B,$C3,$5E,$6B,$21,$FF
  DEFB $00,$3E,$04,$CD,$85,$6C,$F5

; Message at 6B14
  DEFM "\"Cc"

; Data block at 6B17
  DEFB $CD,$A8,$6B,$CD,$74,$63,$F1,$18
  DEFB $E2,$21,$00,$00,$3E,$05,$18,$E9
  DEFB $21,$AA,$FF,$3E,$06,$18,$E2,$21
  DEFB $8A

; Message at 6B30
  DEFM "d>L"

; Data block at 6B33
  DEFB $06,$09,$CD,$85,$6C,$22,$10,$69
  DEFB $32,$AD

; Message at 6B3D
  DEFM "e!ik\""

; Data block at 6B42
  DEFB $AE,$65,$3E,$FF,$32,$B0

; Message at 6B48
  DEFM "ex2"

; Unused
  DEFS $01

; Message at 6B4C
  DEFM "[*Ac\"?c"

; Data block at 6B53
  DEFB $CD,$BC,$6B,$3E,$01

; Message at 6B58
  DEFM "2Lc"

; Data block at 6B5B
  DEFB $C3,$4B,$66,$01,$03,$00

; Message at 6B61
  DEFM "*Ac\""

; Data block at 6B65
  DEFB $01,$5B,$18,$36,$AF

; Message at 6B6A
  DEFM "2Lc"

; Data block at 6B6D
  DEFB $CD

; Message at 6B6E
  DEFM "Kf>"

; Data block at 6B71
  DEFB $7F,$32,$AD

; Message at 6B74
  DEFM "e!;i\""

; Data block at 6B79
  DEFB $AE,$65,$3E,$0F,$32,$B0,$65,$AF
  DEFB $CD,$9E,$71,$CD,$0F,$69,$21,$9B
  DEFB $64,$22,$10,$69,$CD,$B0,$6B,$01
  DEFB $05,$00

; Message at 6B93
  DEFM "*?c\""

; Data block at 6B97
  DEFB $01

; Message at 6B98
  DEFM "[*Ac\""

; Data block at 6B9D
  DEFB $03

; Message at 6B9E
  DEFM "[\"?c"

; Data block at 6BA2
  DEFB $CD,$05,$6A,$C3,$A8,$64

; Routine at 6BA8
;
; Used by the routine at 6BC8.
  LD A,$01                ; A=$01
  CALL $719E              ; CALL 719E
  JP $649B                ; Jump to 649B

; Data block at 6BB0
  DEFB $3A,$5F,$63,$A7,$C0,$3C,$32,$5F
  DEFB $63,$C3,$A8,$6B,$3A,$5F,$63,$A7
  DEFB $C8,$3D,$32,$5F,$63,$C3,$A8,$6B

; Routine at 6BC8
;
; Used by the routine at 6CB7.
  LD A,$01                ; A=$01
  LD ($635F),A            ; POKE $635F,A
  JP $6BA8                ; Jump to 6BA8

; Data block at 6BD0
  DEFB $21,$F7

; Message at 6BD2
  DEFM "d>R"

; Data block at 6BD5
  DEFB $06,$08,$C3

; Message at 6BD8
  DEFM "5k!"

; Data block at 6BDB
  DEFB $1D

; Message at 6BDC
  DEFM "e>E"

; Data block at 6BDF
  DEFB $06,$03,$C3,$35,$6B,$E1,$DD,$E1
  DEFB $3E,$07,$D3,$FE,$C3,$5D,$67,$CD
  DEFB $85,$6C,$3E,$01,$CD,$F2,$6A,$21
  DEFB $BA,$6A,$CD,$F9,$66,$CD,$04,$8A
  DEFB $3E,$11,$CD,$75,$6E,$D2,$1B,$6C
  DEFB $E5,$3E,$02,$CD,$F2,$6A,$D1

; Message at 6C0E
  DEFM "*Fc"

; Data block at 6C11
  DEFB $A7,$ED,$52,$28,$05,$CD

; Message at 6C17
  DEFM "Ph "

; Data block at 6C1A
  DEFB $07

; Message at 6C1B
  DEFM "!Ic5+5"

; Data block at 6C21
  DEFB $C9,$3E,$07,$32,$00,$5B,$ED,$53
  DEFB $01,$5B,$01,$03,$00,$CD,$05,$6A
  DEFB $CD,$BC,$6B,$CD,$4B,$66

; Routine at 6C37
;
; Used by the routines at 68C2 and 6C61.
  XOR A                   ; A=0
  CALL $719E              ; CALL 719E
  PUSH IX                 ; Push IX onto the stack
  POP HL                  ; Pop last item from stack into HL
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  INC HL                  ; HL=HL+1
  EX DE,HL                ; Exchange DE and HL
  LD HL,($6348)           ; L=PEEK $6348; H=PEEK $6349
  PUSH HL                 ; Push HL onto the stack
  LD HL,($634A)           ; L=PEEK $634A; H=PEEK $634B
  PUSH HL                 ; Push HL onto the stack
  LD ($6349),A            ; POKE $6349,A
  CALL $6CB7              ; CALL 6CB7
  POP HL                  ; Pop last item from stack into HL
  LD ($634A),HL           ; POKE $634A,L; POKE $634B,H
  POP HL                  ; Pop last item from stack into HL
  LD ($6348),HL           ; POKE $6348,L; POKE $6349,H
  LD A,$07                ; A=$07
  LD ($6363),A            ; POKE $6363,A
  RET                     ; Return

; Routine at 6C61
  LD A,$C9                ; A=$C9
  LD ($6CDF),A            ; POKE $6CDF,A
  EX DE,HL                ; Exchange DE and HL
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  INC HL                  ; HL=HL+1
  PUSH HL                 ; Push HL onto the stack
  LD A,($634E)            ; A=PEEK $634E
  PUSH AF                 ; Push AF onto the stack
  CALL $6850              ; CALL 6850
  CALL NZ,$6C37           ; CALL 6C37 if the zero flag is not set
  POP AF                  ; Pop last item from stack into AF
  LD ($634E),A            ; POKE $634E,A
  LD A,$CD                ; A=$CD
  LD ($6CDF),A            ; POKE $6CDF,A
  XOR A                   ; A=0
  CALL $719E              ; CALL 719E
  POP DE                  ; Pop last item from stack into DE
  RET                     ; Return

; Data block at 6C85
  DEFB $E5

; Message at 6C86
  DEFM "!Ic4("

; Data block at 6C8B
  DEFB $04,$2B,$34,$E1,$C9,$35,$E1,$E1
  DEFB $21,$ED,$67,$CD,$F2,$66,$CD

; Message at 6C9A
  DEFM "Wq>"

; Data block at 6C9D
  DEFB $11,$C3,$75,$6E,$F5,$AF

; Message at 6CA3
  DEFM "2cc"

; Data block at 6CA6
  DEFB $CD,$5D,$67,$CD,$40,$6F,$F1

; Message at 6CAD
  DEFM "!Ic"

; Data block at 6CB0
  DEFB $BE,$38,$01,$7E,$11,$18,$5E

; Routine at 6CB7
;
; Used by the routine at 6C37.
  LD ($6348),A            ; POKE $6348,A
  INC A                   ; A=A+1
  LD ($634E),A            ; POKE $634E,A
  LD HL,$634E             ; HL=$634E
  DEC (HL)                ; POKE HL,(PEEK HL)-1
  JR Z,$6CDB              ; Jump to 6CDB if (PEEK HL)=0
  LD A,(DE)               ; A=PEEK DE
  LD ($6363),A            ; POKE $6363,A
  INC DE                  ; DE=DE+1
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  LD HL,$6D69             ; HL=$6D69
  ADD A,L                 ; A=A+L
  JR NC,$6CD1             ; Jump to 6CD1 if the carry flag is not set
  INC H                   ; H=H+1
  LD L,A                  ; L=A
  LD A,(HL)               ; A=PEEK HL
  INC HL                  ; HL=HL+1
  LD H,(HL)               ; H=PEEK HL
  LD L,A                  ; L=A
  LD BC,$6CBE             ; BC=$6CBE
  PUSH BC                 ; Push BC onto the stack
  JP (HL)                 ; Jump to HL
  LD ($634A),DE           ; POKE $634A,E; POKE $634B,D
  CALL $64A8              ; CALL 64A8
  CALL $664B              ; CALL 664B
  JP $6BC8                ; Jump to 6BC8

; Routine at 6CE8
;
; Used by the routine at 6D08.
  LD A,(DE)               ; A=PEEK DE
  LD L,A                  ; L=A
  INC DE                  ; DE=DE+1
  LD A,(DE)               ; A=PEEK DE
  LD H,A                  ; H=A
  INC DE                  ; DE=DE+1
  LD ($633F),HL           ; POKE $633F,L; POKE $6340,H
; This entry point is used by the routine at 6D00.
  LD A,(DE)               ; A=PEEK DE
  LD L,A                  ; L=A
  INC DE                  ; DE=DE+1
  LD A,(DE)               ; A=PEEK DE
  LD H,A                  ; H=A
  INC DE                  ; DE=DE+1
  LD ($6341),HL           ; POKE $6341,L; POKE $6342,H
  PUSH DE                 ; Push DE onto the stack
  CALL $636E              ; CALL 636E
  POP DE                  ; Pop last item from stack into DE
  RET                     ; Return

; Routine at 6D00
  LD HL,$649B             ; HL=$649B
; This entry point is used by the routines at 6D10, 6D15 and 6D1A.
  LD ($6CFC),HL           ; POKE $6CFC,L; POKE $6CFD,H
  JR $6CF1                ; Jump to 6CF1

; Routine at 6D08
  LD HL,$651D             ; HL=$651D
; This entry point is used by the routines at 6D1F and 6D24.
  LD ($6CFC),HL           ; POKE $6CFC,L; POKE $6CFD,H
  JR $6CE8                ; Jump to 6CE8

; Routine at 6D10
  LD HL,$636E             ; HL=$636E
  JR $6D03                ; Jump to 6D03

; Routine at 6D15
  LD HL,$6364             ; HL=$6364
  JR $6D03                ; Jump to 6D03

; Routine at 6D1A
  LD HL,$6369             ; HL=$6369
  JR $6D03                ; Jump to 6D03

; Routine at 6D1F
  LD HL,$64F7             ; HL=$64F7
  JR $6D0B                ; Jump to 6D0B

; Routine at 6D24
  LD HL,$648A             ; HL=$648A
  JR $6D0B                ; Jump to 6D0B

; Routine at 6D29
  DEC DE                  ; DE=DE-1
  LD A,(DE)               ; A=PEEK DE
  RST $10                 ; CALL 0010
  INC DE                  ; DE=DE+1
  LD A,(DE)               ; A=PEEK DE
  RST $10                 ; CALL 0010
  INC DE                  ; DE=DE+1
  LD HL,($5C8F)           ; L=PEEK $5C8F; H=PEEK $5C90
  LD ($5C8D),HL           ; POKE $5C8D,L; POKE $5C8E,H
  RET                     ; Return

; Routine at 6D37
  LD A,(DE)               ; A=PEEK DE
  INC DE                  ; DE=DE+1
  PUSH DE                 ; Push DE onto the stack
  AND $07                 ; Keep only bits 0, 1 and 2 of A
  OUT ($FE),A             ; OUT $FE,A
  LD B,$00                ; B=$00
  BIT 2,A                 ; Set the zero flag if bit 2 of A is 0
  JR NZ,$6D46             ; Jump to 6D46 if bit 2 of A is set
  LD B,$07                ; B=$07
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  OR B                    ; A=A|B
  LD ($5C48),A            ; POKE $5C48,A
  LD HL,$5A00             ; HL=$5A00
  LD BC,$00FF             ; BC=$00FF
  LD D,A                  ; D=A
  LD A,($634F)            ; A=PEEK $634F
  DEC A                   ; A=A-1
  JR Z,$6D60              ; Jump to 6D60 if A=0
  LD HL,$5800             ; HL=$5800
  LD BC,$02FF             ; BC=$02FF
  LD A,D                  ; A=D
  LD D,H                  ; D=H
  LD E,L                  ; E=L
  INC DE                  ; DE=DE+1
  LD (HL),A               ; POKE HL,A
  LDIR                    ; POKE DE,PEEK HL; HL=HL+1; DE=DE+1; BC=BC-1; repeat
                          ; until BC=0
  POP DE                  ; Pop last item from stack into DE
  RET                     ; Return

; Data block at 6D69
  DEFB $FF

; Message at 6D6A
  DEFM "l7m"

; Data block at 6D6D
  DEFB $00,$6D,$08,$6D,$10,$6D,$15,$6D
  DEFB $1A

; Message at 6D76
  DEFM "mal"

; Data block at 6D79
  DEFB $1F

; Message at 6D7A
  DEFM "m$m"

; Data block at 6D7D
  DEFB $FF,$6C,$FF,$6C,$FF,$6C,$FF,$6C
  DEFB $FF,$6C,$FF

; Message at 6D88
  DEFM "l)m)m)m)m"

; Data block at 6D91
  DEFB $10,$00,$11,$07,$16,$03,$05,$95
  DEFB $95,$16,$03,$09,$20,$20,$16,$04
  DEFB $05,$95,$95,$16,$04,$09,$20,$20
  DEFB $16,$01,$00,$10,$07,$11,$01

; Message at 6DB0
  DEFM "PEN  INK PAP   X   Y   LAST PIC"

; Data block at 6DCF
  DEFB $16,$05,$00,$92,$93,$94,$16,$02
  DEFB $01,$90,$08,$0A,$91,$16,$03,$18
  DEFB $2F,$FF,$E6,$03

; Message at 6DE3
  DEFM "!Sc"

; Data block at 6DE6
  DEFB $BE,$C8,$C5,$D5

; Message at 6DEA
  DEFM "Fwx"

; Data block at 6DED
  DEFB $F5,$CD,$FB

; Message at 6DF0
  DEFM "m:Sc"

; Data block at 6DF4
  DEFB $CD,$12,$6E,$F1,$D1,$C1,$C9,$CD

; Message at 6DFC
  DEFM "(n:Ocw"

; Data block at 6E02
  DEFB $23,$3A,$48,$5C,$77,$23,$11,$84
  DEFB $5C,$EB,$01,$0E,$00,$ED,$B0,$C9
  DEFB $CD,$28,$6E,$7E

; Message at 6E16
  DEFM "2Oc"

; Data block at 6E19
  DEFB $23,$7E,$32,$48,$5C,$23,$11,$84
  DEFB $5C,$01,$0E,$00,$ED,$B0,$C9,$07
  DEFB $07,$07,$07

; Message at 6E2C
  DEFM "!5n"

; Data block at 6E2F
  DEFB $85,$30,$01,$24,$6F,$C9,$02,$38
  DEFB $00,$40,$00,$50,$21,$18,$21,$18
  DEFB $FF,$38,$00,$38,$00,$00,$02,$38
  DEFB $00,$40,$00,$50,$21,$18,$21,$18
  DEFB $FF,$38,$00,$38,$00,$00,$02,$38
  DEFB $00,$40,$00,$50,$21,$18,$21,$18
  DEFB $FF,$38,$00,$38,$00,$00,$02,$38
  DEFB $00,$40,$00,$50,$21,$18,$21,$18
  DEFB $FF,$38,$00,$38,$00,$00

; Routine at 6E75
;
; Used by the routines at 631E and 66F9.
  PUSH AF                 ; Push AF onto the stack
  PUSH BC                 ; Push BC onto the stack
  PUSH DE                 ; Push DE onto the stack
  PUSH HL                 ; Push HL onto the stack
  PUSH IX                 ; Push IX onto the stack
  LD HL,$6EC5             ; HL=$6EC5
  PUSH HL                 ; Push HL onto the stack
  LD HL,($6354)           ; L=PEEK $6354; H=PEEK $6355
  LD DE,$6356             ; DE=$6356
  LD (HL),A               ; POKE HL,A
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,DE               ; HL=HL-carry-DE
  JR NZ,$6E95             ; Jump to 6E95 if HL>0
  CP $20                  ; Set the zero flag if A=$20, or the carry flag if
                          ; A<$20
  JR C,$6E96              ; Jump to 6E96 if A<$20
  CP $A5                  ; Set the zero flag if A=$A5, or the carry flag if
                          ; A<$A5
  RET NC                  ; Return if A>=$A5
  JP $70AA                ; Jump to 70AA
  LD A,(DE)               ; A=PEEK DE
  LD B,L                  ; B=L
  LD HL,$70E5             ; HL=$70E5
  PUSH AF                 ; Push AF onto the stack
  LD A,(HL)               ; A=PEEK HL
  INC A                   ; A=A+1
  JR NZ,$6EA5             ; Jump to 6EA5 if A>0
  POP AF                  ; Pop last item from stack into AF
  LD ($6354),DE           ; POKE $6354,E; POKE $6355,D
  RET                     ; Return
  POP AF                  ; Pop last item from stack into AF
  CP (HL)                 ; Set the zero flag if A=PEEK HL, or the carry flag
                          ; if A<PEEK HL
  INC HL                  ; HL=HL+1
  JR Z,$6EAF              ; Jump to 6EAF if the zero flag is set
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  JR $6E9A                ; Jump to 6E9A
  LD A,(HL)               ; A=PEEK HL
  CP B                    ; Set the zero flag if A=B, or the carry flag if A<B
  JR Z,$6EBB              ; Jump to 6EBB if A=B
  LD HL,($6354)           ; L=PEEK $6354; H=PEEK $6355
  INC HL                  ; HL=HL+1
  LD ($6354),HL           ; POKE $6354,L; POKE $6355,H
  RET                     ; Return
  LD ($6354),DE           ; POKE $6354,E; POKE $6355,D
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  INC HL                  ; HL=HL+1
  LD H,(HL)               ; H=PEEK HL
  LD L,A                  ; L=A
  JP (HL)                 ; Jump to HL

; Routine at 6EC5
  POP IX                  ; Pop last item from stack into IX
  POP HL                  ; Pop last item from stack into HL
  POP DE                  ; Pop last item from stack into DE
  POP BC                  ; Pop last item from stack into BC
  POP AF                  ; Pop last item from stack into AF
  RET                     ; Return

; Routine at 6ECC
  INC DE                  ; DE=DE+1
  LD A,(DE)               ; A=PEEK DE
  CP $20                  ; Set the zero flag if A=$20, or the carry flag if
                          ; A<$20
  JR NC,$6ED4             ; Jump to 6ED4 if A>=$20
  LD A,$90                ; A=$90
  CALL $70AA              ; CALL 70AA
  RET                     ; Return

; Data block at 6ED8
  DEFB $21,$58,$02,$11,$82,$00,$C3,$B5
  DEFB $03,$3E,$08,$D7,$C9,$3A,$91,$5C
  DEFB $F5,$FD,$36,$57,$01,$3E,$20,$CD
  DEFB $AA,$70,$F1,$32,$91,$5C,$C9,$CD
  DEFB $83,$70,$3D,$18,$23

; Routine at 6EFD
  CALL $7083              ; CALL 7083
  INC A                   ; A=A+1
  LD B,A                  ; B=A
  LD A,($634F)            ; A=PEEK $634F
  LD C,$08                ; C=$08
  CP $02                  ; Set the zero flag if A=$02, or the carry flag if
                          ; A<$02
  JR NZ,$6F0D             ; Jump to 6F0D if A<>$02
  LD C,$17                ; C=$17
  LD A,B                  ; A=B
  CP C                    ; Set the zero flag if A=C, or the carry flag if A<C
  JR C,$6F20              ; Jump to 6F20 if A<C
  DEC B                   ; B=B-1
  PUSH BC                 ; Push BC onto the stack
  LD B,C                  ; B=C
  LD A,B                  ; A=B
  CP $17                  ; Set the zero flag if A=$17, or the carry flag if
                          ; A<$17
  JR Z,$6F1A              ; Jump to 6F1A if A=$17
  DEC B                   ; B=B-1
  CALL $0E00              ; CALL 0E00
  POP BC                  ; Pop last item from stack into BC
  JR $6F0D                ; Jump to 6F0D
  PUSH AF                 ; Push AF onto the stack
  LD A,$16                ; A=$16
  RST $10                 ; CALL 0010
  POP AF                  ; Pop last item from stack into AF
  RST $10                 ; CALL 0010
  CALL $7072              ; CALL 7072
  RST $10                 ; CALL 0010
  RET                     ; Return

; Routine at 6F2B
;
; Used by the routine at 714F.
  LD A,($634F)            ; A=PEEK $634F
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$6F40              ; Jump to 6F40 if A=0
  CP $02                  ; Set the zero flag if A=$02, or the carry flag if
                          ; A<$02
  JR Z,$6F50              ; Jump to 6F50 if A=$02
; This entry point is used by the routine at 664B.
  LD B,$03                ; B=$03
  LD A,($5C48)            ; A=PEEK $5C48
  CALL $6F7A              ; CALL 6F7A
  JP $705D                ; Jump to 705D
; This entry point is used by the routine at 68C2.
  LD B,$01                ; B=$01
  LD A,($5C8D)            ; A=PEEK $5C8D
  CALL $6F7A              ; CALL 6F7A
  LD B,$02                ; B=$02
  CALL $6F7A              ; CALL 6F7A
  JP $705D                ; Jump to 705D
  LD B,$01                ; B=$01
  LD A,($5C48)            ; A=PEEK $5C48
  CALL $6F7A              ; CALL 6F7A
  LD B,$02                ; B=$02
  CALL $6F7A              ; CALL 6F7A
  LD B,$03                ; B=$03
  CALL $6F7A              ; CALL 6F7A
  AND $F8                 ; Reset bits 0, 1 and 2 of A
  LD B,A                  ; B=A
  AND $38                 ; Keep only bits 3, 4 and 5 of A
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  OR B                    ; A=A|B
  LD HL,$5800             ; HL=$5800
  LD DE,$5801             ; DE=$5801
  LD BC,$001F             ; BC=$001F
  LD (HL),A               ; POKE HL,A
  LDIR                    ; POKE DE,PEEK HL; HL=HL+1; DE=DE+1; BC=BC-1; repeat
                          ; until BC=0
  JP $705D                ; Jump to 705D

; Routine at 6F7A
;
; Used by the routine at 6F2B.
  PUSH AF                 ; Push AF onto the stack
  LD A,B                  ; A=B
  LD HL,$3800             ; HL=$3800
  LD DE,$0800             ; DE=$0800
  ADD HL,DE               ; HL=HL+DE
  DJNZ $6F82              ; Decrement B and jump to 6F82 if B>0
  LD D,H                  ; D=H
  LD E,$01                ; E=$01
  LD BC,$07FF             ; BC=$07FF
  LD (HL),$00             ; POKE HL,$00
  LDIR                    ; POKE DE,PEEK HL; HL=HL+1; DE=DE+1; BC=BC-1; repeat
                          ; until BC=0
  ADD A,$57               ; A=A+$57
  LD H,A                  ; H=A
  LD L,$00                ; L=$00
  LD D,A                  ; D=A
  LD E,$01                ; E=$01
  LD BC,$00FF             ; BC=$00FF
  POP AF                  ; Pop last item from stack into AF
  LD (HL),A               ; POKE HL,A
  LDIR                    ; POKE DE,PEEK HL; HL=HL+1; DE=DE+1; BC=BC-1; repeat
                          ; until BC=0
  RET                     ; Return

; Routine at 6F9F
  LD A,$16                ; A=$16
  RST $10                 ; CALL 0010
  CALL $7083              ; CALL 7083
  RST $10                 ; CALL 0010
  XOR A                   ; A=0
  RST $10                 ; CALL 0010
  RET                     ; Return

; Data block at 6FA9
  DEFB $3E,$08,$D7,$3E,$20,$D7,$3E,$08
  DEFB $D7,$C9,$CD,$72,$70,$08,$CD,$9F
  DEFB $6F,$08

; Message at 6FBB
  DEFM "<G> "

; Data block at 6FBF
  DEFB $D7,$10,$FB,$3E,$08,$D7,$C9,$CD
  DEFB $83,$70,$F5,$CD

; Message at 6FCB
  DEFM "rpO> "

; Data block at 6FD0
  DEFB $91,$47,$CD,$BD,$6F,$3E,$16,$D7
  DEFB $F1,$D7,$79,$D7,$C9,$CD,$83,$70
  DEFB $A7,$28,$D0,$4F,$CD,$72,$70,$F5
  DEFB $CD,$5D,$70,$06

; Message at 6FEC
  DEFM " > "

; Data block at 6FEF
  DEFB $D7,$10,$FB,$0D,$20,$F6,$F1,$18
  DEFB $BE,$CD

; Message at 6FF9
  DEFM "rpO"

; Data block at 6FFC
  DEFB $CD,$83

; Message at 6FFE
  DEFM "pG:Oc"

; Data block at 7003
  DEFB $A7,$28,$08,$FE,$02,$28,$08,$3E
  DEFB $07,$18,$06,$3E,$0F,$18,$02,$3E
  DEFB $16,$90,$28,$AF,$C5,$11,$20,$00
  DEFB $21,$00,$00,$19,$10,$FD,$3E,$20
  DEFB $91,$4F,$09,$3E,$20,$D7,$2B,$7C
  DEFB $B5,$20,$F8,$C1,$3E,$16,$D7,$78
  DEFB $D7,$79,$D7,$C9,$3E,$14,$D7,$3E
  DEFB $00,$EE,$01

; Message at 703E
  DEFM "2;p"

; Data block at 7041
  DEFB $D7,$C9

; Routine at 7043
  INC DE                  ; DE=DE+1
  LD A,(DE)               ; A=PEEK DE
; This entry point is used by the routine at 714F.
  LD ($634F),A            ; POKE $634F,A
  CPL                     ; A=$FF-A
  ADD A,$03               ; A=A+$03
  CALL $6AF2              ; CALL 6AF2
  LD A,($634F)            ; A=PEEK $634F
  CP $02                  ; Set the zero flag if A=$02, or the carry flag if
                          ; A<$02
  LD A,$08                ; A=$08
  JR NZ,$7059             ; Jump to 7059 if the zero flag is not set
  LD A,$16                ; A=$16
  LD ($5C6B),A            ; POKE $5C6B,A
  RET                     ; Return

; Routine at 705D
;
; Used by the routine at 6F2B.
  LD A,$16                ; A=$16
  RST $10                 ; CALL 0010
  XOR A                   ; A=0
  RST $10                 ; CALL 0010
  XOR A                   ; A=0
  RST $10                 ; CALL 0010
  RET                     ; Return

; Routine at 7065
  LD A,$16                ; A=$16
  RST $10                 ; CALL 0010
  INC DE                  ; DE=DE+1
  INC DE                  ; DE=DE+1
  LD A,(DE)               ; A=PEEK DE
  DEC A                   ; A=A-1
  RST $10                 ; CALL 0010
  DEC DE                  ; DE=DE-1
  LD A,(DE)               ; A=PEEK DE
  DEC A                   ; A=A-1
  RST $10                 ; CALL 0010
  RET                     ; Return

; Routine at 7072
;
; Used by the routine at 6EFD.
  PUSH HL                 ; Push HL onto the stack
  LD A,($634F)            ; A=PEEK $634F
  LD HL,$5C8A             ; HL=$5C8A
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$707E             ; Jump to 707E if A>0
  DEC HL                  ; HL=HL-1
  DEC HL                  ; HL=HL-1
  LD A,$21                ; A=$21
  SUB (HL)                ; A=A-PEEK HL
  POP HL                  ; Pop last item from stack into HL
  RET                     ; Return

; Routine at 7083
;
; Used by the routines at 6EFD and 6F9F.
  PUSH HL                 ; Push HL onto the stack
  LD A,($634F)            ; A=PEEK $634F
  LD HL,$5C8B             ; HL=$5C8B
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$708F             ; Jump to 708F if A>0
  DEC HL                  ; HL=HL-1
  DEC HL                  ; HL=HL-1
  LD A,$18                ; A=$18
  SUB (HL)                ; A=A-PEEK HL
  POP HL                  ; Pop last item from stack into HL
  RET                     ; Return

; Data block at 7094
  DEFB $13,$1A,$F5,$3E,$11,$D7,$F1,$E6
  DEFB $07,$D7,$C9,$13,$1A,$F5,$3E,$10
  DEFB $D7,$F1,$E6,$07,$D7,$C9

; Routine at 70AA
;
; Used by the routines at 66F9, 6E75 and 6ECC.
  PUSH AF                 ; Push AF onto the stack
  CP $20                  ; Set the zero flag if A=$20, or the carry flag if
                          ; A<$20
  JR C,$70E2              ; Jump to 70E2 if A<$20
  LD A,($5C8A)            ; A=PEEK $5C8A
  DEC A                   ; A=A-1
  JR NZ,$70E2             ; Jump to 70E2 if A>0
  LD A,($634F)            ; A=PEEK $634F
  DEC A                   ; A=A-1
  LD A,($5C8B)            ; A=PEEK $5C8B
  JR Z,$70C4              ; Jump to 70C4 if the zero flag is set
  CP $02                  ; Set the zero flag if A=$02, or the carry flag if
                          ; A<$02
  JR NZ,$70E2             ; Jump to 70E2 if A<>$02
  JR $70C8                ; Jump to 70C8
  CP $11                  ; Set the zero flag if A=$11, or the carry flag if
                          ; A<$11
  JR NZ,$70E2             ; Jump to 70E2 if A<>$11
  PUSH BC                 ; Push BC onto the stack
  PUSH DE                 ; Push DE onto the stack
  PUSH HL                 ; Push HL onto the stack
  NEG                     ; A=$100-A
  ADD A,$18               ; A=A+$18
  LD B,A                  ; B=A
  LD A,$16                ; A=$16
  RST $10                 ; CALL 0010
  LD A,B                  ; A=B
  CP $16                  ; Set the zero flag if A=$16, or the carry flag if
                          ; A<$16
  JR NZ,$70D9             ; Jump to 70D9 if A<>$16
  INC B                   ; B=B+1
  RST $10                 ; CALL 0010
  XOR A                   ; A=0
  RST $10                 ; CALL 0010
  CALL $0E00              ; CALL 0E00
  POP HL                  ; Pop last item from stack into HL
  POP DE                  ; Pop last item from stack into DE
  POP BC                  ; Pop last item from stack into BC
  POP AF                  ; Pop last item from stack into AF
  RST $10                 ; CALL 0010
  RET                     ; Return

; Data block at 70E5
  DEFB $01,$01,$CC,$6E,$04,$01,$FF,$6C
  DEFB $07,$00,$D8,$6E,$08,$00,$E1,$6E
  DEFB $09,$00,$E5,$6E,$0A,$00,$FD,$6E
  DEFB $0B,$00,$F7,$6E,$0C,$00,$2B,$6F
  DEFB $0D,$00,$9F,$6F,$0E,$01,$94,$70
  DEFB $0F,$01,$9F,$70,$10,$00,$A9,$6F
  DEFB $11,$00,$B3,$6F,$12,$00,$C6,$6F
  DEFB $13,$00,$DD,$6F,$14,$00,$F8,$6F
  DEFB $18,$00,$37,$70,$1A,$01,$43,$70
  DEFB $1E,$00,$5D,$70,$1F,$02,$65,$70
  DEFB $FF

; Routine at 7136
;
; Used by the routine at 6321.
  LD A,($634F)            ; A=PEEK $634F
  LD HL,($5C8A)           ; L=PEEK $5C8A; H=PEEK $5C8B
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$7142             ; Jump to 7142 if A>0
  LD HL,($5C88)           ; L=PEEK $5C88; H=PEEK $5C89
  LD A,$22                ; A=$22
  SUB L                   ; A=A-L
  LD L,A                  ; L=A
  LD A,$19                ; A=$19
  SUB H                   ; A=A-H
  LD H,L                  ; H=L
  LD L,A                  ; L=A
  LD A,($5C8C)            ; A=PEEK $5C8C
  RET                     ; Return

; Routine at 714F
;
; Used by the routine at 6330.
  LD A,$02                ; A=$02
  CALL $7045              ; CALL 7045
  JP $6F2B                ; Jump to 6F2B

; Routine at 7157
;
; Used by the routine at 6318.
  PUSH HL                 ; Push HL onto the stack
  CALL $71E7              ; CALL 71E7
  JR NZ,$716C             ; Jump to 716C if the zero flag is not set
  LD HL,$5C3B             ; HL=$5C3B
  RES 5,(HL)              ; Reset bit 5 of (HL)
  BIT 5,(HL)              ; Set the zero flag if bit 5 of (HL) is 0
  CALL $7249              ; CALL 7249
  JR Z,$7162              ; Jump to 7162 if the zero flag is set
  LD A,($5C08)            ; A=PEEK $5C08
  CP $20                  ; Set the zero flag if A=$20, or the carry flag if
                          ; A<$20
  JR NZ,$717B             ; Jump to 717B if A<>$20
  CALL $1F54              ; CALL 1F54
  LD A,$20                ; A=$20
  JR C,$718A              ; Jump to 718A if the carry flag is set
  LD A,$FC                ; A=$FC
  JR $718A                ; Jump to 718A
  CP $0D                  ; Set the zero flag if A=$0D, or the carry flag if
                          ; A<$0D
  JR NC,$718A             ; Jump to 718A if A>=$0D
  SUB $06                 ; A=A-$06
  LD HL,$718D             ; HL=$718D
  ADD A,L                 ; A=A+L
  JR NC,$7188             ; Jump to 7188 if the carry flag is not set
  INC H                   ; H=H+1
  LD L,A                  ; L=A
  LD A,(HL)               ; A=PEEK HL
  POP HL                  ; Pop last item from stack into HL
  SCF                     ; Set the carry flag
  RET                     ; Return

; Data block at 718D
  DEFB $FD,$10,$F2,$F3,$F1,$F0,$7F

; Routine at 7194
;
; Used by the routine at 6333.
  LD DE,($5C7A)           ; E=PEEK $5C7A; D=PEEK $5C7B
  LD HL,($5C78)           ; L=PEEK $5C78; H=PEEK $5C79
  LD D,$00                ; D=$00
  RET                     ; Return

; Routine at 719E
;
; Used by the routines at 675D, 6BA8, 6C37 and 6C61.
  LD HL,$5C91             ; HL=$5C91
  AND $05                 ; Keep only bits 0 and 2 of A
  LD B,A                  ; B=A
  LD A,(HL)               ; A=PEEK HL
  AND $FA                 ; Reset bits 0 and 2 of A
  OR B                    ; A=A|B
  LD (HL),A               ; POKE HL,A
  RET                     ; Return

; Routine at 71AA
;
; Used by the routine at 6327.
  PUSH AF                 ; Push AF onto the stack
  PUSH HL                 ; Push HL onto the stack
  XOR A                   ; A=0
  LD HL,$71D0             ; HL=$71D0
; This entry point is used by the routine at 71C6.
  LD ($635E),A            ; POKE $635E,A
  LD A,($5C91)            ; A=PEEK $5C91
  PUSH AF                 ; Push AF onto the stack
  SET 0,A                 ; Set bit 0 of A
  LD ($5C91),A            ; POKE $5C91,A
  CALL $66F9              ; CALL 66F9
  POP AF                  ; Pop last item from stack into AF
  LD ($5C91),A            ; POKE $5C91,A
  POP HL                  ; Pop last item from stack into HL
  POP AF                  ; Pop last item from stack into AF
  RET                     ; Return

; Routine at 71C6
;
; Used by the routine at 6324.
  PUSH AF                 ; Push AF onto the stack
  PUSH HL                 ; Push HL onto the stack
  LD A,$01                ; A=$01
  LD HL,$71D3             ; HL=$71D3
  JP $71B0                ; Jump to 71B0

; Data block at 71D0
  DEFB $20,$08,$FF,$12,$01,$20,$12,$00
  DEFB $08,$FF,$CD,$54,$1F,$17,$E6,$01
  DEFB $EE,$01,$C9

; Message at 71E3
  DEFM "2bc"

; Data block at 71E6
  DEFB $C9

; Routine at 71E7
;
; Used by the routine at 7157.
  LD A,($6362)            ; A=PEEK $6362
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET Z                   ; Return if A=0
  LD HL,$6362             ; HL=$6362
  LD (HL),$00             ; POKE HL,$00
  RET                     ; Return

; Data block at 71F2
  DEFB $FE,$88,$2F,$A5,$FD,$A1,$04,$8A
  DEFB $8A,$82,$4F,$A5,$26,$85,$49,$72

; Routine at 7202
;
; Used by the routine at 88FE.
  PUSH DE                 ; Push DE onto the stack
  PUSH HL                 ; Push HL onto the stack
  CALL $632D              ; CALL 632D
  POP HL                  ; Pop last item from stack into HL
  POP DE                  ; Pop last item from stack into DE
; This entry point is used by the routines at 8505 and 88FE.
  LD A,D                  ; A=D
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7217              ; Jump to 7217 if A=0
  BIT 7,A                 ; Set the zero flag if bit 7 of A is 0
  JR Z,$7214              ; Jump to 7214 if bit 7 of A is reset
  XOR A                   ; A=0
  JR $7216                ; Jump to 7216
  LD A,$FF                ; A=$FF
  LD E,A                  ; E=A
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$7230             ; Jump to 7230 if A>0
  LD A,L                  ; A=L
  CP $30                  ; Set the zero flag if A=$30, or the carry flag if
                          ; A<$30
  JR C,$7228              ; Jump to 7228 if A<$30
  CP $B0                  ; Set the zero flag if A=$B0, or the carry flag if
                          ; A<$B0
  JR C,$722A              ; Jump to 722A if A<$B0
  LD A,$AF                ; A=$AF
  JR $722A                ; Jump to 722A
  LD A,$30                ; A=$30
  LD D,A                  ; D=A
  LD ($5C7D),DE           ; POKE $5C7D,E; POKE $5C7E,D
  RET                     ; Return
  BIT 7,A                 ; Set the zero flag if bit 7 of A is 0
  JR Z,$7224              ; Jump to 7224 if bit 7 of A is reset
  JR $7228                ; Jump to 7228

; Data block at 7236
  DEFB $E5,$2A,$51,$5C,$E5,$F5,$3E,$03
  DEFB $CD,$01,$16,$F1,$D7,$E1,$22,$51
  DEFB $5C,$E1,$C9

; Routine at 7249
;
; Used by the routine at 7157.
  PUSH AF                 ; Push AF onto the stack
  PUSH HL                 ; Push HL onto the stack
  LD HL,$725B             ; HL=$725B
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7266              ; Jump to 7266 if A=0
  IN A,($FE)              ; A=IN ($0100*A+$FE)
  INC HL                  ; HL=HL+1
  AND (HL)                ; A=A&PEEK HL
  JR NZ,$729B             ; Jump to 729B if A>0
  INC HL                  ; HL=HL+1
  JR $724E                ; Jump to 724E

; Data block at 725B
  DEFB $7F,$18,$FB,$06,$FD,$14,$BF,$0B
  DEFB $DF,$10,$00,$3E,$03,$CD,$2A,$63
  DEFB $F5

; Message at 726C
  DEFM "!zr"

; Data block at 726F
  DEFB $7E,$C6,$64,$28,$18,$CD,$1E,$63
  DEFB $23,$18,$F5,$BB,$9D,$9D,$E6,$FD
  DEFB $04,$BC,$DE,$0E,$01,$0A,$00,$FD
  DEFB $0A,$BC,$BD,$BD,$9C

; Message at 728C
  DEFM ">2v= "

; Data block at 7291
  DEFB $FC,$3E,$11,$CD,$1E,$63,$F1,$CD
  DEFB $2A,$63

; Routine at 729B
;
; Used by the routine at 7249.
  POP HL                  ; Pop last item from stack into HL
  POP AF                  ; Pop last item from stack into AF
  RET                     ; Return

; Data block at 729E
  DEFB $00,$22,$18,$5E

; Message at 72A2
  DEFM "ex\""

; Data block at 72A5
  DEFB $18,$5E,$21,$00,$00,$22,$E3,$A4
  DEFB $C9

; Routine at 72AE
;
; Used by the routine at 7B3F.
  LD HL,$A4E7             ; HL=$A4E7
  RES 7,(HL)              ; Reset bit 7 of (HL)
  RET                     ; Return

; Routine at 72B4
;
; Used by the routine at 75B6.
  LD HL,$9636             ; HL=$9636
  CALL $95D5              ; CALL 95D5
  RET                     ; Return

; Data block at 72BB
  DEFB $21,$E7,$A4,$CB,$FE,$21,$3F,$96
  DEFB $CD,$D5,$95,$C9

; Routine at 72C7
;
; Used by the routine at 7C3F.
  POP HL                  ; Pop last item from stack into HL
  LD ($A501),SP           ; POKE $A501,SP-lo; POKE $A502,SP-hi
  JP (HL)                 ; Jump to HL

; Data block at 72CD
  DEFB $7E,$A7,$C8,$E5,$CD,$E6,$77,$CD
  DEFB $93,$8C,$21,$18,$5E,$CD,$96,$7C
  DEFB $E1,$7E,$A7,$C8,$23,$FE,$3F,$28
  DEFB $E7,$E6,$80,$28,$F4,$23,$18,$F1
  DEFB $21,$4E,$96,$CD,$96,$7C,$2A,$27
  DEFB $A5,$C3,$CD,$72

; Routine at 72F9
;
; Used by the routines at 734F, 7358, 7371, 7393, 73A3, 73B3, 73E1, 740B, 74A2,
; 74B8, 752C, 75B6, 7666, 76B3, 76F6, 77AC, 7805, 792C and 7943.
  LD HL,($A537)           ; L=PEEK $A537; H=PEEK $A538
  PUSH HL                 ; Push HL onto the stack
  PUSH DE                 ; Push DE onto the stack
  LD DE,$A4A3             ; DE=$A4A3
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,DE               ; HL=HL-carry-DE
  POP DE                  ; Pop last item from stack into DE
  POP HL                  ; Pop last item from stack into HL
  CALL Z,$7FC8            ; CALL 7FC8 if the zero flag is set
  NOP                     ; Do nothing
  PUSH DE                 ; Push DE onto the stack
  DEC HL                  ; HL=HL-1
  LD D,(HL)               ; D=PEEK HL
  DEC HL                  ; HL=HL-1
  LD E,(HL)               ; E=PEEK HL
  LD ($A537),HL           ; POKE $A537,L; POKE $A538,H
  POP HL                  ; Pop last item from stack into HL
  EX DE,HL                ; Exchange DE and HL
  RET                     ; Return

; Routine at 7315
;
; Used by the routines at 733B, 734F, 7358, 7371, 738D, 7393, 73A3, 73B3, 7444,
; 74A2, 75B6, 7751, 781B, 792C and 79A1.
  EX DE,HL                ; Exchange DE and HL
  PUSH HL                 ; Push HL onto the stack
  LD HL,($A537)           ; L=PEEK $A537; H=PEEK $A538
  PUSH HL                 ; Push HL onto the stack
  PUSH DE                 ; Push DE onto the stack
  LD DE,$A4E3             ; DE=$A4E3
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,DE               ; HL=HL-carry-DE
  POP DE                  ; Pop last item from stack into DE
  POP HL                  ; Pop last item from stack into HL
  JR NZ,$732A             ; Jump to 732A if the zero flag is not set
  CALL $7FC8              ; CALL 7FC8
  LD BC,$2373             ; BC=$2373
  LD (HL),D               ; POKE HL,D
  INC HL                  ; HL=HL+1
  LD ($A537),HL           ; POKE $A537,L; POKE $A538,H
  POP HL                  ; Pop last item from stack into HL
  EX DE,HL                ; Exchange DE and HL
  RET                     ; Return

; Routine at 7334
;
; Used by the routines at 7967 and 7B3F.
  LD HL,$A4A3             ; HL=$A4A3
  LD ($A537),HL           ; POKE $A537,L; POKE $A538,H
  RET                     ; Return

; Routine at 733B
  LD HL,$7FFF             ; HL=$7FFF
  JP $7315                ; Jump to 7315

; Data block at 7341
  DEFB $CD,$F9,$72,$C3,$92,$88,$AF,$32
  DEFB $E3,$A4,$C3,$96,$83,$00

; Routine at 734F
;
; Used by the routines at 76B3 and 76F6.
  CALL $72F9              ; CALL 72F9
  CALL $7315              ; CALL 7315
  JP $7315                ; Jump to 7315

; Routine at 7358
;
; Used by the routine at 749C.
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  OR L                    ; A=A|L
  LD HL,$0000             ; HL=$0000
  JR NZ,$7363             ; Jump to 7363 if the zero flag is not set
  INC HL                  ; HL=HL+1
  JP $7315                ; Jump to 7315

; Data block at 7366
  DEFB $CD,$F9,$72,$EB,$CD,$F9,$72,$19
  DEFB $C3,$15,$73

; Routine at 7371
;
; Used by the routine at 74A2.
  CALL $72F9              ; CALL 72F9
  EX DE,HL                ; Exchange DE and HL
  CALL $72F9              ; CALL 72F9
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,DE               ; HL=HL-carry-DE
  JP $7315                ; Jump to 7315

; Data block at 737E
  DEFB $CD,$F9,$72,$EB,$CD,$F9,$72,$EB
  DEFB $CD,$15,$73,$EB,$C3,$15,$73

; Routine at 738D
;
; Used by the routines at 7660 and 8378.
  LD HL,($A4ED)           ; L=PEEK $A4ED; H=PEEK $A4EE
  JP $7315                ; Jump to 7315

; Routine at 7393
  CALL $72F9              ; CALL 72F9
  EX DE,HL                ; Exchange DE and HL
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  AND D                   ; A=A&D
  LD H,A                  ; H=A
  LD A,L                  ; A=L
  AND E                   ; A=A&E
  LD L,A                  ; L=A
  JP $7315                ; Jump to 7315

; Routine at 73A3
  CALL $72F9              ; CALL 72F9
  EX DE,HL                ; Exchange DE and HL
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  OR D                    ; A=A|D
  LD H,A                  ; H=A
  LD A,L                  ; A=L
  OR E                    ; A=A|E
  LD L,A                  ; L=A
  JP $7315                ; Jump to 7315

; Routine at 73B3
;
; Used by the routine at 749C.
  CALL $72F9              ; CALL 72F9
  EX DE,HL                ; Exchange DE and HL
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  XOR D                   ; A=A^D
  LD H,A                  ; H=A
  LD A,L                  ; A=L
  XOR E                   ; A=A^E
  LD L,A                  ; L=A
  JP $7315                ; Jump to 7315

; Data block at 73C3
  DEFB $2A,$EB,$A4

; Message at 73C6
  DEFM "DM))"

; Data block at 73CA
  DEFB $09

; Message at 73CB
  DEFM ")))"

; Data block at 73CE
  DEFB $09,$23,$22,$EB,$A4,$EB,$CD,$F9
  DEFB $72,$7D,$CD,$59,$88,$6C,$26,$00
  DEFB $C3,$15,$73

; Routine at 73E1
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  OR L                    ; A=A|L
  LD HL,($A4E8)           ; L=PEEK $A4E8; H=PEEK $A4E9
  JR Z,$73F3              ; Jump to 73F3 if the zero flag is set
  LD A,($A4E7)            ; A=PEEK $A4E7
  OR $08                  ; Set bit 3 of A
  LD ($A4E7),A            ; POKE $A4E7,A
  RET NZ                  ; Return if the zero flag is not set
  BIT 7,(HL)              ; Set the zero flag if bit 7 of (HL) is 0
  JR Z,$73FC              ; Jump to 73FC if bit 7 of PEEK HL is reset
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  JR $73F4                ; Jump to 73F4
  LD A,(HL)               ; A=PEEK HL
  CP $3F                  ; Set the zero flag if A=$3F, or the carry flag if
                          ; A<$3F
  JR Z,$7407              ; Jump to 7407 if A=$3F
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7407              ; Jump to 7407 if A=0
  INC HL                  ; HL=HL+1
  JR $73F4                ; Jump to 73F4
  LD ($A4E8),HL           ; POKE $A4E8,L; POKE $A4E9,H
  RET                     ; Return

; Routine at 740B
;
; Used by the routines at 7428 and 7444.
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7416              ; Jump to 7416 if A=0
  CALL $7FC8              ; CALL 7FC8
  EX AF,AF'               ; Exchange AF and AF'
  LD B,L                  ; B=L
  INC B                   ; B=B+1
  LD HL,$A482             ; HL=$A482
  LD A,$80                ; A=$80
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  JR NC,$7421             ; Jump to 7421 if the carry flag is not set
  INC HL                  ; HL=HL+1
  DJNZ $741D              ; Decrement B and jump to 741D if B>0
  LD E,A                  ; E=A
  XOR $FF                 ; Flip every bit of A
  LD D,A                  ; D=A
  RET                     ; Return

; Routine at 7428
  CALL $740B              ; CALL 740B
  LD A,(HL)               ; A=PEEK HL
  OR E                    ; A=A|E
  LD (HL),A               ; POKE HL,A
  RET                     ; Return

; Data block at 742F
  DEFB $CD,$0B,$74,$7E,$A2,$77,$C9,$CD
  DEFB $0B,$74,$7E,$A3,$21,$00,$00,$28
  DEFB $01,$23,$C3,$15,$73

; Routine at 7444
  CALL $740B              ; CALL 740B
  LD A,(HL)               ; A=PEEK HL
  AND E                   ; A=A&E
  LD HL,$0000             ; HL=$0000
  JR NZ,$744F             ; Jump to 744F if the zero flag is not set
  INC HL                  ; HL=HL+1
  JP $7315                ; Jump to 7315

; Data block at 7452
  DEFB $CD,$F9,$72,$7C,$A7,$20,$05,$7D
  DEFB $E6,$80,$28,$04,$CD,$C8,$7F,$08
  DEFB $EB,$21,$03,$A4,$19,$C9,$CD

; Message at 7469
  DEFM "Rt4"

; Data block at 746C
  DEFB $C0,$35,$C9,$CD,$52,$74,$7E,$A7
  DEFB $C8,$35,$C9,$CD,$52,$74,$EB,$CD
  DEFB $F9,$72,$7D,$12,$C9,$CD

; Message at 7482
  DEFM "Rtn&"

; Data block at 7486
  DEFB $00,$C3,$15,$73,$CD,$52,$74,$EB
  DEFB $CD,$F9,$72,$1A,$BD,$21,$00,$00
  DEFB $20,$01,$23,$C3,$15,$73

; Routine at 749C
;
; Used by the routine at 8378.
  CALL $73B3              ; CALL 73B3
  JP $7358                ; Jump to 7358

; Routine at 74A2
  CALL $7371              ; CALL 7371
  CALL $72F9              ; CALL 72F9
  BIT 7,H                 ; Set the zero flag if bit 7 of H is 0
  LD HL,$0000             ; HL=$0000
  JR Z,$74B0              ; Jump to 74B0 if the zero flag is set
  INC HL                  ; HL=HL+1
  JP $7315                ; Jump to 7315

; Data block at 74B3
  DEFB $CD,$7E,$73,$18,$EA

; Routine at 74B8
;
; Used by the routines at 76B3, 7751, 7761 and 77AC.
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$74C3              ; Jump to 74C3 if A=0
  CALL $7FC8              ; CALL 7FC8
  DEC B                   ; B=B-1
  EX DE,HL                ; Exchange DE and HL
  LD HL,$A1FD             ; HL=$A1FD
  ADD HL,DE               ; HL=HL+DE
  ADD HL,DE               ; HL=HL+DE
  RET                     ; Return

; Data block at 74CA
  DEFB $21,$67,$96,$CD,$6C,$88,$CD,$8F
  DEFB $8E,$21,$3E,$9F,$CD,$6C,$88,$3A
  DEFB $00,$5B,$A7,$20,$05,$3E,$FF,$32
  DEFB $00,$5B,$CD,$E0,$8E,$21,$1F,$A5
  DEFB $DD,$21,$00,$5B,$DD,$36,$00,$03
  DEFB $DD,$36,$0B,$00,$DD,$36,$0C,$80
  DEFB $3E,$01,$32,$74,$5C,$01,$5A,$07
  DEFB $C3,$53,$85,$CD,$F9,$72

; Routine at 7508
;
; Used by the routine at 7666.
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7510              ; Jump to 7510 if A=0
  CALL $7FC8              ; CALL 7FC8
  DEC B                   ; B=B-1
  LD C,L                  ; C=L
  LD HL,($A523)           ; L=PEEK $A523; H=PEEK $A524
  CALL $8A75              ; CALL 8A75
  JR C,$750C              ; Jump to 750C if the carry flag is set
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
; This entry point is used by the routine at 75B6.
  LD DE,$5E18             ; DE=$5E18
  CALL $874F              ; CALL 874F
  DEC DE                  ; DE=DE-1
  DEC A                   ; A=A-1
  LD (DE),A               ; POKE DE,A
  LD HL,$5E18             ; HL=$5E18
  CALL $886C              ; CALL 886C
  RET                     ; Return

; Routine at 752C
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7537              ; Jump to 7537 if A=0
  CALL $7FC8              ; CALL 7FC8
  LD B,$4D                ; B=$4D
; This entry point is used by the routines at 75B6, 76B3, 76E0, 76F6, 77B8,
; 7B03 and 7C3F.
  LD HL,($A52D)           ; L=PEEK $A52D; H=PEEK $A52E
  CALL $8A75              ; CALL 8A75
  JR C,$7533              ; Jump to 7533 if the carry flag is set
  LD DE,$5E18             ; DE=$5E18
  CALL $874F              ; CALL 874F
  DEC DE                  ; DE=DE-1
  DEC A                   ; A=A-1
  LD (DE),A               ; POKE DE,A
  LD HL,$5E18             ; HL=$5E18
  JP $886C                ; Jump to 886C

; Routine at 754F
;
; Used by the routines at 778A and 77B8.
  LD HL,$96B1             ; HL=$96B1
  CALL $886C              ; CALL 886C
  RET                     ; Return

; Data block at 7556
  DEFB $CD,$4F,$73,$CD,$B8,$74,$5E,$23
  DEFB $56,$7E,$FE,$7F,$20,$1F,$ED,$5B
  DEFB $ED,$A4

; Message at 7568
  DEFM "r+s"

; Data block at 756B
  DEFB $CD,$F9

; Message at 756D
  DEFM "rM*"

; Data block at 7570
  DEFB $23,$A5,$CD,$75,$8A,$30,$04,$CD
  DEFB $C8,$7F,$05,$3A,$EF,$A4,$96,$32
  DEFB $EF,$A4,$C9,$CD,$F9,$72,$E5,$0E
  DEFB $F6,$CD,$38,$75,$E1,$C3,$F2,$78
  DEFB $11,$19,$5E,$18,$03,$21,$00,$5B
  DEFB $7E,$FE,$20,$C0,$23,$18,$F9,$CD
  DEFB $B8,$74,$E5,$CD,$B8,$74,$D1,$1A
  DEFB $47,$7E,$12,$78,$77,$13,$23,$1A
  DEFB $47,$7E,$12,$78,$77,$C9

; Routine at 75B6
;
; Used by the routine at 7660.
  CALL $72F9              ; CALL 72F9
  LD A,($A483)            ; A=PEEK $A483
  AND $06                 ; Keep only bits 1 and 2 of A
  JR NZ,$75D3             ; Jump to 75D3 if A>0
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $80                 ; Keep only bit 7 of A
  JR NZ,$75CD             ; Jump to 75CD if A>0
  CALL $72B4              ; CALL 72B4
  CALL $72C0              ; CALL 72C0
  LD C,$FB                ; C=$FB
  CALL $7538              ; CALL 7538
  RET                     ; Return
  LD A,($A483)            ; A=PEEK $A483
  OR $01                  ; Set bit 0 of A
  LD ($A483),A            ; POKE $A483,A
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $80                 ; Keep only bit 7 of A
  JR NZ,$760D             ; Jump to 760D if A>0
  PUSH HL                 ; Push HL onto the stack
  CALL $7315              ; CALL 7315
  POP BC                  ; Pop last item from stack into BC
  LD HL,($A525)           ; L=PEEK $A525; H=PEEK $A526
  CALL $8A3F              ; CALL 8A3F
  LD C,(HL)               ; C=PEEK HL
  INC HL                  ; HL=HL+1
  LD B,(HL)               ; B=PEEK HL
  LD A,B                  ; A=B
  OR C                    ; A=A|C
  JR Z,$7601              ; Jump to 7601 if A=0
  PUSH BC                 ; Push BC onto the stack
  CALL $72B4              ; CALL 72B4
  POP BC                  ; Pop last item from stack into BC
  LD HL,($A52F)           ; L=PEEK $A52F; H=PEEK $A530
  CALL $8A59              ; CALL 8A59
  JR $7605                ; Jump to 7605
  CALL $72C0              ; CALL 72C0
  SCF                     ; Set the carry flag
  JR C,$760A              ; Jump to 760A if the carry flag is set
  CALL $7649              ; CALL 7649
  CALL $72F9              ; CALL 72F9
  LD B,H                  ; B=H
  LD C,L                  ; C=L
  LD HL,($A525)           ; L=PEEK $A525; H=PEEK $A526
  CALL $8A3F              ; CALL 8A3F
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  JR NC,$761D             ; Jump to 761D if the carry flag is not set
  CALL $7FC8              ; CALL 7FC8
  INC B                   ; B=B+1
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7626              ; Jump to 7626 if A=0
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  JR $761D                ; Jump to 761D
  INC HL                  ; HL=HL+1
  CALL $751C              ; CALL 751C
  LD HL,($A537)           ; L=PEEK $A537; H=PEEK $A538
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  EX DE,HL                ; Exchange DE and HL
  PUSH HL                 ; Push HL onto the stack
  LD A,$C9                ; A=$C9
  LD ($631E),A            ; POKE $631E,A
  CALL $7669              ; CALL 7669
  CALL $7749              ; CALL 7749
  POP HL                  ; Pop last item from stack into HL
  RET Z                   ; Return if the zero flag is set
  PUSH HL                 ; Push HL onto the stack
  LD C,$FD                ; C=$FD
  CALL $7538              ; CALL 7538
  POP HL                  ; Pop last item from stack into HL
  JP $7669                ; Jump to 7669

; Routine at 7649
;
; Used by the routine at 75B6.
  PUSH IX                 ; Push IX onto the stack
  PUSH HL                 ; Push HL onto the stack
  POP IX                  ; Pop last item from stack into IX
  CALL $6336              ; CALL 6336
  POP IX                  ; Pop last item from stack into IX
  LD HL,$9639             ; HL=$9639
  CALL $886C              ; CALL 886C
  LD HL,$96B1             ; HL=$96B1
  CALL $886C              ; CALL 886C
  RET                     ; Return

; Routine at 7660
;
; Used by the routines at 7805 and 7B3F.
  CALL $738D              ; CALL 738D
  JP $75B6                ; Jump to 75B6

; Routine at 7666
;
; Used by the routine at 76A8.
  CALL $72F9              ; CALL 72F9
; This entry point is used by the routine at 75B6.
  LD A,H                  ; A=H
  OR L                    ; A=A|L
  JR NZ,$7671             ; Jump to 7671 if A>0
  CALL $7FC8              ; CALL 7FC8
  EX AF,AF'               ; Exchange AF and AF'
  EX DE,HL                ; Exchange DE and HL
  LD HL,$A1FD             ; HL=$A1FD
  XOR A                   ; A=0
  LD ($A4F0),A            ; POKE $A4F0,A
  LD C,(HL)               ; C=PEEK HL
  INC HL                  ; HL=HL+1
  LD B,(HL)               ; B=PEEK HL
  DEC HL                  ; HL=HL-1
  PUSH DE                 ; Push DE onto the stack
  PUSH HL                 ; Push HL onto the stack
  PUSH AF                 ; Push AF onto the stack
  LD A,B                  ; A=B
  XOR D                   ; A=A^D
  JR NZ,$769B             ; Jump to 769B if A>0
  LD A,C                  ; A=C
  XOR E                   ; A=A^E
  JR NZ,$769B             ; Jump to 769B if A>0
  LD A,($A4F0)            ; A=PEEK $A4F0
  CALL $631E              ; CALL 631E
  POP AF                  ; Pop last item from stack into AF
  PUSH AF                 ; Push AF onto the stack
  LD L,A                  ; L=A
  LD H,$00                ; H=$00
  CALL $7508              ; CALL 7508
  LD A,$2C                ; A=$2C
  LD ($A4F0),A            ; POKE $A4F0,A
  POP AF                  ; Pop last item from stack into AF
  POP HL                  ; Pop last item from stack into HL
  POP DE                  ; Pop last item from stack into DE
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  INC A                   ; A=A+1
  JR NZ,$7679             ; Jump to 7679 if A>0
  LD A,($A4F0)            ; A=PEEK $A4F0
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET                     ; Return

; Routine at 76A8
  CALL $7666              ; CALL 7666
  RET NZ                  ; Return if the zero flag is not set
  LD HL,$96B4             ; HL=$96B4
  CALL $886C              ; CALL 886C
  RET                     ; Return

; Routine at 76B3
  CALL $734F              ; CALL 734F
  CALL $74B8              ; CALL 74B8
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  DEC HL                  ; HL=HL-1
  EX DE,HL                ; Exchange DE and HL
  LD BC,($A4ED)           ; C=PEEK $A4ED; B=PEEK $A4EE
  LD A,H                  ; A=H
  CP $7F                  ; Set the zero flag if A=$7F, or the carry flag if
                          ; A<$7F
  JR NZ,$76E0             ; Jump to 76E0 if A<>$7F
  LD C,$F5                ; C=$F5
  CALL $7538              ; CALL 7538
; This entry point is used by the routine at 76E0.
  CALL $72F9              ; CALL 72F9
  JP $78F2                ; Jump to 78F2

; Data block at 76D2
  DEFB $3A,$83,$A4,$E6,$08,$CC,$4F,$75
  DEFB $CC,$28,$77,$C3,$4F,$75

; Routine at 76E0
;
; Used by the routine at 76B3.
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,BC               ; HL=HL-carry-BC
  JR Z,$76F6              ; Jump to 76F6 if HL=0
  LD C,$F7                ; C=$F7
  CALL $7538              ; CALL 7538
  JR $76CC                ; Jump to 76CC

; Data block at 76EC
  DEFB $3E,$20,$12,$13,$7B,$FE,$04,$20
  DEFB $F7,$C9

; Routine at 76F6
;
; Used by the routine at 76E0.
  PUSH DE                 ; Push DE onto the stack
  CALL $734F              ; CALL 734F
  CALL $72F9              ; CALL 72F9
  LD C,L                  ; C=L
  LD HL,($A523)           ; L=PEEK $A523; H=PEEK $A524
  CALL $8A75              ; CALL 8A75
  JR NC,$770A             ; Jump to 770A if the carry flag is not set
  CALL $7FC8              ; CALL 7FC8
  DEC B                   ; B=B-1
  LD E,(HL)               ; E=PEEK HL
  LD A,($A4EF)            ; A=PEEK $A4EF
  ADD A,E                 ; A=A+E
  LD HL,$A4EA             ; HL=$A4EA
  CP (HL)                 ; Set the zero flag if A=PEEK HL, or the carry flag
                          ; if A<PEEK HL
  JR NC,$7721             ; Jump to 7721 if A>=PEEK HL
  LD ($A4EF),A            ; POKE $A4EF,A
  POP HL                  ; Pop last item from stack into HL
  LD (HL),$FF             ; POKE HL,$FF
  INC HL                  ; HL=HL+1
  LD (HL),$7F             ; POKE HL,$7F
  JP $72F9                ; Jump to 72F9
  LD C,$F8                ; C=$F8
  CALL $7538              ; CALL 7538
  JR $7745                ; Jump to 7745

; Data block at 7728
  DEFB $0E,$F9,$CD

; Message at 772B
  DEFM "8u*"

; Data block at 772E
  DEFB $03,$A4,$26,$00,$CD,$92,$88,$0E
  DEFB $FA,$CD,$38,$75,$CD,$7E,$83,$CD
  DEFB $41,$73,$0E,$FF,$C3,$38,$75,$D1
  DEFB $C3,$CC,$76

; Routine at 7749
;
; Used by the routine at 75B6.
  PUSH AF                 ; Push AF onto the stack
  LD A,$C3                ; A=$C3
  LD ($631E),A            ; POKE $631E,A
  POP AF                  ; Pop last item from stack into AF
  RET                     ; Return

; Routine at 7751
  CALL $74B8              ; CALL 74B8
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  CP $7F                  ; Set the zero flag if A=$7F, or the carry flag if
                          ; A<$7F
; This entry point is used by the routine at 7761.
  LD HL,$0000             ; HL=$0000
  JR NZ,$775E             ; Jump to 775E if the zero flag is not set
  INC HL                  ; HL=HL+1
  JP $7315                ; Jump to 7315

; Routine at 7761
  CALL $74B8              ; CALL 74B8
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  LD HL,($A4ED)           ; L=PEEK $A4ED; H=PEEK $A4EE
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,DE               ; HL=HL-carry-DE
  JR $7758                ; Jump to 7758

; Data block at 776F
  DEFB $CD,$B8,$74,$5E,$23,$56,$7A,$FE
  DEFB $7F,$28,$F3,$18,$EB,$CD,$B8,$74
  DEFB $5E,$23,$56,$CD,$F9,$72,$A7,$ED
  DEFB $52,$18,$E3

; Routine at 778A
  CALL $631E              ; CALL 631E
  CALL $864B              ; CALL 864B
  RET NZ                  ; Return if the zero flag is not set
  PUSH HL                 ; Push HL onto the stack
  PUSH HL                 ; Push HL onto the stack
  CALL $6321              ; CALL 6321
  LD B,H                  ; B=H
  POP HL                  ; Pop last item from stack into HL
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  INC B                   ; B=B+1
  CALL $864B              ; CALL 864B
  JR Z,$77A2              ; Jump to 77A2 if the zero flag is set
  CP $FF                  ; Set the zero flag if A=$FF, or the carry flag if
                          ; A<$FF
  JR NZ,$7798             ; Jump to 7798 if A<>$FF
  LD A,B                  ; A=B
  CP $21                  ; Set the zero flag if A=$21, or the carry flag if
                          ; A<$21
  CALL NC,$754F           ; CALL 754F if A>=$21
  POP HL                  ; Pop last item from stack into HL
  RET                     ; Return

; Routine at 77AC
  CALL $72F9              ; CALL 72F9
  PUSH HL                 ; Push HL onto the stack
  CALL $74B8              ; CALL 74B8
  POP DE                  ; Pop last item from stack into DE
  LD (HL),E               ; POKE HL,E
  INC HL                  ; HL=HL+1
  LD (HL),D               ; POKE HL,D
  RET                     ; Return

; Routine at 77B8
;
; Used by the routine at 7BA4.
  CALL $754F              ; CALL 754F
  JP $7538                ; Jump to 7538

; Data block at 77BE
  DEFB $CD,$B8,$74,$5E,$23,$56,$7A,$FE
  DEFB $7F,$28,$16,$B3,$28,$08,$ED,$5B
  DEFB $ED,$A4

; Message at 77D0
  DEFM "r+s"

; Data block at 77D3
  DEFB $C9,$0E,$FC,$CD,$38,$75,$C3,$F2
  DEFB $78,$C3,$30,$63,$0E,$F5,$CD,$38
  DEFB $75,$18,$F3,$E5,$CD,$F1,$84,$E1
  DEFB $C9,$3A,$E3,$A4,$A7,$CA,$5F,$8F
  DEFB $AF,$32,$E3,$A4,$C3,$10,$90,$CA
  DEFB $5F,$8F,$3E,$FF,$32,$E3,$A4,$C3
  DEFB $F4,$8F

; Routine at 7805
  CALL $72F9              ; CALL 72F9
; This entry point is used by the routine at 7B79.
  LD ($A4ED),HL           ; POKE $A4ED,L; POKE $A4EE,H
  JP $7660                ; Jump to 7660

; Data block at 780E
  DEFB $3A,$E3,$A4,$18,$08

; Routine at 7813
  LD A,($A4E5)            ; A=PEEK $A4E5
  JR $781B                ; Jump to 781B

; Data block at 7818
  DEFB $3A,$E6,$A4

; Routine at 781B
;
; Used by the routine at 7813.
  LD L,A                  ; L=A
  LD H,$00                ; H=$00
  JP $7315                ; Jump to 7315

; Data block at 7821
  DEFB $3A,$E3,$A4,$C3,$1B,$78,$CD,$B8
  DEFB $74,$23,$7E,$FE,$7F,$C8,$2B,$B6
  DEFB $CA,$D4,$77,$5E,$23,$56,$EB,$C3
  DEFB $08,$78,$CD,$F9,$72,$7C,$A7,$28
  DEFB $04,$CD,$C8,$7F,$05,$4D,$2A,$23
  DEFB $A5,$CD,$75,$8A,$38,$F3,$7E,$6F
  DEFB $26,$00,$C3,$15,$73,$ED,$4B,$ED
  DEFB $A4,$2A,$25,$A5,$CD,$3F,$8A,$23
  DEFB $23,$30,$04,$CD,$C8,$7F,$04,$EB
  DEFB $CD,$F9,$72,$7C,$A7,$28,$04,$CD
  DEFB $C8,$7F,$08,$EB,$7E,$A7,$20,$06
  DEFB $21,$00,$00,$C3,$15,$73,$BB,$28
  DEFB $05,$23,$23,$23,$18,$EE,$23,$5E
  DEFB $23,$56,$EB,$C3,$15,$73,$DD,$E5
  DEFB $21,$BC,$96,$CD,$6C,$88,$CD,$8F
  DEFB $8E,$21,$3E,$9F,$CD,$6C,$88,$CD
  DEFB $E0,$8E,$21,$FD,$A4,$11,$FD,$A1
  DEFB $CD,$BE,$8E,$DD,$E1,$C9,$00,$00
  DEFB $00,$00,$DD,$E5,$2A,$E8,$A4,$22
  DEFB $AF,$78,$2A,$F4,$A4,$22,$B1,$78
  DEFB $21,$BC,$96,$CD,$6C,$88,$21,$FD
  DEFB $A1,$22,$E8,$74,$CD,$D0,$74,$21
  DEFB $1F,$A5,$22,$E8,$74,$2A,$AF,$78
  DEFB $22,$E8,$A4,$2A,$B1,$78,$22,$F4
  DEFB $A4,$DD,$E1,$21,$36,$96,$CD,$6C
  DEFB $88,$C3,$4F,$75,$0E,$FE,$CD

; Message at 78F0
  DEFM "8u!"

; Data block at 78F3
  DEFB $B1,$96,$CD,$6C,$88

; Routine at 78F8
  LD A,($A4E7)            ; A=PEEK $A4E7
  OR $40                  ; Set bit 6 of A
  LD ($A4E7),A            ; POKE $A4E7,A
  RET                     ; Return

; Data block at 7901
  DEFB $00,$0E,$F4,$CD,$38,$75,$00,$18
  DEFB $00,$CD,$24,$63,$CD,$18,$63,$CD
  DEFB $27,$63,$E6,$DF,$FE,$4E,$C8,$3A
  DEFB $E7,$A4,$F6,$20,$32,$E7,$A4,$C3
  DEFB $D2,$76,$00

; Routine at 7924
  LD A,($A4E3)            ; A=PEEK $A4E3
  JR $792C                ; Jump to 792C

; Data block at 7929
  DEFB $3A,$E4,$A4

; Routine at 792C
;
; Used by the routine at 7924.
  LD E,A                  ; E=A
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7938              ; Jump to 7938 if A=0
  CALL $7FC8              ; CALL 7FC8
  EX AF,AF'               ; Exchange AF and AF'
  LD A,L                  ; A=L
  CP E                    ; Set the zero flag if A=E, or the carry flag if A<E
; This entry point is used by the routine at 7943.
  LD HL,$0000             ; HL=$0000
  JR NZ,$7940             ; Jump to 7940 if the zero flag is not set
  INC HL                  ; HL=HL+1
  JP $7315                ; Jump to 7315

; Routine at 7943
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$794E              ; Jump to 794E if A=0
  CALL $7FC8              ; CALL 7FC8
  EX AF,AF'               ; Exchange AF and AF'
  LD A,L                  ; A=L
  LD HL,($A4E5)           ; L=PEEK $A4E5; H=PEEK $A4E6
  CP H                    ; Set the zero flag if A=H, or the carry flag if A<H
  JR Z,$7956              ; Jump to 7956 if A=H
  CP L                    ; Set the zero flag if A=L, or the carry flag if A<L
  JR $793A                ; Jump to 793A

; Data block at 7958
  DEFB $CD,$F9,$72,$7C,$A7,$28,$04,$CD
  DEFB $C8,$7F,$08,$22,$EA,$A4

; Routine at 7966
  RET                     ; Return

; Routine at 7967
;
; Used by the routines at 7B03 and 7C3F.
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $9F                 ; Reset bits 5 and 6 of A
  LD ($A4E7),A            ; POKE $A4E7,A
  LD ($A4E8),HL           ; POKE $A4E8,L; POKE $A4E9,H
  CALL $7334              ; CALL 7334
; This entry point is used by the routines at 797B and 79A1.
  LD HL,($A4E8)           ; L=PEEK $A4E8; H=PEEK $A4E9
  JP $82B0                ; Jump to 82B0

; Routine at 797B
;
; Used by the routine at 82B0.
  BIT 7,(HL)              ; Set the zero flag if bit 7 of (HL) is 0
  INC HL                  ; HL=HL+1
  JR NZ,$79A1             ; Jump to 79A1 if the zero flag is not set
  LD ($A4E8),HL           ; POKE $A4E8,L; POKE $A4E9,H
  AND $3F                 ; Reset bits 6 and 7 of A
  LD L,A                  ; L=A
  LD H,$00                ; H=$00
  ADD HL,HL               ; HL=HL+HL
  LD DE,$A155             ; DE=$A155
  ADD HL,DE               ; HL=HL+DE
  LD IX,$A51F             ; IX=$A51F
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  CALL $799F              ; CALL 799F
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $60                 ; Keep only bits 5 and 6 of A
  JR Z,$7975              ; Jump to 7975 if A=0
  RET                     ; Return

; Routine at 799F
;
; Used by the routine at 797B.
  PUSH DE                 ; Push DE onto the stack
  RET                     ; Return

; Routine at 79A1
;
; Used by the routine at 797B.
  AND $7F                 ; Reset bit 7 of A
  LD D,A                  ; D=A
  LD A,(HL)               ; A=PEEK HL
  INC HL                  ; HL=HL+1
  LD E,A                  ; E=A
  LD ($A4E8),HL           ; POKE $A4E8,L; POKE $A4E9,H
  EX DE,HL                ; Exchange DE and HL
  CALL $7315              ; CALL 7315
  JR $7975                ; Jump to 7975

; Routine at 79B0
;
; Used by the routine at 7B3F.
  LD HL,($A523)           ; L=PEEK $A523; H=PEEK $A524
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET Z                   ; Return if A=0
  INC HL                  ; HL=HL+1
  LD E,(HL)               ; E=PEEK HL
  LD D,$00                ; D=$00
  INC HL                  ; HL=HL+1
  PUSH DE                 ; Push DE onto the stack
  PUSH HL                 ; Push HL onto the stack
  INC HL                  ; HL=HL+1
  LD C,(HL)               ; C=PEEK HL
  INC HL                  ; HL=HL+1
  LD B,(HL)               ; B=PEEK HL
  LD L,A                  ; L=A
  LD H,$00                ; H=$00
  ADD HL,HL               ; HL=HL+HL
  LD DE,$A1FD             ; DE=$A1FD
  ADD HL,DE               ; HL=HL+DE
  LD (HL),C               ; POKE HL,C
  INC HL                  ; HL=HL+1
  LD (HL),B               ; POKE HL,B
  POP HL                  ; Pop last item from stack into HL
  POP DE                  ; Pop last item from stack into DE
  ADD HL,DE               ; HL=HL+DE
  JR $79B3                ; Jump to 79B3

; Routine at 79D1
;
; Used by the routine at 79E3.
  PUSH DE                 ; Push DE onto the stack
  LD HL,($A531)           ; L=PEEK $A531; H=PEEK $A532
  LD E,(HL)               ; E=PEEK HL
  LD A,B                  ; A=B
  OR C                    ; A=A|C
  INC HL                  ; HL=HL+1
  JR NZ,$79DD             ; Jump to 79DD if the zero flag is not set
  POP DE                  ; Pop last item from stack into DE
  RET                     ; Return
  LD D,$00                ; D=$00
  ADD HL,DE               ; HL=HL+DE
  DEC BC                  ; BC=BC-1
  JR $79D5                ; Jump to 79D5

; Routine at 79E3
;
; Used by the routines at 7A15, 7A28 and 7A3B.
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET Z                   ; Return if A=0
  PUSH HL                 ; Push HL onto the stack
  PUSH DE                 ; Push DE onto the stack
  INC HL                  ; HL=HL+1
  LD C,(HL)               ; C=PEEK HL
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  AND $07                 ; Keep only bits 0, 1 and 2 of A
  LD B,A                  ; B=A
  CALL $79D1              ; CALL 79D1
  LD A,(HL)               ; A=PEEK HL
  AND $7F                 ; Reset bit 7 of A
  LD C,A                  ; C=A
  LD A,(DE)               ; A=PEEK DE
  AND $7F                 ; Reset bit 7 of A
  CP $61                  ; Set the zero flag if A=$61, or the carry flag if
                          ; A<$61
  JR C,$79FF              ; Jump to 79FF if A<$61
  AND $5F                 ; Reset bits 5 and 7 of A
  CP C                    ; Set the zero flag if A=C, or the carry flag if A<C
  JR Z,$7A09              ; Jump to 7A09 if A=C
  POP DE                  ; Pop last item from stack into DE
  POP HL                  ; Pop last item from stack into HL
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  JR $79E3                ; Jump to 79E3
  INC HL                  ; HL=HL+1
  INC DE                  ; DE=DE+1
  LD A,(DE)               ; A=PEEK DE
  CALL $864B              ; CALL 864B
  JR NZ,$79F2             ; Jump to 79F2 if the zero flag is not set
  POP DE                  ; Pop last item from stack into DE
  POP HL                  ; Pop last item from stack into HL
  LD A,(HL)               ; A=PEEK HL
  RET                     ; Return

; Routine at 7A15
;
; Used by the routine at 7A53.
  LD A,($A4E3)            ; A=PEEK $A4E3
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET NZ                  ; Return if A>0
  LD HL,$A54F             ; HL=$A54F
  CALL $79E3              ; CALL 79E3
  LD ($A4E3),A            ; POKE $A4E3,A
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7A27              ; Jump to 7A27 if A=0
  SCF                     ; Set the carry flag
  RET                     ; Return

; Routine at 7A28
;
; Used by the routine at 7A53.
  LD A,($A4E4)            ; A=PEEK $A4E4
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET NZ                  ; Return if A>0
  LD HL,($A521)           ; L=PEEK $A521; H=PEEK $A522
  CALL $79E3              ; CALL 79E3
  LD ($A4E4),A            ; POKE $A4E4,A
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7A3A              ; Jump to 7A3A if A=0
  SCF                     ; Set the carry flag
  RET                     ; Return

; Routine at 7A3B
;
; Used by the routine at 7A53.
  LD HL,($A4E5)           ; L=PEEK $A4E5; H=PEEK $A4E6
  LD A,L                  ; A=L
  OR H                    ; A=A|H
  AND H                   ; A=A&H
  RET NZ                  ; Return if A>0
  LD HL,($A51F)           ; L=PEEK $A51F; H=PEEK $A520
  CALL $79E3              ; CALL 79E3
  LD HL,$A4E5             ; HL=$A4E5
  LD B,A                  ; B=A
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7A51              ; Jump to 7A51 if A=0
  INC HL                  ; HL=HL+1
  LD (HL),B               ; POKE HL,B
  RET                     ; Return

; Routine at 7A53
;
; Used by the routine at 7BA4.
  CALL $7A15              ; CALL 7A15
  RET C                   ; Return if the carry flag is set
  CALL $7A28              ; CALL 7A28
  RET C                   ; Return if the carry flag is set
  JP $7A3B                ; Jump to 7A3B

; Data block at 7A5E
  DEFB $11,$00,$00,$C3,$B4,$88

; Routine at 7A64
;
; Used by the routine at 7BA4.
  LD HL,($A4F4)           ; L=PEEK $A4F4; H=PEEK $A4F5
  LD A,(HL)               ; A=PEEK HL
  CALL $864B              ; CALL 864B
  JR Z,$7A70              ; Jump to 7A70 if the zero flag is set
  INC HL                  ; HL=HL+1
  JR $7A67                ; Jump to 7A67
  INC HL                  ; HL=HL+1
  LD ($A4F4),HL           ; POKE $A4F4,L; POKE $A4F5,H
  DEC HL                  ; HL=HL-1
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET Z                   ; Return if A=0
  CP $2C                  ; Set the zero flag if A=$2C, or the carry flag if
                          ; A<$2C
  RET Z                   ; Return if A=$2C
  CP $2E                  ; Set the zero flag if A=$2E, or the carry flag if
                          ; A<$2E
  RET Z                   ; Return if A=$2E
  CP $3B                  ; Set the zero flag if A=$3B, or the carry flag if
                          ; A<$3B
  RET Z                   ; Return if A=$3B
  CP $21                  ; Set the zero flag if A=$21, or the carry flag if
                          ; A<$21
  RET Z                   ; Return if A=$21
  AND $5F                 ; Reset bits 5 and 7 of A
  CP $41                  ; Set the zero flag if A=$41, or the carry flag if
                          ; A<$41
  JR Z,$7A97              ; Jump to 7A97 if A=$41
  CP $54                  ; Set the zero flag if A=$54, or the carry flag if
                          ; A<$54
  JR Z,$7AB5              ; Jump to 7AB5 if A=$54
  LD A,(HL)               ; A=PEEK HL
  CALL $864B              ; CALL 864B
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  JR Z,$7A70              ; Jump to 7A70 if the zero flag is set
  JR $7ADD                ; Jump to 7ADD
  PUSH HL                 ; Push HL onto the stack
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  AND $5F                 ; Reset bits 5 and 7 of A
  CP $4E                  ; Set the zero flag if A=$4E, or the carry flag if
                          ; A<$4E
  JR NZ,$7AB2             ; Jump to 7AB2 if A<>$4E
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  AND $5F                 ; Reset bits 5 and 7 of A
  CP $44                  ; Set the zero flag if A=$44, or the carry flag if
                          ; A<$44
  JR NZ,$7AB2             ; Jump to 7AB2 if A<>$44
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  CALL $864B              ; CALL 864B
  JR NZ,$7AB2             ; Jump to 7AB2 if the zero flag is not set
  POP DE                  ; Pop last item from stack into DE
  JR $7AD6                ; Jump to 7AD6
  POP HL                  ; Pop last item from stack into HL
  JR $7A8D                ; Jump to 7A8D
  PUSH HL                 ; Push HL onto the stack
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  AND $5F                 ; Reset bits 5 and 7 of A
  CP $48                  ; Set the zero flag if A=$48, or the carry flag if
                          ; A<$48
  JR NZ,$7AB2             ; Jump to 7AB2 if A<>$48
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  AND $5F                 ; Reset bits 5 and 7 of A
  CP $45                  ; Set the zero flag if A=$45, or the carry flag if
                          ; A<$45
  JR NZ,$7AB2             ; Jump to 7AB2 if A<>$45
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  AND $5F                 ; Reset bits 5 and 7 of A
  CP $4E                  ; Set the zero flag if A=$4E, or the carry flag if
                          ; A<$4E
  JR NZ,$7AB2             ; Jump to 7AB2 if A<>$4E
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  CALL $864B              ; CALL 864B
  JR NZ,$7AB2             ; Jump to 7AB2 if the zero flag is not set
  POP DE                  ; Pop last item from stack into DE
  XOR A                   ; A=0
  LD ($A4F4),HL           ; POKE $A4F4,L; POKE $A4F5,H
  LD A,$21                ; A=$21
  RET                     ; Return
  DEC HL                  ; HL=HL-1
  LD ($A4F4),HL           ; POKE $A4F4,L; POKE $A4F5,H
  RET                     ; Return

; Routine at 7AE2
;
; Used by the routine at 7B03.
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  INC HL                  ; HL=HL+1
  LD A,D                  ; A=D
  OR E                    ; A=A|E
  JR NZ,$7AEC             ; Jump to 7AEC if A>0
  CCF                     ; Complement the carry flag
  RET                     ; Return
  LD A,D                  ; A=D
  CP B                    ; Set the zero flag if A=B, or the carry flag if A<B
  JR NZ,$7AF3             ; Jump to 7AF3 if A<>B
  LD A,E                  ; A=E
  CP C                    ; Set the zero flag if A=C, or the carry flag if A<C
  RET Z                   ; Return if A=C
  LD A,(HL)               ; A=PEEK HL
  AND $80                 ; Keep only bit 7 of A
  JR Z,$7AFC              ; Jump to 7AFC if A=0
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  JR $7AF3                ; Jump to 7AF3
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  INC HL                  ; HL=HL+1
  JR Z,$7AE2              ; Jump to 7AE2 if the zero flag is set
  JR $7AF3                ; Jump to 7AF3

; Routine at 7B03
;
; Used by the routine at 7C3F.
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $F7                 ; Reset bit 3 of A
  LD ($A4E7),A            ; POKE $A4E7,A
  LD HL,($A529)           ; L=PEEK $A529; H=PEEK $A52A
  LD BC,($A4ED)           ; C=PEEK $A4ED; B=PEEK $A4EE
  CALL $7AE2              ; CALL 7AE2
  JR C,$7B20              ; Jump to 7B20 if the carry flag is set
  CALL $7967              ; CALL 7967
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $60                 ; Keep only bits 5 and 6 of A
  RET NZ                  ; Return if A>0
  LD HL,($A52B)           ; L=PEEK $A52B; H=PEEK $A52C
  CALL $7967              ; CALL 7967
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $08                 ; Keep only bit 3 of A
  RET NZ                  ; Return if A>0
  LD C,$F1                ; C=$F1
  LD HL,($A4E3)           ; L=PEEK $A4E3; H=PEEK $A4E4
  LD A,H                  ; A=H
  OR L                    ; A=A|L
  LD HL,($A4E5)           ; L=PEEK $A4E5; H=PEEK $A4E6
  OR H                    ; A=A|H
  OR L                    ; A=A|L
  JR NZ,$7B3C             ; Jump to 7B3C if A>0
  LD C,$F2                ; C=$F2
  JP $7538                ; Jump to 7538

; Routine at 7B3F
;
; Used by the routine at 7C3F.
  LD HL,$A1FD             ; HL=$A1FD
  LD DE,$A1FE             ; DE=$A1FE
  LD BC,$02F2             ; BC=$02F2
  LD (HL),$00             ; POKE HL,$00
  LDIR                    ; POKE DE,PEEK HL; HL=HL+1; DE=DE+1; BC=BC-1; repeat
                          ; until BC=0
  CALL $79B0              ; CALL 79B0
  LD A,$02                ; A=$02
  LD ($A483),A            ; POKE $A483,A
  LD A,$FA                ; A=$FA
  LD ($A4EA),A            ; POKE $A4EA,A
  CALL $6333              ; CALL 6333
  LD ($A4EB),HL           ; POKE $A4EB,L; POKE $A4EC,H
  LD HL,($A535)           ; L=PEEK $A535; H=PEEK $A536
  LD ($A4ED),HL           ; POKE $A4ED,L; POKE $A4EE,H
  LD A,$01                ; A=$01
  CALL $6330              ; CALL 6330
  LD A,$10                ; A=$10
  LD ($A4E7),A            ; POKE $A4E7,A
  CALL $7334              ; CALL 7334
  CALL $72AE              ; CALL 72AE
  CALL $7660              ; CALL 7660
  RET                     ; Return

; Routine at 7B79
;
; Used by the routine at 7C3F.
  LD BC,($A4ED)           ; C=PEEK $A4ED; B=PEEK $A4EE
  LD HL,($A525)           ; L=PEEK $A525; H=PEEK $A526
  CALL $8A3F              ; CALL 8A3F
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  JR NC,$7B8B             ; Jump to 7B8B if the carry flag is not set
  CALL $7FC8              ; CALL 7FC8
  INC B                   ; B=B+1
  LD A,($A4E3)            ; A=PEEK $A4E3
  LD B,A                  ; B=A
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET Z                   ; Return if A=0
  CP B                    ; Set the zero flag if A=B, or the carry flag if A<B
  INC HL                  ; HL=HL+1
  JR Z,$7B9A              ; Jump to 7B9A if the zero flag is set
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  JR $7B8F                ; Jump to 7B8F
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  EX DE,HL                ; Exchange DE and HL
  CALL $7808              ; CALL 7808
  XOR A                   ; A=0
  INC A                   ; A=A+1
  RET                     ; Return

; Routine at 7BA4
;
; Used by the routine at 7C0A.
  LD A,($A4E6)            ; A=PEEK $A4E6
  LD HL,($A481)           ; L=PEEK $A481; H=PEEK $A482
  INC HL                  ; HL=HL+1
  LD ($A481),HL           ; POKE $A481,L; POKE $A482,H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7BB9              ; Jump to 7BB9 if A=0
  LD HL,($A4E5)           ; L=PEEK $A4E5; H=PEEK $A4E6
  LD ($A4F1),HL           ; POKE $A4F1,L; POKE $A4F2,H
  JR $7BC2                ; Jump to 7BC2
  LD A,($A4E5)            ; A=PEEK $A4E5
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7BC2              ; Jump to 7BC2 if A=0
  LD ($A4F2),A            ; POKE $A4F2,A
  LD HL,$0000             ; HL=$0000
  LD ($A4E3),HL           ; POKE $A4E3,L; POKE $A4E4,H
  LD ($A4E5),HL           ; POKE $A4E5,L; POKE $A4E6,H
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $10                 ; Keep only bit 4 of A
  JR Z,$7BF2              ; Jump to 7BF2 if A=0
  LD C,$F0                ; C=$F0
  CALL $77B8              ; CALL 77B8
  LD HL,$5B00             ; HL=$5B00
  LD ($A4F4),HL           ; POKE $A4F4,L; POKE $A4F5,H
  LD (HL),$00             ; POKE HL,$00
  CALL $85DC              ; CALL 85DC
  JR NC,$7BD2             ; Jump to 7BD2 if the carry flag is not set
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $EF                 ; Reset bit 4 of A
  LD ($A4E7),A            ; POKE $A4E7,A
  LD A,($5B00)            ; A=PEEK $5B00
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7BD2              ; Jump to 7BD2 if A=0
  LD DE,($A4F4)           ; E=PEEK $A4F4; D=PEEK $A4F5
  CALL $7A53              ; CALL 7A53
  CALL $7A64              ; CALL 7A64
  JR NZ,$7BF2             ; Jump to 7BF2 if the zero flag is not set
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$7C09             ; Jump to 7C09 if A>0
  LD A,($A4E7)            ; A=PEEK $A4E7
  OR $10                  ; Set bit 4 of A
  LD ($A4E7),A            ; POKE $A4E7,A
  RET                     ; Return

; Routine at 7C0A
;
; Used by the routine at 7C3F.
  LD A,($A4E3)            ; A=PEEK $A4E3
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7C13              ; Jump to 7C13 if A=0
  LD ($A4F3),A            ; POKE $A4F3,A
  CALL $7BA4              ; CALL 7BA4
  LD A,($A4E5)            ; A=PEEK $A4E5
  INC A                   ; A=A+1
  JR NZ,$7C22             ; Jump to 7C22 if A>0
  LD A,($A4F2)            ; A=PEEK $A4F2
  LD ($A4E5),A            ; POKE $A4E5,A
  LD A,($A4E6)            ; A=PEEK $A4E6
  INC A                   ; A=A+1
  JR NZ,$7C2E             ; Jump to 7C2E if A>0
  LD A,($A4F2)            ; A=PEEK $A4F2
  LD ($A4E6),A            ; POKE $A4E6,A
  RET                     ; Return

; Routine at 7C2F
;
; Used by the routine at 8538.
  LD HL,($A54D)           ; L=PEEK $A54D; H=PEEK $A54E
  LD ($A535),HL           ; POKE $A535,L; POKE $A536,H
  CALL $7C3F              ; CALL 7C3F
  LD HL,$631E             ; HL=$631E
  LD ($8872),HL           ; POKE $8872,L; POKE $8873,H
  RET                     ; Return

; Routine at 7C3F
;
; Used by the routine at 7C2F.
  CALL $72C7              ; CALL 72C7
  LD HL,$778A             ; HL=$778A
  LD ($8872),HL           ; POKE $8872,L; POKE $8873,H
  LD A,$01                ; A=$01
  CALL $6330              ; CALL 6330
  LD A,$80                ; A=$80
  LD ($A541),A            ; POKE $A541,A
  LD A,$01                ; A=$01
  CALL $6330              ; CALL 6330
  CALL $6327              ; CALL 6327
  CALL $7B3F              ; CALL 7B3F
  LD HL,($A527)           ; L=PEEK $A527; H=PEEK $A528
  CALL $7967              ; CALL 7967
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $20                 ; Keep only bit 5 of A
  JR NZ,$7C82             ; Jump to 7C82 if A>0
  CALL $7C0A              ; CALL 7C0A
  LD HL,$96B1             ; HL=$96B1
  CALL $886C              ; CALL 886C
  CALL $7B79              ; CALL 7B79
  JR NZ,$7C5D             ; Jump to 7C5D if the zero flag is not set
  CALL $7B03              ; CALL 7B03
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $20                 ; Keep only bit 5 of A
  JR Z,$7C5D              ; Jump to 7C5D if A=0
  LD C,$F3                ; C=$F3
  CALL $7538              ; CALL 7538
  CALL $6324              ; CALL 6324
  CALL $6318              ; CALL 6318
  JR $7C42                ; Jump to 7C42

; Data block at 7C8F
  DEFB $21,$DE,$96,$CD,$6C,$88,$C9,$06
  DEFB $00,$3A,$F8,$A4,$4F,$7E,$23,$A7
  DEFB $28,$0B,$CD,$49,$81,$04,$78,$B9
  DEFB $CC,$AC,$7C,$18,$F0,$3A,$F9,$A4
  DEFB $CD,$49,$81,$D0,$3A,$FA,$A4,$CD
  DEFB $49,$81,$D0,$06,$00,$C9,$21,$18
  DEFB $5E,$11,$19,$5E,$01,$FF,$04,$36
  DEFB $20,$ED,$B0,$C9,$21,$11,$97,$CD
  DEFB $96,$7C,$2A,$2D,$A5,$CD,$FD,$7C
  DEFB $7E,$A7,$C8,$23,$11,$18,$5E,$E5
  DEFB $6F,$26,$00,$CD,$71,$8C,$E1,$11
  DEFB $1C,$5E,$4E,$06,$00,$23,$C5,$E5
  DEFB $CD,$4F,$87,$21,$18,$5E,$CD,$96
  DEFB $7C,$E1,$C1,$09,$18,$D7,$F5,$E5
  DEFB $D5,$C5,$CD,$BD,$7C,$C1,$D1,$E1
  DEFB $F1,$C9,$21,$1A,$97,$CD,$96,$7C
  DEFB $21,$22,$97,$CD,$96,$7C,$2A,$23
  DEFB $A5,$7E,$A7,$C8,$CD,$FD,$7C,$23
  DEFB $11,$18,$5E,$4E,$06,$00,$23,$C5
  DEFB $E5,$E5,$6F,$26,$00,$CD,$71,$8C
  DEFB $E1,$7E,$23,$11,$1C,$5E,$E5,$6F
  DEFB $26,$00,$CD,$71,$8C,$E1,$11,$20
  DEFB $5E,$4E,$23,$46,$23,$E5,$60,$69
  DEFB $CD,$71,$8C,$E1,$11,$26,$5E,$CD
  DEFB $4F,$87,$21,$18,$5E,$CD,$96,$7C
  DEFB $E1,$C1,$09,$18,$BC,$7E,$A7,$C8
  DEFB $E5,$CD,$3A,$8F,$21,$00,$5B,$CD
  DEFB $96,$7C,$E1,$23,$23,$23,$18,$ED
  DEFB $21,$3C,$97,$CD,$96,$7C,$21,$4F
  DEFB $A5,$C3,$5C,$7D,$21,$42,$97,$CD
  DEFB $96,$7C,$2A,$1F,$A5,$C3,$5C,$7D
  DEFB $21,$48,$97,$CD,$96,$7C,$2A,$21
  DEFB $A5,$C3,$5C,$7D,$CD,$DC,$7D,$21
  DEFB $50,$97,$CD,$6C,$88,$CD,$24,$63
  DEFB $CD,$18,$63,$CD,$D7,$91,$FE,$FC
  DEFB $C8,$21,$96,$7D,$E5,$E6,$DF,$FE
  DEFB $41,$CA,$87,$7D,$FE,$43,$CA,$31
  DEFB $80,$FE,$48,$CA,$ED,$72,$FE,$4C
  DEFB $CA,$25,$80,$FE,$4D,$CA,$CB,$7C
  DEFB $FE,$4E,$CA,$7B,$7D,$FE,$4F,$CA
  DEFB $09,$7D,$FE,$52,$CA,$B2,$95,$FE
  DEFB $56,$CA,$6F,$7D,$C9,$CD,$8F,$7C

; Message at 7DDF
  DEFM ">P2"

; Data block at 7DE2
  DEFB $F8,$A4,$21,$0D,$0A,$22,$F9,$A4
  DEFB $C9,$7E,$FE,$20,$20,$03,$23,$18
  DEFB $F8,$FE,$28,$20,$08,$DD,$34,$2D
  DEFB $23,$CD,$44,$7E,$C9,$FE,$3A,$30
  DEFB $12,$D5,$CD,$D9,$8B,$2B,$06,$10
  DEFB $4B,$7A,$F6,$80,$D1,$12,$13,$79
  DEFB $12,$13,$C9,$D5,$CD,$DF,$8B,$F5
  DEFB $7E,$E6,$DF,$28,$03,$23,$18,$F8
  DEFB $F1,$D1,$D8,$4F,$06,$00,$E5,$21
  DEFB $A6,$A0,$09,$46,$E1,$78,$E6,$0F
  DEFB $28,$0C,$FE,$01,$28,$02,$37,$C9
  DEFB $C5,$CD,$EB,$7D,$C1,$D8,$79,$12
  DEFB $13,$C9,$CD,$EB,$7D,$D8,$7E,$FE
  DEFB $20,$20,$03,$23,$18,$F8,$A7,$20
  DEFB $07,$DD,$7E,$2D,$A7,$C8,$37,$C9
  DEFB $FE,$29,$20,$07,$23,$DD,$35,$2D
  DEFB $F0,$37,$C9,$78,$E6,$F0,$CA,$44
  DEFB $7E,$D5,$CD,$DF,$8B,$F5,$7E,$E6
  DEFB $DF,$28,$03,$23,$18,$F8,$F1,$D1
  DEFB $D8,$4F,$06,$00,$E5,$21,$A6,$A0
  DEFB $09,$46,$E1,$78,$E6,$0F,$FE,$02
  DEFB $28,$02,$37,$C9,$C5,$CD,$EB,$7D
  DEFB $C1,$D8,$79,$12,$13,$18,$AF,$F5
  DEFB $E5,$ED,$4B,$FB,$A4,$E1,$E5,$A7
  DEFB $ED,$42,$28,$18,$0A,$E6,$80,$03
  DEFB $28,$F3,$E1,$E5,$A7,$ED,$42,$28
  DEFB $03,$03,$18,$E9,$E1,$2B,$C1,$CB
  DEFB $B1,$C5,$F1,$C9,$E1,$2B,$C1,$CB
  DEFB $F1,$18,$F6,$7E,$FE,$20,$C3,$EE
  DEFB $7D,$7E,$A7,$C8,$12,$1B,$2B,$18
  DEFB $F8

; Message at 7ED3
  DEFM "))&"

; Data block at 7ED6
  DEFB $00,$01,$A8,$9F,$09,$3E,$20,$12
  DEFB $1B,$06,$04,$7E,$FE,$2A,$28,$06
  DEFB $FE,$20,$28,$02,$12,$1B,$2B,$10
  DEFB $F2,$C9,$FE,$01,$20,$08,$3E,$20
  DEFB $12,$1B,$3E,$29,$12,$1B,$79,$C3
  DEFB $00,$7F,$E5,$2A,$03,$A5,$77,$23
  DEFB $22,$03,$A5,$E1,$C9,$E5,$2A,$03
  DEFB $A5,$2B,$7E,$22,$03,$A5,$E1,$C9
  DEFB $22,$FB,$A4,$11,$17,$62,$ED,$53
  DEFB $FD,$A4,$01,$FD,$A2,$ED,$43,$03
  DEFB $A5,$7E,$FE,$3F,$28,$0C,$A7,$28
  DEFB $08,$E6,$80,$28,$01,$23,$23,$18
  DEFB $F0,$2B,$E5,$ED,$4B,$FB,$A4,$A7
  DEFB $ED,$42,$E1,$D8,$7E,$CD,$99,$7E
  DEFB $20,$5A,$E5,$4F,$06,$00,$21,$A6
  DEFB $A0,$09,$7E,$E6,$0F,$E1,$20,$58
  DEFB $E5,$69,$26,$00,$CD,$D3,$7E,$E1
  DEFB $E5,$D5,$11,$FD,$A2,$2A,$03,$A5
  DEFB $A7,$ED,$52,$D1,$E1,$20,$06,$ED
  DEFB $53,$FD,$A4,$18,$C5,$CD,$0B,$7F
  DEFB $E5,$4F,$06,$00,$21,$A6,$A0,$09
  DEFB $7E,$E6,$0F,$E1,$FE,$01,$20,$12
  DEFB $3E,$20,$12,$1B,$3E,$28,$12,$1B
  DEFB $E5,$69,$26,$00,$CD,$D3,$7E,$E1
  DEFB $18,$C6,$E5,$69,$26,$00,$CD,$D3
  DEFB $7E,$E1,$18,$CF,$E5,$66,$6F,$CB
  DEFB $BC,$CD,$CA,$95,$E1,$2B,$18,$E8
  DEFB $CD,$F0,$7E,$18,$ED,$18,$D5,$D5
  DEFB $AF,$32,$18,$62,$CD,$16,$7F,$13
  DEFB $EB,$D1,$7E,$12,$A7,$C8,$23,$13
  DEFB $18,$F8,$21,$54,$97,$CD,$6C,$88
  DEFB $E1,$4E,$0C,$ED,$7B,$01,$A5,$21
  DEFB $E6,$A0,$CD,$75,$8A,$7E,$FE,$2A
  DEFB $28,$09,$A7,$28,$0C,$CD,$1E,$63
  DEFB $23,$18,$F2,$21,$5F,$97,$CD,$6C
  DEFB $88,$21,$6A,$97,$CD,$6C,$88,$C3
  DEFB $BE,$82,$2B,$7E,$A7,$28,$04,$FE
  DEFB $3F,$20,$F7,$2B,$CB,$7E,$20,$F2
  DEFB $11,$18,$5E,$23,$23,$CD,$93,$8C
  DEFB $3D,$12,$21,$18,$5E,$CD,$6C,$88
  DEFB $21,$6E,$97,$CD,$6C,$88,$CD,$24
  DEFB $63,$CD,$18,$63,$C3

; Message at 8023
  DEFM "'c!"

; Data block at 8026
  DEFB $81,$97,$CD,$96,$7C,$2A,$2B,$A5
  DEFB $C3,$CD,$72,$21,$99,$97,$CD,$96
  DEFB $7C,$2A,$29,$A5,$5E,$23,$56,$23
  DEFB $7A,$B3,$C8,$E5

; Message at 8042
  DEFM "!Ro"

; Data block at 8045
  DEFB $CD,$A4

; Message at 8047
  DEFM "r!om\""

; Data block at 804C
  DEFB $1A,$5E

; Message at 804E
  DEFM "> 2"

; Data block at 8051
  DEFB $1C,$5E,$EB,$11,$1D,$5E,$CD,$71
  DEFB $8C,$AF,$12,$21,$18,$5E,$CD,$96
  DEFB $7C,$E1,$CD,$CD,$72,$23,$18,$D1
  DEFB $21,$C4,$97,$CD,$6C,$88,$CD,$24
  DEFB $63,$CD,$18,$63,$CD,$27,$63,$E6
  DEFB $DF,$FE,$44,$CA,$AC,$8E,$FE,$52
  DEFB $20,$EC,$21,$F3,$97,$CD,$6C,$88
  DEFB $CD,$8F,$8E,$CD,$E4,$85,$CD,$95
  DEFB $80,$C3,$04,$86,$CD,$E0,$8E,$DD
  DEFB $21,$00,$5B,$AF,$DD,$77,$00,$32
  DEFB $74,$5C,$DD,$36,$0B,$36,$DD,$77
  DEFB $0C,$DD,$36,$0D,$01,$DD,$77,$0E
  DEFB $DD,$36,$0F,$36,$DD,$77,$10,$21
  DEFB $D6,$80,$01,$5A,$07,$CD,$53,$85
  DEFB $11,$C0,$5D,$D5,$DD,$E1,$2A,$33
  DEFB $A5,$A7,$ED

; Message at 80CC
  DEFM "RT]="

; Data block at 80D0
  DEFB $01,$C2,$04,$C3,$53,$85,$00,$0A
  DEFB $0E,$00,$F9,$C0

; Message at 80DC
  DEFM "23778"

; Data block at 80E1
  DEFB $0E,$00,$00,$E2,$5C,$00,$0D,$00
  DEFB $14,$FF,$FF,$EA,$F3,$31,$BF,$5D
  DEFB $21,$E2,$5C,$E5,$ED,$73,$3D,$5C
  DEFB $21,$38,$85,$E5,$11,$40,$A2,$DD
  DEFB $21,$C0,$5D,$3E,$FF,$37,$C3,$56
  DEFB $05,$0D,$54,$22,$1A,$5E,$21,$3A
  DEFB $98,$CD,$2E,$81,$E1,$C3,$85,$8A
  DEFB $21,$43,$98,$CD,$2E,$81,$AF,$32
  DEFB $45,$A5,$37,$E1,$C9,$3E,$08,$CD
  DEFB $1E,$63,$C3,$82,$81,$E5,$3E,$05
  DEFB $CD,$2A,$63,$E1,$F5,$CD,$6C,$88
  DEFB $F1,$CD,$2A,$63,$C9,$22,$35,$A5
  DEFB $7E,$A7,$CA,$78,$90,$C3,$2A,$90
  DEFB $F5,$E5,$3E,$42,$CD,$1B,$63,$E1
  DEFB $28,$03,$F1,$A7,$C9,$F1,$CD,$36
  DEFB $72,$C9

; Routine at 815B
;
; Used by the routines at 817C, 81E1 and 838F.
  PUSH HL                 ; Push HL onto the stack
  LD B,$00                ; B=$00
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$816F              ; Jump to 816F if A=0
  LD A,$01                ; A=$01
  CALL $631E              ; CALL 631E
  LD A,(HL)               ; A=PEEK HL
  CALL $631E              ; CALL 631E
  INC HL                  ; HL=HL+1
  INC B                   ; B=B+1
  JR $815E                ; Jump to 815E
  POP HL                  ; Pop last item from stack into HL
  RET                     ; Return

; Routine at 8171
;
; Used by the routine at 817C.
  LD A,B                  ; A=B
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET Z                   ; Return if A=0
  LD A,$08                ; A=$08
  CALL $631E              ; CALL 631E
  DJNZ $8176              ; Decrement B and jump to 8176 if B>0
  RET                     ; Return

; Routine at 817C
;
; Used by the routines at 81BE and 81E1.
  CALL $815B              ; CALL 815B
  JP $8171                ; Jump to 8171

; Data block at 8182
  DEFB $CD,$5B,$81,$3E,$20,$CD,$1E,$63
  DEFB $04,$C3,$71,$81,$79,$A7,$20,$05
  DEFB $3E,$07,$C3,$1E,$63,$E5,$7E,$2B
  DEFB $77,$23,$23,$A7,$20,$F8,$E1,$2B
  DEFB $0D,$15,$C3,$26,$81,$7E,$A7,$20
  DEFB $05,$3E,$07,$C3,$1E,$63,$E5,$23
  DEFB $7E,$2B,$77,$23,$A7,$20,$F8,$E1
  DEFB $15,$C3,$82,$81

; Routine at 81BE
;
; Used by the routine at 82A4.
  LD B,A                  ; B=A
  LD A,D                  ; A=D
  CP E                    ; Set the zero flag if A=E, or the carry flag if A<E
  JR C,$81C8              ; Jump to 81C8 if A<E
  LD A,$07                ; A=$07
  JP $631E                ; Jump to 631E
  LD A,$01                ; A=$01
  CALL $631E              ; CALL 631E
  LD A,B                  ; A=B
  CALL $631E              ; CALL 631E
  PUSH HL                 ; Push HL onto the stack
  LD A,(HL)               ; A=PEEK HL
  LD (HL),B               ; POKE HL,B
  INC HL                  ; HL=HL+1
  LD B,A                  ; B=A
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$81D2             ; Jump to 81D2 if A>0
  LD (HL),B               ; POKE HL,B
  POP HL                  ; Pop last item from stack into HL
  INC HL                  ; HL=HL+1
  INC C                   ; C=C+1
  INC D                   ; D=D+1
  JP $817C                ; Jump to 817C

; Routine at 81E1
;
; Used by the routine at 828A.
  PUSH HL                 ; Push HL onto the stack
  PUSH DE                 ; Push DE onto the stack
  PUSH BC                 ; Push BC onto the stack
  PUSH HL                 ; Push HL onto the stack
  LD D,$00                ; D=$00
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$81EF              ; Jump to 81EF if A=0
  INC HL                  ; HL=HL+1
  INC D                   ; D=D+1
  JR $81E7                ; Jump to 81E7
  POP HL                  ; Pop last item from stack into HL
  CALL $817C              ; CALL 817C
  CALL $6324              ; CALL 6324
  CALL $6318              ; CALL 6318
  CALL $6327              ; CALL 6327
  PUSH AF                 ; Push AF onto the stack
  PUSH BC                 ; Push BC onto the stack
  PUSH DE                 ; Push DE onto the stack
  PUSH HL                 ; Push HL onto the stack
  PUSH IX                 ; Push IX onto the stack
  LD D,$00                ; D=$00
  LD A,($5C39)            ; A=PEEK $5C39
  LD E,A                  ; E=A
  LD HL,$00FF             ; HL=$00FF
  CALL $03B5              ; CALL 03B5
  POP IX                  ; Pop last item from stack into IX
  POP HL                  ; Pop last item from stack into HL
  POP DE                  ; Pop last item from stack into DE
  POP BC                  ; Pop last item from stack into BC
  POP AF                  ; Pop last item from stack into AF
  CP $FC                  ; Set the zero flag if A=$FC, or the carry flag if
                          ; A<$FC
  JR NZ,$8234             ; Jump to 8234 if A<>$FC
  CALL $815B              ; CALL 815B
  LD A,($5C48)            ; A=PEEK $5C48
  AND $07                 ; Keep only bits 0, 1 and 2 of A
  PUSH AF                 ; Push AF onto the stack
  LD HL,$9884             ; HL=$9884
  CALL $886C              ; CALL 886C
  LD A,$0F                ; A=$0F
  CALL $631E              ; CALL 631E
  POP AF                  ; Pop last item from stack into AF
  CALL $631E              ; CALL 631E
; This entry point is used by the routine at 838F.
  POP BC                  ; Pop last item from stack into BC
  POP DE                  ; Pop last item from stack into DE
  POP HL                  ; Pop last item from stack into HL
  RET                     ; Return
  CP $FD                  ; Set the zero flag if A=$FD, or the carry flag if
                          ; A<$FD
  JR NZ,$8242             ; Jump to 8242 if A<>$FD
  LD A,($5C6A)            ; A=PEEK $5C6A
  XOR $08                 ; Flip bit 3 of A
  LD ($5C6A),A            ; POKE $5C6A,A
  JR $81F3                ; Jump to 81F3
  CP $0D                  ; Set the zero flag if A=$0D, or the carry flag if
                          ; A<$0D
  JR NZ,$8249             ; Jump to 8249 if A<>$0D
  JP $838F                ; Jump to 838F
  CP $7F                  ; Set the zero flag if A=$7F, or the carry flag if
                          ; A<$7F
  JR NZ,$8252             ; Jump to 8252 if A<>$7F
  CALL $818E              ; CALL 818E
  JR $81F3                ; Jump to 81F3
  CP $10                  ; Set the zero flag if A=$10, or the carry flag if
                          ; A<$10
  JR NZ,$825B             ; Jump to 825B if A<>$10
  CALL $81A7              ; CALL 81A7
  JR $8250                ; Jump to 8250
  CP $F2                  ; Set the zero flag if A=$F2, or the carry flag if
                          ; A<$F2
  JR NZ,$8270             ; Jump to 8270 if A<>$F2
  LD A,C                  ; A=C
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$826A             ; Jump to 826A if A>0
  LD A,$07                ; A=$07
  CALL $631E              ; CALL 631E
  JR $8259                ; Jump to 8259
  DEC HL                  ; HL=HL-1
  DEC C                   ; C=C-1
  LD A,$08                ; A=$08
  JR $8265                ; Jump to 8265
  CP $F3                  ; Set the zero flag if A=$F3, or the carry flag if
                          ; A<$F3
  JR NZ,$8285             ; Jump to 8285 if A<>$F3
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$827F             ; Jump to 827F if A>0
  LD A,$07                ; A=$07
  CALL $631E              ; CALL 631E
  JR $8268                ; Jump to 8268
  INC HL                  ; HL=HL+1
  INC C                   ; C=C+1
  LD A,$09                ; A=$09
  JR $827A                ; Jump to 827A
  CALL $82A4              ; CALL 82A4
  JR $827D                ; Jump to 827D

; Routine at 828A
;
; Used by the routine at 829B.
  LD C,$00                ; C=$00
  JP $81E1                ; Jump to 81E1

; Data block at 828F
  DEFB $1E,$03,$18,$0A,$1E,$04,$18,$06
  DEFB $1E,$1C,$18,$02

; Routine at 829B
;
; Used by the routine at 85DC.
  LD E,$FF                ; E=$FF
  JP $828A                ; Jump to 828A

; Data block at 82A0
  DEFB $1E,$0A,$18,$F9

; Routine at 82A4
;
; Used by the routine at 81E1.
  CP $FC                  ; Set the zero flag if A=$FC, or the carry flag if
                          ; A<$FC
  RET Z                   ; Return if A=$FC
  CP $80                  ; Set the zero flag if A=$80, or the carry flag if
                          ; A<$80
  RET NC                  ; Return if A>=$80
  CP $20                  ; Set the zero flag if A=$20, or the carry flag if
                          ; A<$20
  RET C                   ; Return if A<$20
  JP $81BE                ; Jump to 81BE

; Routine at 82B0
;
; Used by the routine at 7967.
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JP NZ,$797B             ; Jump to 797B if A>0
  PUSH HL                 ; Push HL onto the stack
  LD HL,$0000             ; HL=$0000
  LD ($A4E8),HL           ; POKE $A4E8,L; POKE $A4E9,H
  POP HL                  ; Pop last item from stack into HL
  RET                     ; Return

; Data block at 82BE
  DEFB $2A,$E8,$A4,$7C,$B5,$C2,$F8,$7F
  DEFB $C3,$16,$80,$C5,$E5,$CD,$0E,$74
  DEFB $7E,$A3,$3E,$99,$28,$01,$3C,$CD
  DEFB $1E,$63,$E1,$C1,$C9,$C5,$E5,$01
  DEFB $03,$A4,$09,$6E,$26,$00,$11,$00
  DEFB $5B,$CD,$71,$8C,$3E,$20,$12,$13
  DEFB $12,$13,$12,$13,$12,$3E,$FF,$32
  DEFB $04,$5B,$21,$00,$5B,$CD,$6C,$88
  DEFB $E1,$C1,$C9,$C5,$E5,$18,$DF,$21
  DEFB $8C,$98,$CD,$6C,$88,$21,$00,$00
  DEFB $06,$14,$CD,$01,$83,$CD,$C9,$82
  DEFB $23,$7C,$A7,$C0,$10,$F7,$E5,$21
  DEFB $B1,$96,$CD,$6C,$88,$E1,$18,$E8
  DEFB $21,$AB,$98,$CD,$6C,$88,$21,$00
  DEFB $00,$06,$07,$CD,$01,$83,$CD,$DB
  DEFB $82,$23,$CB,$7D,$C0,$10,$F7,$E5
  DEFB $21,$B1,$96,$CD,$6C,$88,$E1,$18
  DEFB $E8,$21,$CF,$98,$CD,$6C,$88,$CD
  DEFB $24,$63,$CD,$18,$63,$CD,$27,$63
  DEFB $FE,$FC,$20,$04,$CD,$C8,$7F,$07
  DEFB $CD,$16,$86,$21,$FD,$98,$CD,$D5
  DEFB $95,$CD,$24,$63,$CD,$18,$63,$CD

; Message at 836E
  DEFM "'c>"

; Data block at 8371
  DEFB $01,$CD,$30,$63,$C3,$60,$76

; Routine at 8378
  CALL $738D              ; CALL 738D
  JP $749C                ; Jump to 749C

; Data block at 837E
  DEFB $2A,$81,$A4,$C3,$15,$73,$3A,$E6
  DEFB $A4,$2A,$81,$A4,$23,$22,$81,$A4
  DEFB $C9

; Routine at 838F
;
; Used by the routine at 81E1.
  CALL $815B              ; CALL 815B
  SCF                     ; Set the carry flag
  JP $8230                ; Jump to 8230

; Data block at 8396
  DEFB $CD,$3A,$8C,$3E,$01,$CD

; Message at 839C
  DEFM "*c!"

; Data block at 839F
  DEFB $13,$99,$CD,$6C,$88,$AF,$C3

; Message at 83A6
  DEFM "*c!"

; Data block at 83A9
  DEFB $16,$99,$CD,$6C,$88,$2A,$11,$A5
  DEFB $C9,$AF,$CD,$2A,$63,$CD,$18,$63
  DEFB $2A,$11,$A5,$C9,$01,$E5,$FF,$09
  DEFB $1B,$1B,$1B,$1B,$1B,$1B,$1B,$C9
  DEFB $3E,$01,$CD

; Message at 83CC
  DEFM "*c*"

; Data block at 83CF
  DEFB $13,$A5,$01,$F7,$FF,$09,$CB,$7C
  DEFB $28,$10,$CD,$EE,$95,$21,$16,$99
  DEFB $CD,$6C,$88,$AF,$CD,$2A,$63,$C3
  DEFB $9F,$8F,$2A,$11,$A5,$01,$E5,$FF
  DEFB $09,$CD,$3A,$8F,$36,$FF,$CD,$EE
  DEFB $95,$21,$16,$99,$CD,$6C,$88,$21
  DEFB $00,$5B,$CD,$6C,$88,$18,$DC,$3E
  DEFB $01,$CD,$2A,$63,$CD,$DF,$95,$21
  DEFB $1A,$99,$CD,$6C,$88,$06,$08,$2A
  DEFB $11,$A5,$23,$23,$23,$7E,$A7,$28
  DEFB $0A,$10,$F7,$CD,$3A,$8F,$36,$FF
  DEFB $C3,$FE,$83,$3E,$20,$CD,$1E,$63
  DEFB $C3,$E2,$83,$21,$FD,$A1,$CD,$6C
  DEFB $88,$CD

; Message at 8439
  DEFM "$c!"

; Data block at 843C
  DEFB $23,$7B,$CD,$27,$8A,$CD,$27,$63
  DEFB $C3,$77,$94,$2A,$1D,$A5,$ED,$4B
  DEFB $33,$A5,$A7,$ED,$42,$7C,$FE,$08
  DEFB $D0

; Message at 8455
  DEFM "DM!F"

; Data block at 8459
  DEFB $99,$CD,$6C,$88,$78,$FE,$02,$30
  DEFB $08,$21,$54,$99,$CD,$6C,$88,$18
  DEFB $0B,$78,$FE,$04,$30,$06,$21,$5B
  DEFB $99,$CD,$6C,$88,$21,$60,$99,$CD
  DEFB $6C,$88,$60,$69,$CD,$92,$88,$21
  DEFB $84,$99,$CD,$6C,$88,$CD,$24,$63
  DEFB $CD,$18,$63,$CD

; Message at 848D
  DEFM "'c!"

; Data block at 8490
  DEFB $9D,$99,$CD,$6C,$88,$C9,$C5,$2A
  DEFB $33,$A5,$ED,$4B,$37,$A5,$A7,$ED
  DEFB $42,$C1,$09,$38,$07,$C5,$2A,$35
  DEFB $A5,$C3,$DC,$8A,$21,$A6,$99,$CD
  DEFB $6C,$88,$CD,$24,$63,$CD,$18,$63
  DEFB $C3,$27,$63,$D5,$E5,$11,$FA,$FF
  DEFB $EB,$A7,$ED,$52,$38,$06,$E1,$D1
  DEFB $1A,$77,$23,$C9,$21,$FE,$99,$CD
  DEFB $6C,$88,$3E,$FF,$E1,$D1,$C9,$78
  DEFB $B1,$C8,$C3,$59,$8A,$FE,$02,$28
  DEFB $04,$F1,$C3,$9A,$94,$21,$45,$9F
  DEFB $CD,$6C,$88,$21,$C8,$00,$C3,$27
  DEFB $8A,$11,$18,$5E,$CD,$FD,$7C,$2A
  DEFB $E3,$A4,$23,$22,$E3,$A4,$CD,$71
  DEFB $8C,$11,$1D,$5E,$C9

; Routine at 8505
;
; Used by the routine at 88FE.
  POP DE                  ; Pop last item from stack into DE
  POP HL                  ; Pop last item from stack into HL
  LD HL,($A53D)           ; L=PEEK $A53D; H=PEEK $A53E
  LD DE,($A53B)           ; E=PEEK $A53B; D=PEEK $A53C
  JP $7209                ; Jump to 7209

; Data block at 8511
  DEFB $CD,$3C,$63,$C3,$18,$90,$CD,$D9
  DEFB $8B,$D8,$2B,$7E,$FE,$20,$20,$03
  DEFB $23,$18,$F8,$A7,$C9,$21,$4F,$85
  DEFB $22,$3D,$5C,$31,$BF,$5D,$21,$FF
  DEFB $FF,$22,$1D,$A5,$C3,$32,$84

; Routine at 8538
  LD HL,$8551             ; HL=$8551
  LD ($5C3D),HL           ; POKE $5C3D,L; POKE $5C3E,H
  LD SP,$5DBF             ; SP=$5DBF
  LD A,$18                ; A=$18
  LD ($8216),A            ; POKE $8216,A
  LD HL,$FFFF             ; HL=$FFFF
  LD ($A51D),HL           ; POKE $A51D,L; POKE $A51E,H
  JP $7C2F                ; Jump to 7C2F

; Data block at 854F
  DEFB $26,$85,$38,$85,$D9,$2A,$3D,$5C
  DEFB $E5,$ED,$73,$B0,$5C,$21,$71,$85
  DEFB $E5,$ED,$73,$3D,$5C,$D9,$CD,$7C
  DEFB $85,$ED,$7B,$B0,$5C,$E1,$22,$3D
  DEFB $5C,$C9,$21,$1F,$9F,$CD,$6C,$88
  DEFB $CD,$18,$63,$18,$EC,$C5,$C9,$AF
  DEFB $32,$E3,$A4,$EB,$CD,$15,$7A,$EB
  DEFB $3A,$E3,$A4,$5F,$16,$00,$7E,$E6
  DEFB $DF,$CA,$1C,$85,$23,$18,$F7,$F5
  DEFB $C5

; Message at 8598
  DEFM "M!O"

; Data block at 859B
  DEFB $A5,$7E,$A7,$28,$13,$B9,$28,$05
  DEFB $23,$23,$23,$18,$F4,$23,$CD,$4F
  DEFB $87,$1B,$3E,$20,$12,$C1,$F1,$C9
  DEFB $3E,$2A,$12,$13,$18,$F4,$21,$1E
  DEFB $5E,$22,$43,$A5,$21,$00,$5B,$AF
  DEFB $32,$1E,$5E,$C9,$E5,$2A,$43,$A5
  DEFB $77,$23,$22,$43,$A5,$E1,$C9,$E5
  DEFB $2A,$43,$A5,$73,$23,$72,$23,$18
  DEFB $F1

; Routine at 85DC
;
; Used by the routine at 7BA4.
  CALL $829B              ; CALL 829B
  RET C                   ; Return if the carry flag is set
  JP $8347                ; Jump to 8347

; Data block at 85E3
  DEFB $07,$21,$9B,$82,$22,$FF,$A4,$21
  DEFB $77,$94,$11,$11,$5B,$01,$EF,$00
  DEFB $ED,$B0,$21,$77,$94,$11,$78,$94
  DEFB $01,$EE,$00,$ED,$B0,$21,$00,$5B
  DEFB $C9,$21,$11,$5B,$11,$77,$94,$01
  DEFB $EF,$00,$ED,$B0,$21,$DC,$85,$22
  DEFB $FF,$A4,$C9,$21,$1E

; Message at 8618
  DEFM "c\"r"

; Data block at 861B
  DEFB $88,$CD,$05,$83,$CD,$2A,$86,$CD
  DEFB $26,$83,$CD,$2A,$86,$18,$F2,$21
  DEFB $FB,$9E,$CD,$6C,$88,$CD,$18,$63
  DEFB $FE,$FC,$C0,$21,$8A

; Message at 8638
  DEFM "w\"r"

; Data block at 863B
  DEFB $88,$F1,$C9,$2A,$0B,$A5,$7C,$FE
  DEFB $27,$D8,$7D,$FE,$0F,$D8,$2B,$C9

; Routine at 864B
;
; Used by the routines at 778A, 79E3 and 7A64.
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET Z                   ; Return if A=0
  CP $20                  ; Set the zero flag if A=$20, or the carry flag if
                          ; A<$20
  RET Z                   ; Return if A=$20
  CP $2E                  ; Set the zero flag if A=$2E, or the carry flag if
                          ; A<$2E
  RET Z                   ; Return if A=$2E
  CP $2C                  ; Set the zero flag if A=$2C, or the carry flag if
                          ; A<$2C
  RET Z                   ; Return if A=$2C
  CP $2D                  ; Set the zero flag if A=$2D, or the carry flag if
                          ; A<$2D
  RET Z                   ; Return if A=$2D
  CP $21                  ; Set the zero flag if A=$21, or the carry flag if
                          ; A<$21
  RET Z                   ; Return if A=$21
  CP $3F                  ; Set the zero flag if A=$3F, or the carry flag if
                          ; A<$3F
  RET Z                   ; Return if A=$3F
  CP $3A                  ; Set the zero flag if A=$3A, or the carry flag if
                          ; A<$3A
  RET                     ; Return

; Data block at 8662
  DEFB $0E,$00,$A7,$C8,$0C,$FE,$20,$C8
  DEFB $0C,$FE,$2E,$C8,$0C,$FE,$2C,$C8
  DEFB $0C,$FE,$2D,$C8,$0C,$FE,$21,$C8
  DEFB $0C,$FE,$3F,$C8,$0C,$C9,$06,$00
  DEFB $E5,$7E,$CD,$4B,$86,$28,$25,$E6
  DEFB $60,$FE,$60,$20,$04,$06,$40,$18
  DEFB $1B,$7E,$E6,$60,$FE,$40,$28,$03
  DEFB $23,$18,$E6,$06,$80,$23,$7E,$CD
  DEFB $4B,$86,$28,$08,$E6,$60,$FE,$60
  DEFB $20,$F3,$06,$00,$E1,$E5,$7E,$CD
  DEFB $4B,$86,$28,$0B,$E6,$60,$FE,$60
  DEFB $20,$02,$CB,$AE,$23,$18,$EF,$7E
  DEFB $A7,$CD,$62,$86,$79,$07,$07,$07
  DEFB $B0,$47,$2B,$CB,$FE,$23,$E1,$C9
  DEFB $E5,$CD,$80,$86

; Message at 86D6
  DEFM "x29"

; Data block at 86D9
  DEFB $A5,$2A,$31,$A5,$D1,$01,$00,$00
  DEFB $C5,$D5,$7E,$23,$A7,$28,$20,$E5
  DEFB $4F,$1A,$BE,$20,$08,$E6,$80,$20
  DEFB $0D,$23,$13,$18,$F4,$E1,$D1,$06
  DEFB $00,$09,$C1,$03,$18,$E2,$E1,$C1
  DEFB $C1,$3A,$39,$A5,$B0,$47,$C9,$D1
  DEFB $C1,$2B,$DD,$E5,$E5,$DD,$E1,$23
  DEFB $CD,$BB,$84,$13,$DD,$34,$00,$E6
  DEFB $80,$28,$F5,$DD,$E1,$36,$00,$22
  DEFB $33,$A5,$1B,$18,$DC,$D5,$7E,$CD
  DEFB $4B,$86,$28,$07,$CD,$D2,$86,$EB
  DEFB $D1,$23,$C9,$01,$00,$C0,$D1,$CD
  DEFB $62,$86,$79,$07,$07,$07,$B0,$47
  DEFB $FE,$C0,$C8,$0E,$01,$7E,$23,$BE
  DEFB $2B,$C0,$03,$23,$18,$F7

; Routine at 874F
;
; Used by the routines at 7508 and 752C.
  PUSH BC                 ; Push BC onto the stack
  LD C,(HL)               ; C=PEEK HL
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  INC HL                  ; HL=HL+1
  LD B,A                  ; B=A
  AND $C0                 ; Keep only bits 6 and 7 of A
  CP $C0                  ; Set the zero flag if A=$C0, or the carry flag if
                          ; A<$C0
  JP Z,$87B5              ; Jump to 87B5 if A=$C0
  PUSH HL                 ; Push HL onto the stack
  PUSH DE                 ; Push DE onto the stack
  PUSH BC                 ; Push BC onto the stack
  LD A,B                  ; A=B
  AND $07                 ; Keep only bits 0, 1 and 2 of A
  LD B,A                  ; B=A
  LD HL,($A531)           ; L=PEEK $A531; H=PEEK $A532
  LD A,B                  ; A=B
  OR C                    ; A=A|C
  JR Z,$8772              ; Jump to 8772 if A=0
  LD E,(HL)               ; E=PEEK HL
  LD D,$00                ; D=$00
  INC HL                  ; HL=HL+1
  DEC BC                  ; BC=BC-1
  ADD HL,DE               ; HL=HL+DE
  JR $8766                ; Jump to 8766
  INC HL                  ; HL=HL+1
  POP BC                  ; Pop last item from stack into BC
  POP DE                  ; Pop last item from stack into DE
  LD A,B                  ; A=B
  AND $C0                 ; Keep only bits 6 and 7 of A
  CP $40                  ; Set the zero flag if A=$40, or the carry flag if
                          ; A<$40
  JR NZ,$8788             ; Jump to 8788 if A<>$40
  LD A,(HL)               ; A=PEEK HL
  AND $40                 ; Keep only bit 6 of A
  CP $40                  ; Set the zero flag if A=$40, or the carry flag if
                          ; A<$40
  LD A,(HL)               ; A=PEEK HL
  JR NZ,$8792             ; Jump to 8792 if the zero flag is not set
  OR $20                  ; Set bit 5 of A
  JR $8792                ; Jump to 8792
  CP $80                  ; Set the zero flag if A=$80, or the carry flag if
                          ; A<$80
  JR NZ,$878F             ; Jump to 878F if A<>$80
  LD A,(HL)               ; A=PEEK HL
  JR $8792                ; Jump to 8792
  LD A,(HL)               ; A=PEEK HL
  SET 6,B                 ; Set bit 6 of B
  AND $7F                 ; Reset bit 7 of A
  LD (DE),A               ; POKE DE,A
  LD A,(HL)               ; A=PEEK HL
  INC HL                  ; HL=HL+1
  INC DE                  ; DE=DE+1
  AND $80                 ; Keep only bit 7 of A
  JR Z,$8775              ; Jump to 8775 if A=0
  LD A,B                  ; A=B
  AND $38                 ; Keep only bits 3, 4 and 5 of A
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  PUSH HL                 ; Push HL onto the stack
  LD HL,$A1E5             ; HL=$A1E5
  LD C,A                  ; C=A
  LD B,$00                ; B=$00
  ADD HL,BC               ; HL=HL+BC
  LD A,(HL)               ; A=PEEK HL
  POP HL                  ; Pop last item from stack into HL
  LD (DE),A               ; POKE DE,A
  INC DE                  ; DE=DE+1
  POP HL                  ; Pop last item from stack into HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JP NZ,$8750             ; Jump to 8750 if A>0
  POP BC                  ; Pop last item from stack into BC
  RET                     ; Return
  LD A,B                  ; A=B
  AND $38                 ; Keep only bits 3, 4 and 5 of A
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  PUSH BC                 ; Push BC onto the stack
  PUSH HL                 ; Push HL onto the stack
  LD HL,$A1E5             ; HL=$A1E5
  LD C,A                  ; C=A
  LD B,$00                ; B=$00
  ADD HL,BC               ; HL=HL+BC
  LD A,(HL)               ; A=PEEK HL
  POP HL                  ; Pop last item from stack into HL
  POP BC                  ; Pop last item from stack into BC
  LD B,C                  ; B=C
  LD (DE),A               ; POKE DE,A
  INC DE                  ; DE=DE+1
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$87B3              ; Jump to 87B3 if A=0
  DJNZ $87C8              ; Decrement B and jump to 87C8 if B>0
  JP $8750                ; Jump to 8750

; Data block at 87D2
  DEFB $C5,$D5,$E5,$C5,$E1,$ED,$4B,$37
  DEFB $A5,$A7,$ED

; Message at 87DD
  DEFM "B(>8 "

; Data block at 87E2
  DEFB $ED,$5B,$33,$A5,$19,$EB,$E1,$E5
  DEFB $ED,$4B,$37,$A5,$09,$D5,$EB,$2A
  DEFB $33,$A5,$A7,$ED,$52,$D1,$44,$4D
  DEFB $03,$2A,$33,$A5,$ED,$B8,$18,$1C
  DEFB $D1,$D5,$EB,$19,$ED,$4B,$37,$A5
  DEFB $09,$E5,$A7,$ED,$52,$E5,$EB,$2A
  DEFB $33,$A5,$A7,$ED,$52,$23,$44,$4D
  DEFB $E1,$D1,$ED,$B0,$E1,$D1,$C1,$78
  DEFB $B1,$C8,$EB,$ED,$B0,$EB,$C9,$DD
  DEFB $E5,$C5,$06,$0B,$C5,$DD,$46,$15
  DEFB $DD,$4E,$14,$E5,$A7,$ED,$42,$E1
  DEFB $30,$1A,$E5,$C5,$E1,$C1,$19,$E5
  DEFB $C5,$E1,$C1,$DD,$70,$15,$DD,$71
  DEFB $14,$C1,$DD,$2B,$DD,$2B,$10,$DC
  DEFB $C1,$DD,$E1,$C9,$C1,$18,$F9

; Routine at 8859
;
; Used by the routine at 88D9.
  LD HL,$0000             ; HL=$0000
  PUSH DE                 ; Push DE onto the stack
  PUSH BC                 ; Push BC onto the stack
  LD D,$00                ; D=$00
  LD B,$08                ; B=$08
  ADD HL,HL               ; HL=HL+HL
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  JR NC,$8867             ; Jump to 8867 if the carry flag is not set
  ADD HL,DE               ; HL=HL+DE
  DJNZ $8862              ; Decrement B and jump to 8862 if B>0
  POP BC                  ; Pop last item from stack into BC
  POP DE                  ; Pop last item from stack into DE
  RET                     ; Return

; Routine at 886C
;
; Used by the routines at 7508, 752C, 754F, 7649, 76A8, 7C3F and 81E1.
  LD A,(HL)               ; A=PEEK HL
  INC HL                  ; HL=HL+1
  CP $FF                  ; Set the zero flag if A=$FF, or the carry flag if
                          ; A<$FF
  RET Z                   ; Return if A=$FF
  CALL $631E              ; CALL 631E
  JR $886C                ; Jump to 886C

; Data block at 8876
  DEFB $3E,$30,$A7,$ED,$42,$38,$03,$3C
  DEFB $18,$F8,$09,$FE,$30,$28,$06,$32
  DEFB $3A,$A5,$C3,$1E,$63,$DD,$CB,$1B
  DEFB $66,$20,$F7,$C9,$AF,$32,$3A,$A5
  DEFB $01,$10,$27,$CD,$76,$88,$01,$E8
  DEFB $03,$CD,$76,$88,$01,$64,$00,$CD
  DEFB $76,$88,$01,$0A,$00,$CD,$76,$88
  DEFB $7D,$C6,$30,$C3,$1E,$63,$C5,$EB
  DEFB $1A,$13,$A7,$28,$1B,$FE,$20,$28
  DEFB $17,$FE,$30,$38,$13,$FE,$3A,$30
  DEFB $0E,$E6,$0F

; Message at 88C9
  DEFM "DM))"

; Data block at 88CD
  DEFB $09,$29,$4F,$06,$00,$09,$18,$E1
  DEFB $37,$EB,$C1,$C9

; Routine at 88D9
;
; Used by the routine at 88FE.
  PUSH IX                 ; Push IX onto the stack
  PUSH HL                 ; Push HL onto the stack
  PUSH DE                 ; Push DE onto the stack
  LD IX,$A1ED             ; IX=$A1ED
  LD B,$00                ; B=$00
  ADD IX,BC               ; IX=IX+BC
  LD E,(IX+$00)           ; E=PEEK (IX+$00)
  LD A,($A53F)            ; A=PEEK $A53F
  CALL $8859              ; CALL 8859
  LD B,H                  ; B=H
  LD E,(IX+$08)           ; E=PEEK (IX+$08)
  LD A,($A540)            ; A=PEEK $A540
  CALL $8859              ; CALL 8859
  LD C,H                  ; C=H
  POP DE                  ; Pop last item from stack into DE
  POP HL                  ; Pop last item from stack into HL
  POP IX                  ; Pop last item from stack into IX
  RET                     ; Return

; Routine at 88FE
;
; Used by the routine at 651D.
  PUSH HL                 ; Push HL onto the stack
  PUSH DE                 ; Push DE onto the stack
  LD BC,($A53D)           ; C=PEEK $A53D; B=PEEK $A53E
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,BC               ; HL=HL-carry-BC
  JR NC,$8912             ; Jump to 8912 if the carry flag is not set
  ADD HL,BC               ; HL=HL+BC
  PUSH HL                 ; Push HL onto the stack
  LD HL,($A53D)           ; L=PEEK $A53D; H=PEEK $A53E
  POP BC                  ; Pop last item from stack into BC
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,BC               ; HL=HL-carry-BC
  LD A,L                  ; A=L
  LD ($A540),A            ; POKE $A540,A
  LD HL,($A53B)           ; L=PEEK $A53B; H=PEEK $A53C
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,DE               ; HL=HL-carry-DE
  JR NC,$8927             ; Jump to 8927 if the carry flag is not set
  PUSH DE                 ; Push DE onto the stack
  LD DE,($A53B)           ; E=PEEK $A53B; D=PEEK $A53C
  POP HL                  ; Pop last item from stack into HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,DE               ; HL=HL-carry-DE
  LD A,L                  ; A=L
  LD ($A53F),A            ; POKE $A53F,A
  LD D,$00                ; D=$00
  LD A,($A53F)            ; A=PEEK $A53F
  LD E,A                  ; E=A
  LD HL,($A53B)           ; L=PEEK $A53B; H=PEEK $A53C
  ADD HL,DE               ; HL=HL+DE
  EX DE,HL                ; Exchange DE and HL
  LD HL,($A53D)           ; L=PEEK $A53D; H=PEEK $A53E
  CALL $7209              ; CALL 7209
  LD C,$00                ; C=$00
  PUSH BC                 ; Push BC onto the stack
  CALL $88D9              ; CALL 88D9
  LD HL,($A53D)           ; L=PEEK $A53D; H=PEEK $A53E
  PUSH BC                 ; Push BC onto the stack
  LD B,$00                ; B=$00
  ADD HL,BC               ; HL=HL+BC
  POP BC                  ; Pop last item from stack into BC
  EX DE,HL                ; Exchange DE and HL
  LD C,B                  ; C=B
  LD B,$00                ; B=$00
  LD HL,($A53B)           ; L=PEEK $A53B; H=PEEK $A53C
  ADD HL,BC               ; HL=HL+BC
  EX DE,HL                ; Exchange DE and HL
  CALL $7202              ; CALL 7202
  POP BC                  ; Pop last item from stack into BC
  INC C                   ; C=C+1
  LD A,C                  ; A=C
  CP $08                  ; Set the zero flag if A=$08, or the carry flag if
                          ; A<$08
  JR NZ,$893E             ; Jump to 893E if A<>$08
  LD D,$00                ; D=$00
  LD A,($A53F)            ; A=PEEK $A53F
  LD E,A                  ; E=A
  LD HL,($A53B)           ; L=PEEK $A53B; H=PEEK $A53C
  ADD HL,DE               ; HL=HL+DE
  EX DE,HL                ; Exchange DE and HL
  LD HL,($A53D)           ; L=PEEK $A53D; H=PEEK $A53E
  CALL $7209              ; CALL 7209
  LD C,$00                ; C=$00
  PUSH BC                 ; Push BC onto the stack
  CALL $88D9              ; CALL 88D9
  LD HL,($A53D)           ; L=PEEK $A53D; H=PEEK $A53E
  PUSH BC                 ; Push BC onto the stack
  LD B,$00                ; B=$00
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,BC               ; HL=HL-carry-BC
  POP BC                  ; Pop last item from stack into BC
  EX DE,HL                ; Exchange DE and HL
  LD C,B                  ; C=B
  LD B,$00                ; B=$00
  LD HL,($A53B)           ; L=PEEK $A53B; H=PEEK $A53C
  ADD HL,BC               ; HL=HL+BC
  EX DE,HL                ; Exchange DE and HL
  CALL $7202              ; CALL 7202
  POP BC                  ; Pop last item from stack into BC
  INC C                   ; C=C+1
  LD A,C                  ; A=C
  CP $08                  ; Set the zero flag if A=$08, or the carry flag if
                          ; A<$08
  JR NZ,$8970             ; Jump to 8970 if A<>$08
  LD D,$00                ; D=$00
  LD A,($A53F)            ; A=PEEK $A53F
  LD E,A                  ; E=A
  LD HL,($A53B)           ; L=PEEK $A53B; H=PEEK $A53C
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,DE               ; HL=HL-carry-DE
  EX DE,HL                ; Exchange DE and HL
  LD HL,($A53D)           ; L=PEEK $A53D; H=PEEK $A53E
  CALL $7209              ; CALL 7209
  LD C,$00                ; C=$00
  PUSH BC                 ; Push BC onto the stack
  CALL $88D9              ; CALL 88D9
  LD HL,($A53D)           ; L=PEEK $A53D; H=PEEK $A53E
  PUSH BC                 ; Push BC onto the stack
  LD B,$00                ; B=$00
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,BC               ; HL=HL-carry-BC
  POP BC                  ; Pop last item from stack into BC
  EX DE,HL                ; Exchange DE and HL
  LD C,B                  ; C=B
  LD B,$00                ; B=$00
  LD HL,($A53B)           ; L=PEEK $A53B; H=PEEK $A53C
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,BC               ; HL=HL-carry-BC
  EX DE,HL                ; Exchange DE and HL
  CALL $7202              ; CALL 7202
  POP BC                  ; Pop last item from stack into BC
  INC C                   ; C=C+1
  LD A,C                  ; A=C
  CP $08                  ; Set the zero flag if A=$08, or the carry flag if
                          ; A<$08
  JR NZ,$89A6             ; Jump to 89A6 if A<>$08
  LD D,$00                ; D=$00
  LD A,($A53F)            ; A=PEEK $A53F
  LD E,A                  ; E=A
  LD HL,($A53B)           ; L=PEEK $A53B; H=PEEK $A53C
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,DE               ; HL=HL-carry-DE
  EX DE,HL                ; Exchange DE and HL
  LD HL,($A53D)           ; L=PEEK $A53D; H=PEEK $A53E
  CALL $7209              ; CALL 7209
  LD C,$00                ; C=$00
  PUSH BC                 ; Push BC onto the stack
  CALL $88D9              ; CALL 88D9
  LD HL,($A53D)           ; L=PEEK $A53D; H=PEEK $A53E
  PUSH BC                 ; Push BC onto the stack
  LD B,$00                ; B=$00
  ADD HL,BC               ; HL=HL+BC
  POP BC                  ; Pop last item from stack into BC
  EX DE,HL                ; Exchange DE and HL
  LD C,B                  ; C=B
  LD B,$00                ; B=$00
  LD HL,($A53B)           ; L=PEEK $A53B; H=PEEK $A53C
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,BC               ; HL=HL-carry-BC
  EX DE,HL                ; Exchange DE and HL
  CALL $7202              ; CALL 7202
  POP BC                  ; Pop last item from stack into BC
  INC C                   ; C=C+1
  LD A,C                  ; A=C
  CP $08                  ; Set the zero flag if A=$08, or the carry flag if
                          ; A<$08
  JR NZ,$89DE             ; Jump to 89DE if A<>$08
  JP $8505                ; Jump to 8505

; Data block at 8A02
  DEFB $B9,$84,$21,$00,$5B,$36,$00,$CD
  DEFB $93,$82,$D0,$21,$00,$5B,$CD,$D9
  DEFB $8B,$EB,$3F,$30,$04,$7C,$B5,$37
  DEFB $C0,$21,$69,$98,$CD,$6C,$88,$C3
  DEFB $04,$8A,$CD,$F9,$72,$CD,$32,$8A
  DEFB $20,$FB,$CD,$32,$8A,$28,$FB,$C9
  DEFB $7C,$B5,$28,$07

; Message at 8A36
  DEFM "v+:"

; Data block at 8A39
  DEFB $04,$5C,$3C,$C9,$E1,$C9

; Routine at 8A3F
;
; Used by the routines at 75B6, 7B79 and 8A59.
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  INC HL                  ; HL=HL+1
  LD A,D                  ; A=D
  OR E                    ; A=A|E
  JR NZ,$8A49             ; Jump to 8A49 if A>0
  SCF                     ; Set the carry flag
  RET                     ; Return
  LD A,E                  ; A=E
  CP C                    ; Set the zero flag if A=C, or the carry flag if A<C
  JR NZ,$8A4F             ; Jump to 8A4F if A<>C
  LD A,D                  ; A=D
  CP B                    ; Set the zero flag if A=B, or the carry flag if A<B
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  INC HL                  ; HL=HL+1
  NOP                     ; Do nothing
  NOP                     ; Do nothing
  RET Z                   ; Return if the zero flag is set
  ADD HL,DE               ; HL=HL+DE
  JR $8A3F                ; Jump to 8A3F

; Routine at 8A59
;
; Used by the routine at 75B6.
  LD A,$2B                ; A=$2B
  LD ($8A52),A            ; POKE $8A52,A
  LD ($8A53),A            ; POKE $8A53,A
  LD ($8A54),A            ; POKE $8A54,A
  CALL $8A3F              ; CALL 8A3F
  LD A,$23                ; A=$23
  LD ($8A52),A            ; POKE $8A52,A
  LD A,$00                ; A=$00
  LD ($8A53),A            ; POKE $8A53,A
  LD ($8A54),A            ; POKE $8A54,A
  RET                     ; Return

; Routine at 8A75
;
; Used by the routines at 7508, 752C and 76F6.
  LD D,$00                ; D=$00
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$8A7D             ; Jump to 8A7D if A>0
  SCF                     ; Set the carry flag
  RET                     ; Return
  INC HL                  ; HL=HL+1
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  CP C                    ; Set the zero flag if A=C, or the carry flag if A<C
  RET Z                   ; Return if A=C
  ADD HL,DE               ; HL=HL+DE
  JR $8A77                ; Jump to 8A77

; Data block at 8A85
  DEFB $78,$B1,$C8,$AF,$32,$45,$A5,$78
  DEFB $E6,$80,$20,$1A,$E5,$D5,$21,$18
  DEFB $62,$E5,$09,$EB,$21,$19,$62,$ED
  DEFB $4B,$06,$A5,$A7,$ED

; Message at 8AA2
  DEFM "BDM"

; Data block at 8AA5
  DEFB $E1,$ED,$B8,$D1,$E1,$C9,$E5,$D5
  DEFB $2A,$06,$A5,$E5,$A7,$ED,$42,$EB
  DEFB $21,$18,$62,$ED,$4B,$06,$A5,$A7
  DEFB $ED

; Message at 8ABE
  DEFM "BDM"

; Data block at 8AC1
  DEFB $E1,$EB,$ED,$B0,$D1,$E1,$C9,$5E
  DEFB $23,$EB,$26,$00,$29,$EB,$C9,$7B
  DEFB $32,$1A,$5E,$ED,$4B,$19,$5E,$C9
  DEFB $C3,$96,$84,$11,$18,$5E,$CD,$D2
  DEFB $87,$E1,$ED,$4B,$37,$A5,$A7,$ED
  DEFB $42,$EB,$2A,$35,$A5,$CD,$29,$88
  DEFB $C3,$47,$84,$D5,$CD,$26,$87,$D1
  DEFB $79,$12,$13,$78,$12,$13,$E6,$38
  DEFB $C8,$23,$18,$EF,$3E,$01,$CD

; Message at 8B08
  DEFM "0c!5"

; Data block at 8B0C
  DEFB $9A,$CD,$6C,$88,$21,$00,$5B,$36
  DEFB $00,$CD,$93,$82,$D0,$3A,$00,$5B
  DEFB $A7,$20,$09,$2A,$0B,$A5,$23,$CD
  DEFB $B3,$8C,$18,$19,$21,$00,$5B,$CD
  DEFB $D9,$8B,$7A,$A7,$20,$03,$B3,$20
  DEFB $08,$21,$52,$9A,$CD,$6C,$88,$18
  DEFB $D3,$ED,$53,$0B,$A5,$ED,$4B,$0B
  DEFB $A5,$2A,$2D,$A5,$CD,$75,$8A,$30
  DEFB $1B,$22,$35,$A5,$21,$00,$00,$22
  DEFB $37,$A5,$3A,$0B,$A5,$21,$18,$5E
  DEFB $77,$23,$AF,$77,$23,$77,$23,$36
  DEFB $C0,$2B,$18,$15,$2B,$2B,$13,$13
  DEFB $22,$35,$A5,$ED,$53,$37,$A5,$42
  DEFB $4B,$11,$18,$5E,$ED,$B0,$21,$1A
  DEFB $5E,$11,$00,$5B,$CD,$4F,$87,$21
  DEFB $71,$9A,$CD,$6C,$88,$2A,$0B,$A5
  DEFB $CD,$92,$88,$21,$82,$9A,$CD,$6C
  DEFB $88,$21,$00,$5B,$CD,$9B,$82,$D2
  DEFB $0A,$8B,$21,$00,$5B,$11,$1A,$5E
  DEFB $CD,$F4,$8A,$01,$02,$00,$21,$1B
  DEFB $5E,$7E,$E6,$38,$28,$06,$23,$23
  DEFB $03,$03,$18,$F5,$78,$A7,$28,$08
  DEFB $21,$8C,$9A,$CD,$6C,$88,$18,$D1
  DEFB $79,$32,$19,$5E,$03,$03,$3A,$1B
  DEFB $5E,$FE,$C0,$20,$02,$0E,$00,$CD
  DEFB $D9,$8A,$C3,$0A,$8B,$11,$00,$00
  DEFB $C3,$B4,$88,$C5,$D5,$11,$A5,$9F
  DEFB $E5,$01,$00,$04,$1A,$FE,$2A,$28
  DEFB $18,$FE,$20,$20,$05,$7E,$A7,$28
  DEFB $10,$1A,$C5,$7E,$FE,$61,$38,$02
  DEFB $E6,$DF,$47,$1A,$B8,$C1,$28,$01
  DEFB $0C,$13,$23,$10,$DF,$79,$A7,$28
  DEFB $0A,$E1,$1A,$FE,$FF,$20,$D1,$37
  DEFB $D1,$C1,$C9,$E1,$1B,$D5,$E5,$EB
  DEFB $11,$A5,$9F,$A7,$ED,$52,$7D,$E1
  DEFB $D1,$E6,$FC,$0F,$0F,$A7,$D1,$C1
  DEFB $C9,$7E,$A7,$20,$02,$12,$C9,$DD
  DEFB $36,$2D,$00,$C3,$44,$7E,$22,$11
  DEFB $A5,$22,$0F,$A5,$C9,$11,$18,$60
  DEFB $21,$19,$5E,$D5,$CD,$4F,$87,$D1
  DEFB $2A,$0F,$A5,$01,$00,$00,$C3,$2E
  DEFB $95,$3E,$30,$A7,$ED,$42,$38,$03
  DEFB $3C,$18,$F8,$09,$FE,$30,$28,$06
  DEFB $32,$3A,$A5,$12,$13,$C9,$DD,$CB
  DEFB $1B,$66,$20,$F7,$C9,$AF,$32,$3A
  DEFB $A5,$01,$10,$27,$CD,$55,$8C,$01
  DEFB $E8,$03,$CD,$55,$8C,$01,$64,$00
  DEFB $CD,$55,$8C,$01,$0A,$00,$CD,$55
  DEFB $8C,$7D,$C6,$30,$12,$13,$C9,$7E
  DEFB $A7,$C2,$B5,$7F,$12,$C9,$02,$E5
  DEFB $D5,$11,$17,$5F,$23,$CD,$4F,$87
  DEFB $4B,$D1,$D5,$21,$17,$5F,$1A,$BE
  DEFB $23,$13,$28,$FA,$D1,$E1,$C9,$7C
  DEFB $A7,$C0,$22,$0B,$A5,$C9,$C9,$21
  DEFB $18,$5E,$11,$00,$5B,$CD,$93,$8C
  DEFB $21,$00,$5B,$CD,$9B,$82,$3F,$D8
  DEFB $21,$00,$5B,$11,$18,$5E,$CD,$2D
  DEFB $8C,$3E,$00,$12,$D0,$E5,$21,$A0
  DEFB $9A,$CD,$6C,$88,$E1,$7E,$AF,$28
  DEFB $0A,$FE,$20,$28,$06,$CD,$1E,$63
  DEFB $23,$18,$F2,$21,$6A,$97,$CD,$6C
  DEFB $88,$18,$CD,$7E,$A7,$C8,$23,$FE
  DEFB $3F,$20,$02,$A7,$C9,$E6,$80,$28
  DEFB $F2,$23,$18,$EF,$3E,$01,$CD

; Message at 8D0B
  DEFM "0c!"

; Data block at 8D0E
  DEFB $B6,$9A,$CD,$6C,$88,$21,$00,$5B
  DEFB $36,$00,$CD,$93,$82,$D0,$21,$00
  DEFB $5B,$7E,$A7,$20,$09,$CD,$3E,$86
  DEFB $23,$22,$0B,$A5,$18,$15,$CD,$D9
  DEFB $8B,$38,$04,$7A,$B3,$20,$08,$21
  DEFB $15,$9A,$CD,$6C,$88,$18,$D6,$ED
  DEFB $53,$0B,$A5,$ED,$4B,$0B,$A5,$2A
  DEFB $0D,$A5,$0B,$78,$B1,$28,$05,$CD
  DEFB $F7,$8C,$20,$F6,$22,$35,$A5,$11
  DEFB $18,$5E,$01,$00,$00,$7E,$12,$A7
  DEFB $28,$11,$23,$13,$03,$CB,$7F,$28
  DEFB $06,$7E,$12,$23,$13,$03,$AF,$FE
  DEFB $3F,$20,$EA,$AF,$12,$ED,$43,$37
  DEFB $A5,$21,$D1,$9A,$CD,$6C,$88,$2A
  DEFB $0B,$A5,$CD,$92,$88,$21,$82,$9A
  DEFB $CD,$6C,$88,$CD,$BB,$8C,$DA,$0D
  DEFB $8D,$21,$18,$5E,$EB,$ED

; Message at 8D94
  DEFM "RDM"

; Data block at 8D97
  DEFB $CD,$D9,$8A,$C3,$0D,$8D,$2A,$27
  DEFB $A5,$18,$03,$2A,$2B,$A5,$22,$0D
  DEFB $A5,$C3,$08,$8D,$3E,$01,$CD

; Message at 8DAE
  DEFM "0c!"

; Data block at 8DB1
  DEFB $96,$9E,$CD,$6C,$88,$21,$00,$5B
  DEFB $36,$00,$CD,$93,$82,$D2,$37,$8E
  DEFB $21,$00,$5B,$7E,$A7,$20,$09,$CD
  DEFB $3E,$86,$23,$22,$0B,$A5,$18,$15
  DEFB $CD,$D9,$8B,$38,$04,$7A,$B3,$20
  DEFB $08,$21,$69,$98,$CD,$6C,$88,$18
  DEFB $D4,$ED,$53,$0B,$A5,$ED,$4B,$0B
  DEFB $A5,$2A,$29,$A5,$5E,$23,$56,$23
  DEFB $7A,$B3,$28,$0F,$EB,$A7,$ED,$42
  DEFB $EB,$28,$32,$CD,$F7,$8C,$20,$FB
  DEFB $23,$18,$E9,$22,$0D,$A5

; Message at 8E07
  DEFM "++\"5"

; Data block at 8E0B
  DEFB $A5,$21,$00,$00,$22,$1A,$5E,$22
  DEFB $37,$A5,$2A,$0B,$A5,$22,$18,$5E
  DEFB $22,$18,$5E,$ED,$5B,$35,$A5,$01
  DEFB $03,$00,$CD,$D9,$8A,$2A,$0D,$A5
  DEFB $22,$35,$A5,$22,$0D,$A5,$CD,$08
  DEFB $8D,$C3,$B0,$8D,$2A,$29,$A5,$5E
  DEFB $23,$56,$23,$7A,$B3,$C8,$7E,$23
  DEFB $A7,$28,$08,$CD,$F7,$8C,$20,$FB
  DEFB $23,$18,$EC

; Message at 8E4E
  DEFM "+++"

; Data block at 8E51
  DEFB $E5,$22,$35,$A5,$EB,$21,$03,$00
  DEFB $22,$37,$A5,$01,$00,$00,$CD,$D9
  DEFB $8A,$E1,$18,$D5,$11,$51,$A5,$21
  DEFB $1F,$A5,$06,$0C,$73,$23,$72,$23
  DEFB $13,$13,$10,$F8,$3E,$80,$32,$41
  DEFB $A5,$32,$4B,$A5,$21,$4F,$A5,$11
  DEFB $50,$A5,$01,$FF,$00,$36,$00,$ED
  DEFB $B0,$DD,$21,$1F,$A5,$C9,$21,$00
  DEFB $5B,$06

; Message at 8E93
  DEFM "\"6 "

; Data block at 8E96
  DEFB $23,$10,$FB,$21,$00,$5B,$36,$00
  DEFB $CD,$A0,$82,$30,$07,$21,$F6,$9E
  DEFB $CD,$6C,$88,$C9,$F1,$C9,$21,$DF
  DEFB $9A,$CD,$6C,$88,$CD,$8F,$8E,$CD
  DEFB $E0,$8E,$2A,$33,$A5,$11,$1F,$A5
  DEFB $A7,$ED,$52,$DD,$21,$00,$5B,$DD
  DEFB $36,$00,$03,$DD,$75,$0B,$DD,$74
  DEFB $0C,$DD,$73,$0D,$DD,$72,$0E,$AF
  DEFB $32,$74,$5C,$EB,$01,$5A,$07,$C3
  DEFB $53,$85,$11,$0A,$5B,$21,$09,$5B
  DEFB $06,$0A,$7E,$A7,$20,$02,$3E,$20
  DEFB $12,$1B,$2B,$10,$F5,$C9,$AF,$12
  DEFB $13,$CD,$71,$8C,$AF,$12,$D1,$21
  DEFB $98,$62,$7E,$A7,$CA,$D0,$7E,$23
  DEFB $18,$F8,$CD,$CA,$74,$C9,$D5,$21
  DEFB $00,$5B,$36,$00,$CD,$8F,$82,$D1
  DEFB $D0,$D5,$21,$00,$5B,$7E,$A7,$20
  DEFB $03,$E1,$37,$C9,$CD,$D9,$8B,$38
  DEFB $07,$7A,$A7,$20,$03,$B3,$20,$08
  DEFB $21,$52,$9A,$CD,$6C,$88,$18,$D7
  DEFB $EB,$D1,$37,$C9,$D5,$E5,$6E,$26
  DEFB $00,$11,$00,$5B,$CD,$71,$8C,$CD
  DEFB $EC,$76,$E1,$23,$CD,$4F,$87,$EB
  DEFB $D1,$C9,$CD

; Message at 8F51
  DEFM "Gs!"

; Data block at 8F54
  DEFB $0E,$9B,$CD,$6C,$88,$21,$00,$00
  DEFB $22,$13,$A5,$3E,$01,$CD,$2A,$63
  DEFB $ED,$5B,$13,$A5,$1B,$1B,$CD,$A8
  DEFB $83,$CD,$BD,$83,$06,$12,$CB,$7A
  DEFB $20,$11,$D5,$C5,$E5,$CD,$3A,$8F
  DEFB $36,$FF,$21,$00,$5B,$CD,$6C,$88
  DEFB $E1,$C1,$D1,$E5,$C5,$D5,$21,$36
  DEFB $9B,$CD,$6C,$88,$D1,$C1,$E1,$23
  DEFB $23,$23,$13,$7E,$A7,$20,$02,$CB
  DEFB $FA,$10,$D3,$CD,$B2,$83,$FE,$F0
  DEFB $28,$19,$FE,$F1,$28,$2D,$FE,$FC
  DEFB $C8,$FE,$0D,$28,$76,$FE,$10,$28
  DEFB $58,$FE,$7F,$28,$36,$CD,$3C,$63
  DEFB $C3,$18,$90,$2A,$13,$A5,$2B,$CB
  DEFB $7C,$C2,$9F,$8F,$22,$13,$A5,$2A
  DEFB $11,$A5

; Message at 8FCE
  DEFM "+++\""

; Data block at 8FD2
  DEFB $11,$A5,$C3,$C9,$83,$2A,$11,$A5
  DEFB $23,$23,$23,$7E,$A7,$CA,$9F,$8F
  DEFB $22,$11,$A5,$2A,$13,$A5,$23,$22
  DEFB $13,$A5,$C3,$06,$84,$7E,$A7,$C3
  DEFB $FA,$77,$E5,$11,$18,$5E,$01,$03
  DEFB $00,$ED,$B0,$21,$03,$00,$22,$37
  DEFB $A5,$E1,$22,$35,$A5,$CD,$D9,$8A
  DEFB $C3,$5F,$8F,$C3,$EC,$77,$21,$00
  DEFB $00,$22,$37,$A5,$18

; Message at 9017
  DEFM "Z\"5"

; Data block at 901A
  DEFB $A5,$21,$00,$00,$22,$37,$A5,$AF
  DEFB $32,$00,$5B,$18,$0C,$C3,$3E,$81
  DEFB $CD,$44,$94,$21,$00,$00,$22,$37
  DEFB $A5,$21,$3B,$9B,$CD,$6C,$88,$21
  DEFB $00,$5B,$CD,$97,$82

; Message at 903F
  DEFM "07:"

; Data block at 9042
  DEFB $00,$5B,$A7,$CA,$9F,$8F,$CD,$95
  DEFB $75,$CD,$D9,$8B,$38,$07,$7A,$A7
  DEFB $20,$03,$B3,$20,$08,$21,$3F,$9B
  DEFB $CD,$6C,$88,$18,$D4,$32,$18,$5E
  DEFB $CD,$90,$75,$CD,$F4,$8A,$3A,$1A
  DEFB $5E,$E6,$07,$F6,$80,$32,$1A,$5E
  DEFB $CD,$41,$8C,$CD,$D9,$8A,$21,$44
  DEFB $9B,$CD,$6C,$88,$C3,$5F,$8F,$3E
  DEFB $01,$CD

; Message at 9084
  DEFM "0c!I"

; Data block at 9088
  DEFB $9B,$CD,$6C,$88,$21,$4F,$A5,$C3
  DEFB $50,$8F,$3E,$01,$CD

; Message at 9095
  DEFM "0c!"

; Data block at 9098
  DEFB $5F,$9B,$CD,$6C,$88,$2A,$1F,$A5
  DEFB $C3,$50,$8F,$3E,$01,$CD

; Message at 90A6
  DEFM "0c!u"

; Data block at 90AA
  DEFB $9B,$CD,$6C,$88,$2A,$21,$A5,$C3
  DEFB $50,$8F,$C9,$CD,$CA,$74,$C9,$3E
  DEFB $01,$CD

; Message at 90BC
  DEFM "0c!"

; Data block at 90BF
  DEFB $8D,$9B,$CD,$6C,$88,$2A,$4D,$A5
  DEFB $11,$00,$5B,$CD,$71,$8C,$AF,$12
  DEFB $21,$00,$5B,$CD,$93,$82,$D0,$21
  DEFB $00,$5B,$CD,$D9,$8B,$38,$09,$7A
  DEFB $B3,$28,$05,$ED,$53,$4D,$A5,$C9
  DEFB $21,$69,$98,$CD,$6C,$88,$18,$E0
  DEFB $21,$00,$5B,$CD,$93,$82,$D0,$21
  DEFB $00,$5B,$CD,$D9,$8B,$EB,$3F,$D8
  DEFB $21,$69,$98,$CD,$6C,$88,$C3,$EF
  DEFB $90,$3E,$01,$CD

; Message at 910B
  DEFM "0c!"

; Data block at 910E
  DEFB $00,$00,$22,$0B,$A5,$21,$C3,$9B
  DEFB $CD,$6C,$88,$ED,$5B,$0B,$A5,$13
  DEFB $CD,$0C,$8F,$D0,$CD,$B3,$8C,$E5
  DEFB $21,$DF,$9B,$CD,$6C,$88,$E1,$E5
  DEFB $CD,$92,$88,$E1,$4D,$2A,$23,$A5
  DEFB $CD,$75,$8A,$DA,$EE,$91

; Message at 913C
  DEFM "++\"5"

; Data block at 9140
  DEFB $A5,$23,$4E,$06,$00,$2B,$03,$03
  DEFB $ED,$43,$37,$A5,$11,$18,$5E,$ED
  DEFB $B0,$21,$1D,$5E,$11,$00,$5B,$CD
  DEFB $4F,$87,$21,$82,$9A,$CD,$6C,$88
  DEFB $21,$00,$5B,$CD,$9B,$82,$D2,$13
  DEFB $91,$3A,$00,$5B,$A7,$20,$09,$01
  DEFB $00,$00,$CD,$D9,$8A,$C3,$13,$91
  DEFB $11,$1D,$5E,$21,$00,$5B,$CD,$F4
  DEFB $8A,$7B,$3D,$32,$19,$5E,$21,$E9
  DEFB $9B,$CD,$6C,$88,$2A,$1B,$5E,$11
  DEFB $00,$5B,$CD,$71,$8C,$AF,$12,$CD
  DEFB $EF,$90,$22,$1B,$5E,$D2,$13,$91
  DEFB $21,$FD,$9B,$CD,$6C,$88,$3A,$1A
  DEFB $5E,$6F,$26,$00,$11,$00,$5B,$CD
  DEFB $71,$8C,$AF,$12,$21,$00,$5B,$CD
  DEFB $BF,$91,$D2,$13,$91,$18,$21,$D5
  DEFB $C3,$12,$8F,$78,$B1,$28,$0B,$E5
  DEFB $2A,$0B,$A5,$A7,$ED,$42,$E1,$C2
  DEFB $59,$8A,$37,$C9,$C3,$3F,$8A,$CD
  DEFB $27,$63,$F5,$CD,$AC,$7C,$F1,$C9
  DEFB $EB,$CD,$D0,$8A,$06,$00,$03,$03
  DEFB $CD,$D9,$8A,$C3,$13,$91,$22,$35
  DEFB $A5,$21,$00,$00,$22,$37,$A5,$21
  DEFB $DF,$9B,$CD,$6C,$88,$2A,$0B,$A5
  DEFB $7D,$32,$18,$5E,$CD,$92,$88,$21
  DEFB $82,$9A,$CD,$6C,$88,$21,$00,$5B
  DEFB $36,$00,$CD,$9B,$82,$D2,$13,$91
  DEFB $3A,$00,$5B,$A7,$CA,$13,$91,$21
  DEFB $00,$5B,$11,$1D,$5E,$CD,$F4,$8A
  DEFB $7B,$3D,$32,$19,$5E,$21,$E9,$9B
  DEFB $CD,$6C,$88,$AF,$32,$00,$5B,$CD
  DEFB $EF,$90,$D2,$13,$91,$22,$1B,$5E
  DEFB $21,$FD,$9B,$CD,$6C,$88,$CD,$0C
  DEFB $8F,$D2,$13,$91,$7D,$32,$1A,$5E
  DEFB $ED,$4B,$19,$5E,$06,$00,$03,$03
  DEFB $CD,$D9,$8A,$C3,$13,$91,$3E,$01
  DEFB $CD

; Message at 9261
  DEFM "0c!"

; Data block at 9264
  DEFB $00,$00,$22,$0B,$A5,$21,$0C,$9C
  DEFB $CD,$6C,$88,$AF,$32,$00,$5B,$CD
  DEFB $04,$8A,$D0,$3A,$00,$5B,$A7,$20
  DEFB $04,$CD,$3E,$86,$23,$22,$0B,$A5

; Message at 9284
  DEFM "DM*%"

; Data block at 9288
  DEFB $A5,$CD,$3F,$8A,$DA,$E4,$93

; Message at 928F
  DEFM "++++"

; Data block at 9293
  DEFB $13,$13,$13,$13,$22,$35,$A5,$ED
  DEFB $53,$37,$A5,$42,$4B,$11,$18,$60
  DEFB $ED,$B0,$21,$26,$9C,$CD,$6C,$88
  DEFB $2A,$0B,$A5,$CD,$92,$88,$21,$82
  DEFB $9A,$CD,$6C,$88,$2A,$18,$60,$22
  DEFB $18,$5E,$2A,$1C,$60,$22,$1C,$5E
  DEFB $21,$00,$00,$22,$1A,$5E,$22,$1E
  DEFB $5E,$21,$1E,$60,$7E,$A7,$23,$28
  DEFB $04,$23,$23,$18,$F7,$11,$00,$5B
  DEFB $CD,$4F,$87,$21,$00,$5B,$CD,$9B
  DEFB $82,$D2,$69,$92,$21,$00,$5B,$7E
  DEFB $A7,$20,$09,$01,$00,$00,$CD,$D9
  DEFB $8A,$C3,$69,$92,$11,$1F,$5E,$CD
  DEFB $F4,$8A,$EB,$11,$E4,$A1,$19,$22
  DEFB $1A,$5E,$21,$1E,$60,$11,$00,$5B
  DEFB $7E,$A7,$28,$1E,$E5,$6F,$26,$00
  DEFB $CD,$96,$85,$3E,$20,$12,$13,$E1
  DEFB $23,$4E,$23,$46,$23,$E5,$60,$69
  DEFB $CD,$71,$8C,$3E,$20,$12,$13,$E1
  DEFB $18,$DE,$AF,$12,$21,$2E,$9C,$CD
  DEFB $6C,$88,$21,$00,$5B,$CD,$9B,$82
  DEFB $D2,$69,$92,$21,$00,$5B,$7E,$A7
  DEFB $28,$23,$CD,$7E,$85,$38,$07,$7A
  DEFB $A7,$20,$03,$B3,$20,$08,$21,$47
  DEFB $9C,$CD,$6C,$88,$18,$DC,$CD,$17
  DEFB $85,$7A,$B3,$20,$E1,$21,$5E,$9C
  DEFB $CD,$6C,$88,$18,$CD,$CD,$B9,$85
  DEFB $7E,$A7,$28,$26,$E5,$2A,$43,$A5
  DEFB $22,$06,$A5,$01,$03,$00,$CD,$85
  DEFB $8A,$2A,$1A,$5E,$23,$23,$23,$22
  DEFB $1A,$5E,$E1,$CD,$7E,$85,$7B,$CD
  DEFB $C7,$85,$CD,$17,$85,$CD,$D2,$85
  DEFB $18,$D6,$21,$7F,$9C,$CD,$6C,$88
  DEFB $11,$00

; Message at 939D
  DEFM "[*7"

; Data block at 93A0
  DEFB $A5,$7C,$B5,$28,$06,$2A,$1C,$5E
  DEFB $CD,$71,$8C,$AF,$12,$21,$00,$5B
  DEFB $CD,$93,$82,$D2,$69,$92,$21,$00
  DEFB $5B,$CD,$D9,$8B,$38,$14,$ED,$53
  DEFB $1C,$5E

; Message at 93C2
  DEFM "BK*/"

; Data block at 93C6
  DEFB $A5,$CD,$D7,$84,$38,$06,$ED,$4B
  DEFB $1A,$5E,$18,$08,$21,$B3,$9C,$CD
  DEFB $6C,$88,$18,$D3,$03,$03,$03,$03
  DEFB $CD,$D9,$8A,$C3,$69,$92

; Message at 93E4
  DEFM "++\"5"

; Data block at 93E8
  DEFB $A5,$21,$00,$00,$22,$37,$A5,$21
  DEFB $26,$9C,$CD,$6C,$88,$2A,$0B,$A5
  DEFB $22,$18,$5E,$CD,$92,$88,$21,$82
  DEFB $9A,$CD,$6C,$88,$21,$00,$5B,$36
  DEFB $00,$CD,$9B,$82,$21,$00,$5B,$D2
  DEFB $69,$92,$7E,$A7,$CA,$69,$92,$7E
  DEFB $A7,$CA,$69,$92,$11,$1F,$5E,$CD
  DEFB $F4,$8A,$EB,$11,$E4,$A1,$19,$22
  DEFB $1A,$5E,$21,$2E,$9C,$CD,$6C,$88
  DEFB $AF,$32,$00,$5B,$C3,$35,$93,$3E
  DEFB $01,$CD

; Message at 943A
  DEFM "0c!"

; Data block at 943D
  DEFB $EA,$9C,$CD,$6C,$88,$18,$14,$E5
  DEFB $CD,$3A,$8F,$21,$03,$00,$22,$37
  DEFB $A5,$E1,$22,$35,$A5,$01,$00,$00
  DEFB $C3,$D9,$8A,$CD,$24,$63,$CD,$18
  DEFB $63,$E6,$5F,$FE,$4E,$C8,$CD

; Message at 9464
  DEFM "'c!"

; Data block at 9467
  DEFB $15,$9D,$CD,$6C,$88,$CD,$24,$63
  DEFB $CD,$18,$63,$E6,$5F,$FE,$4E,$C8
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$23
  DEFB $E5,$C5,$5E,$23,$56,$23,$EB,$D5
  DEFB $11,$18,$60,$CD,$71,$8C,$E1,$3E
  DEFB $2C,$12,$13,$7E,$A7,$23,$28,$19
  DEFB $E5,$6F,$26,$00,$CD,$96,$85,$E1
  DEFB $4E,$23,$46,$23,$E5,$69,$60,$CD
  DEFB $71,$8C,$3E,$20,$12,$13,$E1,$18
  DEFB $E2,$AF,$12,$11,$1D,$5E,$CD,$4F
  DEFB $87,$21,$18,$5E,$CD,$96,$7C,$21
  DEFB $18,$60,$CD,$96,$7C,$C1,$E1,$09
  DEFB $C3,$50,$95,$21,$BD,$9E,$CD,$96
  DEFB $7C,$21,$CF,$9E,$CD,$96,$7C,$21
  DEFB $E1,$9E,$CD,$96,$7C,$CD,$AC,$7C
  DEFB $C3,$4D,$95,$3E,$20,$12,$1B,$D5
  DEFB $11,$97,$62,$C3,$F4,$8E

; Routine at 95D5
;
; Used by the routine at 72B4.
  LD A,(HL)               ; A=PEEK HL
  INC HL                  ; HL=HL+1
  CP $FF                  ; Set the zero flag if A=$FF, or the carry flag if
                          ; A<$FF
  RET Z                   ; Return if A=$FF
  CALL $631E              ; CALL 631E
  JR $95D5                ; Jump to 95D5

; Data block at 95DF
  DEFB $01,$03,$02,$CD,$FD,$95,$04,$0C
  DEFB $78,$FE,$13,$20,$F6,$18,$31,$01
  DEFB $12,$13,$CD,$FD,$95,$05,$0D,$78
  DEFB $FE,$01,$20,$F6,$18,$22,$C5,$78
  DEFB $CD,$9E,$0E,$E5,$79,$CD,$9E,$0E
  DEFB $D1,$3E,$08,$01,$1F,$00,$2C,$1C
  DEFB $C5,$D5,$E5,$ED,$B0,$E1,$D1,$C1
  DEFB $24,$14,$3D,$C2,$0F,$96,$C1,$C9
  DEFB $78,$CD,$9E,$0E,$E5,$54,$5D,$13
  DEFB $01,$1F,$00,$36,$00,$ED,$B0,$E1
  DEFB $24,$7C,$E6,$07,$20,$EE,$C9,$1A
  DEFB $00,$0C,$1A,$01,$1F,$01,$07,$FF
  DEFB $1A,$02,$1F,$01,$16,$FF,$1A,$00
  DEFB $1F,$01,$01,$12,$1A,$02,$FF

; Message at 964E
  DEFM "High priority conditions"

; Data block at 9666
  DEFB $00,$0C,$0A,$0A

; Message at 966A
  DEFM "Which adventure data file do you want to load?..."

; Data block at 969B
  DEFB $FF,$0D,$0A,$0A,$07

; Message at 96A0
  DEFM "Memory full ... "

; Data block at 96B0
  DEFB $FF,$0D,$0A,$FF

; Message at 96B4
  DEFM "nada   "

; Data block at 96BB
  DEFB $FF,$0D,$0A

; Message at 96BE
  DEFM "Nombre Clave?"

; Data block at 96CB
  DEFB $0D,$0A

; Message at 96CD
  DEFM "                "

; Data block at 96DD
  DEFB $FF,$1E

; Message at 96DF
  DEFM "          PRINTER MENU"

; Data block at 96F5
  DEFB $12,$0D,$0A,$0A,$0A,$12,$0A,$0A
  DEFB $12,$0A,$0A,$0A,$0A,$0A,$0A,$12
  DEFB $0A,$0A,$12,$0A,$12,$0A,$0A,$12
  DEFB $0A,$0A,$12,$FF

; Message at 9711
  DEFM "Messages"

; Unused
  DEFS $01

; Message at 971A
  DEFM "Objects"

; Unused
  DEFS $01

; Message at 9722
  DEFM "No. Wt. Start Description"

; Unused
  DEFS $01

; Message at 973C
  DEFM "Verbs"

; Unused
  DEFS $01

; Message at 9742
  DEFM "Nouns"

; Unused
  DEFS $01

; Message at 9748
  DEFM "Adverbs"

; Data block at 974F
  DEFB $00,$1F,$1C,$14,$FF,$0D,$0A,$0A
  DEFB $07

; Message at 9758
  DEFM "ERROR:"

; Data block at 975E
  DEFB $FF

; Message at 975F
  DEFM " not found"

; Data block at 9769
  DEFB $FF,$0D,$0A,$0A,$FF,$0D,$0A,$0A

; Message at 9771
  DEFM "Press a key ..."

; Data block at 9780
  DEFB $FF

; Message at 9781
  DEFM "Low priority conditions"

; Unused
  DEFS $01

; Message at 9799
  DEFM "Local conditions"

; Data block at 97A9
  DEFB $00,$0D,$0A,$0F,$32,$44,$0F

; Message at 97B0
  DEFM "1isc or "

; Data block at 97B8
  DEFB $0F,$32,$54,$0F

; Message at 97BC
  DEFM "1ape..."

; Data block at 97C3
  DEFB $FF,$0C,$0F,$32,$0A,$44,$0F

; Message at 97CA
  DEFM "1ata file or "

; Data block at 97D7
  DEFB $0D,$0A,$0F,$32,$52,$0F

; Message at 97DD
  DEFM "1unnable adventure..."

; Data block at 97F2
  DEFB $FF,$0C

; Message at 97F4
  DEFM "What name do you want to give"

; Data block at 9811
  DEFB $0A,$0D

; Message at 9813
  DEFM "this adventure ?..."

; Data block at 9826
  DEFB $FF,$1F,$1E,$0C

; Message at 982A
  DEFM "MEM"

; Data block at 982D
  DEFB $08,$08,$08,$0A

; Message at 9831
  DEFM "LOW"

; Data block at 9834
  DEFB $08,$08,$08,$0A,$12,$FF,$1F,$1E
  DEFB $0C,$12,$0A,$12,$0A,$12,$FF,$1F
  DEFB $1E,$0C

; Message at 9846
  DEFM "OUT"

; Data block at 9849
  DEFB $08,$08,$08,$0A

; Message at 984D
  DEFM "OF "

; Data block at 9850
  DEFB $08,$08,$08,$0A

; Message at 9854
  DEFM "MEM"

; Data block at 9857
  DEFB $FF,$1F,$1F,$05,$FE,$08,$0A,$FF
  DEFB $0F,$31,$08,$08,$0A,$0A,$D0,$D0
  DEFB $D0,$FF,$0D,$12

; Message at 986B
  DEFM "Number 1..9999 please..."

; Data block at 9883
  DEFB $FF,$0F,$02

; Message at 9886
  DEFM "BRK"

; Data block at 9889
  DEFB $0F,$00,$FF,$1A,$02,$0C

; Message at 988F
  DEFM "Mkr 01234567890123456789"

; Data block at 98A7
  DEFB $0D,$0A,$0A,$FF,$1A,$02,$0C

; Message at 98AE
  DEFM "Ctr +0  +1  +2  +3  +4  +5  +6"

; Data block at 98CC
  DEFB $0D,$0A,$FF,$0D,$0A

; Message at 98D1
  DEFM "Press D for diagnostics or"

; Data block at 98EB
  DEFB $0D,$0A

; Message at 98ED
  DEFM "BRK to break..."

; Data block at 98FC
  DEFB $FF,$1A,$02,$1F,$01,$16

; Message at 9902
  DEFM "Press a key ..."

; Data block at 9911
  DEFB $12,$FF,$1A,$02,$FF,$1F,$02,$01
  DEFB $FF,$1F,$02,$12,$FF,$1F,$06,$15

; Message at 9921
  DEFM "Which picture number ?..."

; Data block at 993A
  DEFB $FF,$1F,$01,$15,$12,$FF,$1F,$01
  DEFB $15,$12,$07,$FF,$1F,$01,$14,$07
  DEFB $12

; Message at 994B
  DEFM "You are "

; Data block at 9953
  DEFB $FF,$18

; Message at 9955
  DEFM "VERY"

; Data block at 9959
  DEFB $18,$FF

; Message at 995B
  DEFM "very"

; Data block at 995F
  DEFB $FF

; Message at 9960
  DEFM " short of memory"

; Data block at 9970
  DEFB $0D,$0A,$12

; Message at 9973
  DEFM "Free memory now "

; Data block at 9983
  DEFB $FF

; Message at 9984
  DEFM " bytes"

; Data block at 998A
  DEFB $0D,$0A,$12

; Message at 998D
  DEFM "PRESS A KEY ..."

; Data block at 999C
  DEFB $FF,$1F,$01,$14,$12,$0A,$12,$0A
  DEFB $12,$FF,$1F,$01,$14,$07,$12

; Message at 99AB
  DEFM "You have run out of memory."

; Data block at 99C6
  DEFB $0D,$0A,$12

; Message at 99C9
  DEFM "This last edit was IGNORED."

; Data block at 99E4
  DEFB $0D,$0A,$12

; Message at 99E7
  DEFM "Please press a key ..."

; Data block at 99FD
  DEFB $FF,$1F,$01,$14,$12,$07,$18

; Message at 9A04
  DEFM " OUT OF MEMORY "

; Data block at 9A13
  DEFB $18,$FF,$1F,$01,$15,$12

; Message at 9A19
  DEFM "  Number 1..9999 please ..."

; Data block at 9A34
  DEFB $FF,$1F,$01,$15

; Message at 9A38
  DEFM "Which message number ?..."

; Data block at 9A51
  DEFB $FF,$0D,$12

; Message at 9A54
  DEFM "Please give a number 1..255 "

; Data block at 9A70
  DEFB $FF,$0C

; Message at 9A72
  DEFM "Message number "

; Data block at 9A81
  DEFB $FF

; Message at 9A82
  DEFM " is..."

; Data block at 9A88
  DEFB $0D,$0A,$0A,$FF,$0D,$0A

; Message at 9A8E
  DEFM "Message too long!"

; Data block at 9A9F
  DEFB $FF,$0D,$0A,$07

; Message at 9AA3
  DEFM "I don't understand"

; Data block at 9AB5
  DEFB $FF,$1F,$01,$15,$12

; Message at 9ABA
  DEFM "Which line number ?..."

; Data block at 9AD0
  DEFB $FF,$0C

; Message at 9AD2
  DEFM "Line number "

; Data block at 9ADE
  DEFB $FF,$0C

; Message at 9AE0
  DEFM "What do you want to call"

; Data block at 9AF8
  DEFB $0D,$0A

; Message at 9AFA
  DEFM "this data file ?..."

; Data block at 9B0D
  DEFB $FF,$1F,$01,$0A,$96,$1F,$01,$16
  DEFB $97,$20,$98

; Message at 9B18
  DEFM " DEL ENTER-edit C/S 1-restore"

; Data block at 9B35
  DEFB $FF,$12,$0D,$0A,$09,$FF,$1F,$01
  DEFB $14,$FF,$1F,$01,$14,$07,$FF,$1F
  DEFB $01,$14,$12,$FF,$1A,$00,$1F,$0A
  DEFB $01

; Message at 9B4E
  DEFM "* EDIT VERBS *"

; Data block at 9B5C
  DEFB $1A,$02,$FF,$1A,$00,$1F,$0A,$01

; Message at 9B64
  DEFM "* EDIT NOUNS *"

; Data block at 9B72
  DEFB $1A,$02,$FF,$1A,$00,$1F,$09,$01

; Message at 9B7A
  DEFM "* EDIT ADVERBS *"

; Data block at 9B8A
  DEFB $1A,$02,$FF

; Message at 9B8D
  DEFM "The room in which you will start"

; Data block at 9BAD
  DEFB $0D,$0A

; Message at 9BAF
  DEFM "the adventure is..."

; Data block at 9BC2
  DEFB $FF,$1F,$01,$16

; Message at 9BC6
  DEFM "Which object number ?..."

; Data block at 9BDE
  DEFB $FF,$0C

; Message at 9BE0
  DEFM "Object "

; Data block at 9BE7
  DEFB $23,$FF,$0D,$0A,$0A

; Message at 9BEC
  DEFM "Starts in room "

; Data block at 9BFB
  DEFB $23,$FF,$0A,$0A,$0D

; Message at 9C00
  DEFM "and weighs "

; Data block at 9C0B
  DEFB $FF,$1F,$01,$16

; Message at 9C0F
  DEFM "Which room number ?..."

; Data block at 9C25
  DEFB $FF,$0C

; Message at 9C27
  DEFM "Room "

; Data block at 9C2C
  DEFB $23,$FF,$0D,$0A,$0A

; Message at 9C31
  DEFM "Connections are..."

; Data block at 9C43
  DEFB $0D,$0A,$0A,$FF,$0D,$12

; Message at 9C49
  DEFM "Error:no such verb"

; Data block at 9C5B
  DEFB $0D,$0A,$FF,$0D,$12

; Message at 9C60
  DEFM "Error:cannot move to this room"

; Data block at 9C7E
  DEFB $FF,$0D,$0A,$0A

; Message at 9C82
  DEFM "Which picture number goes"

; Data block at 9C9B
  DEFB $0D,$0A,$0A

; Message at 9C9E
  DEFM "with this room ?... "

; Data block at 9CB2
  DEFB $FF,$0D,$0B,$12,$07

; Message at 9CB7
  DEFM "This picture does not exist."

; Data block at 9CD3
  DEFB $0D,$0A,$12

; Message at 9CD6
  DEFM "Please try again..."

; Data block at 9CE9
  DEFB $FF

; Message at 9CEA
  DEFM "This will destroy all your data"

; Data block at 9D09
  DEFB $0D,$0A

; Message at 9D0B
  DEFM "Sure ?..."

; Data block at 9D14
  DEFB $FF,$0D,$0A

; Message at 9D17
  DEFM "Really sure ?..."

; Data block at 9D27
  DEFB $FF,$0E,$07,$0F,$00,$0C,$1F,$0C
  DEFB $01

; Message at 9D30
  DEFM "MAIN MENU"

; Data block at 9D39
  DEFB $0D,$0A,$0A,$0F,$32,$41,$0F

; Message at 9D40
  DEFM "1dverbs"

; Data block at 9D47
  DEFB $0A,$0D,$0F,$32,$42,$0F

; Message at 9D4D
  DEFM "1egin where ?"

; Data block at 9D5A
  DEFB $0A,$0D,$0F,$32,$43,$0F

; Message at 9D60
  DEFM "1onditions (LOCAL)"

; Data block at 9D72
  DEFB $0A,$0D,$0F,$32,$47,$0F

; Message at 9D78
  DEFM "1raphics"

; Data block at 9D80
  DEFB $0A,$0D,$0F,$32,$48,$0F

; Message at 9D86
  DEFM "1igh priority conditions"

; Data block at 9D9E
  DEFB $0A,$0D,$0F,$32,$4C,$0F

; Message at 9DA4
  DEFM "1ow priority conditions"

; Data block at 9DBB
  DEFB $0A,$0D,$0F,$32,$4D,$0F

; Message at 9DC1
  DEFM "1essages"

; Data block at 9DC9
  DEFB $0A,$0D,$0F,$32,$4E,$0F

; Message at 9DCF
  DEFM "1ouns"

; Data block at 9DD4
  DEFB $0A,$0D,$0F,$32,$4F,$0F

; Message at 9DDA
  DEFM "1bjects"

; Data block at 9DE1
  DEFB $0A,$0D,$0F,$32,$50,$0F

; Message at 9DE7
  DEFM "1rinter menu"

; Data block at 9DF3
  DEFB $0A,$0D,$0F,$32,$52,$0F

; Message at 9DF9
  DEFM "1oom descriptions"

; Data block at 9E0A
  DEFB $0A,$0D,$0F,$32,$53,$0F

; Message at 9E10
  DEFM "1ave adventure"

; Data block at 9E1E
  DEFB $0A,$0D,$0F,$32,$54,$0F

; Message at 9E24
  DEFM "1-load adventure"

; Data block at 9E34
  DEFB $0A,$0D,$0F,$32,$56,$0F

; Message at 9E3A
  DEFM "1erbs"

; Data block at 9E3F
  DEFB $0A,$0D,$0F,$32,$58,$0F

; Message at 9E45
  DEFM "1-erase adventure"

; Data block at 9E56
  DEFB $0D,$0A,$0A,$0F

; Message at 9E5A
  DEFM "2ENTER"

; Data block at 9E60
  DEFB $0F

; Message at 9E61
  DEFM "1-enter adventure"

; Data block at 9E72
  DEFB $0D,$0A,$0A,$0A

; Message at 9E76
  DEFM "HORUSOFT -Madrid 1987-        ."

; Data block at 9E95
  DEFB $FF,$1F,$01,$14

; Message at 9E99
  DEFM "Which room number ?..."

; Data block at 9EAF
  DEFB $FF,$1F,$14,$03

; Message at 9EB3
  DEFM "FREE:"

; Data block at 9EB8
  DEFB $FF,$1F,$20,$16,$FF

; Message at 9EBD
  DEFM "Room descriptions"

; Unused
  DEFS $01

; Message at 9ECF
  DEFM "No.   Description"

; Unused
  DEFS $01

; Message at 9EE1
  DEFM "Picture"

; Data block at 9EE8
  DEFB $23

; Message at 9EE9
  DEFM " Connections"

; Data block at 9EF5
  DEFB $00,$0C,$1F,$01,$0C,$FF,$1F,$01
  DEFB $16

; Message at 9EFE
  DEFM "BRK to end,other key to continue"

; Data block at 9F1E
  DEFB $FF,$0D,$0A

; Message at 9F21
  DEFM "ERROR... Pulse"

; Data block at 9F2F
  DEFB $0D,$0A

; Message at 9F31
  DEFM "una tecla."

; Data block at 9F3B
  DEFB $0D,$0A,$FF,$1A,$02,$0C,$1F,$01
  DEFB $16,$FF,$0C,$1F,$01,$08,$7F

; Message at 9F4A
  DEFM "1986 INCENTIVE SOFTWARE LTD."

; Data block at 9F66
  DEFB $0D,$0A,$0A

; Message at 9F69
  DEFM "Design by Sean Ellis"

; Data block at 9F7D
  DEFB $0D,$0A

; Message at 9F7F
  DEFM "Programmed by Brendan Kelly."

; Data block at 9F9B
  DEFB $FF,$FF

; Message at 9F9D
  DEFM "DIS"

; Data block at 9FA0
  DEFB $C3

; Message at 9FA1
  DEFM "TAP"

; Data block at 9FA4
  DEFB $C5

; Message at 9FA5
  DEFM "OP00AND OR *NOT XOR HOLDGET DROPSWAPTO *OBJ SET RESESET?RES?CSETC"
  DEFM "TR DECRINCREQU?DESCLOOKMESSPRINRAND< **> **= **SAVELOADHEREAVAICA"
  DEFM "RR+ **- **TURNAT *BRINFINDIN *OP28OP29OKAYWAITQUITEXITROOMNOUNVER"
  DEFM "BADVEGOTONO1 NO2 VBNOLISTPICTTEXTCONNWEIGWITHSTRELF *IF *END "

; Data block at A0A5
  DEFB $FF,$00,$12,$12,$11,$12,$01,$01
  DEFB $01,$02,$02,$01,$01,$01,$11,$11
  DEFB $02,$11,$01,$01,$12,$01,$00,$01
  DEFB $01,$11,$12,$12,$12,$00,$00,$11
  DEFB $11,$11,$12,$12,$10,$11,$01,$01
  DEFB $12,$01,$22,$00,$00,$00,$00,$10
  DEFB $11,$11,$11,$01,$10,$10,$10,$01
  DEFB $00,$00,$11,$11,$10,$01,$00,$01
  DEFB $00,$01,$0E

; Message at A0E8
  DEFM "Stack empty"

; Data block at A0F3
  DEFB $0A,$0D,$00,$02,$0D

; Message at A0F8
  DEFM "Stack full"

; Data block at A102
  DEFB $0A,$0D,$00,$03,$07

; Message at A107
  DEFM "Marker*"

; Data block at A10E
  DEFB $04,$08

; Message at A110
  DEFM "Counter*"

; Data block at A118
  DEFB $05,$05

; Message at A11A
  DEFM "Room*"

; Data block at A11F
  DEFB $06,$07

; Message at A121
  DEFM "Object*"

; Data block at A128
  DEFB $07,$08

; Message at A12A
  DEFM "Message*"

; Data block at A132
  DEFB $08,$0E,$0F

; Message at A135
  DEFM "3STOPPED"

; Data block at A13D
  DEFB $0F,$31,$0A,$0D,$00,$09,$10

; Message at A144
  DEFM "Illegal value"

; Data block at A151
  DEFB $0D,$0A,$00,$00,$66,$79,$93,$73
  DEFB $A3

; Message at A15A
  DEFM "sXs"

; Data block at A15D
  DEFB $B3,$73,$24,$8A,$B3

; Message at A162
  DEFM "vVu"

; Data block at A165
  DEFB $9F,$75,$AC,$77,$05

; Message at A16A
  DEFM "u(t/t6tDtwt"

; Data block at A175
  DEFB $81

; Message at A176
  DEFM "totht"

; Data block at A17B
  DEFB $8A,$74,$B6,$75,$60

; Message at A180
  DEFM "v,uAs"

; Data block at A185
  DEFB $C3,$73,$A2,$74,$B3,$74,$9C,$74
  DEFB $8F,$78,$B3

; Message at A190
  DEFM "xawowQwfsqs"

; Data block at A19B
  DEFB $7E,$83,$78,$83,$BE

; Message at A1A0
  DEFM "w'x"

; Data block at A1A3
  DEFB $7C

; Message at A1A4
  DEFM "wfyfy"

; Data block at A1A9
  DEFB $ED,$78,$F8,$78,$02,$79,$18,$79
  DEFB $8D

; Message at A1B2
  DEFM "sCy$y)y"

; Data block at A1B9
  DEFB $05,$78,$13,$78,$18,$78,$0E,$78
  DEFB $A8,$76,$AE,$72,$BB

; Message at A1C6
  DEFM "rVx;x;sXyOu"

; Data block at A1D1
  DEFB $E1

; Message at A1D2
  DEFM "sfy"

; Data block at A1D5
  DEFB $7C

; Message at A1D6
  DEFM "TTTTTTTT"

; Data block at A1DE
  DEFB $7C

; Message at A1DF
  DEFM "DD88"

; Data block at A1E3
  DEFB $10,$10,$00

; Message at A1E6
  DEFM " .,-!?:"

; Data block at A1ED
  DEFB $FB,$ED,$D5,$B5,$8E,$62,$32,$00
  DEFB $32,$62,$8E,$B5,$D5,$ED,$FB,$FF
  DEFB $00,$00,$FF,$7F,$00,$00,$00,$00
  DEFB $00,$00,$0D,$00,$00,$00,$00,$00
  DEFB $14,$00,$14,$00,$14,$00,$14,$00
  DEFB $14,$00,$00,$00,$14,$00,$14,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$02,$00,$0B,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $01,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$18,$00,$00,$FA,$A8,$B3
  DEFB $01,$00,$01,$00,$00,$00,$1D,$00
  DEFB $5B,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$9B,$82,$BB,$5D,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $FF,$FF,$DB,$A5,$9D,$A6,$9F,$A6
  DEFB $CD,$A8,$A0,$AD,$FB,$AD,$ED,$B3
  DEFB $13,$B6,$ED,$C1,$1E,$EA,$37,$FC
  DEFB $88,$13,$A3,$A4

; Message at A539
  DEFM "h6t"

; Data block at A53C
  DEFB $00,$55,$00,$04,$04,$80,$00,$21
  DEFB $5E,$00,$00,$00,$00,$00,$00,$80
  DEFB $00,$88,$13,$18,$1F,$80,$1F,$42
  DEFB $82,$14,$25,$80,$08,$0F,$80,$17
  DEFB $29,$80,$1A,$21,$80,$05,$0C,$80
  DEFB $0A,$2E,$80,$06,$2D,$82,$06,$0D
  DEFB $80,$0A,$11,$80,$10,$17,$80,$03
  DEFB $2C,$80,$1C,$23,$80,$11,$18,$80
  DEFB $1E,$3A,$80,$03,$08,$80,$09,$10
  DEFB $80,$0F,$16,$80,$1B,$22,$80,$17
  DEFB $28,$80,$17,$1E,$80,$0C,$30,$80
  DEFB $15,$1C,$80,$0C,$13,$80,$09,$61
  DEFB $82,$0E,$15,$80,$13,$1A,$80,$15
  DEFB $26,$80,$01,$2A,$80,$01,$07,$80
  DEFB $04,$2D,$80,$04,$0B,$80,$16,$1D
  DEFB $80,$15,$27,$80,$14,$1B,$80,$0B
  DEFB $2F,$80,$1D,$B0,$80,$0B,$12,$80
  DEFB $19,$20,$80,$02,$2B,$80,$12,$19
  DEFB $80,$0D,$14,$80,$07,$0E,$80,$02
  DEFB $0A,$80,$14,$24,$80,$00,$00,$33
  DEFB $EE,$81,$29,$FC,$80,$04,$8D,$80
  DEFB $1E,$60,$80,$20,$A9,$80,$11,$35
  DEFB $80,$19,$84,$80,$1B,$A4,$80,$1D
  DEFB $A7,$80,$1A,$57,$80,$0D,$98,$80
  DEFB $0C,$97,$80,$01,$89,$80,$07,$90
  DEFB $80,$08,$91,$80,$25,$AF,$80,$1C
  DEFB $A5,$80,$19,$6F,$80,$13,$9F,$80
  DEFB $16,$A0,$80,$35,$4B,$81,$2C,$FF
  DEFB $80,$0F,$9B,$80,$05,$9E,$80,$05
  DEFB $8E,$80,$2D,$00,$81,$2E,$01,$81
  DEFB $2F,$02,$81,$1B,$60,$82,$30,$2C
  DEFB $82,$0E,$99,$80,$09,$92,$80,$1F
  DEFB $9B,$81,$10,$9C,$80,$22,$AC,$80
  DEFB $2B,$FE,$80,$34,$DF,$81,$21,$AA
  DEFB $80,$0A,$94,$80,$1F,$A8,$80,$22
  DEFB $08,$81,$06,$8F,$80,$36,$65,$81
  DEFB $0F,$9A,$80,$02,$8B,$80,$19,$A2
  DEFB $80,$25,$AE,$80,$18,$55,$80,$1C
  DEFB $A6,$80,$32,$54,$80,$24,$69,$80
  DEFB $14,$3E,$80,$0B,$95,$80,$17,$A1
  DEFB $80,$23,$AD,$80,$15,$47,$80,$21
  DEFB $AB,$80,$27,$FA,$80,$1A,$A3,$80
  DEFB $28,$FB,$80,$26,$7D,$80,$2A,$FD
  DEFB $80,$12,$39,$80,$31,$5E,$81,$00
  DEFB $00,$00,$00,$01,$22,$01,$00,$00
  DEFB $46,$48,$89,$48,$8A,$40

; Message at A6AA
  DEFM "cer eso"

; Data block at A6B1
  DEFB $FF

; Message at A6B2
  DEFM "la Ciudad.Salidas"

; Data block at A6C3
  DEFB $02,$20,$01,$00,$00,$00,$48,$8B
  DEFB $40,$8A,$40

; Message at A6CE
  DEFM "cer eso"

; Data block at A6D5
  DEFB $FF

; Message at A6D6
  DEFM "la Ciudad.Salid"

; Data block at A6E5
  DEFB $03,$22,$01,$00,$00,$00,$48,$8B
  DEFB $48,$8C,$40

; Message at A6F0
  DEFM "cer eso"

; Data block at A6F7
  DEFB $FF

; Message at A6F8
  DEFM "la Ciudad.Salidas"

; Data block at A709
  DEFB $04,$20,$01,$00,$00,$00,$48,$8D
  DEFB $40,$8C,$40

; Message at A714
  DEFM "cer eso"

; Data block at A71B
  DEFB $FF

; Message at A71C
  DEFM "la Ciudad.Salid"

; Data block at A72B
  DEFB $05,$20,$01,$0D,$00,$46,$48,$8E
  DEFB $40,$8C,$40

; Message at A736
  DEFM "cer eso"

; Data block at A73D
  DEFB $FF

; Message at A73E
  DEFM "la Ciudad.Salid"

; Data block at A74D
  DEFB $06,$20,$01,$00,$00,$46,$48,$8F
  DEFB $40,$8C,$40

; Message at A758
  DEFM "cer eso"

; Data block at A75F
  DEFB $FF

; Message at A760
  DEFM "la Ciudad.Salid"

; Data block at A76F
  DEFB $07,$20,$01,$00,$00,$46,$48,$90
  DEFB $40,$8C,$40

; Message at A77A
  DEFM "cer eso"

; Data block at A781
  DEFB $FF

; Message at A782
  DEFM "la Ciudad.Salid"

; Data block at A791
  DEFB $08,$20,$01,$14,$00,$00,$48,$91
  DEFB $40,$8C,$40

; Message at A79C
  DEFM "cer eso"

; Data block at A7A3
  DEFB $FF

; Message at A7A4
  DEFM "la Ciudad.Salid"

; Data block at A7B3
  DEFB $09,$22,$01,$14,$00,$00,$48,$92
  DEFB $48,$93,$40

; Message at A7BE
  DEFM "cer eso"

; Data block at A7C5
  DEFB $FF

; Message at A7C6
  DEFM "la Ciudad.Salidas"

; Data block at A7D7
  DEFB $0A,$20,$01,$14,$00,$00,$48,$94
  DEFB $40,$93,$40

; Message at A7E2
  DEFM "cer eso"

; Data block at A7E9
  DEFB $FF

; Message at A7EA
  DEFM "la Ciudad.Salid"

; Data block at A7F9
  DEFB $0B,$20,$01,$14,$00,$46,$48,$95
  DEFB $40,$96,$40

; Message at A804
  DEFM "cer eso"

; Data block at A80B
  DEFB $FF

; Message at A80C
  DEFM "la Ciudad.Salid"

; Data block at A81B
  DEFB $0C,$20,$01,$14,$00,$46,$48,$97
  DEFB $40,$96,$40

; Message at A826
  DEFM "cer eso"

; Data block at A82D
  DEFB $FF

; Message at A82E
  DEFM "la Ciudad.Salid"

; Data block at A83D
  DEFB $0E,$20,$01,$14,$00,$00,$48,$99
  DEFB $40,$96,$40

; Message at A848
  DEFM "cer eso"

; Data block at A84F
  DEFB $FF

; Message at A850
  DEFM "la Ciudad.Salid"

; Data block at A85F
  DEFB $0F,$24,$01,$14,$00,$00,$48,$9A
  DEFB $48,$03,$48,$9B,$40

; Message at A86C
  DEFM "r eso"

; Data block at A871
  DEFB $FF

; Message at A872
  DEFM "la Ciudad.Salidas: "

; Data block at A885
  DEFB $10,$20,$01,$00,$00,$00,$48,$9C
  DEFB $40,$03,$48,$9B,$40

; Message at A892
  DEFM "r eso"

; Data block at A897
  DEFB $FF

; Message at A898
  DEFM "la Ciudad.Salid"

; Data block at A8A7
  DEFB $0D,$22,$01,$00,$00,$00,$48,$99
  DEFB $48,$9D,$40

; Message at A8B2
  DEFM "cer eso"

; Data block at A8B9
  DEFB $FF

; Message at A8BA
  DEFM "la Ciudad.Salid: "

; Data block at A8CB
  DEFB $00,$00,$01,$00,$29,$00,$01,$00
  DEFB $01,$06,$00,$03,$02,$00,$00,$00
  DEFB $08,$01,$48,$02,$48,$03,$48,$04
  DEFB $48,$05,$10,$70,$08,$0A,$08,$B8

; Message at A8EB
  DEFM "H7H"

; Data block at A8EE
  DEFB $23,$52,$06,$38,$01,$C8,$07,$18
  DEFB $08,$10,$09,$00,$02,$00,$2E,$00
  DEFB $02,$00,$01,$07,$00,$04,$01,$00
  DEFB $11,$03,$00,$00,$31,$08,$32,$48
  DEFB $00,$48,$02,$48,$03,$48,$04,$48
  DEFB $05,$50,$33,$08,$34,$48,$00

; Message at A91D
  DEFM "H5H6"

; Data block at A921
  DEFB $10,$06,$38,$01,$C8,$07,$18,$0B
  DEFB $10,$09,$00,$03,$00,$1E,$00,$03
  DEFB $00,$12,$02,$00,$00,$32,$08

; Message at A938
  DEFM "7H8H"

; Data block at A93C
  DEFB $03,$48,$00

; Message at A93F
  DEFM "H5P7"

; Data block at A943
  DEFB $08

; Message at A944
  DEFM "9H:H;H<P"

; Data block at A94C
  DEFB $09,$00,$04,$00,$18,$00,$04,$00
  DEFB $03,$05,$00,$00,$31,$08,$32,$48
  DEFB $00

; Message at A95D
  DEFM "H=H>P"

; Data block at A962
  DEFB $06,$38,$01,$C8,$08,$10,$09,$00
  DEFB $05,$00,$30,$00,$05,$00,$11,$04
  DEFB $00,$03,$06,$00,$01,$09,$00,$00
  DEFB $31,$08,$32,$48,$00,$48,$02,$48
  DEFB $03,$48,$04,$48,$05,$10,$3F,$08
  DEFB $40

; Message at A98B
  DEFM "HAHBH"

; Unused
  DEFS $01

; Message at A991
  DEFM "H>P"

; Data block at A994
  DEFB $06,$38,$01,$C8,$07,$18,$08,$10
  DEFB $09,$00,$06,$00,$27,$00,$06,$00
  DEFB $01,$0A,$00,$02,$01,$00,$03,$07
  DEFB $00,$04,$05,$00,$00,$43,$08,$32
  DEFB $48,$00

; Message at A9B6
  DEFM "HDHEP"

; Data block at A9BB
  DEFB $06,$38,$01,$C8,$07,$18,$0A,$18
  DEFB $08,$18,$0B,$10,$09,$00,$07,$00
  DEFB $38,$00,$07,$00,$01,$0B,$00,$02
  DEFB $02,$00,$04,$06,$00,$00,$31,$08
  DEFB $32,$48,$00,$48,$02,$48,$03,$48
  DEFB $04,$48,$05,$50,$3F,$08,$40

; Message at A9EA
  DEFM "HAHBHFHGHHHIHJ"

; Data block at A9F8
  DEFB $10,$06,$38,$01,$C8,$07,$18,$0A
  DEFB $18,$0B,$10,$09,$00,$08,$00,$26
  DEFB $00,$08,$00,$04,$07,$00,$00,$31
  DEFB $08

; Message at AA11
  DEFM "2H7H8HHHG"

; Data block at AA1A
  DEFB $08,$03,$48,$4A,$10,$37,$08

; Message at AA21
  DEFM "KHLHMP"

; Data block at AA27
  DEFB $06,$38,$01,$C8,$0B,$10,$09,$00
  DEFB $09,$00,$1F,$00,$09,$00,$02,$05
  DEFB $00,$03,$0A,$00,$00,$4E,$08

; Message at AA3E
  DEFM "OH2HFHPHQP"

; Data block at AA48
  DEFB $06,$38,$01,$C8,$0A,$18,$08,$10
  DEFB $09,$00,$0A,$00,$32,$00,$0A,$00
  DEFB $02,$06,$00,$03,$0B,$00,$04,$09
  DEFB $00,$00,$32,$08,$00,$48,$02,$48
  DEFB $03,$48,$04,$48,$05,$10,$52,$08
  DEFB $53,$48,$04

; Message at AA73
  DEFM "HTH"

; Data block at AA76
  DEFB $03,$48,$00,$48,$55,$10,$06,$38
  DEFB $01,$C8,$0A,$18,$08,$18,$0B,$10
  DEFB $09,$00,$0B,$00,$2D,$00,$0B,$00
  DEFB $02,$07,$00,$04,$0A,$00,$00,$32
  DEFB $08,$00,$48,$02,$48,$03,$48,$04
  DEFB $48,$05,$10,$52,$08,$53,$48,$04

; Message at AAA6
  DEFM "HVH"

; Data block at AAA9
  DEFB $03

; Message at AAAA
  DEFM "HFHW"

; Data block at AAAE
  DEFB $10,$06,$38,$01,$C8,$0A,$18,$0B
  DEFB $10,$09,$00,$0C,$00,$20,$00,$0C
  DEFB $00,$04,$0B,$00,$00,$58,$08

; Message at AAC5
  DEFM "HHWPY"

; Data block at AACA
  DEFB $08,$03

; Message at AACC
  DEFM "HZH[H7H"

; Data block at AAD3
  DEFB $5C,$50,$06,$38,$01,$C8,$0B,$10
  DEFB $09,$00,$0D,$00,$0D,$00,$0D,$00
  DEFB $00,$32,$08,$00

; Message at AAE7
  DEFM "H]H"

; Data block at AAEA
  DEFB $5E,$50,$09,$00,$0E,$00,$2D,$00
  DEFB $0E,$00,$01,$16,$00,$03,$0F,$00
  DEFB $00,$31,$08

; Message at AAFD
  DEFM "2HFH"

; Data block at AB01
  DEFB $5F,$48,$03,$48,$04

; Message at AB06
  DEFM "HUX?H"

; Data block at AB0B
  DEFB $40,$48,$04

; Message at AB0E
  DEFM "HTH"

; Data block at AB11
  DEFB $03,$48,$00,$48,$5E,$50,$06,$38
  DEFB $07,$18,$08,$10,$09,$00,$0F,$00
  DEFB $2C,$00,$0F,$00,$02,$0D,$00,$04
  DEFB $0E,$00,$11,$11,$00,$00,$31,$08

; Message at AB31
  DEFM "2HFH"

; Data block at AB35
  DEFB $5F,$48,$03,$48,$04

; Message at AB3A
  DEFM "HUX?H"

; Data block at AB3F
  DEFB $40

; Message at AB40
  DEFM "HFH"

; Data block at AB43
  DEFB $60,$50,$06,$38,$01,$C8,$08,$18
  DEFB $0B,$10,$09,$00,$10,$00,$29,$00
  DEFB $10,$00,$00,$32,$08,$46,$48,$5F
  DEFB $48,$03,$48,$04

; Message at AB5F
  DEFM "HUP4"

; Data block at AB63
  DEFB $08

; Message at AB64
  DEFM "FHaH3PN"

; Data block at AB6B
  DEFB $08

; Message at AB6C
  DEFM "bHch"

; Data block at AB70
  DEFB $01,$E8,$01,$C8,$06,$38,$01,$C8
  DEFB $0B,$10,$09,$00,$11,$00,$0B,$00
  DEFB $11,$00,$00,$58,$08,$48,$48,$60
  DEFB $50,$09,$00,$12,$00,$18,$00,$12
  DEFB $00,$11,$11,$00,$00,$31,$08,$32
  DEFB $48,$04

; Message at AB9A
  DEFM "HdH"

; Data block at AB9D
  DEFB $03

; Message at AB9E
  DEFM "HePf"

; Data block at ABA2
  DEFB $08,$67,$50,$09,$00,$13,$00,$28
  DEFB $00,$13,$00,$11,$11,$00,$00,$31
  DEFB $08

; Message at ABB3
  DEFM "2HFH"

; Data block at ABB7
  DEFB $5F,$48,$03,$48,$04,$48,$55,$10
  DEFB $46,$08

; Message at ABC1
  DEFM "hHiHjH7HkP"

; Data block at ABCB
  DEFB $06,$38,$01,$C8,$07,$10,$09,$00
  DEFB $14,$00,$16,$00,$14,$00,$03,$15
  DEFB $00,$00,$46,$08,$6C,$48,$03,$48
  DEFB $6D,$10,$06,$38,$01,$C8,$08,$10
  DEFB $09,$00,$15,$00,$1D,$00,$15,$00
  DEFB $04,$14,$00,$02,$13,$00,$00,$46
  DEFB $08,$5F,$48,$03,$48,$04,$48,$55
  DEFB $10,$06,$38,$01,$C8,$0B,$18,$0A
  DEFB $10,$09,$00,$16,$00,$35,$00,$16
  DEFB $00,$00,$31,$08

; Message at AC17
  DEFM "2H7Hn"

; Data block at AC1C
  DEFB $08,$03,$48,$6F,$08,$03,$48,$04

; Message at AC24
  DEFM "HU("

; Data block at AC27
  DEFB $03,$E8,$01,$C8,$70,$08,$71,$58
  DEFB $01,$C8

; Message at AC31
  DEFM "rHsHtHuHvHAP"

; Data block at AC3D
  DEFB $01,$C8,$4C,$08,$37,$48,$16,$A8
  DEFB $00,$C0,$17,$00,$21,$00,$17,$00
  DEFB $00,$31,$08,$32,$48,$04

; Message at AC53
  DEFM "HwHHHxPp"

; Data block at AC5B
  DEFB $08,$0B,$08,$34,$48,$00

; Message at AC61
  DEFM "HyP"

; Data block at AC64
  DEFB $06,$38,$01,$C8,$0E,$10,$09,$00
  DEFB $18,$00,$27,$00,$18,$00,$01,$19
  DEFB $00,$02,$1A,$00,$03,$19,$00,$04
  DEFB $1A,$00,$00,$31,$08,$32,$48,$00

; Message at AC84
  DEFM "HzH"

; Data block at AC87
  DEFB $7B,$50,$06,$38,$01,$C8,$07,$18
  DEFB $0A,$18,$08,$18,$0B,$10,$09,$00
  DEFB $19,$00,$27,$00,$18,$00,$01,$19
  DEFB $00,$02,$18,$00,$03,$1A,$00,$04
  DEFB $19,$00,$00,$31,$08,$32,$48,$00

; Message at ACAF
  DEFM "HzH"

; Data block at ACB2
  DEFB $7B,$50,$06,$38,$01,$C8,$07,$18
  DEFB $0A,$18,$08,$18,$0B,$10,$09,$00
  DEFB $1A,$00,$27,$00,$18,$00,$01,$18
  DEFB $00,$02,$19,$00,$03,$1A,$00,$04
  DEFB $1B,$00,$00,$31,$08,$32,$48,$00

; Message at ACDA
  DEFM "HzH"

; Data block at ACDD
  DEFB $7B,$50,$06,$38,$01,$C8,$07,$18
  DEFB $0A,$18,$08,$18,$0B,$10,$09,$00
  DEFB $1B,$00,$33,$00,$1B,$00,$01,$19
  DEFB $00,$02,$1A,$00,$03,$1A,$00,$04
  DEFB $19,$00,$00,$31,$08,$32,$48,$00

; Message at AD05
  DEFM "HzH"

; Data block at AD08
  DEFB $7B,$50,$32,$08,$37,$48,$7C

; Message at AD0F
  DEFM "HBH"

; Data block at AD12
  DEFB $00,$48,$7D,$50,$06,$38,$01,$C8
  DEFB $07,$18,$0A,$18,$08,$18,$0B,$10
  DEFB $09,$00,$1C,$00,$1B,$00,$1C,$00
  DEFB $03,$1D,$00,$04,$1C,$00,$00,$46
  DEFB $08,$7F

; Message at AD34
  DEFM "H2H"

; Data block at AD37
  DEFB $80,$50,$06,$38,$01,$C8,$08,$18
  DEFB $0B,$10,$09,$00,$1D,$00,$15,$00
  DEFB $23,$01,$00,$31,$08

; Message at AD4C
  DEFM "2H7H"

; Data block at AD50
  DEFB $81,$48,$03

; Message at AD53
  DEFM "HrH"

; Data block at AD56
  DEFB $82,$28,$02,$E8,$00,$C0,$1E,$00
  DEFB $26,$00,$1E,$00,$04,$0F,$00,$00
  DEFB $32,$08,$46,$48,$5F,$48,$03,$48
  DEFB $04,$48,$55,$10,$32,$08,$37,$48
  DEFB $83

; Message at AD77
  DEFM "H4HFH"

; Data block at AD7C
  DEFB $84,$50,$06,$38,$01,$C8,$0B,$10
  DEFB $09,$00,$88,$13,$09,$00,$88,$13
  DEFB $00,$B1,$88,$04,$88,$B2,$80,$E8
  DEFB $03,$07,$00,$E8,$03,$00,$01,$C8
  DEFB $00,$C0,$00,$00,$93,$88,$24,$3E
  DEFB $80,$03,$0B,$15,$3F,$80,$0D,$24
  DEFB $80,$1E,$0E,$01,$3E,$80,$64,$12
  DEFB $3F,$80,$10,$24,$3E,$80,$32,$12
  DEFB $3F,$80,$16,$24,$3E,$81,$2C,$05
  DEFB $2D,$3F,$80,$1D,$24,$80,$07,$20
  DEFB $01,$3E,$80,$51,$16,$81,$2C,$05
  DEFB $2D,$3F,$80,$1D,$24,$80,$07,$20
  DEFB $03,$01,$3E,$80,$52,$16,$81,$2C
  DEFB $05,$2D,$3F,$80,$0D,$24,$80,$1C
  DEFB $0E,$01

; Message at ADEE
  DEFM ">=="

; Data block at ADF1
  DEFB $80,$68,$16,$81,$2C,$05,$2D,$3F
  DEFB $00,$00,$88,$13,$80,$1D

; Message at ADFF
  DEFM "0>======"

; Data block at AE07
  DEFB $80,$01,$93,$88,$09,$80,$01,$06
  DEFB $80,$01

; Message at AE11
  DEFM "2+?"

; Data block at AE14
  DEFB $00,$01,$00,$80,$02,$30,$3E,$80
  DEFB $3F,$16,$2B,$3F,$00,$02,$00,$80
  DEFB $09,$30,$80,$11,$2F,$01,$3E,$80
  DEFB $11,$16,$2B,$3F,$80,$00,$00,$03
  DEFB $00,$80,$0A,$30,$3E,$80,$29,$16
  DEFB $2B,$3F,$80,$09,$30,$80,$12,$2F
  DEFB $01,$3E,$80,$12,$16,$2B,$3F,$80
  DEFB $15,$30,$80,$10,$2F,$01,$80,$10
  DEFB $20,$01,$3E,$80,$10,$80,$00,$09
  DEFB $80,$19,$0B,$80,$40,$16,$2B,$3F
  DEFB $80,$14,$30,$80,$33,$2F,$01,$80
  DEFB $19,$0D,$01,$3E,$80,$41,$16,$81
  DEFB $2C,$05,$80,$1C

; Message at AE78
  DEFM "2+?"

; Data block at AE7B
  DEFB $80,$14,$30,$80,$33,$2F,$03,$01
  DEFB $80,$19,$0D,$01,$3E,$80,$6C,$16
  DEFB $80,$19,$0C,$2B,$3F,$00,$04,$00
  DEFB $80,$0A,$30,$3E,$80,$2A,$16,$2B
  DEFB $3F,$80,$09,$30,$80,$13,$2F,$01
  DEFB $3E,$80,$13,$16,$2B,$3F,$00,$05
  DEFB $00,$80,$09,$30,$80,$14,$2F,$01
  DEFB $3E,$80,$14,$16,$2B,$3F,$00,$07
  DEFB $00,$80,$0A,$30,$3E,$80,$2B,$16
  DEFB $2B,$3F,$80,$09,$30,$80,$15,$2F
  DEFB $01,$3E,$80,$15,$16,$2B,$3F,$80
  DEFB $16,$30,$80,$30,$2F,$01,$80,$1A
  DEFB $0E,$01,$3E,$80,$42,$16,$80,$10
  DEFB $80,$07,$09,$80,$1A,$0B,$2B,$3F
  DEFB $80,$11,$30,$80,$1B,$0E,$01,$3E
  DEFB $80,$08

; Message at AEF5
  DEFM "2+?"

; Data block at AEF8
  DEFB $80,$11,$30,$80,$1B,$0D,$01,$3E
  DEFB $80,$6A,$16,$2B,$3F,$80,$16,$30
  DEFB $80,$30,$2F,$01,$80,$1A,$0D,$01
  DEFB $3E,$80,$6D,$16,$2B,$3F,$00,$08
  DEFB $00,$80,$0A,$30,$3E,$80,$2C,$16
  DEFB $2B,$3F,$80,$09,$30,$80,$16,$2F
  DEFB $01,$3E,$80,$16,$16,$2B,$3F,$80
  DEFB $17,$30,$3E,$80,$43,$16,$80,$1B
  DEFB $0B,$81,$2C,$05,$3D,$80,$0D

; Message at AF3F
  DEFM "2+?"

; Data block at AF42
  DEFB $00,$09,$00,$80,$0A,$30,$3E,$80
  DEFB $2D,$16,$2B,$3F,$80,$09,$30,$80
  DEFB $17,$2F,$01,$3E,$80,$17,$16,$2B
  DEFB $3F,$80,$18,$30,$80,$17,$2F,$01
  DEFB $3E,$80,$44,$16,$2B,$3F,$00,$0A
  DEFB $00,$80,$0A,$30,$3E,$80,$2E,$16
  DEFB $2B,$3F,$80,$09,$30,$80,$18,$2F
  DEFB $01,$3E,$80,$18,$16,$2B,$3F,$80
  DEFB $09,$30,$80,$19,$2F,$01,$3E,$80
  DEFB $19,$16,$2B,$3F,$80,$11,$30,$3E
  DEFB $80,$56,$16,$2B,$3F,$00,$0B,$00
  DEFB $80,$0A,$30,$3E,$80,$2F,$16,$2B
  DEFB $3F,$80,$09,$30,$80,$1B,$2F,$01
  DEFB $3E,$80,$1B,$16,$2B,$3F,$80,$11
  DEFB $30,$80,$1C,$0E,$01,$3E,$80,$0C

; Message at AFBA
  DEFM "2+?"

; Data block at AFBD
  DEFB $80,$11,$30,$80,$1C,$0D,$01,$3E
  DEFB $80,$69,$16,$2B,$3F,$00,$0C,$00
  DEFB $80,$0A,$30,$3E,$80,$30,$16,$2B
  DEFB $3F,$80,$09,$30,$80,$1C,$2F,$01
  DEFB $3E,$80,$1C,$16,$2B,$3F,$80,$06
  DEFB $30,$80,$01,$2F,$01,$80,$01,$20
  DEFB $01,$3E,$80,$1C,$0B,$80,$01,$80
  DEFB $00,$09,$38,$80,$45,$16,$80,$46
  DEFB $16,$80,$47,$16,$87,$D0,$05,$37
  DEFB $3D,$80,$0B

; Message at B008
  DEFM "2+?"

; Data block at B00B
  DEFB $00,$0D,$00,$80,$0A,$30,$3E,$80
  DEFB $31,$16,$2B,$3F,$80,$1D,$2F,$80
  DEFB $1D,$0E,$01,$80,$09,$30,$01,$3E
  DEFB $80,$1D,$0B,$80,$02,$80,$0D,$09
  DEFB $80,$1D,$16,$3D,$80,$E8,$16,$2B
  DEFB $3F,$80,$1D,$2F,$80,$09,$30,$01
  DEFB $3E,$80,$1D,$16,$2B,$3F,$80,$0A
  DEFB $80,$64,$13,$3E,$80,$64,$12,$80
  DEFB $1E,$0B,$80,$57,$16,$2B,$3F,$80
  DEFB $01,$30,$80,$1E,$0D,$01,$3E,$80
  DEFB $22,$0B,$80,$0F

; Message at B05F
  DEFM "2+?"

; Data block at B062
  DEFB $80,$09,$30,$80,$32,$2F,$01,$80
  DEFB $1E,$0E,$01,$3E,$80,$65,$16,$2B
  DEFB $3F,$80,$09,$30,$80,$32,$2F,$01
  DEFB $80,$1E,$0D,$01,$3E,$80,$67,$16
  DEFB $2B,$3F,$00,$0E,$00,$80,$0A,$30
  DEFB $3E,$80,$32,$16,$2B,$3F,$80,$2A
  DEFB $2F,$80,$14,$30,$01,$3E,$80,$4A
  DEFB $16,$80,$C8,$05,$2D,$80,$14,$30
  DEFB $80,$2A,$2F,$03,$01,$3E,$80,$53
  DEFB $16,$80,$C8,$05,$2D,$00,$0F,$00
  DEFB $80,$0A,$30,$3E,$80,$33,$16,$2B
  DEFB $3F,$80,$1E,$2F,$80,$09,$30,$01
  DEFB $3E,$80,$1E,$16,$2B,$3F,$80,$03
  DEFB $30,$80,$1F,$0E,$01,$3E,$80,$10

; Message at B0D2
  DEFM "2+?"

; Data block at B0D5
  DEFB $80,$03,$30,$80,$1F,$0D,$01,$3E
  DEFB $80,$1E

; Message at B0DF
  DEFM "2+?"

; Data block at B0E2
  DEFB $00,$10,$00,$80,$02,$2F,$80,$10
  DEFB $30,$01,$80,$03,$20,$01,$3E,$80
  DEFB $02,$80,$03,$08,$80,$1F,$0B,$80
  DEFB $58,$16,$80,$C8,$05,$3D,$80,$1E

; Message at B102
  DEFM "2+?"

; Data block at B105
  DEFB $80,$01,$80,$32,$13,$3E,$80,$5A
  DEFB $16,$80,$C8,$05,$2D,$3F,$00,$11
  DEFB $00,$80,$0A,$30,$3E,$80,$35,$16
  DEFB $2B,$3F,$80,$1F,$2F,$80,$09,$30
  DEFB $01,$3E,$80,$1F,$16,$2B,$3F,$80
  DEFB $2D,$2F,$80,$14,$30,$01,$3E,$80
  DEFB $20,$0B,$80,$21,$0C,$80,$22,$0C
  DEFB $80,$E9,$16,$2B,$3F,$80,$2E,$2F
  DEFB $80,$14,$30,$01,$3E,$80,$21,$0B
  DEFB $80,$20,$0C,$80,$22,$0C,$80,$E9
  DEFB $16,$2B,$3F,$80,$2F,$2F,$80,$14
  DEFB $30,$01,$3E,$80,$22,$0B,$80,$20
  DEFB $0C,$80,$21,$0C,$80,$E9,$16,$2B
  DEFB $3F,$80,$12,$30,$80,$20,$0D,$01
  DEFB $3E,$80,$13

; Message at B178
  DEFM "2+?"

; Data block at B17B
  DEFB $80,$12,$30,$80,$21,$0D,$01,$3E
  DEFB $80,$12

; Message at B185
  DEFM "2+?"

; Data block at B188
  DEFB $80,$12,$30,$80,$22,$0D,$01,$3E
  DEFB $80,$0F

; Message at B192
  DEFM "2+?"

; Data block at B195
  DEFB $00,$12,$00,$80,$0A,$30,$3E,$80
  DEFB $36,$16,$2B,$3F,$80,$21,$2F,$80
  DEFB $09,$30,$01,$3E,$80,$21,$16,$2B
  DEFB $3F,$80,$23,$2F,$80,$09,$30,$01
  DEFB $3E,$80,$23,$16,$2B,$3F,$80,$22
  DEFB $2F,$80,$23,$0E,$01,$80,$24,$0E
  DEFB $01,$80,$09,$30,$01,$3E,$80,$22
  DEFB $16,$2B,$3F,$80,$22,$2F,$80,$23
  DEFB $0D,$01,$80,$24,$0E,$01,$80,$09
  DEFB $30,$01,$3E,$80,$20,$16,$2B,$3F
  DEFB $80,$22,$2F,$80,$24,$0D,$01,$80
  DEFB $09,$30,$01,$3E,$80,$5B,$16,$2B
  DEFB $3F,$80,$27,$2F,$80,$14,$30,$01
  DEFB $80,$23,$0E,$01,$3E,$80,$23,$0B
  DEFB $80,$4B,$16,$2B,$3F,$80,$34,$2F
  DEFB $80,$14,$30,$01,$80,$23,$0D,$01
  DEFB $80,$24,$0E,$01,$3E,$80,$24,$0B
  DEFB $80,$07,$80,$12,$09,$80,$4C,$16
  DEFB $3D,$80,$E8,$16,$2B,$3F,$80,$27
  DEFB $03,$2F,$80,$34,$03,$2F,$02,$80
  DEFB $14,$30,$01,$3E,$80,$53,$16,$81
  DEFB $2C,$05,$2D,$3F,$80,$09,$30,$80
  DEFB $35,$2F,$01,$3E,$80,$64,$16,$2B
  DEFB $3F,$00,$13,$00,$80,$0A,$30,$3E
  DEFB $80,$37,$16,$2B,$3F,$80,$24,$2F
  DEFB $80,$09,$30,$01,$3E,$80,$24,$16
  DEFB $2B,$3F,$80,$01,$30,$80,$25,$0E
  DEFB $01,$3E,$80,$4D,$16,$2B,$3F,$80
  DEFB $01,$30,$80,$25,$0D,$01,$3E,$80
  DEFB $25,$0C,$80,$15

; Message at B281
  DEFM "2+?"

; Data block at B284
  DEFB $80,$02,$2F,$80,$10,$30,$01,$80
  DEFB $03,$20,$01,$3E,$80,$5C,$16,$81
  DEFB $2C,$05,$2D,$3F,$80,$28,$2F,$80
  DEFB $14,$30,$01,$80,$25,$0E,$01,$3E
  DEFB $80,$25,$0B,$80,$4E,$16,$2B,$3F
  DEFB $80,$28,$03,$2F,$80,$14,$30,$01
  DEFB $3E,$80,$53,$16,$81,$2C,$05,$2D
  DEFB $3F,$00,$14,$00,$80,$0A,$30,$3E
  DEFB $80,$38,$16,$2B,$3F,$00,$15,$00
  DEFB $80,$0A,$30,$3E,$80,$39,$16,$2B
  DEFB $3F,$80,$08,$30,$3E,$80,$01,$0C
  DEFB $80,$17

; Message at B2DE
  DEFM "2+?"

; Data block at B2E1
  DEFB $00,$17,$00,$80,$07,$30,$3E,$80
  DEFB $01,$0B,$80,$15

; Message at B2ED
  DEFM "2+?"

; Data block at B2F0
  DEFB $80,$0A,$30,$80,$26,$0E,$01,$80
  DEFB $02,$0D,$01,$3E,$80,$3A,$16,$2B
  DEFB $3F,$80,$0A,$30,$80,$26,$0D,$01
  DEFB $80,$02,$0D,$01,$3E,$80,$3B,$16
  DEFB $2B,$3F,$80,$17,$2F,$80,$18,$30
  DEFB $01,$80,$0A,$20,$01,$80,$26,$0E
  DEFB $01,$80,$00,$0D,$01,$3E,$80,$26
  DEFB $0B,$80,$4F,$16,$2B,$3F,$80,$25
  DEFB $2F,$80,$09,$30,$01,$80,$26,$0D
  DEFB $01,$80,$02,$0D,$01,$3E,$80,$25
  DEFB $16,$2B,$3F,$80,$08,$30,$80,$26
  DEFB $0D,$01,$80,$02,$0D,$01,$3E,$80
  DEFB $01,$0B,$80,$18

; Message at B354
  DEFM "2+?"

; Data block at B357
  DEFB $80,$17,$2F,$80,$09,$30,$01,$80
  DEFB $02,$0D,$01,$3E,$80,$17,$16,$2B
  DEFB $3F,$00,$1B,$00,$80,$0A,$30,$3E
  DEFB $80,$3D,$16,$2B,$3F,$80,$26,$2F
  DEFB $80,$09,$30,$01,$3E,$80,$26,$16
  DEFB $2B,$3F,$80,$31,$2F,$80,$14,$30
  DEFB $01,$80,$27,$0E,$01,$3E,$80,$27
  DEFB $0B,$80,$E9,$16,$2B,$3F,$80,$31
  DEFB $2F,$80,$1B,$30,$01,$80,$27,$0D
  DEFB $01,$3E,$80,$28,$0B,$80,$50,$16
  DEFB $2B,$3F,$80,$07,$30,$80,$28,$0D
  DEFB $01,$3E,$80,$09,$32,$80,$5D,$16
  DEFB $2B,$3F,$00,$1C,$00,$80,$0A,$30
  DEFB $3E,$80,$3E,$16,$2B,$3F,$00,$1E
  DEFB $00,$80,$0A,$30,$3E,$80,$34,$16
  DEFB $2B,$3F,$80,$19,$2F,$80,$09,$30
  DEFB $01,$80,$29,$0E,$01,$3E,$80,$29
  DEFB $0B,$80,$06,$80,$1E,$09,$80,$E8
  DEFB $16,$2B,$3F,$00,$00,$00,$80,$0D
  DEFB $30,$3E,$1C,$15,$2A,$3F,$80,$0E
  DEFB $30,$3E,$1D,$15

; Message at B3FB
  DEFM "+?3"

; Data block at B3FE
  DEFB $80,$00,$1B,$80,$05,$30,$01,$3E
  DEFB $80,$EF,$16

; Message at B409
  DEFM "+?3"

; Data block at B40C
  DEFB $80,$00,$1B,$80,$06,$30,$01,$3E
  DEFB $80,$EF,$16

; Message at B417
  DEFM "+?3"

; Data block at B41A
  DEFB $80,$00,$1B,$80,$09,$30,$01,$3E
  DEFB $80,$EF,$16,$2B,$3F,$80,$0C,$30
  DEFB $3E,$80,$EC,$16

; Message at B42E
  DEFM ";6+?"

; Data block at B432
  DEFB $80,$0F

; Message at B434
  DEFM "0>,?"

; Data block at B438
  DEFB $80,$0B,$30,$3E,$15,$2B,$3F,$80
  DEFB $01,$24,$80,$02,$24,$02,$80,$05
  DEFB $24,$02,$80,$06,$24,$02,$80,$0A
  DEFB $30,$01,$3E,$80,$28,$16,$2B,$3F
  DEFB $80,$1A,$30,$80,$02,$2F,$01,$80
  DEFB $02,$20,$01,$80,$04,$20,$01,$3E
  DEFB $80,$04,$80,$00,$09,$80,$03,$80
  DEFB $02,$08,$80,$49,$16,$2B,$3F,$80
  DEFB $10,$30,$80,$02,$2F,$01,$80,$03
  DEFB $20,$01,$3E,$80,$02,$80,$03,$08
  DEFB $80,$55,$16,$2B,$3F,$80,$18,$30
  DEFB $3E,$80,$EE,$16,$2B,$3F,$80,$02
  DEFB $2F,$80,$03,$1E,$01,$80,$05,$30
  DEFB $01,$3E,$80,$03,$06,$2A,$3F,$80
  DEFB $0E,$2F,$80,$0D,$1E,$01,$80,$05
  DEFB $30,$01,$3E,$80,$0D,$06

; Message at B4B6
  DEFM "*?3"

; Data block at B4B9
  DEFB $80,$11,$19,$80,$05,$30,$01,$3E
  DEFB $33,$06,$2A,$3F,$80,$02,$2F,$80
  DEFB $03,$20,$01,$80,$06,$30,$01,$3E
  DEFB $80,$03,$07,$2A,$3F,$80,$0E,$2F
  DEFB $80,$0D,$20,$01,$80,$06,$30,$01
  DEFB $3E,$80,$0D,$07

; Message at B4E5
  DEFM "*?3"

; Data block at B4E8
  DEFB $80,$11,$19,$80,$06,$30,$01,$3E
  DEFB $33,$07,$2A,$3F,$80,$02,$2F,$80
  DEFB $03,$20,$01,$80,$09,$30,$01,$3E
  DEFB $80,$03,$16,$2B,$3F,$80,$0E,$2F
  DEFB $80,$0D,$20,$01,$80,$09,$30,$01
  DEFB $3E,$80,$0D,$16,$2B,$3F,$80,$02
  DEFB $2F,$80,$03,$1E,$01,$80,$09,$30
  DEFB $01,$3E,$80,$EB,$16,$2B,$3F,$80
  DEFB $0E,$2F,$80,$0D,$1E,$01,$80,$09
  DEFB $30,$01,$3E,$80,$EB,$16

; Message at B536
  DEFM "+?3"

; Data block at B539
  DEFB $80,$11,$19,$80,$09,$30,$01,$33
  DEFB $20,$01,$3E,$33,$16

; Message at B546
  DEFM "+?3"

; Data block at B549
  DEFB $80,$11,$19,$33,$1E,$01,$80,$09
  DEFB $30,$01,$3E,$80,$EB,$16,$2B,$3F
  DEFB $80,$05,$2F,$80,$19,$30,$01,$80
  DEFB $05,$20,$01,$3E,$80,$05,$80,$00
  DEFB $09,$80,$04,$3B,$09,$80,$04,$07
  DEFB $80,$48,$16,$2B,$3F,$80,$1E,$30
  DEFB $3E,$80,$59,$16,$2B,$3F,$80,$0E
  DEFB $2F,$80,$1C,$30,$01,$80,$0E,$20
  DEFB $01,$80,$17,$24,$01,$3E,$80,$0D
  DEFB $80,$0E,$08,$80,$02,$0B,$15,$3F
  DEFB $80,$0E,$2F,$80,$1F,$30,$01,$80
  DEFB $0D,$20,$01,$80,$17,$24,$01,$3E
  DEFB $80,$0E,$80,$0D,$08,$80,$02,$0C
  DEFB $15,$3F,$80,$0E,$2F,$80,$1F,$30
  DEFB $01,$80,$0D,$20,$01,$3E,$80,$0E
  DEFB $80,$0D,$08,$80,$02,$0C,$2A,$3F
  DEFB $80,$0E,$2F,$80,$1C,$30,$01,$80
  DEFB $0E,$20,$01,$3E,$80,$0D,$80,$0E
  DEFB $08,$80,$02,$0B,$2A,$3F,$80,$18
  DEFB $24,$80,$19,$24,$02,$80,$1A,$24
  DEFB $02,$80,$0A,$30,$01,$3E,$80,$3C
  DEFB $16,$2B,$3F,$80,$01,$24,$80,$02
  DEFB $24,$02,$80,$05,$24,$02,$80,$06
  DEFB $24,$02,$80,$09,$30,$01,$80,$36
  DEFB $2F,$01,$3E,$80,$66,$16,$2B,$3F
  DEFB $00,$00,$F0,$02,$7E,$00,$F2,$04
  DEFB $85,$30,$00,$C0,$F1,$08,$86,$08
  DEFB $52,$48,$87,$48,$88,$40,$FD,$06
  DEFB $52,$08,$53,$78,$00,$C0,$F3,$16
  DEFB $04,$88,$3C,$8A,$62,$88,$3D,$92
  DEFB $B3,$08,$00,$48,$B4,$48,$B5,$48
  DEFB $B6,$48,$40,$48,$B7,$40,$F4,$08
  DEFB $B8,$08,$B9,$70,$01,$C8,$BA,$80
  DEFB $F5,$08,$BB,$08,$BC,$48,$BD,$68
  DEFB $00,$C0,$F6,$08,$86,$08,$BC,$48
  DEFB $BD,$68,$00,$C0,$F7,$08,$86,$08
  DEFB $B8

; Message at B66A
  DEFM "H3h"

; Data block at B66D
  DEFB $00,$C0,$F8,$08,$BE,$08,$BF,$48
  DEFB $C0,$50,$00,$C0,$FB,$12,$B8,$08
  DEFB $C6,$48,$C7,$50,$86,$08,$52,$48
  DEFB $87,$48,$C8

; Message at B688
  DEFM "HGj"

; Data block at B68B
  DEFB $00,$C0,$FC,$06,$86,$08,$BC,$48
  DEFB $4F,$40,$FE,$04,$C9,$28,$00,$C0
  DEFB $EF,$06,$37,$08,$CB,$70,$00,$C0
  DEFB $EE,$04,$CC,$30,$00,$C0,$ED,$08
  DEFB $86,$08,$42,$48,$C8,$48,$CD,$40
  DEFB $EC,$06,$BE,$08,$CF,$78,$00,$C0
  DEFB $01,$12,$4C,$08,$46,$48,$89,$48
  DEFB $8A,$48,$D0

; Message at B6C6
  DEFM "H7H"

; Data block at B6C9
  DEFB $D1,$48,$03,$48,$D2,$00,$02,$16
  DEFB $4C,$08,$00,$48,$D3,$48,$C4,$48
  DEFB $D4,$48,$8B,$48,$03,$48,$D5,$50
  DEFB $B8,$08,$D6,$50,$00,$C0,$03,$16
  DEFB $4C,$08,$00,$48,$D3,$48,$C4,$48
  DEFB $D4,$48,$8B,$48,$03,$48,$D5,$50
  DEFB $B8,$08,$D7,$50,$00,$C0,$04,$0C
  DEFB $00,$08,$D8,$48,$8D,$48,$03,$48
  DEFB $D9,$50,$00,$C0,$05,$0E,$4C,$08
  DEFB $00,$48,$9E,$48,$03,$48,$DA,$48
  DEFB $DB,$48,$DC,$40,$06,$1A,$00,$08
  DEFB $DD,$48,$03,$48,$8F,$48,$D0,$48
  DEFB $DB,$48,$DE,$50,$DF,$88,$E0,$88
  DEFB $E1,$08,$E2,$88,$E3,$88,$E4,$80
  DEFB $07,$12,$4C,$08,$46,$48,$E5,$48
  DEFB $03,$48,$AA,$48,$D0,$48,$E6,$48
  DEFB $E7,$48,$E8,$40,$08,$0A,$E9,$08
  DEFB $88,$58,$00,$48,$91,$68,$00,$C0
  DEFB $09,$12,$EA,$08,$EB,$48,$03,$48
  DEFB $92,$48,$93,$50,$CB,$08,$EC,$48
  DEFB $ED,$70,$00,$C0,$0A,$14,$E9,$08
  DEFB $4C,$48,$00,$48,$EE,$48,$EF,$48
  DEFB $03,$48,$D9,$58,$CC

; Message at B77E
  DEFM "HLH"

; Data block at B781
  DEFB $F0,$40,$0B,$14,$4C,$08,$46,$48
  DEFB $F1,$48,$95,$48,$96,$50,$BA,$09
  DEFB $CB,$48,$08

; Message at B794
  DEFM "Hkj"

; Data block at B797
  DEFB $00,$C0,$0C,$0C,$03,$08,$D9,$48
  DEFB $D0,$48,$F2,$48,$86,$48,$F3,$40
  DEFB $0D,$08,$00,$08,$99,$48,$F4,$58
  DEFB $F5,$40,$0E,$06,$00,$48,$99,$48
  DEFB $F4,$40,$0F,$08,$F6,$08,$9B,$48
  DEFB $F7,$68,$00,$C0,$10,$0C,$4C,$08
  DEFB $00,$48,$9C,$48,$03,$48,$F8,$08
  DEFB $F9,$40,$EB,$08,$03,$09,$04,$49
  DEFB $05,$69,$00,$C0,$11,$0E,$00,$08

; Message at B7DF
  DEFM "5H6H"

; Data block at B7E3
  DEFB $03,$48,$BC,$48,$06,$49,$F0,$40
  DEFB $12,$24,$EA,$08,$46,$48,$AD,$48
  DEFB $07,$49,$C4,$48,$00,$48,$08,$51
  DEFB $09,$09,$40,$48,$B8

; Message at B800
  DEFM "H4H"

; Data block at B803
  DEFB $00,$48,$0A,$51,$04,$08,$08,$49
  DEFB $0B,$49,$0C,$89,$0D,$81,$13,$50
  DEFB $37,$08,$0E,$59,$DB,$48,$0F

; Message at B81A
  DEFM "YNH"

; Data block at B81D
  DEFB $1E,$78,$01,$C8,$10,$19,$11,$71
  DEFB $01,$C8,$E9,$08,$12

; Message at B82A
  DEFM "IFH"

; Data block at B82D
  DEFB $13,$79,$01,$C8,$14,$49,$15,$49
  DEFB $16,$49,$17,$49,$18

; Message at B83A
  DEFM "I2H7HG"

; Data block at B840
  DEFB $08,$03,$48,$4A,$10,$4C,$08,$46
  DEFB $48,$19,$49,$1A,$49,$D0

; Message at B84E
  DEFM "HUh"

; Data block at B851
  DEFB $1B,$11,$1C,$09,$40,$48,$C1,$48
  DEFB $1D,$49,$C4,$48,$1E,$49,$B5,$48
  DEFB $1F,$41,$14,$0A,$66,$08,$20,$49
  DEFB $C6

; Message at B86A
  DEFM "H=h"

; Data block at B86D
  DEFB $00,$C0,$15,$12,$00,$08

; Message at B873
  DEFM "!I\"I"

; Data block at B877
  DEFB $D0

; Message at B878
  DEFM "HFH"

; Data block at B87B
  DEFB $23

; Message at B87C
  DEFM "IFH$I%A"

; Data block at B883
  DEFB $16,$0A,$26,$09

; Message at B887
  DEFM "FH'I(i"

; Data block at B88D
  DEFB $00,$C0,$17,$18,$4C,$08,$00,$48
  DEFB $A1,$48,$03,$48,$D9,$48,$CB

; Message at B89C
  DEFM "HFJpH*I"

; Data block at B8A3
  DEFB $03,$48,$04,$48,$05,$00,$18,$0E
  DEFB $46,$08

; Message at B8AD
  DEFM "+IxH"

; Data block at B8B1
  DEFB $D0,$48,$23,$49,$03

; Message at B8B6
  DEFM "H,A"

; Data block at B8B9
  DEFB $19,$1C,$CB,$08,$2D,$49,$03

; Message at B8C0
  DEFM "H.i"

; Data block at B8C3
  DEFB $01,$C8,$2F,$09,$CB,$48,$86,$48
  DEFB $16

; Message at B8CC
  DEFM "I0I"

; Data block at B8CF
  DEFB $CB

; Message at B8D0
  DEFM "H1I2I3"

; Data block at B8D6
  DEFB $40,$1A,$0C,$86,$08

; Message at B8DB
  DEFM "fHFH3I"

; Data block at B8E1
  DEFB $C6

; Message at B8E2
  DEFM "H4A"

; Data block at B8E5
  DEFB $1B,$14,$35,$39,$01,$C8,$36,$89
  DEFB $A5,$88,$01,$E0,$01,$C8,$37,$89
  DEFB $C4,$88,$5A,$88,$38,$81,$1C,$10
  DEFB $4C,$08

; Message at B8FF
  DEFM "FH9I:I"

; Data block at B905
  DEFB $CB

; Message at B906
  DEFM "HfH;I<A"

; Data block at B90D
  DEFB $1D,$0E,$C6,$08,$3D,$51,$B8,$08
  DEFB $3E,$49,$03

; Message at B918
  DEFM "H?a"

; Data block at B91B
  DEFB $40,$41,$1E,$14,$0E,$08,$C4,$48
  DEFB $0F,$58,$CC

; Message at B926
  DEFM "HAIrHBQ"

; Data block at B92D
  DEFB $CB,$08,$ED,$70,$00,$C0,$1F,$10
  DEFB $EA,$08,$43,$09

; Message at B939
  DEFM "DIEIF"

; Data block at B93E
  DEFB $99,$47,$89,$C4,$48,$48,$81,$21
  DEFB $16,$49,$09,$03

; Message at B94A
  DEFM "HFH"

; Data block at B94D
  DEFB $AC,$48,$C4

; Message at B950
  DEFM "HFH"

; Data block at B953
  DEFB $AD,$50,$4A,$09,$34,$48,$00

; Message at B95A
  DEFM "HKA\""

; Data block at B95E
  DEFB $0C,$35,$39,$01,$C8,$4C,$89,$4D
  DEFB $89,$03,$88,$4E,$81,$20,$0C,$35
  DEFB $39,$01,$C8,$4F,$89,$48,$88,$50
  DEFB $B1,$1B,$01,$23,$0A,$4C,$08,$46
  DEFB $48,$AD,$48,$51,$89,$F0,$40,$24
  DEFB $1E,$4C,$08

; Message at B989
  DEFM "FHiHaHRISI"

; Data block at B993
  DEFB $C4

; Message at B994
  DEFM "HTQ2"

; Data block at B998
  DEFB $08,$C1

; Message at B99A
  DEFM "HUI"

; Data block at B99D
  DEFB $EA

; Message at B99E
  DEFM "HFH"

; Data block at B9A1
  DEFB $AD

; Message at B9A2
  DEFM "HVA%"

; Data block at B9A6
  DEFB $0C,$EA,$08

; Message at B9A9
  DEFM "WIXI2H"

; Data block at B9AF
  DEFB $C1

; Message at B9B0
  DEFM "HYA&$"

; Data block at B9B5
  DEFB $EA,$08

; Message at B9B7
  DEFM "DJER2"

; Data block at B9BC
  DEFB $08,$C1,$48,$5C

; Message at B9C0
  DEFM "I4H"

; Unused
  DEFS $01

; Message at B9C4
  DEFM "H]I"

; Data block at B9C7
  DEFB $03,$48,$5E,$59,$CC

; Message at B9CC
  DEFM "H2H"

; Data block at B9CF
  DEFB $04,$48,$5F,$49,$03

; Message at B9D4
  DEFM "HFH"

; Data block at B9D7
  DEFB $60,$41,$27,$12,$4C,$08,$00,$48
  DEFB $A1

; Message at B9E0
  DEFM "HHH9IaI2H7H*A($1"

; Data block at B9F0
  DEFB $08,$32,$48,$00,$48,$03

; Message at B9F6
  DEFM "HbIcI"

; Data block at B9FB
  DEFB $03,$48,$64,$11,$65,$09,$03

; Message at BA02
  DEFM "HfIgIhIiIAXjIkIlA)\"2"

; Data block at BA16
  DEFB $08

; Message at BA17
  DEFM "7H8H"

; Data block at BA1B
  DEFB $03,$48,$00

; Message at BA1E
  DEFM "H5H6P"

; Data block at BA23
  DEFB $40,$88,$6D,$49,$03

; Message at BA28
  DEFM "HrHnIRHSH"

; Data block at BA31
  DEFB $40

; Message at BA32
  DEFM "HrHeA*02"

; Data block at BA3A
  DEFB $08,$04

; Message at BA3C
  DEFM "H>XoIpI"

; Data block at BA43
  DEFB $03

; Message at BA44
  DEFM "HqYRHSH"

; Data block at BA4B
  DEFB $40

; Message at BA4C
  DEFM "HrHrIsI"

; Data block at BA53
  DEFB $C4

; Message at BA54
  DEFM "HtIuQ2"

; Data block at BA5A
  DEFB $08,$00

; Message at BA5C
  DEFM "HvIFH"

; Data block at BA61
  DEFB $9F

; Message at BA62
  DEFM "HNHwIxA+,7"

; Data block at BA6C
  DEFB $08,$47,$48,$EA

; Message at BA70
  DEFM "HFHyI"

; Data block at BA75
  DEFB $23,$51,$72,$08,$7A,$49,$7B,$49
  DEFB $C4,$48,$7C,$59,$7D,$49,$7E,$49
  DEFB $40,$48,$7F,$49,$80,$49,$81,$49
  DEFB $1D,$50,$CB,$08,$82,$69,$01,$E8
  DEFB $00,$C0

; Message at BA97
  DEFM ",0r"

; Data block at BA9A
  DEFB $08,$7A,$49,$15,$49,$83

; Message at BAA0
  DEFM "IiI"

; Data block at BAA3
  DEFB $00,$48,$A0

; Message at BAA6
  DEFM "HHH"

; Data block at BAA9
  DEFB $84,$49,$4A,$18,$85

; Message at BAAE
  DEFM "I2H7H"

; Data block at BAB3
  DEFB $86,$49,$03

; Message at BAB6
  DEFM "HrH"

; Data block at BAB9
  DEFB $87,$51,$86,$08,$15,$49,$88,$49
  DEFB $14,$49,$00,$48,$89,$69,$00,$C0
  DEFB $2D,$16,$46,$08

; Message at BACD
  DEFM "=IQP2"

; Data block at BAD2
  DEFB $08,$37,$48,$83

; Message at BAD6
  DEFM "HRHSH"

; Data block at BADB
  DEFB $00,$48,$A1,$48,$8A

; Message at BAE0
  DEFM "A. ?"

; Data block at BAE4
  DEFB $08,$40,$48,$04

; Message at BAE8
  DEFM "HTH4HFHoH"

; Data block at BAF1
  DEFB $03,$48,$8B,$49,$23,$51,$04,$08
  DEFB $8C

; Message at BAFA
  DEFM "IfH"

; Data block at BAFD
  DEFB $8D

; Message at BAFE
  DEFM "I7Hx"

; Data block at BB02
  DEFB $40,$2F,$18,$37,$08

; Message at BB07
  DEFM "WHfH$I"

; Data block at BB0D
  DEFB $8E,$51,$34,$08,$46,$48,$A4,$48
  DEFB $09,$49,$40,$48,$04,$48,$54,$40
  DEFB $30,$36,$04,$08,$A3,$48,$B8

; Message at BB24
  DEFM "HgH"

; Data block at BB27
  DEFB $C4

; Message at BB28
  DEFM "H4HFH"

; Data block at BB2D
  DEFB $8F,$49,$90,$49,$40

; Message at BB32
  DEFM "H7Q"

; Data block at BB35
  DEFB $03,$08,$91,$49,$92,$49,$93

; Message at BB3C
  DEFM "IFH"

; Data block at BB3F
  DEFB $94,$51,$95,$49,$96,$09,$A5,$18
  DEFB $37,$48,$A6,$50,$32,$08,$CB

; Message at BB4E
  DEFM "HRH"

; Data block at BB51
  DEFB $97,$71,$1B,$01

; Message at BB55
  DEFM "1$1"

; Data block at BB58
  DEFB $08,$32,$48,$00,$48,$5E

; Message at BB5E
  DEFM "HHH"

; Data block at BB61
  DEFB $98,$09,$55,$10,$70,$08,$07,$08
  DEFB $B8,$48,$04

; Message at BB6C
  DEFM "HTPv"

; Data block at BB70
  DEFB $08,$37,$48,$83

; Message at BB74
  DEFM "H4HFH"

; Data block at BB79
  DEFB $A7,$40

; Message at BB7B
  DEFM "2 F"

; Data block at BB7E
  DEFB $08,$99,$49,$5F,$50,$3F,$08,$40

; Message at BB86
  DEFM "HAHBH"

; Data block at BB8B
  DEFB $04

; Message at BB8C
  DEFM "HTH"

; Data block at BB8F
  DEFB $03,$48,$00,$48,$5E,$50,$EA,$08
  DEFB $46,$48,$AD

; Message at BB9A
  DEFM "HVA3"

; Data block at BB9E
  DEFB $1C,$46,$08,$99,$49,$5F,$50,$3F
  DEFB $08,$40

; Message at BBA8
  DEFM "HAHBHFH"

; Data block at BBAF
  DEFB $60,$50,$70,$08,$0A,$08,$B8

; Message at BBB6
  DEFM "HAH"

; Data block at BBB9
  DEFB $5E,$40,$34,$14,$46,$08,$99,$49
  DEFB $5F,$50,$3F,$08,$40

; Message at BBC6
  DEFM "HAHBHFH"

; Data block at BBCD
  DEFB $A2,$48,$9A,$41,$35,$1C,$31,$08

; Message at BBD5
  DEFM "2H7H8HHH"

; Data block at BBDD
  DEFB $60,$50,$32,$08,$04

; Message at BBE2
  DEFM "HYI4HFH"

; Data block at BBE9
  DEFB $A8,$48,$03,$48,$9B,$41,$36,$1C
  DEFB $3F,$08,$40

; Message at BBF4
  DEFM "HAHBHFH"

; Data block at BBFB
  DEFB $AB,$48,$03,$48,$AA,$50,$40,$88
  DEFB $41,$48,$9C,$49,$B8

; Message at BC08
  DEFM "H7H"

; Data block at BC0B
  DEFB $60,$40,$37,$1C,$46,$08,$9D,$49
  DEFB $D0

; Message at BC14
  DEFM "HFH"

; Data block at BC17
  DEFB $60,$48,$40

; Message at BC1A
  DEFM "HAH"

; Data block at BC1D
  DEFB $9C,$51,$3F,$08,$40

; Message at BC22
  DEFM "HAH4HFHi"

; Data block at BC2A
  DEFB $40,$38,$10,$46,$08,$9E

; Message at BC30
  DEFM "IlH"

; Data block at BC33
  DEFB $03,$48,$9F,$59,$A0,$49,$03,$48
  DEFB $A1,$41,$39,$14,$46,$08,$99,$49
  DEFB $5F,$50,$70,$08,$08,$08,$34,$48
  DEFB $00

; Message at BC4C
  DEFM "HyH"

; Data block at BC4F
  DEFB $CB,$48,$0F,$40,$3A,$38,$04,$08

; Message at BC57
  DEFM "wHHHxX"

; Data block at BC5D
  DEFB $A2,$49,$15,$49,$A3

; Message at BC62
  DEFM "IrH"

; Data block at BC65
  DEFB $A4

; Message at BC66
  DEFM "Y7H"

; Data block at BC69
  DEFB $A5,$49,$03,$48,$A6,$59,$A7,$51
  DEFB $70,$08,$0B,$08,$34,$48,$00

; Message at BC78
  DEFM "HyH"

; Data block at BC7B
  DEFB $CB,$48,$0E,$50,$32,$08,$37,$48
  DEFB $83

; Message at BC84
  DEFM "H4H"

; Data block at BC87
  DEFB $00,$48,$A1,$48,$8A

; Message at BC8C
  DEFM "A;<"

; Data block at BC8F
  DEFB $04,$08

; Message at BC91
  DEFM "wHHHxX"

; Data block at BC97
  DEFB $A2,$49,$15,$49,$A3

; Message at BC9C
  DEFM "IrH"

; Data block at BC9F
  DEFB $A4

; Message at BCA0
  DEFM "Y7H"

; Data block at BCA3
  DEFB $A5,$49,$03,$48,$A6,$59,$A7,$51
  DEFB $70,$08,$0B,$08,$34,$48,$00

; Message at BCB2
  DEFM "HyH"

; Data block at BCB5
  DEFB $CB,$48,$0E,$50,$32,$08,$37,$48
  DEFB $83

; Message at BCBE
  DEFM "H4HFH"

; Data block at BCC3
  DEFB $C7,$48,$AE,$48,$03

; Message at BCC8
  DEFM "H*A<"

; Data block at BCCC
  DEFB $08,$26,$09,$A8,$69,$01,$E8,$00
  DEFB $C0,$3D,$24,$00,$08,$A9,$49,$7B
  DEFB $58,$C4

; Message at BCDE
  DEFM "H2H"

; Data block at BCE1
  DEFB $C1,$48,$7C,$48,$00,$48,$7D,$48
  DEFB $AA,$49,$03,$48,$04,$48,$CB,$48
  DEFB $0F,$48,$00

; Message at BCF4
  DEFM "HyH"

; Data block at BCF7
  DEFB $03,$48,$AB,$41,$3E,$10,$46,$08
  DEFB $C7,$48,$7F,$50,$70,$08,$08

; Message at BD06
  DEFM "HBH"

; Data block at BD09
  DEFB $00,$48,$AC,$41,$3F,$1E,$D0,$08
  DEFB $BC,$48,$CB

; Message at BD14
  DEFM "HNHbH"

; Data block at BD19
  DEFB $AD,$49,$AE,$49,$AF

; Message at BD1E
  DEFM "I3p"

; Data block at BD21
  DEFB $01,$C8,$03,$08,$88,$48,$C8,$68
  DEFB $02,$E8,$00,$C0,$40,$16,$B0,$09
  DEFB $04,$48,$9C

; Message at BD34
  DEFM "H2H"

; Data block at BD37
  DEFB $04,$48,$0A,$51,$04,$08,$08,$49
  DEFB $0B,$49,$B1,$89,$B2,$81,$41,$1E
  DEFB $37,$08,$83,$48,$03,$48,$04

; Message at BD4E
  DEFM "H5H"

; Data block at BD51
  DEFB $15,$49,$B3,$49,$C4,$48,$B4,$49
  DEFB $40

; Message at BD5A
  DEFM "HFH"

; Data block at BD5D
  DEFB $C7,$48,$B5,$69,$01,$E8,$00,$C0

; Message at BD65
  DEFM "B,F"

; Data block at BD68
  DEFB $08,$B6,$49,$B7,$09,$4E,$48,$B8
  DEFB $49,$00,$48,$9C,$48,$D0,$48,$B9
  DEFB $49,$03,$48,$BA,$51,$BB,$49,$15
  DEFB $49,$BC

; Message at BD82
  DEFM "HlJ"

; Data block at BD85
  DEFB $D0,$48,$00,$48,$BD,$49,$BE,$69
  DEFB $1B,$19,$16,$49,$BF

; Message at BD92
  DEFM "AC2F"

; Data block at BD96
  DEFB $08,$C0,$49,$03,$48,$C1,$49,$15
  DEFB $49,$1C,$49,$C2

; Message at BDA2
  DEFM "IAH"

; Data block at BDA5
  DEFB $D0

; Message at BDA6
  DEFM "H7H"

; Data block at BDA9
  DEFB $C3

; Message at BDAA
  DEFM "I2H"

; Data block at BDAD
  DEFB $C4,$49,$C5,$69,$01,$E8,$01,$C8
  DEFB $32,$08,$C6

; Message at BDB8
  DEFM "INH"

; Data block at BDBB
  DEFB $C7,$49,$C4,$48,$C8,$49,$40,$48
  DEFB $04,$48,$A2,$00,$44,$0C,$86,$08
  DEFB $52,$50,$B8,$08

; Message at BDCF
  DEFM "ZI2IX"

; Data block at BDD4
  DEFB $40,$45,$60,$A5,$08,$C9

; Message at BDDA
  DEFM "I7H"

; Data block at BDDD
  DEFB $89,$48,$C4,$48,$CA,$49,$15,$49
  DEFB $CB,$49,$40,$48,$04

; Message at BDEA
  DEFM "HTH"

; Data block at BDED
  DEFB $C4,$48,$04,$48,$CC,$51,$4E,$08
  DEFB $77,$49,$C4

; Message at BDF8
  DEFM "H2H"

; Data block at BDFB
  DEFB $CD,$49,$0F

; Message at BDFE
  DEFM "H5y"

; Data block at BE01
  DEFB $01,$C8,$CE,$49,$CF,$49,$D0,$51
  DEFB $B8,$08,$4C,$48,$04,$48,$D1,$79
  DEFB $01,$C8,$72,$08,$D2,$49,$03,$48
  DEFB $D3,$09,$03,$48,$04,$48,$D4,$09
  DEFB $D5,$49,$D6,$49,$D7,$49,$D8,$49
  DEFB $03,$48,$C4,$49,$D9

; Message at BE2E
  DEFM "I2H"

; Data block at BE31
  DEFB $04,$48,$DA,$49,$00,$C0,$46,$5A
  DEFB $DB,$51,$DC,$09,$DD,$49,$CB

; Message at BE40
  DEFM "HrH"

; Data block at BE43
  DEFB $E7,$48,$03,$48,$DE,$49,$15,$49
  DEFB $A3

; Message at BE4C
  DEFM "I2HrHeH"

; Data block at BE53
  DEFB $03,$48,$04,$48,$55,$08,$5C

; Message at BE5A
  DEFM "X2HFH"

; Data block at BE5F
  DEFB $90,$48,$03,$48,$B2,$48,$DF,$91
  DEFB $E0,$09,$E1

; Message at BE6A
  DEFM "I2H"

; Data block at BE6D
  DEFB $04

; Message at BE6E
  DEFM "HUH"

; Data block at BE71
  DEFB $C4,$48,$E2

; Message at BE74
  DEFM "I7HPQ"

; Data block at BE79
  DEFB $E3,$09,$E4

; Message at BE7C
  DEFM "I2H"

; Data block at BE7F
  DEFB $04,$48,$A2,$48,$E5,$49,$BC,$48
  DEFB $E6,$49,$B5,$48,$E7,$49,$04,$48
  DEFB $E8,$51,$00,$C0,$47,$3E,$E9,$09
  DEFB $EA

; Message at BE98
  DEFM "I7H"

; Data block at BE9B
  DEFB $EB,$49,$EC

; Message at BE9E
  DEFM "IpH"

; Data block at BEA1
  DEFB $ED,$49,$EE,$11,$EF,$09,$2F,$49
  DEFB $CB

; Message at BEAA
  DEFM "HLH7H"

; Data block at BEAF
  DEFB $F0,$49,$03,$48,$CB

; Message at BEB4
  DEFM "HNH"

; Data block at BEB7
  DEFB $F1,$49,$F2,$49,$F3,$49,$F4,$69
  DEFB $1B,$11,$4E,$08,$F5,$49,$03,$48
  DEFB $04,$48,$A3,$48,$C4,$48,$04,$48
  DEFB $CC,$49,$00,$C0,$48,$1A,$F6,$09
  DEFB $37,$48,$8E,$48,$F7

; Message at BEDC
  DEFM "I7H"

; Data block at BEDF
  DEFB $83,$58,$F8,$51,$34,$08,$DB

; Message at BEE6
  DEFM "HoIrH"

; Data block at BEEB
  DEFB $F9,$69,$00,$C0,$49,$0C,$B0,$09
  DEFB $04,$48,$8D

; Message at BEF6
  DEFM "H2H"

; Data block at BEF9
  DEFB $04,$48,$8B,$40,$4A,$34,$04,$08
  DEFB $54,$48,$15,$49,$1F,$50,$03,$08
  DEFB $04,$48,$5E,$48,$FA

; Message at BF0E
  DEFM "IFH9I"

; Data block at BF13
  DEFB $CB

; Message at BF14
  DEFM "XjI"

; Data block at BF17
  DEFB $FB,$49,$FC

; Message at BF1A
  DEFM "YNH"

; Data block at BF1D
  DEFB $FD,$69,$01,$C8,$32,$09,$DB,$48
  DEFB $CF,$49,$FE,$69,$02,$E8,$01,$C8
  DEFB $FF,$11,$03,$D0,$00,$C0,$4B,$10
  DEFB $15,$09,$00,$4A,$04,$48,$08,$49
  DEFB $C4,$48,$01,$4A,$02,$4A,$03,$42
  DEFB $4C,$0C,$04,$08,$4B,$49,$15,$49
  DEFB $04

; Message at BF4E
  DEFM "J2H"

; Data block at BF51
  DEFB $05,$42,$4D,$1E,$37,$08,$69,$48
  DEFB $86

; Message at BF5A
  DEFM "HNH"

; Data block at BF5D
  DEFB $06,$4A,$07,$52,$D0,$08,$8A,$49
  DEFB $CD

; Message at BF66
  DEFM "I5I"

; Data block at BF69
  DEFB $08,$8A,$03,$88,$6B,$98,$32,$89
  DEFB $09,$82,$4E,$16,$37,$08

; Message at BF77
  DEFM "iH5I"

; Data block at BF7B
  DEFB $0A,$8A,$0B,$8A,$C4,$48,$15,$49
  DEFB $0C,$4A,$40

; Message at BF86
  DEFM "HFH"

; Data block at BF89
  DEFB $0D,$42,$4F,$1A,$0E,$0A,$04,$48
  DEFB $0F,$4A,$A1,$48,$D0,$48,$04,$48
  DEFB $94,$48,$C4,$48,$04,$48,$10,$4A
  DEFB $40

; Message at BFA2
  DEFM "HFH"

; Data block at BFA5
  DEFB $0D,$42,$50,$0E,$22,$08,$11,$52
  DEFB $04,$08,$7D,$48,$15,$49,$1F,$48
  DEFB $12

; Message at BFB6
  DEFM "BQ."

; Data block at BFB9
  DEFB $81,$09,$13

; Message at BFBC
  DEFM "J7HPQ"

; Data block at BFC1
  DEFB $14,$8A,$15,$8A

; Message at BFC5
  DEFM "5I7H"

; Data block at BFC9
  DEFB $16,$4A,$03,$48,$04,$48,$DA,$49
  DEFB $17,$8A,$16,$89,$18,$8A,$48,$88
  DEFB $19,$92,$00,$08,$BD,$49,$1A,$4A
  DEFB $1B

; Message at BFE2
  DEFM "J:h"

; Data block at BFE5
  DEFB $00,$C0

; Message at BFE7
  DEFM "R4p"

; Data block at BFEA
  DEFB $08,$53,$48,$CB,$48,$86,$48,$BD

; Message at BFF2
  DEFM "H7HPY"

; Data block at BFF7
  DEFB $1C,$4A,$CB,$48,$81,$49,$1D,$4A
  DEFB $1E,$6A,$01,$E8,$01,$C8,$EF,$09
  DEFB $4E,$48,$1F,$4A,$40,$48,$D2,$10
  DEFB $02,$D0,$32,$48,$F9,$51,$CB,$08
  DEFB $20,$6A,$02,$E8,$00,$C0,$E8,$06
  DEFB $DB,$08,$01,$6A,$00,$C0,$E9,$04
  DEFB $21,$2A,$00,$C0,$EA,$08,$86,$08
  DEFB $BD,$48,$BC

; Message at C032
  DEFM "H\"BS."

; Data block at C037
  DEFB $04,$08,$B2

; Message at C03A
  DEFM "HLH$j"

; Data block at C03F
  DEFB $01,$E8,$01,$C8,$00,$08,$25,$4A
  DEFB $03

; Message at C048
  DEFM "H&J'J"

; Data block at C04D
  DEFB $40

; Message at C04E
  DEFM "H(J"

; Data block at C051
  DEFB $C4,$58,$03,$48,$91,$49,$92,$59
  DEFB $93

; Message at C05A
  DEFM "IFH)R*"

; Data block at C060
  DEFB $0A,$2B,$6A,$00,$C0,$55,$14,$04
  DEFB $08,$8D,$48,$FA

; Message at C06C
  DEFM "I.J"

; Data block at C06F
  DEFB $C4,$48,$15

; Message at C072
  DEFM "I/J2H"

; Unused
  DEFS $01

; Message at C078
  DEFM "HYAV"

; Data block at C07C
  DEFB $14,$33,$08

; Message at C07F
  DEFM "0J4H"

; Data block at C083
  DEFB $00,$48,$EB,$48,$03,$48,$E1,$59
  DEFB $C4

; Message at C08C
  DEFM "HLH1BW*2"

; Data block at C094
  DEFB $0A

; Message at C095
  DEFM "FH3J"

; Data block at C099
  DEFB $C4,$48,$04

; Message at C09C
  DEFM "HTH"

; Data block at C09F
  DEFB $03,$48,$04,$48,$5E,$48,$15,$49
  DEFB $1F,$68,$01,$C8,$34,$0A,$4E,$48
  DEFB $B8

; Message at C0B0
  DEFM "H5J"

; Data block at C0B3
  DEFB $40

; Message at C0B4
  DEFM "H6J"

; Data block at C0B7
  DEFB $04

; Message at C0B8
  DEFM "H7j"

; Data block at C0BB
  DEFB $00,$C0,$58,$1A,$04,$08,$8D,$48
  DEFB $15

; Message at C0C4
  DEFM "I/J2H7HnHHH"

; Data block at C0CF
  DEFB $A2,$58,$CB

; Message at C0D2
  DEFM "H8JpH9BY"

; Data block at C0DA
  DEFB $0A,$37,$08

; Message at C0DD
  DEFM ":J;R"

; Data block at C0E1
  DEFB $02,$D0,$00,$C0,$5A,$10,$37,$08
  DEFB $A2,$48,$17,$68,$01,$C8,$3E,$0A
  DEFB $0E,$49,$9A,$69,$00,$C0,$5B,$0A
  DEFB $37,$08,$AA,$48,$15

; Message at C0FE
  DEFM "IbH?B"

; Data block at C103
  DEFB $5C,$20,$04,$08,$8D,$48,$40,$4A
  DEFB $F7

; Message at C10C
  DEFM "I7HiX"

; Data block at C111
  DEFB $C4,$48,$08,$48,$1F

; Message at C116
  DEFM "HuH"

; Data block at C119
  DEFB $F7

; Message at C11A
  DEFM "IAP"

; Data block at C11D
  DEFB $02,$D0,$40

; Message at C120
  DEFM "HAj"

; Data block at C123
  DEFB $00,$C0,$5D,$0A,$04,$08,$7D,$48
  DEFB $1C,$49,$40

; Message at C12E
  DEFM "HCBd"

; Data block at C132
  DEFB $0C,$4C,$08,$00

; Message at C136
  DEFM "HKI"

; Data block at C139
  DEFB $96,$58,$C6

; Message at C13C
  DEFM "HHBe"

; Data block at C140
  DEFB $10,$4C,$08,$00

; Message at C144
  DEFM "HTH"

; Data block at C147
  DEFB $03

; Message at C148
  DEFM "HIJJ"

; Data block at C14C
  DEFB $12,$4B,$0A

; Message at C14F
  DEFM "LBf 4"

; Data block at C154
  DEFB $08,$4D,$4A,$03

; Message at C158
  DEFM "HNJbIgIOR"

; Data block at C161
  DEFB $02,$D0,$C4

; Message at C164
  DEFM "HPJ"

; Data block at C167
  DEFB $CB,$48,$86

; Message at C16A
  DEFM "HQJcHRj"

; Data block at C171
  DEFB $00,$C0,$67,$0A,$04,$08,$54,$48
  DEFB $B8

; Message at C17A
  DEFM "HSj"

; Data block at C17D
  DEFB $00,$C0

; Message at C17F
  DEFM "h4b"

; Data block at C182
  DEFB $09

; Message at C183
  DEFM "TJUJ"

; Data block at C187
  DEFB $5F

; Message at C188
  DEFM "J2H"

; Data block at C18B
  DEFB $04

; Message at C18C
  DEFM "HUPX"

; Data block at C190
  DEFB $08,$03

; Message at C192
  DEFM "H$IWJXJ>J"

; Data block at C19B
  DEFB $C4

; Message at C19C
  DEFM "HYJZJ"

; Data block at C1A1
  DEFB $40

; Message at C1A2
  DEFM "H[j"

; Data block at C1A5
  DEFB $01,$C8,$4E,$08,$1D,$4A,$5C

; Message at C1AC
  DEFM "J2H]J"

; Data block at C1B1
  DEFB $5E,$6A,$00,$C0,$69,$08,$37,$08
  DEFB $63,$4A,$B8

; Message at C1BC
  DEFM "HdBj"

; Data block at C1C0
  DEFB $16,$65,$0A

; Message at C1C3
  DEFM "HHfJ"

; Data block at C1C7
  DEFB $03,$48,$05,$49,$86

; Message at C1CC
  DEFM "HNH"

; Data block at C1CF
  DEFB $0D,$48,$14

; Message at C1D2
  DEFM "Igj"

; Data block at C1D5
  DEFB $00,$C0,$6C,$04,$68,$0A

; Message at C1DB
  DEFM "iBm"

; Data block at C1DE
  DEFB $0C,$86,$08,$34,$48,$06,$49,$7E

; Message at C1E6
  DEFM "Ijj"

; Data block at C1E9
  DEFB $00,$C0,$00,$00,$88,$13,$0C,$00
  DEFB $03,$01,$00,$11,$00,$05,$80,$70
  DEFB $18,$00,$49,$01,$54,$07,$E8,$03
  DEFB $11,$07,$05,$AF,$8F,$08,$6F,$97
  DEFB $8F,$6F,$09,$8F,$97,$97,$9F,$09
  DEFB $6F,$97,$67,$9F,$09,$6F,$6F,$40
  DEFB $57,$09,$90,$6F,$BF,$57,$09,$87
  DEFB $6F,$AF,$40,$09

; Message at C225
  DEFM "wpO"

; Data block at C228
  DEFB $40,$09

; Message at C22A
  DEFM "wpwh"

; Data block at C22E
  DEFB $09

; Message at C22F
  DEFM "whg"

; Data block at C232
  DEFB $40,$09,$87,$70,$87,$68,$09,$87
  DEFB $68,$97,$40,$09,$77,$68,$87,$68
  DEFB $09,$6F,$88,$40,$98,$09,$8F,$88
  DEFB $BF,$98,$08,$BF,$90,$B7,$78,$08
  DEFB $9F,$88,$A7,$80,$08,$40,$8F,$48
  DEFB $77,$08,$58,$87,$60,$7F,$04,$7A
  DEFB $6C,$06,$7A,$9C,$06,$66,$9E,$06
  DEFB $6D,$8A,$06,$42,$96,$06,$4B,$8E
  DEFB $06,$62,$86,$06,$42,$5C,$06,$4F
  DEFB $41,$06,$67,$60,$06,$71,$6B,$06
  DEFB $65,$42,$06,$70,$5B,$06,$75,$69
  DEFB $06,$7E,$67,$06,$98,$42,$06,$8D
  DEFB $5B,$06,$89,$68,$06,$B0,$41,$06
  DEFB $96,$5F,$06,$8C,$6D,$06,$BE,$96
  DEFB $06,$B6,$8F,$06,$95,$87,$06,$BE
  DEFB $5C,$06,$99,$9E,$06,$91,$8A,$09
  DEFB $78,$67,$86,$66,$09,$86

; Message at C2B8
  DEFM "fze"

; Data block at C2BB
  DEFB $09,$88,$6B,$8A,$66,$09,$88,$6E
  DEFB $8F,$6D,$09,$8F,$6D,$8C,$6C,$09
  DEFB $90,$70,$92,$96,$09,$92,$96,$93
  DEFB $70,$09

; Message at C2D5
  DEFM "nol"

; Data block at C2D8
  DEFB $96,$09,$6C,$96,$6A,$6E,$09,$70
  DEFB $98,$8E,$99,$09,$8E,$99,$70,$9A
  DEFB $09,$87,$6E,$AE,$40,$09,$AE,$40
  DEFB $AE,$40,$09,$AE,$40,$AE,$40,$09

; Message at C2F8
  DEFM "voP"

; Data block at C2FB
  DEFB $40,$11,$06,$05,$B8,$89,$05,$A1
  DEFB $85,$05,$59,$85,$05,$42,$85,$08
  DEFB $BA,$8E,$BF,$7B,$08,$A1,$86,$A5
  DEFB $81,$08,$5F,$81,$59,$85,$08,$46
  DEFB $8D,$40,$79,$11,$00,$10,$06,$05
  DEFB $80,$79,$02,$7D,$80,$02,$83,$80
  DEFB $10,$00,$09,$70,$90,$8F,$90,$09
  DEFB $8F,$90,$8F,$70,$10,$06,$02,$87
  DEFB $81,$02,$78,$82,$02,$73,$84,$1B
  DEFB $00,$56,$00,$13,$07,$18,$00,$11
  DEFB $07,$10,$00,$08,$B3,$9F,$B0,$4F
  DEFB $09,$B2,$50,$B2,$9F,$09,$B1,$9F
  DEFB $B1,$4F,$08,$A3,$4F,$A6,$9F,$09
  DEFB $A4,$9F,$A4,$4F,$09,$A5,$4F,$A5
  DEFB $9F,$08,$B2,$97,$A2,$94,$08,$A2
  DEFB $84,$B2,$81,$08,$B2,$71,$A2,$6E
  DEFB $08,$A2,$5E,$B2,$5B,$08,$B2,$5C
  DEFB $A2,$5D,$08,$A3,$6F,$B3,$70,$08
  DEFB $B3,$82,$A3,$83,$08,$A3,$95,$B3
  DEFB $96,$10,$00,$11,$07,$16,$00,$50
  DEFB $00,$14,$07,$13,$00,$11,$06,$09
  DEFB $63,$93,$63,$8B,$09,$63,$93,$9B
  DEFB $93,$09,$9B,$93,$9B,$87,$09,$9B
  DEFB $77,$9B,$5B,$09,$63,$7E,$63,$51
  DEFB $04,$6B,$8D,$04,$8E,$8F,$04,$9A
  DEFB $91,$04,$9A,$6F,$04,$68,$7F,$04
  DEFB $64,$58,$04,$64,$90,$04,$64,$90
  DEFB $04,$64,$90,$04,$67,$89,$09,$47
  DEFB $9F,$47,$57,$09,$47,$57,$40,$54
  DEFB $09,$60,$9C,$9B,$9C,$15,$00,$74
  DEFB $00,$1A,$07,$E8,$03,$11,$06,$05
  DEFB $AF,$97,$08,$6F,$97,$97,$57,$09
  DEFB $97,$57,$BF,$47,$09,$6F,$57,$40
  DEFB $47,$09,$6F,$97,$67,$9F,$09,$97
  DEFB $97,$9F,$9F,$09,$AF,$4F,$AF,$97
  DEFB $09,$AF,$97,$9F,$8F,$09,$9F,$8F
  DEFB $9F,$54,$09,$9F,$8F,$AF,$87,$09
  DEFB $AF,$67,$A7,$6F,$09,$A7,$6F,$A7
  DEFB $6C,$09,$A7,$6C,$AF,$64,$09,$AF
  DEFB $60,$A7,$50,$06,$AE,$95,$06,$A0
  DEFB $8D,$06,$AE,$6F,$06,$A5,$53,$04
  DEFB $AE,$4F,$09,$B2,$4C,$B2,$9B,$09
  DEFB $B2,$9B,$9C,$8F,$09,$9C,$8F,$9C
  DEFB $55,$06,$82,$56,$08,$77,$8F,$8F
  DEFB $5F,$14,$00,$F5,$00,$36,$07,$E8
  DEFB $03,$11,$07,$05,$AF,$8F,$08,$A7
  DEFB $57,$8F,$97,$09,$8F,$97,$87,$97
  DEFB $09,$87,$97,$87,$5F,$09,$87,$5F
  DEFB $8F,$57,$09,$48,$5F,$40,$57,$09
  DEFB $48,$5F,$48,$9F,$09,$9F,$97,$9F
  DEFB $9F,$08,$92,$5A,$A4,$92,$08,$A2
  DEFB $6E,$A0,$76,$08,$95,$8A,$A1,$86
  DEFB $09

; Message at C49C
  DEFM "QVYV"

; Data block at C4A0
  DEFB $09,$59,$56,$5C,$63,$09,$5C

; Message at C4A7
  DEFM "cNc"

; Data block at C4AA
  DEFB $09

; Message at C4AB
  DEFM "NcPV"

; Data block at C4AF
  DEFB $09

; Message at C4B0
  DEFM "Ra[Y"

; Data block at C4B4
  DEFB $09

; Message at C4B5
  DEFM "PcF"

; Data block at C4B8
  DEFB $8B,$09,$47,$8B,$51,$63,$09,$89
  DEFB $83,$81,$63,$09,$82,$63,$8A,$83
  DEFB $09,$80,$67,$80,$55,$09,$84

; Message at C4CF
  DEFM "dyX"

; Data block at C4D2
  DEFB $09

; Message at C4D3
  DEFM "yXzT"

; Data block at C4D7
  DEFB $09,$7A,$54,$7E,$53,$09,$7E,$53
  DEFB $80,$54,$09,$7E,$5B,$7E,$54,$09
  DEFB $7D,$5B,$7C,$57,$08,$BF,$48,$AF
  DEFB $60,$09,$AF,$60,$AB,$62,$09,$AB
  DEFB $62,$AB,$4B,$09,$AB,$4B,$AF,$48
  DEFB $09,$AB,$63,$BF,$63,$08,$50,$87
  DEFB $80,$85,$09,$50,$85,$50,$7D,$09
  DEFB $50,$7D,$80,$85,$06,$51,$84,$08
  DEFB $53,$88,$6B,$90,$08,$73,$90,$7B
  DEFB $88,$09,$87,$5F,$5B,$5F,$09,$4F
  DEFB $5F,$48,$5F,$09,$A7,$5F,$AB,$5B
  DEFB $06,$6B,$5E,$06,$4B,$5E,$06,$83
  DEFB $5E,$06,$A8,$5C,$06,$58,$8C,$06
  DEFB $78,$8C,$08,$55,$8E,$69,$8B,$06
  DEFB $AE,$4A,$06,$BE,$62,$11,$04,$06
  DEFB $BE,$52,$13,$00,$2E,$02,$7E,$07
  DEFB $E8,$03,$11,$06,$05,$B7,$8F,$09
  DEFB $9F,$4F,$BF,$40,$09,$9F,$97,$A7
  DEFB $9F,$09,$5F,$97,$57,$9F,$09,$5F
  DEFB $4F,$40,$40,$09,$6F,$8F,$7F,$8F
  DEFB $09,$7F,$8F,$87,$87,$09,$87,$87
  DEFB $77,$77,$09

; Message at C582
  DEFM "wwg"

; Data block at C585
  DEFB $87,$09,$67,$87,$6F,$8F,$09,$87
  DEFB $87,$8F,$87,$08,$8F,$8F,$97,$6F
  DEFB $09,$67,$87,$6F,$67,$09,$6F,$67
  DEFB $97,$67,$09,$97,$67,$9F,$87,$09
  DEFB $9F,$87,$97,$87,$09,$9F,$87,$A7
  DEFB $8F,$09,$A7,$8F,$B7,$7F,$09,$B7
  DEFB $7F,$B7,$77,$09,$B7,$77,$9F,$7F
  DEFB $08,$B7,$77,$AF,$5F,$09,$67,$87
  DEFB $5F,$8F,$09,$5F,$8F,$4F,$7F,$09
  DEFB $4F,$7F,$4F,$77,$09

; Message at C5D2
  DEFM "Owg"

; Data block at C5D5
  DEFB $7F,$08

; Message at C5D7
  DEFM "OwW"

; Data block at C5DA
  DEFB $5F,$08,$77,$67,$8F,$5F,$09,$AF
  DEFB $5F,$B3,$5B,$09,$B7,$5F,$B4,$5B
  DEFB $09,$B1,$5D,$AC,$58,$09,$AC,$58
  DEFB $B1,$53,$09,$B1,$53,$B3,$55,$09
  DEFB $B3,$55,$B1,$57,$09,$B1,$57,$B4
  DEFB $5A,$09,$B4,$5A,$B8,$56,$09,$B8
  DEFB $56,$B1,$4F,$09,$B1,$4F,$B4,$4C
  DEFB $09,$B4,$4C,$BD,$55,$09,$BD,$55
  DEFB $B5,$5D,$09,$4F,$5F,$53,$5B,$09

; Message at C622
  DEFM "S[W"

; Data block at C625
  DEFB $5F,$09

; Message at C627
  DEFM "U]ZX"

; Data block at C62B
  DEFB $09

; Message at C62C
  DEFM "ZXUS"

; Data block at C630
  DEFB $09

; Message at C631
  DEFM "USSU"

; Data block at C635
  DEFB $09

; Message at C636
  DEFM "SUUW"

; Data block at C63A
  DEFB $09

; Message at C63B
  DEFM "S[VX"

; Data block at C63F
  DEFB $09

; Message at C640
  DEFM "R[LU"

; Data block at C644
  DEFB $09

; Message at C645
  DEFM "LUSN"

; Data block at C649
  DEFB $09

; Message at C64A
  DEFM "SNPK"

; Data block at C64E
  DEFB $09

; Message at C64F
  DEFM "PKGT"

; Data block at C653
  DEFB $09

; Message at C654
  DEFM "GTP]"

; Data block at C658
  DEFB $09,$AF,$77,$A0,$7F,$09

; Message at C65E
  DEFM "Wwg"

; Data block at C661
  DEFB $7F,$09,$6F,$8F,$77,$87,$09,$77
  DEFB $87,$7F,$8F,$09,$6F,$87,$77,$84
  DEFB $09,$77,$84,$7F,$87,$09,$7F,$87
  DEFB $7F,$82,$09,$7F,$82,$77,$7A,$09

; Message at C681
  DEFM "wzo"

; Data block at C684
  DEFB $82,$09,$6F,$82,$6F,$87,$04,$77
  DEFB $7B,$04,$70,$86,$04,$7E,$86,$09
  DEFB $77,$5F,$6F,$5F,$09,$6F,$5F,$67
  DEFB $57,$09

; Message at C69E
  DEFM "gWoO"

; Data block at C6A2
  DEFB $09

; Message at C6A3
  DEFM "oOwW"

; Data block at C6A7
  DEFB $09

; Message at C6A8
  DEFM "wWw"

; Data block at C6AB
  DEFB $5F,$09,$8F,$5F,$97,$5F,$09,$97
  DEFB $5F,$9F,$57,$09,$9F,$57,$97,$4F
  DEFB $09,$97,$4F,$8F,$57,$09,$8F,$57
  DEFB $8F,$5F,$08,$77,$57,$8F,$54,$08

; Message at C6CB
  DEFM "wgra"

; Data block at C6CF
  DEFB $08,$8F,$61,$94,$67,$03,$93,$87
  DEFB $90,$8B,$03,$93,$7B,$90,$7F,$04
  DEFB $93,$7C,$04,$93,$86,$06,$77,$88
  DEFB $06,$5F,$8D,$06,$A7,$8D,$06,$80
  DEFB $65,$09

; Message at C6F1
  DEFM "fVnN"

; Data block at C6F5
  DEFB $09,$98,$4E,$A0,$56,$04,$80,$56
  DEFB $08,$7F,$6F,$87,$67,$09

; Message at C703
  DEFM "QwQ"

; Data block at C706
  DEFB $5F,$04,$50,$60,$09,$B5,$60,$B5
  DEFB $78,$04,$B6,$75,$09,$95,$5F,$9D
  DEFB $57,$09

; Message at C718
  DEFM "uWmO"

; Data block at C71C
  DEFB $09

; Message at C71D
  DEFM "rgh"

; Data block at C720
  DEFB $86,$09,$8D,$87,$8D,$6D,$09,$8D
  DEFB $6D,$97,$6E,$04,$8E,$6E,$09,$5F
  DEFB $97,$6B,$8B,$09,$9F,$97,$97,$8F
  DEFB $09,$9F,$4F,$9D,$51,$09,$5F

; Message at C73F
  DEFM "OgS"

; Data block at C742
  DEFB $06,$76,$55,$06,$68,$52,$06,$9C
  DEFB $50,$11,$05,$05,$82,$6A,$05,$82
  DEFB $5A,$02,$80,$6D,$02,$82,$6D,$02
  DEFB $84,$6D,$02,$86,$6D,$02,$86,$6B
  DEFB $02,$86,$69,$02,$84,$69,$02,$82
  DEFB $69,$02,$82,$6B,$02,$84,$6B,$02
  DEFB $80,$69,$02,$80,$6B,$11,$02,$05
  DEFB $B0,$6B,$05,$53,$6B,$12,$00,$31
  DEFB $01,$46,$07,$E8,$03,$11,$06,$05
  DEFB $AF,$97,$08,$BF,$4F,$5F,$47,$08
  DEFB $6F,$57,$BF,$5F,$08,$5F,$5F,$BF
  DEFB $6F,$09,$6F,$7F,$97,$7F,$09,$6F
  DEFB $7F,$5F,$6F,$09,$6F,$57,$5F,$4F
  DEFB $08,$9F,$87,$BF,$9F,$09,$97,$7F
  DEFB $9F,$87,$08,$97,$7F,$BF,$77,$08
  DEFB $A3,$9F,$BE,$8A,$09,$70,$7D,$80
  DEFB $7D,$09,$88,$7D,$97,$7D,$09,$6F
  DEFB $7D,$67,$75,$09

; Message at C7CE
  DEFM "guwu"

; Data block at C7D2
  DEFB $09,$77,$75,$7F,$7D,$09,$87,$7D
  DEFB $7F,$75,$09,$7F,$75,$8F,$75,$09
  DEFB $8F,$75,$97,$7D,$09

; Message at C7E7
  DEFM "oYOY"

; Data block at C7EB
  DEFB $09,$4F,$59,$40,$51,$09

; Message at C7F1
  DEFM "PYP"

; Data block at C7F4
  DEFB $9F,$09,$72,$7D,$6A,$75,$09,$75
  DEFB $7D,$6D,$75,$09,$78,$7D,$70,$75
  DEFB $09,$7B,$7D,$73,$75,$09,$8B,$7D
  DEFB $83,$75,$03,$8E,$7A,$8A,$7D,$04
  DEFB $8E,$7A,$09,$6D,$7B,$7D,$7B,$09
  DEFB $A8,$87,$A0,$7F,$09,$B0,$7F,$B8
  DEFB $87,$09,$A6,$85,$B6,$85,$09,$B4
  DEFB $83,$A4,$83,$09,$A2,$81,$B2,$81
  DEFB $09,$B4,$87,$AC,$7F,$09,$A9,$7F
  DEFB $B1,$87,$09,$AE,$87,$A6,$7F,$09
  DEFB $A3,$7F,$AB,$87,$06,$50,$57,$04
  DEFB $80,$4D,$09,$97,$9F,$87,$7F,$06
  DEFB $97,$97,$04,$80,$5A,$08,$58,$9F
  DEFB $88,$87,$03,$68,$97,$58,$9F,$03
  DEFB $68,$97,$60,$9C,$08,$80,$9C,$84
  DEFB $8C,$08,$54,$9F,$8C,$84,$11,$05
  DEFB $05,$78,$6A,$08,$64,$6C,$BF,$62
  DEFB $09,$64,$67,$BF,$67,$11,$00,$10
  DEFB $04,$05,$B7,$97,$02,$A5,$9B,$02
  DEFB $A7,$9B,$02,$AA,$9B,$09,$AF,$9B
  DEFB $B7,$9B,$02,$BA,$9B,$02,$AA,$96
  DEFB $02,$AC,$96,$02,$B1,$96,$02,$B5
  DEFB $96,$02,$B8,$96,$09,$BB,$93,$AB
  DEFB $93,$02,$A9,$93,$11,$00,$5C,$00
  DEFB $16,$07,$E8,$03,$11,$05,$05,$B7
  DEFB $97,$08,$9F,$9F,$67,$47,$09,$67
  DEFB $47,$5F,$40,$09,$9F,$48,$A7,$40
  DEFB $08,$8F,$90,$97,$70,$06,$97,$44
  DEFB $09,$6A,$9F,$6A,$47,$09,$9C,$47
  DEFB $9C,$9F,$09,$A2,$9F,$A2,$45,$09
  DEFB $64,$9F,$64,$44,$08,$8D,$92,$99
  DEFB $6E,$11,$06,$05,$94,$72,$03,$93
  DEFB $77,$96,$7A,$03,$93,$7F,$96,$82
  DEFB $03,$93,$88,$96,$8B,$10,$02,$04
  DEFB $94,$88,$04,$94,$7F,$04,$94,$77
  DEFB $10,$00,$05,$02,$73,$07,$E8,$03
  DEFB $11,$06,$05,$AF,$8F,$08,$97,$97
  DEFB $67,$57,$09,$97,$57,$B7,$40,$09
  DEFB $97,$97,$9F,$9F,$09,$67,$97,$5F
  DEFB $9F,$09

; Message at C92E
  DEFM "gWG"

; Data block at C931
  DEFB $40,$09,$83,$56,$84,$4D,$09,$84
  DEFB $4D,$83,$4B,$09,$84,$4B,$89,$49
  DEFB $09,$89,$49,$8D,$49,$09,$8D,$49
  DEFB $8E,$4B,$09,$8E,$4B,$8A,$4E,$09
  DEFB $8A,$4E,$89,$56,$04,$88,$56,$09
  DEFB $7D,$56,$7E,$4C,$09,$7E

; Message at C95F
  DEFM "LwJ"

; Data block at C962
  DEFB $09

; Message at C963
  DEFM "wJsJ"

; Data block at C967
  DEFB $09

; Message at C968
  DEFM "sJrL"

; Data block at C96C
  DEFB $09

; Message at C96D
  DEFM "rMwO"

; Data block at C971
  DEFB $09

; Message at C972
  DEFM "wOwV"

; Data block at C976
  DEFB $04,$79,$56,$04,$76,$4B,$06,$68
  DEFB $56,$06,$81,$56,$06,$97,$56,$09
  DEFB $97,$7F,$67,$7F,$09,$A7,$9F,$A7
  DEFB $57,$09,$A7,$57,$BF,$47,$09,$58
  DEFB $9F,$58,$57,$09,$58,$57,$40,$47
  DEFB $11,$05,$05,$7F,$87,$03,$80,$89
  DEFB $76,$80,$09,$7A,$82,$7A,$8B,$09
  DEFB $85,$8B,$85,$81,$08,$85,$8B,$7A
  DEFB $87,$09,$7E,$83,$82,$83,$02,$7F
  DEFB $86,$02,$81,$86,$09,$7D,$8B,$7C
  DEFB $87,$09,$7F,$87,$80,$8B,$09,$83
  DEFB $8B,$82,$88,$06,$80,$90,$06,$79
  DEFB $8A,$06,$86,$83,$08,$7C,$81,$85
  DEFB $80,$04,$6D,$90,$04,$95,$90,$11
  DEFB $02,$05,$75,$70,$09,$85,$7E,$85
  DEFB $76,$09,$85,$76,$89,$75,$09,$89
  DEFB $75,$8E,$7C,$09,$8E,$7C,$85,$7E
  DEFB $09,$7C,$7E,$7C,$76,$09,$7C

; Message at CA05
  DEFM "vxu"

; Data block at CA08
  DEFB $09

; Message at CA09
  DEFM "xusz"

; Data block at CA0D
  DEFB $09,$73,$7A,$7B,$7E,$09,$86

; Message at CA14
  DEFM "kzk"

; Data block at CA17
  DEFB $09

; Message at CA18
  DEFM "zkyt"

; Data block at CA1C
  DEFB $09,$89,$74,$88,$6D,$09,$80,$65
  DEFB $7D,$5F,$09,$7D,$5F,$7E,$58,$09

; Message at CA2C
  DEFM "wXva"

; Data block at CA30
  DEFB $09

; Message at CA31
  DEFM "vazj"

; Data block at CA35
  DEFB $09,$80,$65,$82,$58,$09,$88,$58
  DEFB $87,$65,$08,$7F,$6B,$82,$68,$09
  DEFB $7A,$69,$7E,$68,$09,$82,$68,$85
  DEFB $69,$09

; Message at CA4F
  DEFM "ykvk"

; Data block at CA53
  DEFB $09

; Message at CA54
  DEFM "vkua"

; Data block at CA58
  DEFB $09

; Message at CA59
  DEFM "xtqs"

; Data block at CA5D
  DEFB $09

; Message at CA5E
  DEFM "qvqn"

; Data block at CA62
  DEFB $09

; Message at CA63
  DEFM "qnln"

; Data block at CA67
  DEFB $09

; Message at CA68
  DEFM "lnlv"

; Data block at CA6C
  DEFB $09

; Message at CA6D
  DEFM "lvty"

; Data block at CA71
  DEFB $09

; Message at CA72
  DEFM "lnmf"

; Data block at CA76
  DEFB $09

; Message at CA77
  DEFM "mfkd"

; Data block at CA7B
  DEFB $09

; Message at CA7C
  DEFM "kdma"

; Data block at CA80
  DEFB $09

; Message at CA81
  DEFM "maoa"

; Data block at CA85
  DEFB $09

; Message at CA86
  DEFM "oaod"

; Data block at CA8A
  DEFB $09

; Message at CA8B
  DEFM "oerd"

; Data block at CA8F
  DEFB $09

; Message at CA90
  DEFM "rdrg"

; Data block at CA94
  DEFB $09

; Message at CA95
  DEFM "pgrn"

; Data block at CA99
  DEFB $09,$8C,$7A,$92,$77,$09,$92,$77
  DEFB $93,$72,$09,$93,$72,$91,$6D,$09
  DEFB $91,$6D,$8C,$6F,$09,$8D,$6F,$8F
  DEFB $75,$09,$89,$75,$8E,$73,$09,$8C
  DEFB $6F,$8A,$6C,$09,$8A,$6C,$86,$6C
  DEFB $09,$86,$6C,$86,$67,$09,$86,$66
  DEFB $8B,$66,$09,$8B,$66,$8D,$69,$09
  DEFB $8D,$69,$92,$6C,$09

; Message at CAD6
  DEFM "wlvn"

; Data block at CADA
  DEFB $09

; Message at CADB
  DEFM "vnyo"

; Data block at CADF
  DEFB $06,$79,$6E,$04,$68,$7D,$04,$78
  DEFB $73,$04,$75,$6F,$04,$74,$66,$04
  DEFB $8A,$73,$04,$7F,$62,$04,$96,$7E
  DEFB $09,$83,$58,$89,$5A,$04,$87,$58
  DEFB $09,$7D

; Message at CB01
  DEFM "XxY"

; Data block at CB04
  DEFB $04,$79,$58,$09,$80,$7E,$80,$71
  DEFB $09,$80,$71,$81,$6D,$0F,$00,$78
  DEFB $00,$1D,$07,$E8,$03,$11,$06,$05
  DEFB $AF,$97,$08,$67,$97,$97,$57,$09
  DEFB $97,$97,$9F,$9F,$09,$97,$57,$9F
  DEFB $47,$08,$9F,$47,$BF,$9F,$09,$67
  DEFB $97,$5F,$9F,$09,$67,$57,$5F,$47
  DEFB $08,$5F,$47,$40,$9F,$08,$70,$57
  DEFB $90,$8F,$06,$80,$56,$08

; Message at CB4A
  DEFM "nzjp"

; Data block at CB4E
  DEFB $02,$6B,$72,$02,$6B,$76,$11,$05
  DEFB $05,$80,$76,$09,$8C,$58,$8C,$8F
  DEFB $09,$74,$8F,$74,$58,$06,$72,$58
  DEFB $06,$8E,$58,$08,$88,$5C,$78,$8E
  DEFB $09,$78,$5C,$75,$5A,$09,$8C,$5A
  DEFB $88,$5C,$08,$86,$81,$83,$76,$02
  DEFB $85,$78,$02,$85,$7A,$02,$85,$7C
  DEFB $06,$85,$5B,$0E,$00,$79,$00,$1A
  DEFB $07,$E8,$03,$11,$06,$05,$AF,$8F
  DEFB $08,$6F,$47,$97,$97,$08,$6B,$47
  DEFB $9B,$9A,$09,$BF,$46,$9B,$46,$09
  DEFB $6B,$46,$40,$46,$08,$B0,$9F,$BF
  DEFB $4F,$08,$57,$9F,$40,$4F,$08,$68
  DEFB $7F,$60,$6F,$09

; Message at CBBA
  DEFM "bob"

; Data block at CBBD
  DEFB $7F,$09,$64,$7F,$64,$6F,$09

; Message at CBC4
  DEFM "fof"

; Data block at CBC7
  DEFB $7F,$09,$60,$7C,$68,$7C,$09,$68
  DEFB $79,$60,$79,$09,$60

; Message at CBD4
  DEFM "vhv"

; Data block at CBD7
  DEFB $09,$68,$73,$60,$73,$09,$60

; Message at CBDE
  DEFM "qhq"

; Data block at CBE1
  DEFB $06,$80,$46,$11,$05,$05,$78,$8E
  DEFB $08,$78,$8E,$90,$4E,$08,$97,$4A
  DEFB $94,$61,$08,$97,$93,$94,$7B,$08
  DEFB $94,$80,$97,$8E,$08,$97,$5C,$94
  DEFB $4E,$0D,$00,$07,$01,$39,$07,$E8
  DEFB $03,$11,$07,$05,$AF,$8F,$09,$6F
  DEFB $57,$8F,$40,$09,$97,$5F,$BF,$4F
  DEFB $09,$6F,$5F,$9F,$40,$09,$6F,$60
  DEFB $97,$60,$09,$97,$60,$97,$9F,$09
  DEFB $6F,$5F,$6F,$57,$09,$6F,$57,$40
  DEFB $57,$08,$60,$9F,$80,$87,$09,$60
  DEFB $87,$50,$57,$09

; Message at CC3D
  DEFM "PWX"

; Data block at CC40
  DEFB $40,$09,$80,$88,$98,$80,$09,$98
  DEFB $80,$BF,$68,$06,$96,$9D,$06,$BE
  DEFB $9D,$06,$46,$9D,$06,$46,$4D,$08
  DEFB $76,$9F,$71,$8A,$08,$6B,$8A,$66
  DEFB $9F,$09,$7A,$9F,$7A,$8C,$09,$7A
  DEFB $8C,$76,$8C,$09,$71,$8C,$6B,$8C
  DEFB $09,$66,$8C,$60,$8C,$06,$7D,$9D
  DEFB $09,$7A,$8C,$7F,$88,$09,$74,$8A
  DEFB $74,$9F,$09,$69,$9F,$69,$8B,$04
  DEFB $6A,$8B,$04,$75,$8B,$06,$70,$8B
  DEFB $06,$65,$8B,$09,$65,$7B,$65,$6B
  DEFB $09,$65,$7B,$6D,$7B,$03

; Message at CC9E
  DEFM "mspv"

; Data block at CCA2
  DEFB $09,$6D,$7B,$6D,$76,$09

; Message at CCA8
  DEFM "mqmi"

; Data block at CCAC
  DEFB $09

; Message at CCAD
  DEFM "jnon"

; Data block at CCB1
  DEFB $09

; Message at CCB2
  DEFM "mijf"

; Data block at CCB6
  DEFB $09

; Message at CCB7
  DEFM "miof"

; Data block at CCBB
  DEFB $09

; Message at CCBC
  DEFM "evhz"

; Data block at CCC0
  DEFB $09,$9A,$71,$9A,$69,$09,$9C,$6F
  DEFB $9C,$67,$09,$9E,$65,$9E,$6D,$09
  DEFB $A0,$6B,$A0,$63,$09,$98,$6C,$A3
  DEFB $68,$03,$5B,$48,$60,$4B,$04,$5B
  DEFB $49,$09,$60

; Message at CCE3
  DEFM "IcL"

; Data block at CCE6
  DEFB $09

; Message at CCE7
  DEFM "aIeI"

; Data block at CCEB
  DEFB $09,$5E,$46,$60,$45,$09,$5C

; Message at CCF2
  DEFM "F[C"

; Data block at CCF5
  DEFB $09

; Message at CCF6
  DEFM "XFUD"

; Data block at CCFA
  DEFB $09,$9D,$5C,$85,$5C,$09,$B5,$54
  DEFB $A5,$54,$09,$9D,$54,$95,$54,$0C
  DEFB $00,$F3,$00,$37,$07,$E8,$03,$11
  DEFB $06,$05,$AF,$97,$08,$BF

; Message at CD18
  DEFM "Ggo"

; Data block at CD1B
  DEFB $08,$5F,$6F,$BF,$77,$09

; Message at CD21
  DEFM "gOOO"

; Data block at CD25
  DEFB $09,$4F,$4F,$40,$47,$09

; Message at CD2B
  DEFM "POP"

; Data block at CD2E
  DEFB $9F,$08,$68,$97,$A0,$77,$09,$4D
  DEFB $9F,$4D,$57,$09,$4D,$57,$40,$52
  DEFB $06,$41,$4A,$06,$4E,$53,$09,$53
  DEFB $9F,$53,$57,$09

; Message at CD4A
  DEFM "SWeW"

; Data block at CD4E
  DEFB $06,$52,$50,$08,$64,$78,$A4,$9A
  DEFB $09

; Message at CD57
  DEFM "dndV"

; Data block at CD5B
  DEFB $08,$B4,$78,$BF,$9A,$08,$BF,$97
  DEFB $B7,$77,$04,$BC,$8F,$11,$07,$05
  DEFB $87,$87,$03,$88,$87,$81,$94,$03
  DEFB $85,$88,$88,$8B,$03,$8B,$88,$88
  DEFB $8B,$09,$87,$85,$86,$83,$09,$89
  DEFB $86,$8A,$83,$09,$8A,$83,$86,$83
  DEFB $09,$84,$82,$86,$80,$09,$86,$80
  DEFB $8A,$80,$09,$8A,$80,$8C,$82,$09
  DEFB $82,$88,$7F,$8A,$09,$7F,$8A,$81
  DEFB $84,$09,$8E,$88,$91,$8A,$09,$91
  DEFB $8A,$8F,$84,$09,$83,$80,$7F,$79
  DEFB $09,$8F,$81,$92,$79,$04,$9F,$96
  DEFB $04,$69,$93,$06,$83,$7D,$06,$8E
  DEFB $81,$11,$02,$05,$69,$73,$05,$69
  DEFB $63,$09,$61,$73,$A1,$73,$09

; Message at CDD2
  DEFM "qnq"

; Data block at CDD5
  DEFB $5E,$09

; Message at CDD7
  DEFM "qVqN"

; Data block at CDDB
  DEFB $09

; Message at CDDC
  DEFM "snsf"

; Data block at CDE0
  DEFB $09,$7C,$6E,$7C,$5E,$02,$7C,$56
  DEFB $09,$84,$48,$84,$60,$09,$87,$48
  DEFB $87,$50,$09,$9F,$50,$9F,$58,$09
  DEFB $9F,$60,$9F,$68,$0B,$00,$5D,$01
  DEFB $51,$07,$E8,$03,$11,$05,$05,$AF
  DEFB $7F,$08,$97,$9F,$40,$4F,$09,$98
  DEFB $57,$B0,$47,$09,$B0,$47,$40,$47
  DEFB $09,$90,$4F,$90,$9F,$08,$88,$9C
  DEFB $84,$86,$09,$84,$86,$7D,$83,$09
  DEFB $7D,$83,$7D,$96,$09,$7D,$96,$84
  DEFB $9C,$09,$7D,$83,$82,$83,$09,$82
  DEFB $83,$87,$85,$04,$83,$84,$09,$7F
  DEFB $95,$82,$98,$09,$82,$98,$82,$87
  DEFB $09,$82,$87,$7F,$85,$09,$7F,$85
  DEFB $7F,$95,$09,$7E,$97,$7E,$9E,$09
  DEFB $83,$9B,$81,$9F,$08,$89,$7F,$71
  DEFB $4F,$08,$69,$7F,$41,$5F,$08,$79
  DEFB $83,$40,$93,$08,$41,$7C,$66,$62
  DEFB $08,$74,$51,$86,$7D,$08,$76,$85
  DEFB $40,$91,$08,$B0,$47,$40,$45,$09
  DEFB $5E,$62,$5E,$7C,$09,$5B,$7C,$5B
  DEFB $62,$09

; Message at CE8A
  DEFM "SbS"

; Data block at CE8D
  DEFB $7C,$09,$50,$7C,$50,$62,$09

; Message at CE94
  DEFM "HbH"

; Data block at CE97
  DEFB $7C,$09,$45,$7C,$45,$62,$09

; Message at CE9E
  DEFM "fjAj"

; Data block at CEA2
  DEFB $09

; Message at CEA3
  DEFM "Amfm"

; Data block at CEA7
  DEFB $09

; Message at CEA8
  DEFM "fuAu"

; Data block at CEAC
  DEFB $09

; Message at CEAD
  DEFM "Axfx"

; Data block at CEB1
  DEFB $06,$61,$7A,$06,$59,$7A,$06,$49
  DEFB $7A,$06,$42,$7A,$06,$42,$72,$06
  DEFB $4A,$72,$06,$5A,$72,$06,$62,$72
  DEFB $04,$62,$69,$04,$5A,$69,$04,$4F
  DEFB $69,$04,$43,$69,$08,$79,$77,$81
  DEFB $57,$08

; Message at CEDB
  DEFM "uew"

; Data block at CEDE
  DEFB $5C,$08,$57,$59,$5E,$57,$08,$5C

; Message at CEE6
  DEFM "WdU"

; Data block at CEE9
  DEFB $08,$54,$9D,$5D,$9B,$08,$5B,$9B
  DEFB $65,$99,$09,$97,$89,$9F,$89,$09
  DEFB $9F,$89,$9F,$99,$09,$9F,$99,$A7
  DEFB $99,$09,$A7,$99,$A7,$81,$09,$A7
  DEFB $81,$AF,$81,$09,$AF,$81,$AF,$89
  DEFB $09,$AF,$89,$BF,$89,$09,$BF,$61
  DEFB $97,$61,$06,$7F,$61,$06,$87,$61
  DEFB $06,$72,$61,$04,$A2,$91,$04,$BA
  DEFB $81,$06,$BA,$59,$10,$01,$04,$9A
  DEFB $91,$04,$AA,$89,$11,$04,$05,$62
  DEFB $89,$09,$44,$87,$4C,$8F,$09,$4C
  DEFB $8F,$4C,$87,$02,$4F,$8B,$02,$4F
  DEFB $88,$08,$54,$88,$61,$8C,$03,$66
  DEFB $8E,$6A,$8B,$09,$66,$89,$6F,$8B
  DEFB $0A,$00,$72,$01,$59,$07,$E8,$03
  DEFB $11,$07,$05,$B7,$97,$08,$67,$97
  DEFB $97,$8F,$08,$8F,$8F,$6F,$87,$09
  DEFB $67,$87,$97,$87,$09,$97,$87,$9F
  DEFB $4F,$09,$9F,$4F,$5F,$4F,$09,$5F
  DEFB $4F,$67,$87,$09,$97,$97,$9F,$9F
  DEFB $09,$5F,$9F,$67,$97,$08,$87

; Message at CF90
  DEFM "Wwo"

; Data block at CF93
  DEFB $09,$98,$83,$BF,$83,$09,$67,$83
  DEFB $40,$83,$09,$60,$53,$40,$53,$09
  DEFB $9E,$53,$BE,$53,$08,$66,$7D,$98
  DEFB $7A,$08,$76,$57,$88,$55,$08,$89

; Message at CFB3
  DEFM "UuS"

; Data block at CFB6
  DEFB $08,$74,$53,$8A,$51,$06,$5A,$51
  DEFB $06,$AA,$51,$08,$8B

; Message at CFC3
  DEFM "QsO"

; Data block at CFC6
  DEFB $09,$40,$4A,$BF,$4A,$09,$BF,$47
  DEFB $40,$47,$09,$66,$83,$46,$53,$08
  DEFB $75,$55,$89,$71,$09,$9C,$63,$B4
  DEFB $63,$09,$B4,$63,$BF,$73,$09,$98
  DEFB $7F,$BF,$7F,$09,$63,$7F,$40,$7F
  DEFB $09

; Message at CFEF
  DEFM "vWfO"

; Data block at CFF3
  DEFB $04,$65,$80,$04,$64,$7C,$04,$5E
  DEFB $54,$04,$BE,$70,$04,$72,$50,$06
  DEFB $75,$7C,$06,$75,$8C,$06,$A5,$81
  DEFB $06,$55,$81,$04,$74,$55,$08,$A4
  DEFB $75,$B4,$71,$08,$5C

; Message at D018
  DEFM "uLq"

; Data block at D01B
  DEFB $06,$4F,$72,$06,$A7,$72,$09,$87

; Message at D023
  DEFM "gwg"

; Data block at D026
  DEFB $03,$7F,$6B,$7B,$67,$08,$7C,$6A
  DEFB $82,$6C,$02,$7E,$6B,$02,$80,$6B
  DEFB $04,$86,$6E,$04,$78,$6E,$11,$02
  DEFB $05,$78,$5E,$05,$7A,$5F,$09,$7B
  DEFB $66,$7C,$61,$09,$83,$66,$82,$61
  DEFB $09,$82,$61,$7D,$61,$09,$7C,$60
  DEFB $7B,$58,$09,$7F,$5E,$7E,$58,$09
  DEFB $7F,$5E,$7F,$58,$09,$82,$60,$82
  DEFB $58,$09

; Message at D068
  DEFM "zfya"

; Data block at D06C
  DEFB $09,$79,$61,$7B,$60,$09,$84,$66
  DEFB $85,$62,$09,$85,$62,$84,$5D,$09
  DEFB $84,$5D,$83,$5D,$09,$82,$60,$84
  DEFB $60,$09,$7F,$66,$7C,$64,$09,$82
  DEFB $64,$80,$65,$09,$83,$63,$83,$61
  DEFB $04,$78,$66,$04,$86,$66,$11,$06
  DEFB $05,$6E,$9E,$09,$80,$9F,$80,$98
  DEFB $09,$90,$9F,$8C,$98,$09,$70,$9F
  DEFB $74,$98,$10,$01,$04,$42,$9D,$04
  DEFB $42,$9D,$04,$42,$9D,$04,$42,$9D
  DEFB $04,$42,$9D,$04,$42,$9D,$04,$42
  DEFB $9D,$04,$42,$9D,$04,$BA,$9D,$09
  DEFB $00,$D2,$00,$30,$07,$E8,$03,$11
  DEFB $07,$05,$B7,$97,$08,$97,$9F,$67
  DEFB $5F,$09,$97,$5F,$BF,$4F,$03,$80
  DEFB $4F,$60,$57,$06,$80,$4F,$03,$80

; Message at D0EC
  DEFM "OhS"

; Data block at D0EF
  DEFB $03,$80,$4F,$84,$51,$04,$81,$4F
  DEFB $08,$40,$9F,$48,$87,$08,$40,$87
  DEFB $4B,$77,$08,$40,$77,$48,$5F,$09
  DEFB $48,$5F,$40,$57,$09,$48,$5F,$50
  DEFB $5F,$09,$50,$5F,$52,$5B,$09

; Message at D116
  DEFM "R[PT"

; Data block at D11A
  DEFB $09

; Message at D11B
  DEFM "PTHT"

; Data block at D11F
  DEFB $09

; Message at D120
  DEFM "HTEU"

; Data block at D124
  DEFB $09

; Message at D125
  DEFM "EUBW"

; Data block at D129
  DEFB $09,$4E,$5F,$4C,$5A,$09

; Message at D12F
  DEFM "LZMT"

; Data block at D133
  DEFB $04,$4F,$5E,$09,$48,$5E,$45,$56
  DEFB $09

; Message at D13C
  DEFM "MVGV"

; Data block at D140
  DEFB $09,$43,$5F,$46,$57,$06,$42,$5D
  DEFB $06,$44,$59,$06,$4A,$55,$09,$67
  DEFB $5F,$41,$51,$06,$65,$99,$06,$6D
  DEFB $91,$06,$BD,$91,$06,$55,$59,$04
  DEFB $41,$52,$09,$44,$9F,$44,$87,$09

; Message at D168
  DEFM "DwD"

; Data block at D16B
  DEFB $5F,$06,$43,$61,$06,$43,$91,$09
  DEFB $43,$87,$43,$77,$06,$42,$78,$09

; Message at D17B
  DEFM "JNZM"

; Data block at D17F
  DEFB $09

; Message at D180
  DEFM "ZMLK"

; Data block at D184
  DEFB $09,$74,$5B,$94,$5D,$09,$94,$5D
  DEFB $89,$5A,$09,$A9,$52,$BA,$47,$09
  DEFB $BA,$47,$AC,$4D,$09,$AC,$4D,$A7
  DEFB $4C,$02,$00,$92,$01,$58,$07,$E8
  DEFB $03,$11,$05,$05,$A7,$8F,$09,$9F
  DEFB $7F,$BF,$40,$08,$77,$68,$8F,$9F
  DEFB $09,$97,$9F,$97,$6F,$09,$97,$6F
  DEFB $8F,$68,$09,$9F,$80,$97,$80,$09
  DEFB $77,$68,$40,$40,$09,$9F,$88,$B7
  DEFB $88,$09,$B7,$88,$A7,$90,$09,$A7
  DEFB $90,$9F,$88,$09,$AB,$8E,$A9,$8E
  DEFB $09,$A9,$8E,$A7,$8C,$09,$A7,$8C
  DEFB $AE,$8C,$09,$9F,$87,$B6,$87,$04
  DEFB $AA,$8D,$09,$A5,$8A,$AE,$8A,$09
  DEFB $97,$8D,$A4,$8D,$09,$AF,$8D,$BF
  DEFB $8D,$09,$97,$97,$BF,$97,$08,$9A
  DEFB $95,$A3,$92,$08,$A7,$95,$B1,$92
  DEFB $08,$B5,$95,$BE,$92,$06,$BE,$8C
  DEFB $06,$9E,$8C,$09,$A3,$86,$A8,$86
  DEFB $09,$B0,$86,$B5,$86,$09,$48,$9F
  DEFB $48,$47,$09,$48,$47,$40,$47,$08
  DEFB $42,$87,$47,$72,$03,$45,$82,$44
  DEFB $80,$03,$45,$7D,$43,$79,$04,$43
  DEFB $9E,$04,$43,$66,$06,$43,$46,$09
  DEFB $77,$87,$6F,$8F,$09,$6F,$8F,$6F
  DEFB $87,$09,$6F,$87,$57,$87,$09,$57
  DEFB $87,$57,$6F,$09

; Message at D258
  DEFM "Woo"

; Data block at D25B
  DEFB $7F,$09,$6F,$7F,$6F,$77,$09

; Message at D262
  DEFM "oww"

; Data block at D265
  DEFB $87,$09,$5A,$84,$5A,$74,$09,$5A
  DEFB $84,$5E,$84,$09,$5E,$84,$5E,$7E
  DEFB $09,$5E,$7E,$5A,$7C,$09,$60,$84
  DEFB $60,$77,$09,$60,$7E,$63,$7F,$09
  DEFB $63,$84,$63,$7A,$09,$65,$84,$65
  DEFB $7B,$09,$65,$7B,$68,$7D,$09,$68
  DEFB $7D,$68,$84,$09,$68,$84,$65,$84
  DEFB $09,$6A,$84,$6A,$7E,$09,$6A,$84
  DEFB $6C,$80,$09,$6C,$80,$6C,$84,$09
  DEFB $6E,$84,$6E,$81,$09,$6E,$81,$6F
  DEFB $82,$09,$6E,$84,$6F,$84,$09,$6E
  DEFB $81,$6F,$81,$08,$57,$87,$55,$6F
  DEFB $09,$6E,$8F,$6E,$87,$09,$6E,$7F
  DEFB $6E,$77,$09,$4E,$9F,$4E,$4A,$09
  DEFB $9B,$80,$B3,$40,$09,$98,$8C,$A3
  DEFB $8C,$09,$B0,$8C,$BF,$8C,$11,$02
  DEFB $05,$82,$83,$08,$7F,$9F,$87,$6F
  DEFB $08,$7A,$9F,$8C,$6B,$08,$8C,$8B
  DEFB $8A,$7D,$11,$05,$05,$82,$88,$09
  DEFB $83,$9F,$83,$70,$09,$83,$60,$73
  DEFB $40,$09,$7B,$50,$8B,$50,$02,$93
  DEFB $50,$09

; Message at D30F
  DEFM "kPcH"

; Data block at D313
  DEFB $09

; Message at D314
  DEFM "kPcP"

; Data block at D318
  DEFB $09,$8B,$60,$93,$60,$09,$9B,$60
  DEFB $A3,$60,$04,$82,$71,$10,$02,$04
  DEFB $90,$6B,$10,$01,$04,$A0,$9B,$03
  DEFB $00,$D0,$01,$6A,$07,$E8,$03,$11
  DEFB $05,$05,$B7,$8F,$08,$50,$57,$90
  DEFB $87,$08,$50,$87,$68,$97,$08

; Message at D347
  DEFM "PghW"

; Data block at D34B
  DEFB $08,$78,$57,$90,$67,$11,$06,$05
  DEFB $70,$67,$08,$54,$6B,$7C,$83,$08

; Message at D35B
  DEFM "igwY"

; Data block at D35F
  DEFB $09

; Message at D360
  DEFM "idxd"

; Data block at D364
  DEFB $09

; Message at D365
  DEFM "xaia"

; Data block at D369
  DEFB $09,$69,$5E,$78,$5E,$09

; Message at D36F
  DEFM "x[i["

; Data block at D373
  DEFB $09

; Message at D374
  DEFM "mgmZ"

; Data block at D378
  DEFB $09

; Message at D379
  DEFM "qZqg"

; Data block at D37D
  DEFB $09

; Message at D37E
  DEFM "tgtY"

; Data block at D382
  DEFB $02,$6B,$65,$02,$6F,$65,$02,$73
  DEFB $65,$02,$76,$65,$09,$8C,$87,$8C
  DEFB $8F,$09,$8C,$8F,$84,$8F,$09,$84
  DEFB $8F,$7C,$87,$09,$8C,$89,$80,$89
  DEFB $09,$80,$89,$80,$87,$09,$87,$84
  DEFB $83,$80,$09,$83,$80,$85,$80,$09
  DEFB $85,$80,$85,$7A,$09,$87,$84,$8B
  DEFB $80,$09,$8B,$80,$89,$80,$09,$89
  DEFB $80,$89,$7A,$09,$89,$7A,$85,$7A
  DEFB $08,$80,$77,$84,$71,$09,$86,$76
  DEFB $8A,$76,$02,$8D,$76,$02,$87,$73
  DEFB $02,$89,$73,$09,$8C,$73,$8E,$73
  DEFB $08

; Message at D3E3
  DEFM "RefY"

; Data block at D3E7
  DEFB $08,$7B,$65,$8D,$59,$06,$85,$61
  DEFB $06,$5D,$61,$04,$5C,$79,$03,$5C
  DEFB $8F,$62,$95,$03,$5C,$8F,$60,$93
  DEFB $04,$5C,$8F,$11,$05,$08,$40,$57
  DEFB $B0,$4F,$06,$98,$52,$09,$88,$9F
  DEFB $88,$8F,$09,$70,$9F,$70,$88,$09

; Message at D417
  DEFM "pOp"

; Data block at D41A
  DEFB $40,$09,$88,$40,$88,$4F,$09,$90
  DEFB $5F,$BF,$5F,$09,$BF,$47,$88,$47
  DEFB $09,$70,$47,$40,$47,$09,$40,$5F
  DEFB $4F,$5F,$10,$02,$04,$77,$9D,$04
  DEFB $77,$4D,$04,$67,$4D,$04,$47,$5D
  DEFB $04,$B7,$5D,$08,$97,$9F,$BF,$67
  DEFB $11,$04,$05,$B7,$77,$10,$00,$08
  DEFB $9B,$9F,$BF,$6B,$03,$BA,$99,$B5
  DEFB $94,$03,$B1,$8E,$B6,$93,$09,$B8
  DEFB $95,$B5,$91,$09,$B0,$89,$B0,$82
  DEFB $09,$B0,$82,$B3,$7E,$09,$B3,$7E
  DEFB $BF,$7F,$09,$B2,$83,$B5,$80,$09
  DEFB $B3,$82,$BD,$8B,$09,$BD,$8B,$BF
  DEFB $90,$09,$B4,$81,$BF,$85,$03,$B1
  DEFB $8E,$B3,$90,$03,$BA,$99,$BC,$9B
  DEFB $04,$BA,$99,$09,$B8,$97,$BC,$9B
  DEFB $09,$AF,$8C,$B3,$8F,$09,$BF,$7E
  DEFB $B7,$73,$09,$B7,$73,$BF,$77,$09
  DEFB $B9,$74,$B4,$6B,$09,$AC,$6B,$AB
  DEFB $73,$09,$AB,$73,$AF,$76,$09,$AF
  DEFB $76,$A7,$7B,$09,$A7,$7B,$A4,$75
  DEFB $09,$A4,$75,$A8,$78,$09,$AA,$79
  DEFB $A7,$89,$09,$A7,$89,$A6,$7C,$09
  DEFB $A6,$7C,$A0,$78,$09,$A0,$78,$A4
  DEFB $71,$09,$A4,$71,$A9,$75,$09,$A5
  DEFB $72,$A7,$6B,$10,$02,$09,$A6,$9A
  DEFB $9E,$9A,$09,$9E,$9A,$9E,$91,$02
  DEFB $A2,$95,$03,$A5,$91,$A9,$94,$04
  DEFB $BE,$8C,$04,$B8,$85,$04,$00,$AD
  DEFB $02,$A1,$07,$E8,$03,$11,$05,$05
  DEFB $AF,$97,$09,$BF,$48,$A7,$58,$09
  DEFB $A7,$58,$9F,$68,$09,$97,$68,$A6
  DEFB $6A,$09,$A6,$6A,$A7,$76,$09,$A3
  DEFB $76,$A2,$6E,$09,$A2,$6E,$97,$6C
  DEFB $09,$97,$6C,$96,$68,$09,$98,$7C
  DEFB $9F,$82,$09,$9F,$82,$A6,$84,$09
  DEFB $A6,$84,$AC,$7F,$09,$AC,$7F,$AE
  DEFB $71,$09,$AE,$71,$B1,$61,$09,$98
  DEFB $7C,$9B,$7A,$09,$9B,$7A,$A3,$79
  DEFB $09,$A0,$79,$9F,$6E,$09,$B1,$61
  DEFB $A1,$64,$09,$B1,$61,$B5,$4E,$09
  DEFB $A0,$80,$A4,$81,$09,$A4,$81,$A7
  DEFB $7F,$03,$A4,$7E,$A2,$80,$04,$A4
  DEFB $7E,$09,$9A,$7B,$A6,$7B,$09,$AF
  DEFB $70,$B7,$78,$09,$B7,$78,$BF,$78
  DEFB $09,$97,$40,$87,$58,$09,$87,$58
  DEFB $87,$68,$09,$87,$68,$9F,$78,$09
  DEFB $AC,$7D,$BF,$7D,$09,$B7,$78,$B7
  DEFB $60,$09,$B7,$60,$BF,$60,$09,$B7
  DEFB $60,$B3,$5C,$06,$BB,$64,$06,$B5
  DEFB $75,$09,$87,$58,$87,$40,$04,$BE
  DEFB $5F,$06,$88,$54,$09,$96,$69,$90
  DEFB $67,$09,$90,$67,$95,$64,$09,$95
  DEFB $64,$9D,$66,$09,$9D,$66,$9A,$68
  DEFB $06,$89,$53,$08,$80,$40,$60,$88
  DEFB $09,$60,$70,$80,$70,$08,$98,$58
  DEFB $A0,$48,$09,$98,$50,$A0,$50,$09
  DEFB $98,$57,$9C,$56,$09,$9C,$56,$A0
  DEFB $57,$09,$BF,$97,$40,$97,$09,$40

; Message at D5F2
  DEFM "oEt"

; Data block at D5F5
  DEFB $09

; Message at D5F6
  DEFM "EtDy"

; Data block at D5FA
  DEFB $09

; Message at D5FB
  DEFM "DyG"

; Data block at D5FE
  DEFB $7C,$09,$47,$7C,$4A,$78,$09

; Message at D605
  DEFM "JxIu"

; Data block at D609
  DEFB $09

; Message at D60A
  DEFM "IuKp"

; Data block at D60E
  DEFB $09

; Message at D60F
  DEFM "KpRq"

; Data block at D613
  DEFB $09

; Message at D614
  DEFM "RqWz"

; Data block at D618
  DEFB $09

; Message at D619
  DEFM "WzWk"

; Data block at D61D
  DEFB $09,$57,$6B,$60,$6F,$03,$87,$78
  DEFB $89,$7D,$04,$87,$7A,$09,$86,$74
  DEFB $82,$71,$09,$89,$74,$8D,$71,$09
  DEFB $8D,$71,$8F,$84,$09,$8F,$84,$95
  DEFB $86,$03,$9A,$8D,$8F,$85,$09,$A0
  DEFB $86,$A3,$84,$09,$AA,$82,$AD,$89
  DEFB $09,$AD,$89,$B4,$89,$09,$B4,$89
  DEFB $B9,$84,$09,$B9,$84,$BA,$7E,$03
  DEFB $B1,$8E,$AC,$88,$09,$90,$8F,$8A
  DEFB $90,$09,$8A,$90,$88,$95,$09,$88
  DEFB $95,$89,$8D,$09,$89,$8D,$8F,$8C
  DEFB $09,$A4,$8C,$AB,$8D,$09,$AB,$8D
  DEFB $AD,$95,$09,$AD,$95,$AA,$90,$09
  DEFB $AA,$90,$A4,$90,$09,$41,$90,$89
  DEFB $90,$09,$B5,$90,$BF,$90,$09,$40
  DEFB $50,$60,$40,$04,$47,$7A,$04,$47
  DEFB $7A,$04,$47,$7A,$04,$56,$77,$04
  DEFB $5F,$6D,$04,$5F,$45,$04,$87,$73
  DEFB $04,$86,$67,$04,$95,$85,$04,$9A
  DEFB $93,$04,$8E,$8D,$04,$8C,$8F,$04
  DEFB $A5,$8F,$04,$A7,$8D,$04,$B1,$91
  DEFB $04,$B1,$88,$09,$60,$88,$5C,$6E
  DEFB $09,$60,$88,$70,$8D,$09,$70,$8D
  DEFB $6E,$89,$09,$78,$89,$7A,$8E,$09
  DEFB $7A,$8E,$81,$8B,$09,$81,$8B,$83
  DEFB $72,$04,$81,$83,$04,$7B,$8D,$04
  DEFB $6D,$8B,$04,$5F,$7D,$06,$41,$72
  DEFB $06,$4D,$71,$06,$58,$6D,$06,$76
  DEFB $89,$06,$84,$74,$06,$8C,$73,$06
  DEFB $A9,$83,$06,$BB,$7E,$06,$BB,$9E
  DEFB $06,$43,$46,$11,$06,$05,$5A,$93
  DEFB $11,$04,$05,$78,$78,$03,$70,$7D
  DEFB $7F,$88,$09,$71,$7F,$6D,$86,$09
  DEFB $6D,$86,$6F,$75,$09

; Message at D72A
  DEFM "our"

; Data block at D72D
  DEFB $7C,$03,$78,$7F,$74,$83,$02,$79
  DEFB $7F,$09

; Message at D737
  DEFM "yuvx"

; Data block at D73B
  DEFB $02,$75,$78,$02,$79,$7F,$08

; Message at D742
  DEFM "isyq"

; Data block at D746
  DEFB $04,$7F,$87,$04,$61,$87,$04,$61
  DEFB $7B,$04,$7F,$7A,$11,$03,$05,$77
  DEFB $62,$09

; Message at D758
  DEFM "lohU"

; Data block at D75C
  DEFB $09,$68,$55,$7D,$58,$09,$7D,$58
  DEFB $7E,$5F,$09,$7E,$5F,$78,$60,$09
  DEFB $78,$60,$6F,$5C,$09,$6F,$5C,$72
  DEFB $6A,$08,$77,$60,$7C,$66,$08,$78
  DEFB $57,$7C,$53,$09

; Message at D780
  DEFM "vou"

; Data block at D783
  DEFB $5F,$09,$75,$5E,$75,$58,$09

; Message at D78A
  DEFM "iUf"

; Data block at D78D
  DEFB $40,$09,$77,$40,$74,$57,$09

; Message at D794
  DEFM "tSjS"

; Data block at D798
  DEFB $04,$62,$6E,$04,$7E,$6D,$04,$7F
  DEFB $5C,$04,$76,$64,$04,$76,$55,$10
  DEFB $02,$04,$9A,$4F,$05,$00,$19,$02
  DEFB $7A,$07,$E8,$03,$11,$07,$05,$AF
  DEFB $87,$09,$67,$9F,$67,$57,$09

; Message at D7BF
  DEFM "gWwW"

; Data block at D7C3
  DEFB $09

; Message at D7C4
  DEFM "wWw"

; Data block at D7C7
  DEFB $40,$11,$04,$05,$4F,$58,$09,$67
  DEFB $57,$40,$40,$09

; Message at D7D3
  DEFM "PHRb"

; Data block at D7D7
  DEFB $09,$56,$60,$55,$4C,$09

; Message at D7DD
  DEFM "RbY"

; Data block at D7E0
  DEFB $5E,$09,$59,$5E,$5E,$5E,$09,$5E
  DEFB $5E,$60,$63,$09,$60,$63,$5F,$6D
  DEFB $09,$5F

; Message at D7F2
  DEFM "m[q"

; Data block at D7F5
  DEFB $09

; Message at D7F6
  DEFM "[qTr"

; Data block at D7FA
  DEFB $09

; Message at D7FB
  DEFM "TrPm"

; Data block at D7FF
  DEFB $09

; Message at D800
  DEFM "PmOg"

; Data block at D804
  DEFB $09

; Message at D805
  DEFM "OgQc"

; Data block at D809
  DEFB $03

; Message at D80A
  DEFM "ThYm"

; Data block at D80E
  DEFB $09,$5F

; Message at D810
  DEFM "mbj"

; Data block at D813
  DEFB $09

; Message at D814
  DEFM "bjae"

; Data block at D818
  DEFB $09

; Message at D819
  DEFM "VeSg"

; Data block at D81D
  DEFB $09

; Message at D81E
  DEFM "SgRk"

; Data block at D822
  DEFB $09

; Message at D823
  DEFM "Vrcq"

; Data block at D827
  DEFB $09

; Message at D828
  DEFM "cqee"

; Data block at D82C
  DEFB $09

; Message at D82D
  DEFM "Urbt"

; Data block at D831
  DEFB $09

; Message at D832
  DEFM "btcc"

; Data block at D836
  DEFB $09

; Message at D837
  DEFM "ULdM"

; Data block at D83B
  DEFB $09

; Message at D83C
  DEFM "dMfI"

; Data block at D840
  DEFB $09

; Message at D841
  DEFM "fIQH"

; Data block at D845
  DEFB $09

; Message at D846
  DEFM "ZHTC"

; Data block at D84A
  DEFB $09

; Message at D84B
  DEFM "TCfD"

; Data block at D84F
  DEFB $09

; Message at D850
  DEFM "fDdA"

; Data block at D854
  DEFB $09,$5F

; Message at D856
  DEFM "MdQ"

; Data block at D859
  DEFB $09

; Message at D85A
  DEFM "dQjO"

; Data block at D85E
  DEFB $09

; Message at D85F
  DEFM "jOlQ"

; Data block at D863
  DEFB $09

; Message at D864
  DEFM "QNOC"

; Data block at D868
  DEFB $09

; Message at D869
  DEFM "OCR"

; Data block at D86C
  DEFB $40,$09

; Message at D86E
  DEFM "QUJL"

; Data block at D872
  DEFB $09

; Message at D873
  DEFM "JLK"

; Data block at D876
  DEFB $40,$09,$55,$56,$5C,$52,$09,$5C
  DEFB $52,$5C,$4C,$06,$53,$5F,$06,$63
  DEFB $4C,$06,$58,$49,$09

; Message at D88B
  DEFM "gWrR"

; Data block at D88F
  DEFB $09

; Message at D890
  DEFM "rRnA"

; Data block at D894
  DEFB $04,$76,$56,$09,$67,$77,$40,$7F
  DEFB $06,$66,$79,$11,$05,$08,$77,$57
  DEFB $9F,$40,$09,$80,$4D,$8E,$4D,$09
  DEFB $8E,$4D,$91,$4A,$09,$91,$4A,$96
  DEFB $4A,$09,$96,$4A,$96,$47,$09,$96
  DEFB $47,$91,$47,$09,$91,$47,$8E,$44
  DEFB $09,$8E,$44,$80,$44,$09,$80,$44
  DEFB $7E,$48,$09,$7E,$48,$7F,$4D,$09
  DEFB $8A,$44,$89,$4C,$09,$84,$4C,$85
  DEFB $45,$09,$95,$4A,$95,$48,$09,$80
  DEFB $4C,$81,$46,$04,$7A,$56,$04,$9E
  DEFB $4D,$11,$07,$09,$68,$67,$BF,$67
  DEFB $09,$68,$5D,$BF,$53,$04,$68,$5C
  DEFB $04,$A0,$56,$06,$BE,$66,$11,$00
  DEFB $10,$06,$05,$A6,$76,$08,$BF,$70
  DEFB $A7,$80,$08,$9E,$88,$86,$68,$08
  DEFB $7E,$70,$68,$80,$08,$7E,$88,$A6
  DEFB $98,$08,$81,$95,$A3,$8B,$08,$85
  DEFB $93,$88,$8D,$09,$8A,$92,$92,$92
  DEFB $02,$8C,$8F,$02,$90,$8F,$03,$9A
  DEFB $90,$94,$93,$09,$92,$90,$A2,$90
  DEFB $09,$92,$88,$92,$68,$08,$89,$85
  DEFB $8F,$6D,$08,$9B,$6D,$95,$85,$04
  DEFB $98,$82,$04,$8C,$82,$11,$06,$10
  DEFB $00,$05,$6C,$7A,$05,$B4,$7A,$09
  DEFB $AC,$70,$AE,$76,$09,$AE,$76,$B1
  DEFB $75,$09,$B1,$75,$B2,$70,$09,$B8
  DEFB $70,$B6,$77,$09,$B6,$77,$BA,$77
  DEFB $09,$BA,$77,$BD,$70,$03,$B0,$79
  DEFB $AD,$7D,$03,$B7,$7A,$BB,$7D,$04
  DEFB $B0,$7A,$04,$B7,$7A,$04,$B9,$76
  DEFB $04,$AE,$74,$08,$AA,$7E,$BF,$72
  DEFB $09

; Message at D995
  DEFM "kpl"

; Data block at D998
  DEFB $7B,$09,$6C,$7B,$71,$7C,$09,$71
  DEFB $7C,$76,$7A,$09

; Message at D9A4
  DEFM "vzwp"

; Data block at D9A8
  DEFB $09,$74,$7B,$75,$7E,$09,$75,$7E
  DEFB $7C,$78,$09,$7C

; Message at D9B4
  DEFM "xwx"

; Data block at D9B7
  DEFB $04,$76,$7C,$04,$78,$79,$04,$71
  DEFB $7B,$08,$7B,$7E,$68,$72,$06,$00
  DEFB $78,$01,$57,$07,$E8,$03,$11,$05
  DEFB $05,$AF,$8F,$09,$7F,$9F,$7F,$6F
  DEFB $09,$7F,$6F,$BF,$40,$08,$7F,$70
  DEFB $68,$9F,$09,$80,$9F,$80,$6F,$09
  DEFB $68,$77,$60,$77,$09,$60,$77,$40
  DEFB $40,$09,$68,$80,$40,$80,$06,$42
  DEFB $7F,$09,$40,$7D,$68,$7D,$09,$9F
  DEFB $57,$9F,$9F,$09,$A7,$9F,$A7,$57
  DEFB $09,$A7,$57,$BF,$47,$09,$AF,$9F
  DEFB $AF,$7F,$09,$AF,$7F,$B7,$7D,$09
  DEFB $B7,$7D,$B7,$9E,$09,$B9,$9E,$B9
  DEFB $7D,$09,$B9,$7D,$B8,$7D,$08,$B1
  DEFB $9D,$B4,$93,$08,$B2,$91,$B4,$8E
  DEFB $08,$B2,$8C,$B4,$87,$06,$BE,$4A
  DEFB $06,$AE,$9A,$04,$A6,$9A,$04,$AD
  DEFB $52,$04,$B5,$4D,$04,$BE,$47,$09
  DEFB $BC,$4A,$BC,$9F,$09,$64,$67,$5C
  DEFB $40,$09,$5C

; Message at DA52
  DEFM "HlH"

; Data block at DA55
  DEFB $02,$74,$48,$09,$7C,$68,$84,$58
  DEFB $09,$8C,$48,$94,$40,$09,$7C,$60
  DEFB $74,$60,$11,$04,$05,$6C,$97,$09
  DEFB $69,$97,$6D,$9C,$09,$6D,$9C,$73
  DEFB $9E,$09,$73,$9E,$79,$9D,$09,$79
  DEFB $9D,$7D,$97,$09,$7D,$97,$7E,$8F
  DEFB $09,$69,$96,$6A,$92,$09,$6A,$92
  DEFB $6F,$90,$09,$6F,$90,$77,$92,$09
  DEFB $69,$80,$6B,$84,$09,$6B,$84,$74
  DEFB $87,$09,$70,$86,$71,$90,$09,$7A
  DEFB $90,$7B,$8A,$09,$7B,$8A,$78,$86
  DEFB $09,$78,$86,$7A,$82,$09,$7A,$82
  DEFB $7C,$86,$09,$7C,$86,$7F,$89,$09
  DEFB $7E,$7F,$72,$7E,$09,$73,$7D,$72
  DEFB $71,$09

; Message at DAC7
  DEFM "isms"

; Data block at DACB
  DEFB $09

; Message at DACC
  DEFM "msqq"

; Data block at DAD0
  DEFB $09,$78,$7E,$79,$76,$09,$79,$76
  DEFB $7E,$71,$09

; Message at DADB
  DEFM "rwyw"

; Data block at DADF
  DEFB $06,$74,$7D,$03,$73,$99,$77,$94
  DEFB $09,$71,$98,$76,$98,$02,$72,$97
  DEFB $10,$01,$04,$69,$9E,$04,$7E,$9E
  DEFB $10,$05,$04,$73,$76,$10,$02,$04
  DEFB $69,$92,$11,$02,$10,$01,$05,$51
  DEFB $92,$09,$48,$9F,$48,$8F,$09,$48
  DEFB $8F,$50,$8F,$09,$50,$8F,$50,$97
  DEFB $09,$50,$97,$58,$8F,$09,$58,$8F
  DEFB $60,$8F,$09,$60,$8F,$60,$97,$09
  DEFB $60,$97,$67,$97,$04,$49,$91,$04
  DEFB $59,$90,$10,$07,$08,$48,$85,$54
  DEFB $87,$08,$5A,$87,$67,$85,$1E,$00
  DEFB $AF,$01,$65,$07,$E8,$03,$11,$06
  DEFB $05,$AF,$97,$08,$67,$97,$97,$57
  DEFB $09,$97,$97,$9F,$9F,$09,$67,$97
  DEFB $5F,$9F,$09

; Message at DB5A
  DEFM "gWG"

; Data block at DB5D
  DEFB $40,$09,$97,$58,$B7,$40,$09,$97

; Message at DB65
  DEFM "pgp"

; Data block at DB68
  DEFB $11,$02,$05,$77,$60,$09,$86,$5F
  DEFB $85,$6A,$09,$85,$6A,$8C,$58,$09
  DEFB $8C,$58,$90,$5B,$09,$90,$5B,$8B
  DEFB $6B,$09,$86,$69,$81,$6B,$09,$81
  DEFB $6B,$83,$6F,$09,$83,$6F,$89,$6D
  DEFB $09,$89,$6D,$86,$69,$09,$88,$6B
  DEFB $8B,$6B,$09

; Message at DB9B
  DEFM "zkzo"

; Data block at DB9F
  DEFB $09

; Message at DBA0
  DEFM "zosm"

; Data block at DBA4
  DEFB $09

; Message at DBA5
  DEFM "smwh"

; Data block at DBA9
  DEFB $09

; Message at DBAA
  DEFM "whyj"

; Data block at DBAE
  DEFB $09

; Message at DBAF
  DEFM "skoZ"

; Data block at DBB3
  DEFB $09

; Message at DBB4
  DEFM "oZtX"

; Data block at DBB8
  DEFB $09

; Message at DBB9
  DEFM "tXxh"

; Data block at DBBD
  DEFB $09

; Message at DBBE
  DEFM "xhyX"

; Data block at DBC2
  DEFB $09,$86,$5F,$87,$58,$09,$90,$5B
  DEFB $90,$58,$09

; Message at DBCD
  DEFM "n[nX"

; Data block at DBD1
  DEFB $04,$68,$6F,$04,$77,$61,$04,$88
  DEFB $61,$04,$87,$62,$04,$96,$6F,$09
  DEFB $7E,$6E,$80,$5E,$09,$80,$5E,$7F
  DEFB $58,$11,$05,$05,$7F,$78,$03,$7E
  DEFB $78,$76,$81,$09,$7A,$72,$7B,$76
  DEFB $08,$7B,$77,$82,$74,$09,$82,$74
  DEFB $82,$74,$09,$82,$74,$81,$71,$02
  DEFB $7E,$72,$02,$7F,$72,$06,$7E,$7F
  DEFB $06,$7A,$75,$06,$83,$75,$04,$68
  DEFB $96,$04,$90,$7E,$11,$06,$09,$7C

; Message at DC21
  DEFM "WsO"

; Data block at DC24
  DEFB $09

; Message at DC25
  DEFM "sOtJ"

; Data block at DC29
  DEFB $09,$74,$4A,$7D,$46,$09,$7D,$46
  DEFB $7C,$41,$09,$7C,$41,$80,$41,$09
  DEFB $80,$41,$82,$49,$09,$82

; Message at DC3F
  DEFM "IzO"

; Data block at DC42
  DEFB $09,$7A,$4F,$81,$51,$09,$82,$51
  DEFB $8E,$44,$09,$8E,$44,$92,$41,$09
  DEFB $99,$41,$9A,$4A,$09,$9A,$4A,$97
  DEFB $4C,$09,$97,$4C,$94,$48,$09,$94
  DEFB $48,$92,$47,$09,$92,$47,$89,$55
  DEFB $09,$89,$55,$87,$57,$09,$91,$57
  DEFB $8D,$51,$09

; Message at DC75
  DEFM "oWoQ"

; Data block at DC79
  DEFB $09

; Message at DC7A
  DEFM "oQsP"

; Data block at DC7E
  DEFB $04,$97,$4B,$04,$8D,$47,$04,$7D
  DEFB $42,$04,$80,$4A,$04,$7A,$4D,$08
  DEFB $6F,$57,$8F,$4F,$04,$89,$4E,$06
  DEFB $98,$56,$06,$68,$56,$06,$89,$41
  DEFB $06,$83,$4E,$06,$93,$49,$06,$A7
  DEFB $4B,$09,$A7,$9F,$A7,$57,$09,$A7
  DEFB $57,$BF,$47,$09,$AF,$9F,$AF,$5F
  DEFB $09,$AF,$5F,$BF,$57,$09,$57,$9F
  DEFB $57,$57,$09,$57,$57,$40,$47,$09
  DEFB $50,$9F,$50,$5F,$09,$50,$5F,$40
  DEFB $57,$11,$02,$05,$83,$54,$09

; Message at DCD5
  DEFM "tVvS"

; Data block at DCD9
  DEFB $04,$77,$54,$09,$8A,$54,$8C,$56
  DEFB $04,$8A,$55,$04,$82,$50,$08,$7C
  DEFB $57,$88,$55,$1D,$00,$3F,$04,$FF
  DEFB $07,$E8,$03,$11,$07,$05,$AF,$97
  DEFB $03,$77,$67,$7E,$72,$03

; Message at DCFF
  DEFM "uhxk"

; Data block at DD03
  DEFB $03,$7A,$68,$7D,$65,$09

; Message at DD09
  DEFM "wfvd"

; Data block at DD0D
  DEFB $09

; Message at DD0E
  DEFM "vdyd"

; Data block at DD12
  DEFB $09

; Message at DD13
  DEFM "ydye"

; Data block at DD17
  DEFB $09

; Message at DD18
  DEFM "ubyb"

; Data block at DD1C
  DEFB $09

; Message at DD1D
  DEFM "qhnl"

; Data block at DD21
  DEFB $09

; Message at DD22
  DEFM "nlpc"

; Data block at DD26
  DEFB $09,$7D,$69,$7F,$6E,$09,$7F,$6E
  DEFB $7E,$67,$09

; Message at DD31
  DEFM "xQqR"

; Data block at DD35
  DEFB $09,$78,$53,$7C,$4D,$09,$7C,$4D
  DEFB $83,$4C,$09,$83,$4C,$85,$51,$09
  DEFB $85,$51,$80,$5B,$09,$80,$5B,$7B
  DEFB $5E,$09

; Message at DD4F
  DEFM "uSxV"

; Data block at DD53
  DEFB $09,$78,$56,$7B,$55,$09,$7C,$55
  DEFB $7F,$52,$09

; Message at DD5E
  DEFM "zOnM"

; Data block at DD62
  DEFB $09

; Message at DD63
  DEFM "nMjR"

; Data block at DD67
  DEFB $09

; Message at DD68
  DEFM "jRn"

; Data block at DD6B
  DEFB $5C,$09,$6E,$5C,$73,$5E,$09

; Message at DD72
  DEFM "rSsX"

; Data block at DD76
  DEFB $09

; Message at DD77
  DEFM "nMoA"

; Data block at DD7B
  DEFB $09,$7D,$41,$7E,$4C,$09,$7D

; Message at DD82
  DEFM "FqE"

; Data block at DD85
  DEFB $09,$77,$5C,$77,$55,$09

; Message at DD8B
  DEFM "wMwE"

; Data block at DD8F
  DEFB $05,$A9,$8F,$09,$8F,$9F,$8F,$40
  DEFB $11,$05,$05,$9F,$48,$03,$A1,$7D
  DEFB $99,$9D,$03,$A1,$65,$9D,$6B,$09
  DEFB $9E,$66,$A3,$66,$09,$A4,$63,$9F
  DEFB $63,$06,$A1,$9B,$04,$9F,$65,$09
  DEFB $A0,$69,$A0,$60,$09,$A2,$60,$A2
  DEFB $69,$09,$9C,$6D,$9E,$6A,$09,$A6
  DEFB $6D,$A5,$6B,$09,$A1,$9B,$A1,$73
  DEFB $09,$A4,$52,$9F,$52,$09,$9F,$52
  DEFB $A3,$57,$09,$A3,$57,$AC,$53,$09
  DEFB $A4,$53,$AB,$4D,$09,$AB,$4D,$B1
  DEFB $4C,$09,$B1,$4C,$B3,$51,$09,$B3
  DEFB $51,$AD,$64,$09,$AD,$64,$A9,$67
  DEFB $09,$A9,$67,$A6,$65,$09,$9F,$52
  DEFB $99,$52,$09,$A7,$4F,$98,$4D,$09
  DEFB $98,$4D,$93,$51,$09,$93,$51,$92
  DEFB $56,$09,$92,$56,$96,$64,$09,$96
  DEFB $64,$99,$66,$09,$99,$66,$9C,$64
  DEFB $09,$9A,$52,$9B,$5C,$09,$A9,$5C
  DEFB $AB,$58,$09,$A9,$55,$AC,$57,$06
  DEFB $AA,$64,$06,$98,$64,$06,$9C,$5C
  DEFB $06,$AF,$5B,$06,$A8,$56,$06,$A3
  DEFB $56,$09,$AC,$57,$B0,$53,$09,$B0
  DEFB $53,$AD,$52,$09,$9A,$4C,$9B,$41
  DEFB $09,$A9,$41,$AA,$4D,$06,$A8,$4E
  DEFB $09,$A8,$67,$AE,$79,$09,$AE,$79
  DEFB $B2,$7A,$09,$B2,$7A,$B2,$73,$09
  DEFB $B2,$73,$AF,$71,$09,$AF,$71,$AC
  DEFB $66,$09,$9B,$69,$95,$77,$09,$95
  DEFB $77,$92,$7A,$09,$92,$7A,$91,$73
  DEFB $09,$91,$73,$94,$71,$09,$94,$71
  DEFB $99,$66,$09,$AE,$63,$B1,$6C,$09
  DEFB $B1,$6C,$B3,$6D,$09,$B3,$6D,$B0
  DEFB $5D,$09,$96,$64,$93,$6D,$09,$93
  DEFB $6D,$91,$6E,$09,$91,$6E,$94,$60
  DEFB $09,$AA,$46,$AE,$41,$09,$B5,$41
  DEFB $BC,$56,$09,$BC,$56,$BA,$6C,$09
  DEFB $BA,$6C,$B7,$73,$09,$B7,$73,$BC
  DEFB $70,$09,$BC,$70,$BF,$64,$09,$BF
  DEFB $4D,$BC,$40,$06,$BB,$41,$06,$BE
  DEFB $52,$06,$BB,$67,$06,$AA,$45,$06
  DEFB $AB,$67,$06,$AD,$6F,$06,$B1,$75
  DEFB $06,$AF,$61,$06,$B0,$66,$06,$9A
  DEFB $66,$06,$98,$6B,$06,$96,$70,$06
  DEFB $93,$74,$06,$94,$63,$08,$68,$40
  DEFB $40,$68,$04,$90,$9D,$04,$BD,$9B
  DEFB $04,$99,$71,$04,$97,$66,$04,$95
  DEFB $6A,$04,$94,$6E,$04,$A8,$6C,$04
  DEFB $A9,$70,$04,$AD,$65,$04,$AE,$69
  DEFB $04,$AF,$6D,$04,$B4,$70,$04,$B9
  DEFB $6D,$11,$04,$05,$50,$58,$03,$5F

; Message at DF27
  DEFM "QdV"

; Data block at DF2A
  DEFB $03

; Message at DF2B
  DEFM "OQTV"

; Data block at DF2F
  DEFB $09

; Message at DF30
  DEFM "QVUY"

; Data block at DF34
  DEFB $09

; Message at DF35
  DEFM "VYZY"

; Data block at DF39
  DEFB $09,$5A,$59,$5E,$56,$09

; Message at DF3F
  DEFM "OMQG"

; Data block at DF43
  DEFB $09

; Message at DF44
  DEFM "QGVC"

; Data block at DF48
  DEFB $09,$56,$43,$5C,$46,$09,$5C,$46
  DEFB $5F,$4C,$09

; Message at DF53
  DEFM "WSWC"

; Data block at DF57
  DEFB $09

; Message at DF58
  DEFM "UXPh"

; Data block at DF5C
  DEFB $09

; Message at DF5D
  DEFM "PhRX"

; Data block at DF61
  DEFB $09,$58,$58,$5C,$68,$09,$5C

; Message at DF68
  DEFM "h[X"

; Data block at DF6B
  DEFB $09

; Message at DF6C
  DEFM "SDR"

; Data block at DF6F
  DEFB $40,$09,$56,$40,$58,$44,$08,$58
  DEFB $9F,$78,$7F,$03

; Message at DF7B
  DEFM "OQST"

; Data block at DF7F
  DEFB $03,$5F

; Message at DF81
  DEFM "QcT"

; Data block at DF84
  DEFB $04,$5F,$51,$04,$4F,$51,$04,$42
  DEFB $66,$04,$56,$66,$04,$67,$66,$04
  DEFB $67,$66,$11,$02,$05,$67,$8F,$09
  DEFB $60,$9F,$64,$97,$09,$64,$97,$69
  DEFB $98,$09,$69,$98,$6F,$97,$09,$6F
  DEFB $97,$73,$9F,$09,$77,$95,$72,$8B
  DEFB $09,$72,$8B,$70,$90,$09,$70,$90
  DEFB $71,$85,$09,$71,$85,$6C,$84,$09
  DEFB $6C,$84,$66,$84,$09,$65,$84,$62
  DEFB $86,$09,$62,$86,$64,$91,$09,$64
  DEFB $91,$61,$8C,$09,$61,$8C,$5B,$9E
  DEFB $08,$6F,$94,$64,$90,$09,$68,$90
  DEFB $66,$84,$09,$6D,$84,$6B,$90,$09
  DEFB $6B,$94,$6B,$97,$09,$68,$97,$68
  DEFB $94,$08,$62,$80,$71,$82,$09,$6F
  DEFB $84,$6F,$82,$09,$64,$82,$64,$84
  DEFB $04,$69,$99,$04,$5A,$9D,$04,$71
  DEFB $8D,$09,$70,$90,$73,$8C,$04,$77
  DEFB $93,$04,$77,$93,$04,$77,$93,$04
  DEFB $77,$93,$04,$77,$93,$04,$77,$93
  DEFB $04,$77,$93,$04,$77,$93,$04,$71
  DEFB $8C,$11,$07,$05,$7F,$93,$05,$47
  DEFB $93,$05,$81,$87,$05,$49,$9C,$09
  DEFB $73,$7E,$7B,$7C,$09,$82,$7B,$87
  DEFB $79,$09,$63,$7F,$57,$7A,$08,$57
  DEFB $81,$50,$6B,$09

; Message at E050
  DEFM "OwIu"

; Data block at E054
  DEFB $09

; Message at E055
  DEFM "IuFm"

; Data block at E059
  DEFB $09

; Message at E05A
  DEFM "FmGi"

; Data block at E05E
  DEFB $09

; Message at E05F
  DEFM "SiSk"

; Data block at E063
  DEFB $08,$7C,$80,$82,$6C,$09,$8E,$9E
  DEFB $86,$5E,$09,$86,$5E,$81,$5A,$09
  DEFB $6E,$5C,$67,$6E,$09,$67,$6E,$40
  DEFB $68,$09,$57,$9F,$40,$77,$06,$42
  DEFB $9E,$04,$57,$9D,$04,$58,$7E,$04
  DEFB $48,$81,$04,$41,$73,$04,$52,$6A
  DEFB $04,$66,$6D,$09,$60,$7D,$69,$78
  DEFB $09

; Message at E09C
  DEFM "ix]"

; Data block at E09F
  DEFB $7B,$06,$60,$7C,$09,$77,$7C,$6D
  DEFB $78,$09

; Message at E0A9
  DEFM "mxzz"

; Data block at E0AD
  DEFB $06,$78,$7B,$09

; Message at E0B1
  DEFM "lplb"

; Data block at E0B5
  DEFB $04,$69,$66,$09,$7E,$66,$80,$5C
  DEFB $04,$7E,$63,$04,$8E,$93,$04,$7A
  DEFB $9E,$02,$88,$78,$04,$88,$79,$06
  DEFB $53,$79,$06,$7F,$79,$09,$69,$7F
  DEFB $6A,$79,$09,$6D,$7E,$6C,$79,$09
  DEFB $58,$77,$5E,$75,$09,$5E

; Message at E0E3
  DEFM "uXt"

; Data block at E0E6
  DEFB $09

; Message at E0E7
  DEFM "etlq"

; Data block at E0EB
  DEFB $09

; Message at E0EC
  DEFM "lqqt"

; Data block at E0F0
  DEFB $09,$7B

; Message at E0F2
  DEFM "tus"

; Data block at E0F5
  DEFB $09,$75,$73,$7B,$78,$04,$76,$7A
  DEFB $09

; Message at E0FE
  DEFM "jwkr"

; Data block at E102
  DEFB $09

; Message at E103
  DEFM "krmw"

; Data block at E107
  DEFB $04,$6B,$7D,$04,$62,$7B,$04,$59
  DEFB $76,$04,$7B,$76,$06,$82,$63,$09
  DEFB $7E,$63,$87,$64,$09,$85,$6D,$84
  DEFB $75,$06,$6F,$5E,$06,$4F,$6E,$09

; Message at E127
  DEFM "OnGl"

; Data block at E12B
  DEFB $23,$01,$16,$00,$06,$07,$1D,$00
  DEFB $11,$05,$04,$B3,$4E,$04,$AC,$4C
  DEFB $06,$A8,$53,$04,$BE,$42,$07,$00
  DEFB $62,$02,$8B,$07,$E8,$03,$11,$05
  DEFB $05,$AF,$97,$09,$BF,$5F,$40,$5F
  DEFB $09,$8F,$5F,$8F,$4F,$09,$8F

; Message at E15A
  DEFM "OwG"

; Data block at E15D
  DEFB $09,$8F,$4F,$BF,$4F,$09,$5F,$4F
  DEFB $40,$4F,$08,$6F,$5F,$8D,$5C,$08
  DEFB $6C,$5C,$8A,$59,$08,$69,$59,$87
  DEFB $56,$08,$66,$56,$84,$53,$08,$63
  DEFB $53,$81,$50,$08,$60,$50,$7E,$4D
  DEFB $08,$5D,$4D,$7B,$4A,$08

; Message at E18B
  DEFM "ZJxG"

; Data block at E18F
  DEFB $08,$97,$5F,$77,$97,$08,$7F,$5F
  DEFB $97,$93,$08,$87,$5F,$97,$87,$08
  DEFB $6F,$5F,$67,$8F,$08,$9F,$8F,$A7
  DEFB $5F,$09,$9F,$8F,$97,$97,$09,$97
  DEFB $97,$9F,$99,$09,$9F,$99,$A7,$99
  DEFB $09,$A7,$99,$AF,$97,$09,$AF,$97
  DEFB $A7,$8F,$09,$6F,$8F,$77,$97,$09
  DEFB $77,$97,$6F,$99,$09,$6F,$99,$67
  DEFB $99,$09,$67,$99,$5F,$97,$09,$5F
  DEFB $97,$67,$8F,$03,$9D,$56,$A0,$5A
  DEFB $09,$9B,$53,$97,$51,$09,$97,$51
  DEFB $95,$47,$09,$95,$47,$9D,$46,$09
  DEFB $9D,$46,$9C,$52,$09,$9C,$4F,$A0
  DEFB $4C,$09,$A0,$4C,$A3,$4C,$09,$A3
  DEFB $4C,$A3,$43,$09,$A1,$4C,$A0,$49
  DEFB $09,$A0,$49,$9D,$4B,$09,$9A,$46
  DEFB $99,$43,$09,$99,$43,$9C,$43,$09
  DEFB $98,$47,$96,$44,$09,$96,$44,$9A
  DEFB $43,$04,$9D,$57,$04,$9B,$51,$04
  DEFB $9B,$4E,$09,$9F,$53,$A0,$51,$09
  DEFB $B7,$5F,$B7,$9F,$09,$57,$5F,$57
  DEFB $9F,$09,$57,$8F,$47,$8F,$09,$47
  DEFB $5F,$47,$97,$09,$47,$97,$4F,$8F
  DEFB $09,$4F,$8F,$57,$97,$09,$47,$87
  DEFB $4F,$87,$09,$4F,$87,$4F,$5F,$06
  DEFB $48,$6F,$06,$78,$6F,$09,$77,$97
  DEFB $7F,$93,$04,$80,$92,$06,$8E,$5E
  DEFB $06,$7F,$4F,$08,$BF,$5F,$BB,$8F
  DEFB $09,$BB,$8F,$BB,$97,$09,$BB,$97
  DEFB $BF,$93,$06,$B8,$9E,$06,$BE,$97
  DEFB $09,$A9,$98,$A7,$90,$04,$AA,$97
  DEFB $04,$A8,$92,$09,$9E,$99,$9F,$8F
  DEFB $09,$70,$99,$6E,$90,$04,$71,$98
  DEFB $04,$6F,$91,$09,$67,$99,$68,$8F
  DEFB $09

; Message at E2A0
  DEFM "lSjN"

; Data block at E2A4
  DEFB $09

; Message at E2A5
  DEFM "jNqN"

; Data block at E2A9
  DEFB $09

; Message at E2AA
  DEFM "qNrT"

; Data block at E2AE
  DEFB $09

; Message at E2AF
  DEFM "rTpV"

; Data block at E2B3
  DEFB $09

; Message at E2B4
  DEFM "pVqY"

; Data block at E2B8
  DEFB $09

; Message at E2B9
  DEFM "qYt["

; Data block at E2BD
  DEFB $09

; Message at E2BE
  DEFM "t[n"

; Data block at E2C1
  DEFB $5E,$09,$6E,$5E,$6A,$54,$09

; Message at E2C8
  DEFM "qVqV"

; Data block at E2CC
  DEFB $04,$6F,$5D,$04,$6F,$5A,$04,$6F
  DEFB $57,$04,$6F,$54,$04,$6F,$51,$04
  DEFB $6F,$4F,$09

; Message at E2DF
  DEFM "rVwX"

; Data block at E2E3
  DEFB $09

; Message at E2E4
  DEFM "wXwU"

; Data block at E2E8
  DEFB $09

; Message at E2E9
  DEFM "wUsT"

; Data block at E2ED
  DEFB $04,$74,$55,$04,$76,$57,$09

; Message at E2F4
  DEFM "xWyX"

; Data block at E2F8
  DEFB $09

; Message at E2F9
  DEFM "kLlK"

; Data block at E2FD
  DEFB $09

; Message at E2FE
  DEFM "oMqJ"

; Data block at E302
  DEFB $03

; Message at E303
  DEFM "IZOW"

; Data block at E307
  DEFB $04,$4C,$5A,$08

; Message at E30B
  DEFM "HWLK"

; Data block at E30F
  DEFB $04,$4A,$52,$04,$4A,$4D,$09

; Message at E316
  DEFM "HKFF"

; Data block at E31A
  DEFB $09

; Message at E31B
  DEFM "FFDF"

; Data block at E31F
  DEFB $09

; Message at E320
  DEFM "GGIG"

; Data block at E324
  DEFB $09

; Message at E325
  DEFM "IGJJ"

; Data block at E329
  DEFB $04,$49,$4A,$04,$48,$48,$09

; Message at E330
  DEFM "JILG"

; Data block at E334
  DEFB $09

; Message at E335
  DEFM "LGNH"

; Data block at E339
  DEFB $09

; Message at E33A
  DEFM "NHMJ"

; Data block at E33E
  DEFB $04,$4C,$49,$09

; Message at E342
  DEFM "MGOF"

; Data block at E346
  DEFB $09

; Message at E347
  DEFM "OFME"

; Data block at E34B
  DEFB $09

; Message at E34C
  DEFM "LTQR"

; Data block at E350
  DEFB $09

; Message at E351
  DEFM "QRNN"

; Data block at E355
  DEFB $09

; Message at E356
  DEFM "HSEO"

; Data block at E35A
  DEFB $09

; Message at E35B
  DEFM "EODR"

; Data block at E35F
  DEFB $09

; Message at E360
  DEFM "OYRX"

; Data block at E364
  DEFB $09

; Message at E365
  DEFM "RXRR"

; Data block at E369
  DEFB $09

; Message at E36A
  DEFM "RRTR"

; Data block at E36E
  DEFB $11,$06,$05,$68,$6F,$05,$90,$6F
  DEFB $05,$A0,$6F,$09,$6B,$8F,$6B,$60
  DEFB $06,$6C,$60,$09,$A3,$60,$A3,$8F
  DEFB $06,$A4,$8E,$06,$8C,$86,$08,$8A
  DEFB $84,$97,$7B,$08,$8A,$78,$94,$60
  DEFB $11,$05,$10,$01,$04,$42,$9E,$04
  DEFB $42,$9E,$04,$4F,$97,$08,$00,$83
  DEFB $02,$92,$07,$E8,$03,$11,$07,$05
  DEFB $AF,$97,$09,$60,$4F,$60,$97,$09
  DEFB $60,$97,$68,$9F,$09,$98,$9F,$A0
  DEFB $97,$09,$A0,$97,$A0,$4F,$09,$A0
  DEFB $4F,$60,$4F,$09,$60,$4F,$40,$47
  DEFB $09,$A0,$4F,$BF,$47,$09,$52,$4B
  DEFB $AA,$4B,$04,$82,$4D,$06,$82,$45
  DEFB $09,$60,$4A,$A0,$48,$09,$A0,$48
  DEFB $60,$46,$09,$A0,$96,$BF,$9E,$09
  DEFB $5F,$96,$40,$9E,$06,$42,$9C,$04
  DEFB $5F,$97,$04,$A1,$97,$06,$BE,$9C
  DEFB $06,$BE,$9C,$06,$BE,$9C,$06,$BE
  DEFB $9C,$06,$BE,$9C,$06,$BE,$9C,$06
  DEFB $BE,$9C,$06,$BE,$9C,$06,$BE,$9C
  DEFB $06,$BE,$9C,$09,$BF,$97,$A7,$92
  DEFB $09,$A7,$92,$A7,$52,$09,$A7,$52
  DEFB $BF,$4D,$09,$40,$97,$58,$92,$09
  DEFB $58,$92,$58,$52,$09,$58,$52,$40
  DEFB $4D,$03,$B0,$6D,$AC,$8D,$03

; Message at E43D
  DEFM "PmL"

; Data block at E440
  DEFB $8D,$11,$06,$05,$70,$96,$03,$98
  DEFB $64,$94,$60,$03,$86,$67,$83,$5D
  DEFB $03,$76,$72,$7B,$77,$03

; Message at E456
  DEFM "hbdf"

; Data block at E45A
  DEFB $03

; Message at E45B
  DEFM "hiln"

; Data block at E45F
  DEFB $09

; Message at E460
  DEFM "hmhq"

; Data block at E464
  DEFB $09

; Message at E465
  DEFM "tnq"

; Data block at E468
  DEFB $5E,$09,$78,$6D,$7B,$5E,$09,$86
  DEFB $70,$83,$75,$09,$87,$70,$89,$75
  DEFB $09,$95,$61,$94,$5F,$09,$9A,$61
  DEFB $9D,$5F,$08,$94,$5E,$9D,$50,$08
  DEFB $84,$5E,$88,$50,$08,$7B,$5E,$70
  DEFB $52,$03

; Message at E492
  DEFM "hYd"

; Data block at E495
  DEFB $5E,$03

; Message at E497
  DEFM "hReU"

; Data block at E49B
  DEFB $04,$68,$6A,$04,$68,$62,$09,$67
  DEFB $5E,$69,$5E,$04,$68,$5A,$04,$68
  DEFB $52,$04,$75,$56,$04,$76,$6C,$04
  DEFB $76,$72,$04,$86,$6E,$04,$86,$56
  DEFB $04,$99,$56,$04,$99,$60,$04,$99
  DEFB $64,$09,$94,$60,$91,$59,$09,$91
  DEFB $59,$94,$55,$09,$9E,$5D,$9E,$57
  DEFB $09,$89,$5D,$8B,$57,$09,$8B,$57
  DEFB $89,$55,$09,$84,$5E,$81,$58,$09
  DEFB $81,$58,$84,$55,$09,$7A,$64,$7F
  DEFB $61,$09,$7F,$61,$7B,$57,$09

; Message at E4F2
  DEFM "yRyP"

; Data block at E4F6
  DEFB $09

; Message at E4F7
  DEFM "sPsR"

; Data block at E4FB
  DEFB $09

; Message at E4FC
  DEFM "rcn"

; Data block at E4FF
  DEFB $60,$09,$6E,$60,$70,$59,$09

; Message at E506
  DEFM "siog"

; Data block at E50A
  DEFB $09

; Message at E50B
  DEFM "ogqa"

; Data block at E50F
  DEFB $09,$79,$68,$7D,$66,$09,$7D,$66
  DEFB $7C,$61,$03,$7F,$8F,$6F,$9F,$03
  DEFB $7F,$8F,$82,$92,$03,$85,$94,$80
  DEFB $99,$03,$79,$94,$7E,$99,$09,$7F
  DEFB $94,$7C,$99,$09,$7C,$99,$75,$99
  DEFB $09,$75,$99,$73,$94,$09,$7F,$95
  DEFB $82,$99,$09,$82,$99,$89,$99,$09
  DEFB $89,$99,$8B,$94,$02,$85,$93,$02
  DEFB $7A,$93,$09,$73,$8B,$8B,$8B,$09
  DEFB $8B,$8B,$86,$85,$09,$86,$85,$7F
  DEFB $83,$09,$7F,$83,$77,$85,$09,$77
  DEFB $85,$73,$8B,$09,$78,$85,$7B,$88
  DEFB $09,$7B,$88,$7C,$85,$09,$82,$84
  DEFB $83,$88,$09,$83,$88,$86,$85,$04
  DEFB $7F,$8A,$04,$78,$86,$04,$86,$86
  DEFB $09,$82,$8F,$8B,$8C,$09,$7C,$8F
  DEFB $73,$8C,$09,$7A,$8B,$7B,$8E,$09
  DEFB $85,$8E,$85,$8C,$08,$83,$80,$7A
  DEFB $78,$09,$82,$80,$8A,$78,$09,$8A
  DEFB $78,$8A,$80,$09,$8A,$80,$92,$80
  DEFB $09,$92,$80,$92,$88,$09,$92,$88
  DEFB $9A,$90,$09,$9A,$90,$92,$90,$09
  DEFB $92,$90,$9A,$98,$09,$9A,$98,$92
  DEFB $98,$09,$92,$98,$92,$9F,$09,$7A
  DEFB $7F,$72,$77,$09

; Message at E5D3
  DEFM "rwr"

; Data block at E5D6
  DEFB $7F,$09,$72,$7F,$6A,$7F,$09,$6A
  DEFB $7F,$6A,$87,$09,$6A,$87,$62,$8F
  DEFB $09,$62,$8F,$6A,$8F,$09,$6A,$8F
  DEFB $62,$97,$09,$62,$97,$6A,$97,$09
  DEFB $6A,$97,$6A,$9F,$09,$83,$78,$9B
  DEFB $70,$09,$9B,$70,$9F,$68,$09

; Message at E605
  DEFM "zxbp"

; Data block at E609
  DEFB $09,$62,$70,$60,$70,$06,$69,$9E
  DEFB $06,$61,$96,$06,$93,$9E,$06,$9F
  DEFB $97,$06,$79,$7D,$06,$75,$77,$06
  DEFB $84,$7D,$06,$88,$78,$1C,$00,$42
  DEFB $00,$11,$07,$E8,$03,$11,$07,$05
  DEFB $B7,$97,$08,$77,$87,$87,$67,$09
  DEFB $A7

; Message at E63A
  DEFM "WNO"

; Data block at E63D
  DEFB $09

; Message at E63E
  DEFM "NOF"

; Data block at E641
  DEFB $9F,$09,$A6,$57,$AE,$9F,$09,$A6
  DEFB $57,$BE,$47,$09,$4E,$4F,$40,$47
  DEFB $06,$41,$49,$06,$A6,$56,$06,$BE
  DEFB $9E,$04,$4F,$50,$04,$A7,$68,$11
  DEFB $06,$06,$7F,$70,$06,$7F,$70,$17
  DEFB $00,$72,$01,$58,$07,$E8,$03,$11
  DEFB $07,$05,$AF,$8F,$09,$4F,$9F,$4F
  DEFB $40,$08,$5F,$50,$6F,$98,$08,$7F
  DEFB $90,$87,$60,$09,$6F,$98,$75,$95
  DEFB $09,$75,$95,$75,$55,$09

; Message at E68F
  DEFM "uUoP"

; Data block at E693
  DEFB $09,$87,$90,$8A,$8E,$09,$8A,$8E
  DEFB $8A,$62,$09,$8A,$62,$88,$60,$09
  DEFB $90,$88,$8B,$8B,$09,$7F,$8F,$76
  DEFB $92,$09,$5F,$98,$51,$9E,$09,$8F
  DEFB $68,$8A,$67,$09,$7F

; Message at E6B8
  DEFM "avZ"

; Data block at E6BB
  DEFB $09,$5F

; Message at E6BD
  DEFM "QOE"

; Data block at E6C0
  DEFB $08,$B7,$8F,$BF,$5F,$09,$B7,$8F
  DEFB $B5,$8C,$09,$B5,$8C,$B5,$62,$09
  DEFB $B5,$62,$B7,$60,$08,$90,$88,$B5
  DEFB $68,$09,$95,$88,$95,$78,$09,$95
  DEFB $78,$9D,$70,$09,$9D,$70,$B5,$70
  DEFB $09,$B5,$78,$B5,$78,$09,$B5,$75
  DEFB $A0,$75,$09,$A0,$75,$9A,$7B,$09
  DEFB $9A,$7B,$9A,$88,$09,$9A,$86,$95
  DEFB $86,$09,$95,$80,$9A,$80,$09,$9A
  DEFB $7A,$95,$78,$09,$9D,$78,$99,$74
  DEFB $09,$A0,$75,$9D,$71,$09,$A3,$70
  DEFB $A3,$75,$09,$A8,$75,$A8,$70,$09
  DEFB $AC,$70,$AC,$75,$09,$B0,$75,$B0
  DEFB $70,$09,$A0,$88,$A0,$78,$09,$A0
  DEFB $78,$B4,$78,$09,$4F,$70,$5F,$78
  DEFB $09,$75,$78,$7D,$80,$09,$8A,$78
  DEFB $8F,$7C,$09,$A7,$9F,$BF,$97,$09
  DEFB $77,$9F,$92,$89,$06,$4A,$89,$04
  DEFB $51,$72,$06,$5E,$76,$06,$50,$48
  DEFB $09,$5F,$78,$6F,$88,$04,$60,$7B
  DEFB $04,$77,$9E,$04,$86,$92,$06,$71
  DEFB $96,$06,$6D,$85,$04,$76,$91,$02
  DEFB $7E,$90,$06,$7E,$7F,$06,$76,$5B
  DEFB $09,$7F,$81,$87,$85,$04,$80,$83
  DEFB $06,$86,$83,$06,$88,$8D,$04,$88
  DEFB $90,$04,$8B,$8E,$04,$8E,$8A,$04
  DEFB $90,$89,$06,$A8,$9E,$04,$BE,$9E
  DEFB $06,$BE,$7A,$04,$B6,$7A,$04,$8B
  DEFB $89,$06,$8F,$7A,$09,$97,$87,$97
  DEFB $78,$09,$97,$78,$9E,$72,$09,$9E
  DEFB $72,$B6,$72,$09,$BB,$5E,$BF,$44
  DEFB $04,$BE,$4F,$06,$93,$87,$06,$9D
  DEFB $86,$06,$A2,$86,$06,$9E,$78,$06
  DEFB $A0,$78,$06,$A0,$77,$03,$A0,$57
  DEFB $8C,$5B,$06,$9F,$59,$03,$9F,$57
  DEFB $AC,$59,$01,$00,$25,$02,$7E,$07
  DEFB $E8,$03,$11,$05,$05,$A7,$8F,$09
  DEFB $80,$9F,$80,$4F,$08,$90,$47,$A0
  DEFB $67,$11,$03,$05,$98,$5F,$09,$9F
  DEFB $67,$96,$65,$09,$96,$65,$93,$60
  DEFB $09,$93,$60,$92,$4C,$09,$92,$4C
  DEFB $90,$48,$09,$90,$48,$9F,$48,$09
  DEFB $9F,$48,$9D,$51,$09,$9D,$51,$9F
  DEFB $5D,$09,$9B,$5D,$9A,$4F,$09,$9A
  DEFB $4F,$95,$50,$09,$95,$50,$97,$5F
  DEFB $04,$91,$66,$04,$9F,$58,$09,$9C
  DEFB $4F,$9B,$4A,$09,$93,$4E,$94,$4A
  DEFB $09,$97,$5F,$99,$62,$11,$05,$09
  DEFB $A0,$65,$A4,$68,$09,$A4,$68,$A7
  DEFB $66,$09,$A7,$66,$AA,$5C,$09,$AA
  DEFB $5C,$A5,$62,$09,$A5,$62,$A0,$5F
  DEFB $03,$A5,$65,$A3,$63,$09,$80,$4F
  DEFB $8F,$4B,$09,$A0,$47,$BF,$40,$09
  DEFB $80,$6F,$BF,$77,$09,$AF,$75,$AF
  DEFB $45,$09,$80,$6F,$88,$6F,$09,$88
  DEFB $6F,$88,$4F,$09,$88,$4F,$80,$4F
  DEFB $09,$88,$6E,$AF,$72,$09,$88,$4F
  DEFB $8F,$4E,$09,$A0,$4B,$AF,$48,$04
  DEFB $AE,$71,$04,$AE,$71,$04,$AE,$71
  DEFB $04,$AE,$71,$04,$AE,$71,$04,$89
  DEFB $68,$04,$A5,$60,$04,$8E,$4F,$09
  DEFB $B1,$44,$B1,$74,$09,$AF,$74,$BF
  DEFB $74,$09,$AF,$44,$BF,$44,$06,$81
  DEFB $6D,$03,$74,$54,$7C,$62,$03

; Message at E8BF
  DEFM "tUxY"

; Data block at E8C3
  DEFB $02,$75,$56,$09

; Message at E8C7
  DEFM "qNvN"

; Data block at E8CB
  DEFB $09

; Message at E8CC
  DEFM "tati"

; Data block at E8D0
  DEFB $09

; Message at E8D1
  DEFM "saqg"

; Data block at E8D5
  DEFB $09

; Message at E8D6
  DEFM "uawg"

; Data block at E8DA
  DEFB $09

; Message at E8DB
  DEFM "tGhF"

; Data block at E8DF
  DEFB $09

; Message at E8E0
  DEFM "hFdA"

; Data block at E8E4
  DEFB $09,$77,$46,$7D,$46,$09,$7D,$46
  DEFB $82,$41,$10,$02,$04,$73,$46,$10
  DEFB $00,$09,$90,$9F,$90,$7F,$09,$90
  DEFB $7F,$A1,$82,$09,$A1,$82,$A1,$9F
  DEFB $09,$92,$9F,$92,$8F,$09,$92,$8F
  DEFB $A1,$94,$04,$91,$9D,$06,$94,$9D
  DEFB $04,$A0,$92,$09,$80,$57,$7C,$57
  DEFB $09,$6D,$57,$40,$57,$09

; Message at E922
  DEFM "PWP"

; Data block at E925
  DEFB $9F,$09,$60,$97,$60,$57,$09,$60
  DEFB $5F,$50,$67,$09,$50,$67,$40,$67
  DEFB $09,$60,$97,$58,$9F,$09,$60,$7F
  DEFB $65,$7F,$09,$65,$7F,$65,$6F,$09

; Message at E945
  DEFM "eojo"

; Data block at E949
  DEFB $09

; Message at E94A
  DEFM "jomy"

; Data block at E94E
  DEFB $09

; Message at E94F
  DEFM "myqy"

; Data block at E953
  DEFB $09

; Message at E954
  DEFM "qysl"

; Data block at E958
  DEFB $09

; Message at E959
  DEFM "slxl"

; Data block at E95D
  DEFB $09

; Message at E95E
  DEFM "xlx"

; Data block at E961
  DEFB $7D,$09,$78,$7D,$7A,$7D,$09,$7A
  DEFB $7D,$7E,$72,$09,$7E,$72,$80,$72
  DEFB $08,$48,$9B,$4D,$8B,$08,$4D,$83
  DEFB $48,$73,$06,$43,$64,$06,$52,$64
  DEFB $09,$62,$7C,$62,$74,$09

; Message at E987
  DEFM "blbd"

; Data block at E98B
  DEFB $08

; Message at E98C
  DEFM "flih"

; Data block at E990
  DEFB $02,$6F,$76,$02,$6F,$6E,$06,$B3
  DEFB $72,$09,$48,$91,$4C,$91,$04,$49
  DEFB $8F,$06,$49,$97,$09

; Message at E9A5
  DEFM "HuLu"

; Data block at E9A9
  DEFB $04,$4B,$74,$06,$4B,$7C,$08,$40

; Message at E9B1
  DEFM "dNW"

; Data block at E9B4
  DEFB $09

; Message at E9B5
  DEFM "RWRc"

; Data block at E9B9
  DEFB $09,$52,$63,$5E,$5E,$09,$5E,$5E
  DEFB $5E,$57,$09,$AE,$9F,$B1,$8F,$09
  DEFB $B1,$8F,$BF,$87,$09,$B1,$8F,$AB
  DEFB $7F,$09,$40

; Message at E9D4
  DEFM "HXK"

; Data block at E9D7
  DEFB $09,$58,$4B,$60,$49,$09,$60,$49
  DEFB $40,$45,$06,$56,$4A,$06,$46,$48
  DEFB $06,$43,$46,$09,$40,$54,$60,$54
  DEFB $09,$5B,$97,$5B,$67,$10,$01,$04
  DEFB $7F,$74,$04,$77,$74,$04,$67,$74
  DEFB $E8,$03,$1D,$00,$07,$11,$00,$05
  DEFB $80,$70,$10,$07,$08,$00,$30,$FF
  DEFB $AF,$08,$40,$40,$BF,$9F,$08,$38
  DEFB $38,$C7,$A7,$10,$00,$00,$00,$03
  DEFB $55,$4E,$C1,$05

; Message at EA23
  DEFM "ANCH"

; Data block at EA27
  DEFB $C1,$05

; Message at EA29
  DEFM "CALL"

; Data block at EA2D
  DEFB $C5,$02,$44,$C5,$02,$4C,$C1,$06

; Message at EA35
  DEFM "CIUDA"

; Data block at EA3A
  DEFB $C4,$07

; Message at EA3C
  DEFM "SALIDA"

; Data block at EA42
  DEFB $D3,$05

; Message at EA44
  DEFM "NORT"

; Data block at EA48
  DEFB $C5,$04

; Message at EA4A
  DEFM "EST"

; Data block at EA4D
  DEFB $C5

; Message at EA4E
  DEFM " *******************************"

; Data block at EA6E
  DEFB $AA,$03,$53,$55,$D2,$05

; Message at EA74
  DEFM "OEST"

; Data block at EA78
  DEFB $C5,$04

; Message at EA7A
  DEFM "COG"

; Data block at EA7D
  DEFB $C5,$04

; Message at EA7F
  DEFM "DEJ"

; Data block at EA82
  DEFB $C1,$04

; Message at EA84
  DEFM "SUB"

; Data block at EA87
  DEFB $C5,$04

; Message at EA89
  DEFM "BAJ"

; Data block at EA8C
  DEFB $C1,$07

; Message at EA8E
  DEFM "EXAMIN"

; Data block at EA94
  DEFB $C1,$07

; Message at EA96
  DEFM "DETALL"

; Data block at EA9C
  DEFB $C1,$06

; Message at EA9E
  DEFM "REDES"

; Data block at EAA3
  DEFB $C3,$06

; Message at EAA5
  DEFM "INVEN"

; Data block at EAAA
  DEFB $D4,$04

; Message at EAAC
  DEFM "SAV"

; Data block at EAAF
  DEFB $C5,$04

; Message at EAB1
  DEFM "LOA"

; Data block at EAB4
  DEFB $C4,$03,$46,$49,$CE,$07

; Message at EABA
  DEFM "DISPAR"

; Data block at EAC0
  DEFB $C1,$05

; Message at EAC2
  DEFM "ENTR"

; Data block at EAC6
  DEFB $C1,$03,$53,$41,$CC,$04

; Message at EACC
  DEFM "MAT"

; Data block at EACF
  DEFB $C1,$05

; Message at EAD1
  DEFM "PULS"

; Data block at EAD5
  DEFB $C1,$07

; Message at EAD7
  DEFM "INSERT"

; Data block at EADD
  DEFB $C1,$04

; Message at EADF
  DEFM "PID"

; Data block at EAE2
  DEFB $C5,$05

; Message at EAE4
  DEFM "HABL"

; Data block at EAE8
  DEFB $C1,$04

; Message at EAEA
  DEFM "ABR"

; Data block at EAED
  DEFB $C5,$05

; Message at EAEF
  DEFM "ROMP"

; Data block at EAF3
  DEFB $C5,$05

; Message at EAF5
  DEFM "CARG"

; Data block at EAF9
  DEFB $C1,$04

; Message at EAFB
  DEFM "GIR"

; Data block at EAFE
  DEFB $C1,$08

; Message at EB00
  DEFM "ENCIEND"

; Data block at EB07
  DEFB $C5,$06

; Message at EB09
  DEFM "TECLE"

; Data block at EB0E
  DEFB $C1,$07

; Message at EB10
  DEFM "APRIET"

; Data block at EB16
  DEFB $C1,$04

; Message at EB18
  DEFM "MET"

; Data block at EB1B
  DEFB $C5,$03,$50,$4F,$CE,$05

; Message at EB21
  DEFM "GRIT"

; Data block at EB25
  DEFB $C1,$05

; Message at EB27
  DEFM "CANT"

; Data block at EB2B
  DEFB $C1,$01,$CE,$01,$D3,$01,$C5,$01
  DEFB $CF,$01,$C4,$01,$D2,$01,$C9,$05

; Message at EB3B
  DEFM "ESTO"

; Data block at EB3F
  DEFB $D9,$02,$45,$CE,$04

; Message at EB44
  DEFM "AQU"

; Data block at EB47
  DEFB $C9,$03,$48,$41,$D9,$06

; Message at EB4D
  DEFM "CABIN"

; Data block at EB52
  DEFB $C1,$0B

; Message at EB54
  DEFM "VIDEOFONIC"

; Data block at EB5E
  DEFB $C1,$02,$45,$CC,$08

; Message at EB63
  DEFM "INTERIO"

; Data block at EB6A
  DEFB $D2,$09

; Message at EB6C
  DEFM "VIDEOFON"

; Data block at EB74
  DEFB $CF,$06

; Message at EB76
  DEFM "ESPER"

; Data block at EB7B
  DEFB $C1,$03,$53,$45,$D2,$09

; Message at EB81
  DEFM "UTILIZAD"

; Data block at EB89
  DEFB $CF,$07

; Message at EB8B
  DEFM "ANIMAD"

; Data block at EB91
  DEFB $C1,$07

; Message at EB93
  DEFM "TABERN"

; Data block at EB99
  DEFB $C1,$06

; Message at EB9B
  DEFM "FRENT"

; Data block at EBA0
  DEFB $C5,$01,$C1,$02,$4D,$C9,$03,$56
  DEFB $45,$CF,$04

; Message at EBAB
  DEFM "ESO"

; Data block at EBAE
  DEFB $D9,$0A

; Message at EBB0
  DEFM "TRANSITAD"

; Data block at EBB9
  DEFB $C1,$07

; Message at EBBB
  DEFM "AVENID"

; Data block at EBC1
  DEFB $C1,$02,$55,$CE,$06

; Message at EBC6
  DEFM "TEMPL"

; Data block at EBCB
  DEFB $CF,$03,$44,$45,$CC,$05

; Message at EBD1
  DEFM "CULT"

; Data block at EBD5
  DEFB $CF,$04

; Message at EBD7
  DEFM "SOT"

; Data block at EBDA
  DEFB $C8,$08

; Message at EBDC
  DEFM "SILENCI"

; Data block at EBE3
  DEFB $CF,$02,$45,$D3,$05

; Message at EBE8
  DEFM "TOTA"

; Data block at EBEC
  DEFB $CC,$02,$4D,$C5,$09

; Message at EBF1
  DEFM "ENCUENTR"

; Data block at EBF9
  DEFB $CF,$08

; Message at EBFB
  DEFM "ESTRECH"

; Data block at EC02
  DEFB $CF,$08

; Message at EC04
  DEFM "CALLEJO"

; Data block at EC0B
  DEFB $CE,$05

; Message at EC0D
  DEFM "PUED"

; Data block at EC11
  DEFB $CF,$03,$56,$45,$D2,$06

; Message at EC17
  DEFM "PUERT"

; Data block at EC1C
  DEFB $C1,$07

; Message at EC1E
  DEFM "PRISIO"

; Data block at EC24
  DEFB $CE,$07

; Message at EC26
  DEFM "ENTRAD"

; Data block at EC2C
  DEFB $C1,$08

; Message at EC2E
  DEFM "COMERCI"

; Data block at EC35
  DEFB $CF,$06

; Message at EC37
  DEFM "DENTR"

; Data block at EC3C
  DEFB $CF,$08

; Message at EC3E
  DEFM "MONTONE"

; Data block at EC45
  DEFB $D3,$06

; Message at EC47
  DEFM "PIELE"

; Data block at EC4C
  DEFB $D3,$06

; Message at EC4E
  DEFM "LLENA"

; Data block at EC53
  DEFB $CE,$05

; Message at EC55
  DEFM "LOCA"

; Data block at EC59
  DEFB $CC,$06

; Message at EC5B
  DEFM "OSCUR"

; Data block at EC60
  DEFB $C1,$05

; Message at EC62
  DEFM "CELD"

; Data block at EC66
  DEFB $C1,$07

; Message at EC68
  DEFM "PASILL"

; Data block at EC6E
  DEFB $CF,$08

; Message at EC70
  DEFM "ASCENSO"

; Data block at EC77
  DEFB $D2,$08

; Message at EC79
  DEFM "GUARDIA"

; Data block at EC80
  DEFB $CE,$02,$48,$C1,$05

; Message at EC85
  DEFM "VIST"

; Data block at EC89
  DEFB $CF,$04

; Message at EC8B
  DEFM "SAL"

; Data block at EC8E
  DEFB $C1,$08

; Message at EC90
  DEFM "ARCHIVO"

; Data block at EC97
  DEFB $D3,$06

; Message at EC99
  DEFM "PAREC"

; Data block at EC9E
  DEFB $C5,$08

; Message at ECA0
  DEFM "DESIERT"

; Data block at ECA7
  DEFB $C1,$09

; Message at ECA9
  DEFM "VIGILANT"

; Data block at ECB1
  DEFB $C5,$05

; Message at ECB3
  DEFM "ROBO"

; Data block at ECB7
  DEFB $D4,$06

; Message at ECB9
  DEFM "GUARD"

; Data block at ECBE
  DEFB $C1,$06

; Message at ECC0
  DEFM "ACCES"

; Data block at ECC5
  DEFB $CF,$06

; Message at ECC7
  DEFM "CUART"

; Data block at ECCC
  DEFB $CF,$0D

; Message at ECCE
  DEFM "MANTENIMIENT"

; Data block at ECDA
  DEFB $CF,$06

; Message at ECDC
  DEFM "CUERP"

; Data block at ECE1
  DEFB $CF,$07

; Message at ECE3
  DEFM "GUARDI"

; Data block at ECE9
  DEFB $C1,$02,$41,$CC,$05

; Message at ECEE
  DEFM "VERM"

; Data block at ECF2
  DEFB $C5,$03,$4C,$4F,$D3,$0A

; Message at ECF8
  DEFM "GUARDIANE"

; Data block at ED01
  DEFB $D3,$05

; Message at ED03
  DEFM "ABRE"

; Data block at ED07
  DEFB $CE,$05

; Message at ED09
  DEFM "FUEG"

; Data block at ED0D
  DEFB $CF,$05

; Message at ED0F
  DEFM "SOBR"

; Data block at ED13
  DEFB $C5,$04

; Message at ED15
  DEFM "BAS"

; Data block at ED18
  DEFB $C5,$08

; Message at ED1A
  DEFM "EDIFICI"

; Data block at ED21
  DEFB $CF,$08

; Message at ED23
  DEFM "ESCALER"

; Data block at ED2A
  DEFB $C1,$05

; Message at ED2C
  DEFM "SUCI"

; Data block at ED30
  DEFB $C1,$0C

; Message at ED32
  DEFM "ALCANTARILL"

; Data block at ED3D
  DEFB $C1,$05

; Message at ED3F
  DEFM "TECH"

; Data block at ED43
  DEFB $CF,$09

; Message at ED45
  DEFM "TRAMPILL"

; Data block at ED4D
  DEFB $C1,$03,$3E,$3E,$BE,$05

; Message at ED53
  DEFM "TUNE"

; Data block at ED57
  DEFB $CC,$08

; Message at ED59
  DEFM "PENUMBR"

; Data block at ED60
  DEFB $C1,$09

; Message at ED62
  DEFM "ESCONDIT"

; Data block at ED6A
  DEFB $C5,$08

; Message at ED6C
  DEFM "REBELDE"

; Data block at ED73
  DEFB $D3,$05

; Message at ED75
  DEFM "SUEL"

; Data block at ED79
  DEFB $CF,$07

; Message at ED7B
  DEFM "CADAVE"

; Data block at ED81
  DEFB $D2,$06

; Message at ED83
  DEFM "PERDO"

; Data block at ED88
  DEFB $CE,$02,$4E,$CF,$05

; Message at ED8D
  DEFM "HACE"

; Data block at ED91
  DEFB $D2,$03,$45,$53,$CF,$05

; Message at ED97
  DEFM "DISC"

; Data block at ED9B
  DEFB $CF,$08

; Message at ED9D
  DEFM "METALIC"

; Data block at EDA4
  DEFB $CF,$07

; Message at EDA6
  DEFM "PISTOL"

; Data block at EDAC
  DEFB $C1,$09

; Message at EDAE
  DEFM "(CARGADA"

; Data block at EDB6
  DEFB $A9,$05

; Message at EDB8
  DEFM "AGUJ"

; Data block at EDBC
  DEFB $C1,$05

; Message at EDBE
  DEFM "JARR"

; Data block at EDC2
  DEFB $CF,$05

; Message at EDC4
  DEFM "PAPE"

; Data block at EDC8
  DEFB $CC,$07

; Message at EDCA
  DEFM "DOSSIE"

; Data block at EDD0
  DEFB $D2,$06

; Message at EDD2
  DEFM "ESCOB"

; Data block at EDD7
  DEFB $C1,$05

; Message at EDD9
  DEFM "LLAV"

; Data block at EDDD
  DEFB $C5,$07

; Message at EDDF
  DEFM "INGLES"

; Data block at EDE5
  DEFB $C1,$0A

; Message at EDE7
  DEFM "PALANQUET"

; Data block at EDF0
  DEFB $C1,$07

; Message at EDF2
  DEFM "TALADR"

; Data block at EDF8
  DEFB $CF,$05

; Message at EDFA
  DEFM "LASE"

; Data block at EDFE
  DEFB $D2,$0E

; Message at EE00
  DEFM "DESTORNILLADO"

; Data block at EE0D
  DEFB $D2,$04

; Message at EE0F
  DEFM "CUB"

; Data block at EE12
  DEFB $CF,$08

; Message at EE14
  DEFM "LINTERN"

; Data block at EE1B
  DEFB $C1,$08

; Message at EE1D
  DEFM "PASTILL"

; Data block at EE24
  DEFB $C1,$05

; Message at EE26
  DEFM "JABO"

; Data block at EE2A
  DEFB $CE,$06

; Message at EE2C
  DEFM "MONED"

; Data block at EE31
  DEFB $C1,$0B

; Message at EE33
  DEFM "(ENCENDIDA"

; Data block at EE3D
  DEFB $A9,$05

; Message at EE3F
  DEFM "JARR"

; Data block at EE43
  DEFB $C1,$06

; Message at EE45
  DEFM "HUMAN"

; Data block at EE4A
  DEFB $CF,$06

; Message at EE4C
  DEFM "IMAGE"

; Data block at EE51
  DEFB $CE,$04

; Message at EE53
  DEFM "TAP"

; Data block at EE56
  DEFB $C1,$07

; Message at EE58
  DEFM "POLICI"

; Data block at EE5E
  DEFB $C1,$06

; Message at EE60
  DEFM "TIEND"

; Data block at EE65
  DEFB $C1,$06

; Message at EE67
  DEFM "CARTE"

; Data block at EE6C
  DEFB $CC,$04

; Message at EE6E
  DEFM "GOS"

; Data block at EE71
  DEFB $C8,$0B

; Message at EE73
  DEFM "PROPIETARI"

; Data block at EE7D
  DEFB $CF,$07

; Message at EE7F
  DEFM "COLCHO"

; Data block at EE85
  DEFB $CE,$05

; Message at EE87
  DEFM "PANE"

; Data block at EE8B
  DEFB $CC,$05

; Message at EE8D
  DEFM "BOTO"

; Data block at EE91
  DEFB $CE,$09

; Message at EE93
  DEFM "ORDENADO"

; Data block at EE9B
  DEFB $D2,$08

; Message at EE9D
  DEFM "TERMINA"

; Data block at EEA4
  DEFB $CC,$07

; Message at EEA6
  DEFM "MONITO"

; Data block at EEAC
  DEFB $D2,$07

; Message at EEAE
  DEFM "TECLAD"

; Data block at EEB4
  DEFB $CF,$04

; Message at EEB6
  DEFM "POZ"

; Data block at EEB9
  DEFB $CF,$04

; Message at EEBB
  DEFM "FOS"

; Data block at EEBE
  DEFB $CF,$06

; Message at EEC0
  DEFM "REBEC"

; Data block at EEC5
  DEFB $C1,$0A

; Message at EEC7
  DEFM "INTRODUZC"

; Data block at EED0
  DEFB $C1,$05

; Message at EED2
  DEFM "CLAV"

; Data block at EED6
  DEFB $C5,$05

; Message at EED8
  DEFM "PULS"

; Data block at EEDC
  DEFB $C5,$05

; Message at EEDE
  DEFM "TECL"

; Data block at EEE2
  DEFB $C1,$04

; Message at EEE4
  DEFM "PAR"

; Data block at EEE7
  DEFB $C1,$06

; Message at EEE9
  DEFM "VOLVE"

; Data block at EEEE
  DEFB $D2,$05

; Message at EEF0
  DEFM "JUGA"

; Data block at EEF4
  DEFB $D2,$04

; Message at EEF6
  DEFM "EST"

; Data block at EEF9
  DEFB $C1,$06

; Message at EEFB
  DEFM "SEGUR"

; Data block at EF00
  DEFB $CF,$05

; Message at EF02
  DEFM "(S/N"

; Data block at EF06
  DEFB $A9,$02,$59,$C1,$02,$4C,$CF,$05

; Message at EF0E
  DEFM "TENG"

; Data block at EF12
  DEFB $CF,$05

; Message at EF14
  DEFM "LLEV"

; Data block at EF18
  DEFB $CF,$09

; Message at EF1A
  DEFM "DEMASIAD"

; Data block at EF22
  DEFB $CF,$04

; Message at EF24
  DEFM "PES"

; Data block at EF27
  DEFB $CF,$02,$53,$D5,$0A

; Message at EF2C
  DEFM "PUNTUACIO"

; Data block at EF35
  DEFB $CE,$03,$46,$55,$C5,$01,$D9,$07

; Message at EF3D
  DEFM "EFECTU"

; Data block at EF43
  DEFB $CF,$03,$4D,$55,$D9,$06

; Message at EF49
  DEFM "OSCUR"

; Data block at EF4E
  DEFB $CF,$04

; Message at EF50
  DEFM "NAD"

; Data block at EF53
  DEFB $C1,$05

; Message at EF55
  DEFM "HECH"

; Data block at EF59
  DEFB $CF,$0B

; Message at EF5B
  DEFM "MOVIMIENTO"

; Data block at EF65
  DEFB $D3,$03,$51,$55,$C5,$04

; Message at EF6B
  DEFM "COM"

; Data block at EF6E
  DEFB $CF,$08

; Message at EF70
  DEFM "ESPECIA"

; Data block at EF77
  DEFB $CC,$07

; Message at EF79
  DEFM "LINTER"

; Data block at EF7F
  DEFB $CE,$07

; Message at EF81
  DEFM "CONMIG"

; Data block at EF87
  DEFB $CF,$03,$43,$4F,$CE,$07

; Message at EF8D
  DEFM "SIMBOL"

; Data block at EF93
  DEFB $CF,$09

; Message at EF95
  DEFM "HORUSCOR"

; Data block at EF9D
  DEFB $D0,$0A

; Message at EF9F
  DEFM "SILENCIOS"

; Data block at EFA8
  DEFB $C1,$06

; Message at EFAA
  DEFM "MORTA"

; Data block at EFAF
  DEFB $CC,$06

; Message at EFB1
  DEFM "AGUJA"

; Data block at EFB6
  DEFB $D3,$0A

; Message at EFB8
  DEFM "DESCARGAD"

; Data block at EFC1
  DEFB $C1,$07

; Message at EFC3
  DEFM "CARGAD"

; Data block at EFC9
  DEFB $C1,$04

; Message at EFCB
  DEFM "FIN"

; Data block at EFCE
  DEFB $C1,$05

; Message at EFD0
  DEFM "ACER"

; Data block at EFD4
  DEFB $CF,$05

; Message at EFD6
  DEFM "BARR"

; Data block at EFDA
  DEFB $CF,$04

; Message at EFDC
  DEFM "ALG"

; Data block at EFDF
  DEFB $CF,$0D

; Message at EFE1
  DEFM "DESPORTILLAD"

; Data block at EFED
  DEFB $C1,$04

; Message at EFEF
  DEFM "HOJ"

; Data block at EFF2
  DEFB $C1,$07

; Message at EFF4
  DEFM "ESCRIT"

; Data block at EFFA
  DEFB $CF,$09

; Message at EFFC
  DEFM "\"THX1138"

; Data block at F004
  DEFB $A2,$06

; Message at F006
  DEFM "\"TMA1"

; Data block at F00B
  DEFB $A2,$0B

; Message at F00D
  DEFM "\"366117891"

; Data block at F017
  DEFB $A2,$0E

; Message at F019
  DEFM "\"USSCSS180286"

; Data block at F026
  DEFB $A2,$09

; Message at F028
  DEFM "\"NCC1701"

; Data block at F030
  DEFB $A2,$0A

; Message at F032
  DEFM "\"INCOMT65"

; Data block at F03B
  DEFB $A2,$07

; Message at F03D
  DEFM "LISTAD"

; Data block at F043
  DEFB $CF,$06

; Message at F045
  DEFM "VARIO"

; Data block at F04A
  DEFB $D3,$07

; Message at F04C
  DEFM "NOMBRE"

; Data block at F052
  DEFB $D3,$08

; Message at F054
  DEFM "ESCRITO"

; Data block at F05B
  DEFB $D3,$04

; Message at F05D
  DEFM "PUE"

; Data block at F060
  DEFB $D3,$05

; Message at F062
  DEFM "TIEN"

; Data block at F066
  DEFB $C5,$05

; Message at F068
  DEFM "FORM"

; Data block at F06C
  DEFB $C1,$02,$54,$C5,$09

; Message at F071
  DEFM "ESPERABA"

; Data block at F079
  DEFB $D3,$05

; Message at F07B
  DEFM "LARG"

; Data block at F07F
  DEFB $C1,$05

; Message at F081
  DEFM "BARR"

; Data block at F085
  DEFB $C1,$06

; Message at F087
  DEFM "NORMA"

; Data block at F08C
  DEFB $CC,$07

; Message at F08E
  DEFM "POTENT"

; Data block at F094
  DEFB $C5,$05

; Message at F096
  DEFM "MANG"

; Data block at F09A
  DEFB $CF,$09

; Message at F09C
  DEFM "CONDUCTO"

; Data block at F0A4
  DEFB $D2,$09

; Message at F0A6
  DEFM "ELECTRIC"

; Data block at F0AE
  DEFB $C1,$09

; Message at F0B0
  DEFM "ENCENDID"

; Data block at F0B8
  DEFB $C1,$07

; Message at F0BA
  DEFM "GENUIN"

; Data block at F0C0
  DEFB $CF,$09

; Message at F0C2
  DEFM "\"LAGARTO"

; Data block at F0CA
  DEFB $A2,$01,$B1,$07

; Message at F0CE
  DEFM "CREDIT"

; Data block at F0D4
  DEFB $CF,$07

; Message at F0D6
  DEFM "THX113"

; Data block at F0DC
  DEFB $B8,$04

; Message at F0DE
  DEFM "TMA"

; Data block at F0E1
  DEFB $B1,$09

; Message at F0E3
  DEFM "36611789"

; Data block at F0EB
  DEFB $B1,$0C

; Message at F0ED
  DEFM "USSCSS18028"

; Data block at F0F8
  DEFB $B6,$07

; Message at F0FA
  DEFM "NCC170"

; Data block at F100
  DEFB $B1,$08

; Message at F102
  DEFM "INCOMT6"

; Data block at F109
  DEFB $B5,$02,$4C,$B1,$02,$4C,$B2,$02
  DEFB $4C,$B3,$08

; Message at F114
  DEFM "NECESIT"

; Data block at F11B
  DEFB $CF,$07

; Message at F11D
  DEFM "TENERL"

; Data block at F123
  DEFB $CF,$05

; Message at F125
  DEFM "ANTE"

; Data block at F129
  DEFB $D3,$03,$4D,$41,$D3,$08

; Message at F12F
  DEFM "NUMERIC"

; Data block at F136
  DEFB $CF,$08

; Message at F138
  DEFM "PANTALL"

; Data block at F13F
  DEFB $C1,$05

; Message at F141
  DEFM "JUNT"

; Data block at F145
  DEFB $CF,$06

; Message at F147
  DEFM "RANUR"

; Data block at F14C
  DEFB $C1,$06

; Message at F14E
  DEFM "INDIC"

; Data block at F153
  DEFB $C1,$08

; Message at F155
  DEFM "\"INSERT"

; Data block at F15C
  DEFB $C5,$07

; Message at F15E
  DEFM "MONEDA"

; Data block at F164
  DEFB $A2,$06

; Message at F166
  DEFM "HOMBR"

; Data block at F16B
  DEFB $C5,$06

; Message at F16D
  DEFM "BEBID"

; Data block at F172
  DEFB $CF,$0A

; Message at F174
  DEFM "\"FORASTER"

; Data block at F17D
  DEFB $CF,$02,$45,$C8,$05

; Message at F182
  DEFM "TENG"

; Data block at F186
  DEFB $C1,$07

; Message at F188
  DEFM "CONSEJ"

; Data block at F18E
  DEFB $CF,$02,$4E,$C9,$02,$53,$C5,$02
  DEFB $4C,$C5,$06

; Message at F199
  DEFM "OCURR"

; Data block at F19E
  DEFB $C1,$06

; Message at F1A0
  DEFM "HABLA"

; Data block at F1A5
  DEFB $D2,$0A

; Message at F1A7
  DEFM "SACRILEGI"

; Data block at F1B0
  DEFB $CF,$09

; Message at F1B2
  DEFM "CASTIGAD"

; Data block at F1BA
  DEFB $CF,$01,$A2,$06

; Message at F1BE
  DEFM "VUELV"

; Data block at F1C3
  DEFB $C5,$06

; Message at F1C5
  DEFM "BEBID"

; Data block at F1CA
  DEFB $C1,$07

; Message at F1CC
  DEFM "MURMUR"

; Data block at F1D2
  DEFB $C1,$02,$53,$C9,$05

; Message at F1D7
  DEFM "ESTA"

; Data block at F1DB
  DEFB $D2,$0D

; Message at F1DD
  DEFM "IMPRESIONANT"

; Data block at F1E9
  DEFB $C5,$0C

; Message at F1EB
  DEFM "CONSTRUCCIO"

; Data block at F1F6
  DEFB $CE,$07

; Message at F1F8
  DEFM "ASPECT"

; Data block at F1FE
  DEFB $CF,$04

; Message at F200
  DEFM "POC"

; Data block at F203
  DEFB $CF,$07

; Message at F205
  DEFM "TETRIC"

; Data block at F20B
  DEFB $CF,$04

; Message at F20D
  DEFM "VAY"

; Data block at F210
  DEFB $C1,$03,$54,$49,$CF,$03,$46,$45
  DEFB $CF,$03,$44,$41,$D2,$0E

; Message at F21E
  DEFM "ALCANTARILLAD"

; Data block at F22B
  DEFB $CF,$0A

; Message at F22D
  DEFM "MONUMENTA"

; Data block at F236
  DEFB $CC,$09

; Message at F238
  DEFM "FORTALEZ"

; Data block at F240
  DEFB $C1,$04

; Message at F242
  DEFM "CAR"

; Data block at F245
  DEFB $C1,$06

; Message at F247
  DEFM "BESTI"

; Data block at F24C
  DEFB $C1,$04

; Message at F24E
  DEFM "CRE"

; Data block at F251
  DEFB $CF,$05

; Message at F253
  DEFM "GUST"

; Data block at F257
  DEFB $C1,$06

; Message at F259
  DEFM "HUSME"

; Data block at F25E
  DEFB $C5,$03,$50,$4F,$D2,$07

; Message at F264
  DEFM "NEGOCI"

; Data block at F26A
  DEFB $CF,$08

; Message at F26C
  DEFM "PROSPER"

; Data block at F273
  DEFB $CF,$04

; Message at F275
  DEFM "DIC"

; Data block at F278
  DEFB $C5,$0A

; Message at F27A
  DEFM "\"PELETERI"

; Data block at F283
  DEFB $C1,$08

; Message at F285
  DEFM "CURTIDO"

; Data block at F28C
  DEFB $D3,$06

; Message at F28E
  DEFM "FINAS"

; Data block at F293
  DEFB $A2,$04

; Message at F295
  DEFM "TIP"

; Data block at F298
  DEFB $CF,$06

; Message at F29A
  DEFM "BAJIT"

; Data block at F29F
  DEFB $CF,$07

; Message at F2A1
  DEFM "SONREI"

; Data block at F2A7
  DEFB $D2,$0E

; Message at F2A9
  DEFM "CONSTANTEMENT"

; Data block at F2B6
  DEFB $C5,$05

; Message at F2B8
  DEFM "SUCI"

; Data block at F2BC
  DEFB $CF,$07

; Message at F2BE
  DEFM "RELLEN"

; Data block at F2C4
  DEFB $CF,$04

; Message at F2C6
  DEFM "GOM"

; Data block at F2C9
  DEFB $C1,$06

; Message at F2CB
  DEFM "ESPUM"

; Data block at F2D0
  DEFB $C1,$05

; Message at F2D2
  DEFM "TODO"

; Data block at F2D6
  DEFB $D3,$0A

; Message at F2D8
  DEFM "ASCENSORE"

; Data block at F2E1
  DEFB $D3,$01,$B3,$07

; Message at F2E5
  DEFM "BOTONE"

; Data block at F2EB
  DEFB $D3,$08

; Message at F2ED
  DEFM "MARCADO"

; Data block at F2F4
  DEFB $D3,$04

; Message at F2F6
  DEFM "\"L1"

; Data block at F2F9
  DEFB $A2,$04

; Message at F2FB
  DEFM "\"L2"

; Data block at F2FE
  DEFB $A2,$04

; Message at F300
  DEFM "\"L3"

; Data block at F303
  DEFB $A2,$06

; Message at F305
  DEFM "CONST"

; Data block at F30A
  DEFB $C1,$07

; Message at F30C
  DEFM "TAMBIE"

; Data block at F312
  DEFB $CE,$09

; Message at F314
  DEFM "IMPRESOR"

; Data block at F31C
  DEFB $C1,$0B

; Message at F31E
  DEFM "\"INTRODUZC"

; Data block at F328
  DEFB $C1,$06

; Message at F32A
  DEFM "CODIG"

; Data block at F32F
  DEFB $CF,$07

; Message at F331
  DEFM "ACCESO"

; Data block at F337
  DEFB $A2,$07

; Message at F339
  DEFM "\"CODIG"

; Data block at F33F
  DEFB $CF,$09

; Message at F341
  DEFM "DOCUMENT"

; Data block at F349
  DEFB $CF,$06

; Message at F34B
  DEFM "QWERT"

; Data block at F350
  DEFB $D9,$0B

; Message at F352
  DEFM "FUERTEMENT"

; Data block at F35C
  DEFB $C5,$06

; Message at F35E
  DEFM "ARMAD"

; Data block at F363
  DEFB $CF,$08

; Message at F365
  DEFM "BLINDAD"

; Data block at F36C
  DEFB $CF,$05

; Message at F36E
  DEFM "PECH"

; Data block at F372
  DEFB $CF,$0C

; Message at F374
  DEFM "ALFANUMERIC"

; Data block at F37F
  DEFB $CF,$04

; Message at F381
  DEFM "UNO"

; Data block at F384
  DEFB $D3,$09

; Message at F386
  DEFM "ESCALONE"

; Data block at F38E
  DEFB $D3,$05

; Message at F390
  DEFM "PARE"

; Data block at F394
  DEFB $C4,$07

; Message at F396
  DEFM "CERRAD"

; Data block at F39C
  DEFB $C1,$0E

; Message at F39E
  DEFM "HERMETICAMENT"

; Data block at F3AB
  DEFB $C5,$06

; Message at F3AD
  DEFM "CENTR"

; Data block at F3B2
  DEFB $CF,$07

; Message at F3B4
  DEFM "ESPECI"

; Data block at F3BA
  DEFB $C5,$07

; Message at F3BC
  DEFM "VOLANT"

; Data block at F3C2
  DEFB $C5,$09

; Message at F3C4
  DEFM "ESCOTILL"

; Data block at F3CC
  DEFB $C1,$09

; Message at F3CE
  DEFM "SUBMARIN"

; Data block at F3D6
  DEFB $CF,$08

; Message at F3D8
  DEFM "EMPLEAD"

; Data block at F3DF
  DEFB $CF,$03,$4C,$41,$D3,$06

; Message at F3E5
  DEFM "CALLE"

; Data block at F3EA
  DEFB $D3,$06

; Message at F3EC
  DEFM "NYHMI"

; Data block at F3F1
  DEFB $D2,$09

; Message at F3F3
  DEFM "PASEANTE"

; Data block at F3FB
  DEFB $D3,$06

; Message at F3FD
  DEFM "VARIA"

; Data block at F402
  DEFB $D3,$05

; Message at F404
  DEFM "RAZA"

; Data block at F408
  DEFB $D3,$06

; Message at F40A
  DEFM "CRUZA"

; Data block at F40F
  DEFB $CE,$04

; Message at F411
  DEFM "ANT"

; Data block at F414
  DEFB $C5,$03,$53,$49,$CE,$09

; Message at F41A
  DEFM "PRESTARM"

; Data block at F422
  DEFB $C5,$08

; Message at F424
  DEFM "ATENCIO"

; Data block at F42B
  DEFB $CE,$06

; Message at F42D
  DEFM "TRAVE"

; Data block at F432
  DEFB $D3,$09

; Message at F434
  DEFM "CRISTALE"

; Data block at F43C
  DEFB $D3,$05

; Message at F43E
  DEFM "ENTR"

; Data block at F442
  DEFB $C5,$05

; Message at F444
  DEFM "NUBE"

; Data block at F448
  DEFB $D3,$04

; Message at F44A
  DEFM "HUM"

; Data block at F44D
  DEFB $CF,$0C

; Message at F44F
  DEFM "PARROQUIANO"

; Data block at F45A
  DEFB $D3,$09

; Message at F45C
  DEFM "CHARLAND"

; Data block at F464
  DEFB $CF,$08

; Message at F466
  DEFM "BEBIEND"

; Data block at F46D
  DEFB $CF,$0C

; Message at F46F
  DEFM "ANIMADAMENT"

; Data block at F47A
  DEFB $C5,$04

; Message at F47C
  DEFM "MES"

; Data block at F47F
  DEFB $C1,$04

; Message at F481
  DEFM "MIR"

; Data block at F484
  DEFB $C1,$07

; Message at F486
  DEFM "CURIOS"

; Data block at F48C
  DEFB $CF,$09

; Message at F48E
  DEFM "SINIESTR"

; Data block at F496
  DEFB $CF,$06

; Message at F498
  DEFM "FIELE"

; Data block at F49D
  DEFB $D3,$06

; Message at F49F
  DEFM "ENTRA"

; Data block at F4A4
  DEFB $CE,$05

; Message at F4A6
  DEFM "SALE"

; Data block at F4AA
  DEFB $CE,$0A

; Message at F4AC
  DEFM "ENTREGAND"

; Data block at F4B5
  DEFB $CF,$08

; Message at F4B7
  DEFM "LIMOSNA"

; Data block at F4BE
  DEFB $D3,$06

; Message at F4C0
  DEFM "CUANT"

; Data block at F4C5
  DEFB $CF,$07

; Message at F4C7
  DEFM "MENDIG"

; Data block at F4CD
  DEFB $CF,$03,$4C,$45,$D3,$0B

; Message at F4D3
  DEFM "GENEROSIDA"

; Data block at F4DD
  DEFB $C4,$07

; Message at F4DF
  DEFM "POSTRA"

; Data block at F4E5
  DEFB $CE,$04

; Message at F4E7
  DEFM "DIO"

; Data block at F4EA
  DEFB $D3,$06

; Message at F4EC
  DEFM "ORAND"

; Data block at F4F1
  DEFB $CF,$05

; Message at F4F3
  DEFM "MAYO"

; Data block at F4F7
  DEFB $D2,$09

; Message at F4F9
  DEFM "SILENCIO"

; Data block at F501
  DEFB $D3,$03,$4F,$59,$C5,$05

; Message at F507
  DEFM "MOSC"

; Data block at F50B
  DEFB $C1,$08

; Message at F50D
  DEFM "METALIC"

; Data block at F514
  DEFB $C1,$06

; Message at F516
  DEFM "BRUTA"

; Data block at F51B
  DEFB $CC,$05

; Message at F51D
  DEFM "GENT"

; Data block at F521
  DEFB $C5,$06

; Message at F523
  DEFM "EVITA"

; Data block at F528
  DEFB $D2,$0A

; Message at F52A
  DEFM "CONCURRID"

; Data block at F533
  DEFB $CF,$08

; Message at F535
  DEFM "HORRIBL"

; Data block at F53C
  DEFB $C5,$04

; Message at F53E
  DEFM "OLO"

; Data block at F541
  DEFB $D2,$05

; Message at F543
  DEFM "ALGU"

; Data block at F547
  DEFB $CE,$05

; Message at F549
  DEFM "LUGA"

; Data block at F54D
  DEFB $D2,$05

; Message at F54F
  DEFM "SURG"

; Data block at F553
  DEFB $C5,$09

; Message at F555
  DEFM "INDIVIDU"

; Data block at F55D
  DEFB $CF,$04

; Message at F55F
  DEFM "\"SO"

; Data block at F562
  DEFB $D9,$04

; Message at F564
  DEFM "AHM"

; Data block at F567
  DEFB $C9,$08

; Message at F569
  DEFM "AYUDARL"

; Data block at F570
  DEFB $C5,$06

; Message at F572
  DEFM "BLOQU"

; Data block at F577
  DEFB $C5,$0A

; Message at F579
  DEFM "SILENCIOS"

; Data block at F582
  DEFB $CF,$06

; Message at F584
  DEFM "MUERT"

; Data block at F589
  DEFB $CF,$06

; Message at F58B
  DEFM "MANDO"

; Data block at F590
  DEFB $D3,$07

; Message at F592
  DEFM "ESPALD"

; Data block at F598
  DEFB $C1,$08

; Message at F59A
  DEFM "CORREDO"

; Data block at F5A1
  DEFB $D2,$0A

; Message at F5A3
  DEFM "ABARROTAD"

; Data block at F5AC
  DEFB $CF,$0C

; Message at F5AE
  DEFM "HERRAMIENTA"

; Data block at F5B9
  DEFB $D3,$05

; Message at F5BB
  DEFM "LLEN"

; Data block at F5BF
  DEFB $CF,$07

; Message at F5C1
  DEFM "TRASTO"

; Data block at F5C7
  DEFB $D3,$05

; Message at F5C9
  DEFM "DOND"

; Data block at F5CD
  DEFB $C5,$0A

; Message at F5CF
  DEFM "ENCUENTRA"

; Data block at F5D8
  DEFB $CE,$0B

; Message at F5DA
  DEFM "GENERADORE"

; Data block at F5E4
  DEFB $D3,$0E

; Message at F5E6
  DEFM "ACONDICIONADO"

; Data block at F5F3
  DEFB $D2,$04

; Message at F5F5
  DEFM "AIR"

; Data block at F5F8
  DEFB $C5,$03,$45,$54,$C3,$05

; Message at F5FE
  DEFM "PEST"

; Data block at F602
  DEFB $C5,$08

; Message at F604
  DEFM "APESTOS"

; Data block at F60B
  DEFB $C1,$08

; Message at F60D
  DEFM "CIRCULA"

; Data block at F614
  DEFB $D2,$05

; Message at F616
  DEFM "META"

; Data block at F61A
  DEFB $CC,$03,$4C,$55,$DA,$07

; Message at F620
  DEFM "COSTAD"

; Data block at F626
  DEFB $CF,$06

; Message at F628
  DEFM "LLEGA"

; Data block at F62D
  DEFB $D2,$05

; Message at F62F
  DEFM "HAST"

; Data block at F633
  DEFB $C1,$05

; Message at F635
  DEFM "PONG"

; Data block at F639
  DEFB $CF,$07

; Message at F63B
  DEFM "\"TECLE"

; Data block at F641
  DEFB $C5,$07

; Message at F643
  DEFM "NUMERO"

; Data block at F649
  DEFB $A2,$07

; Message at F64B
  DEFM "DESLIZ"

; Data block at F651
  DEFB $C1,$05

; Message at F653
  DEFM "CAIG"

; Data block at F657
  DEFB $CF,$08

; Message at F659
  DEFM "PASADIZ"

; Data block at F660
  DEFB $CF,$08

; Message at F662
  DEFM "ESCAMOS"

; Data block at F669
  DEFB $CF,$05

; Message at F66B
  DEFM "GRUT"

; Data block at F66F
  DEFB $C8,$06

; Message at F671
  DEFM "ARROJ"

; Data block at F676
  DEFB $C1,$05

; Message at F678
  DEFM "GEST"

; Data block at F67C
  DEFB $CF,$07

; Message at F67E
  DEFM "LASTIM"

; Data block at F684
  DEFB $C1,$05

; Message at F686
  DEFM "\"SOT"

; Data block at F68A
  DEFB $C8,$04

; Message at F68C
  DEFM "PAG"

; Data block at F68F
  DEFB $C5,$05

; Message at F691
  DEFM "BUEN"

; Data block at F695
  DEFB $C1,$05

; Message at F697
  DEFM "NOVI"

; Data block at F69B
  DEFB $C1,$05

; Message at F69D
  DEFM "DESE"

; Data block at F6A1
  DEFB $CF,$03,$4D,$41,$D2,$07

; Message at F6A7
  DEFM "ROSTRO"

; Data block at F6AD
  DEFB $D3,$05

; Message at F6AF
  DEFM "HACI"

; Data block at F6B3
  DEFB $C1,$04

; Message at F6B5
  DEFM "ODI"

; Data block at F6B8
  DEFB $CF,$03,$53,$55,$D3,$04

; Message at F6BE
  DEFM "OJO"

; Data block at F6C1
  DEFB $D3,$08

; Message at F6C3
  DEFM "SEGUNDO"

; Data block at F6CA
  DEFB $D3,$07

; Message at F6CC
  DEFM "SUJETA"

; Data block at F6D2
  DEFB $CE,$08

; Message at F6D4
  DEFM "CONDUCE"

; Data block at F6DB
  DEFB $CE,$07

; Message at F6DD
  DEFM "OBSERV"

; Data block at F6E3
  DEFB $C1,$0B

; Message at F6E5
  DEFM "RAPIDAMENT"

; Data block at F6EF
  DEFB $C5,$08

; Message at F6F1
  DEFM "ENCAMIN"

; Data block at F6F8
  DEFB $C1,$06

; Message at F6FA
  DEFM "CIERR"

; Data block at F6FF
  DEFB $C1,$03,$56,$4F,$DA,$03,$22,$4C
  DEFB $C5,$06

; Message at F709
  DEFM "ESTAB"

; Data block at F70E
  DEFB $C1,$09

; Message at F710
  DEFM "ESPERAND"

; Data block at F718
  DEFB $CF,$09

; Message at F71A
  DEFM "SITUACIO"

; Data block at F722
  DEFB $CE,$07

; Message at F724
  DEFM "AGENTE"

; Data block at F72A
  DEFB $D3,$0C

; Message at F72C
  DEFM "INTELIGENCI"

; Data block at F737
  DEFB $C1,$0A

; Message at F739
  DEFM "FEDERACIO"

; Data block at F742
  DEFB $CE,$03,$48,$41,$CE,$0A

; Message at F748
  DEFM "CONSEGUID"

; Data block at F751
  DEFB $CF,$09

; Message at F753
  DEFM "INFILTRA"

; Data block at F75B
  DEFB $D2,$07

; Message at F75D
  DEFM "ALGUNO"

; Data block at F763
  DEFB $D3,$07

; Message at F765
  DEFM "HOMBRE"

; Data block at F76B
  DEFB $D3,$0C

; Message at F76D
  DEFM "ORGANIZACIO"

; Data block at F778
  DEFB $CE,$07

; Message at F77A
  DEFM "REBELD"

; Data block at F780
  DEFB $C5,$05

; Message at F782
  DEFM "HEMO"

; Data block at F786
  DEFB $D3,$06

; Message at F788
  DEFM "SABID"

; Data block at F78D
  DEFB $CF,$05

; Message at F78F
  DEFM "ESTO"

; Data block at F793
  DEFB $D3,$04

; Message at F795
  DEFM "ONI"

; Data block at F798
  DEFB $D8,$06

; Message at F79A
  DEFM "DEBER"

; Data block at F79F
  DEFB $C1,$06

; Message at F7A1
  DEFM "ENTRA"

; Data block at F7A6
  DEFB $D2,$05

; Message at F7A8
  DEFM "ROBA"

; Data block at F7AC
  DEFB $D2,$08

; Message at F7AE
  DEFM "NUESTRO"

; Data block at F7B5
  DEFB $D3,$0B

; Message at F7B7
  DEFM "INFILTRADO"

; Data block at F7C1
  DEFB $D3,$05

; Message at F7C3
  DEFM "HARA"

; Data block at F7C7
  DEFB $CE,$07

; Message at F7C9
  DEFM "POSIBL"

; Data block at F7CF
  DEFB $C5,$0B

; Message at F7D1
  DEFM "FACILITARL"

; Data block at F7DB
  DEFB $C5,$05

; Message at F7DD
  DEFM "HUID"

; Data block at F7E1
  DEFB $C1,$06

; Message at F7E3
  DEFM "CUAND"

; Data block at F7E8
  DEFB $CF,$05

; Message at F7EA
  DEFM "ACAB"

; Data block at F7EE
  DEFB $C5,$07

; Message at F7F0
  DEFM "TRABAJ"

; Data block at F7F6
  DEFB $CF,$05

; Message at F7F8
  DEFM "LLAM"

; Data block at F7FC
  DEFB $C5,$06

; Message at F7FE
  DEFM "NUMER"

; Data block at F803
  DEFB $CF,$06

; Message at F805
  DEFM "10118"

; Data block at F80A
  DEFB $B5,$05

; Message at F80C
  DEFM "AHOR"

; Data block at F810
  DEFB $C1,$07

; Message at F812
  DEFM "MOMENT"

; Data block at F818
  DEFB $CF,$04

; Message at F81A
  DEFM "TOM"

; Data block at F81D
  DEFB $C5,$04

; Message at F81F
  DEFM "UNA"

; Data block at F822
  DEFB $D3,$06

; Message at F824
  DEFM "LARGA"

; Data block at F829
  DEFB $D3,$0A

; Message at F82B
  DEFM "VACACIONE"

; Data block at F834
  DEFB $D3,$04

; Message at F836
  DEFM "ECH"

; Data block at F839
  DEFB $C1,$06

; Message at F83B
  DEFM "GOLPE"

; Data block at F840
  DEFB $CF,$06

; Message at F842
  DEFM "CONTR"

; Data block at F847
  DEFB $C1,$0B

; Message at F849
  DEFM "ROMPIENDOL"

; Data block at F853
  DEFB $CF,$07

; Message at F855
  DEFM "PEDAZO"

; Data block at F85B
  DEFB $D3,$04

; Message at F85D
  DEFM "SAL"

; Data block at F860
  DEFB $C5,$06

; Message at F862
  DEFM "MEDIA"

; Data block at F867
  DEFB $D2,$07

; Message at F869
  DEFM "PALABR"

; Data block at F86F
  DEFB $C1,$0A

; Message at F871
  DEFM "ESTRANGUL"

; Data block at F87A
  DEFB $C1,$09

; Message at F87C
  DEFM "ENCERRAD"

; Data block at F884
  DEFB $CF,$07

; Message at F886
  DEFM "AAGHHF"

; Data block at F88C
  DEFB $C6,$05

; Message at F88E
  DEFM "BORR"

; Data block at F892
  DEFB $C1,$07

; Message at F894
  DEFM "APAREC"

; Data block at F89A
  DEFB $C5,$04

; Message at F89C
  DEFM "OTR"

; Data block at F89F
  DEFB $CF,$07

; Message at F8A1
  DEFM "MENSAJ"

; Data block at F8A7
  DEFB $C5,$04

; Message at F8A9
  DEFM "PON"

; Data block at F8AC
  DEFB $C5,$0E

; Message at F8AE
  DEFM "FUNCIONAMIENT"

; Data block at F8BB
  DEFB $CF,$07

; Message at F8BD
  DEFM "PERMIT"

; Data block at F8C3
  DEFB $C5,$07

; Message at F8C5
  DEFM "AVANZA"

; Data block at F8CB
  DEFB $D2,$06

; Message at F8CD
  DEFM "\"CLAV"

; Data block at F8D2
  DEFB $C5,$06

; Message at F8D4
  DEFM "FAVOR"

; Data block at F8D9
  DEFB $A2,$07

; Message at F8DB
  DEFM "\"ACCES"

; Data block at F8E1
  DEFB $CF,$0A

; Message at F8E3
  DEFM "PERMITIDO"

; Data block at F8EC
  DEFB $A2,$06

; Message at F8EE
  DEFM "APART"

; Data block at F8F3
  DEFB $C1,$04

; Message at F8F5
  DEFM "LAD"

; Data block at F8F8
  DEFB $CF,$05

; Message at F8FA
  DEFM "QUIT"

; Data block at F8FE
  DEFB $CF,$06

; Message at F900
  DEFM "PESAD"

; Data block at F905
  DEFB $C1,$06

; Message at F907
  DEFM "APART"

; Data block at F90C
  DEFB $CF,$0A

; Message at F90E
  DEFM "SUAVEMENT"

; Data block at F917
  DEFB $C5,$0F

; Message at F919
  DEFM "HIDRAULICAMENT"

; Data block at F927
  DEFB $C5,$07

; Message at F929
  DEFM "ENTREG"

; Data block at F92F
  DEFB $CF,$05

; Message at F931
  DEFM "\"BUE"

; Data block at F935
  DEFB $CE,$08

; Message at F937
  DEFM "TRABAJO"

; Data block at F93E
  DEFB $A2,$04

; Message at F940
  DEFM "JEF"

; Data block at F943
  DEFB $C5,$09

; Message at F945
  DEFM "\"NOSOTRO"

; Data block at F94D
  DEFB $D3,$09

; Message at F94F
  DEFM "SACAREMO"

; Data block at F957
  DEFB $D3,$08

; Message at F959
  DEFM "PLANETA"

; Data block at F960
  DEFB $A2,$0A

; Message at F962
  DEFM "RECOMPENS"

; Data block at F96B
  DEFB $C1,$03,$4E,$4F,$D3,$07

; Message at F971
  DEFM "PIENSA"

; Data block at F977
  DEFB $CE,$02,$48,$C5,$0B

; Message at F97C
  DEFM "TRAICIONAD"

; Data block at F986
  DEFB $CF,$0A

; Message at F988
  DEFM "DEVOLVERA"

; Data block at F991
  DEFB $CE,$07

; Message at F993
  DEFM "FRACAS"

; Data block at F999
  DEFB $CF,$05

; Message at F99B
  DEFM "CLIC"

; Data block at F99F
  DEFB $CB,$09

; Message at F9A1
  DEFM "NECESARI"

; Data block at F9A9
  DEFB $CF,$0B

; Message at F9AB
  DEFM "EMBARCADER"

; Data block at F9B5
  DEFB $CF,$0A

; Message at F9B7
  DEFM "INCORRECT"

; Data block at F9C0
  DEFB $C1,$06

; Message at F9C2
  DEFM "SIREN"

; Data block at F9C7
  DEFB $C1,$06

; Message at F9C9
  DEFM "ALARM"

; Data block at F9CE
  DEFB $C1,$08

; Message at F9D0
  DEFM "COMIENZ"

; Data block at F9D7
  DEFB $C1,$05

; Message at F9D9
  DEFM "SONA"

; Data block at F9DD
  DEFB $D2,$07

; Message at F9DF
  DEFM "DISPAR"

; Data block at F9E5
  DEFB $CF,$04

; Message at F9E7
  DEFM "TOD"

; Data block at F9EA
  DEFB $CF,$05

; Message at F9EC
  DEFM "ACAB"

; Data block at F9F0
  DEFB $CF,$07

; Message at F9F2
  DEFM "LIMOSN"

; Data block at F9F8
  DEFB $C1,$04

; Message at F9FA
  DEFM "DAL"

; Data block at F9FD
  DEFB $C5,$09

; Message at F9FF
  DEFM "DISPARAD"

; Data block at FA07
  DEFB $C1,$05

; Message at FA09
  DEFM "CLAV"

; Data block at FA0D
  DEFB $C1,$04

; Message at FA0F
  DEFM "SOL"

; Data block at FA12
  DEFB $CF,$08

; Message at FA14
  DEFM "DETENID"

; Data block at FA1B
  DEFB $CF,$05

; Message at FA1D
  DEFM "SUEN"

; Data block at FA21
  DEFB $C1,$08

; Message at FA23
  DEFM "PESTILL"

; Data block at FA2A
  DEFB $CF,$07

; Message at FA2C
  DEFM "ALGUIE"

; Data block at FA32
  DEFB $CE,$08

; Message at FA34
  DEFM "AYUDAND"

; Data block at FA3B
  DEFB $CF,$07

; Message at FA3D
  DEFM "CUMPLI"

; Data block at FA43
  DEFB $D2,$06

; Message at FA45
  DEFM "MISIO"

; Data block at FA4A
  DEFB $CE,$05

; Message at FA4C
  DEFM "MUER"

; Data block at FA50
  DEFB $C5,$08

; Message at FA52
  DEFM "INSTANT"

; Data block at FA59
  DEFB $C5,$06

; Message at FA5B
  DEFM "TIEMP"

; Data block at FA60
  DEFB $CF,$04

; Message at FA62
  DEFM "PAS"

; Data block at FA65
  DEFB $C1,$08

; Message at FA67
  DEFM "AVENTUR"

; Data block at FA6E
  DEFB $C1,$09

; Message at FA70
  DEFM "TERMINAD"

; Data block at FA78
  DEFB $CF,$03,$53,$4F,$D9,$0C

; Message at FA7E
  DEFM "DESCONECTAD"

; Data block at FA89
  DEFB $CF,$06

; Message at FA8B
  DEFM "REBOT"

; Data block at FA90
  DEFB $C1,$0A

; Message at FA92
  DEFM "QUEMARROP"

; Data block at FA9B
  DEFB $C1,$05

; Message at FA9D
  DEFM "APAG"

; Data block at FAA1
  DEFB $C1,$08

; Message at FAA3
  DEFM "CERRARS"

; Data block at FAAA
  DEFB $C5,$06

; Message at FAAC
  DEFM "CIERR"

; Data block at FAB1
  DEFB $C5,$09

; Message at FAB3
  DEFM "HERMETIC"

; Data block at FABB
  DEFB $CF,$02,$44,$C1,$03,$41,$53,$C9
  DEFB $06

; Message at FAC4
  DEFM "RAPID"

; Data block at FAC9
  DEFB $C1,$0C

; Message at FACB
  DEFM "IMPENETRABL"

; Data block at FAD6
  DEFB $C5,$08

; Message at FAD8
  DEFM "PLASTEE"

; Data block at FADF
  DEFB $CC,$09

; Message at FAE1
  DEFM "IMPOSIBL"

; Data block at FAE9
  DEFB $C5,$08

; Message at FAEB
  DEFM "FORZARL"

; Data block at FAF2
  DEFB $C1,$05

; Message at FAF4
  DEFM "SERE"

; Data block at FAF8
  DEFB $D3,$05

; Message at FAFA
  DEFM "TODA"

; Data block at FAFE
  DEFB $D3,$09

; Message at FB00
  DEFM "CONOCIDA"

; Data block at FB08
  DEFB $D3,$07

; Message at FB0A
  DEFM "ALGUNA"

; Data block at FB10
  DEFB $D3,$05

; Message at FB12
  DEFM "HABI"

; Data block at FB16
  DEFB $C1,$05

; Message at FB18
  DEFM "NUNC"

; Data block at FB1C
  DEFB $C1,$07

; Message at FB1E
  DEFM "ABIERT"

; Data block at FB24
  DEFB $C1,$05

; Message at FB26
  DEFM "HORA"

; Data block at FB2A
  DEFB $D3,$05

; Message at FB2C
  DEFM "PASA"

; Data block at FB30
  DEFB $CE,$07

; Message at FB32
  DEFM "DEPACI"

; Data block at FB38
  DEFB $CF,$0B

; Message at FB3A
  DEFM "AVERIGUARA"

; Data block at FB44
  DEFB $CE,$05

; Message at FB46
  DEFM "QUIE"

; Data block at FB4A
  DEFB $CE,$04

; Message at FB4C
  DEFM "SER"

; Data block at FB4F
  DEFB $C5,$09

; Message at FB51
  DEFM "CONDENAD"

; Data block at FB59
  DEFB $CF,$06

; Message at FB5B
  DEFM "MUERT"

; Data block at FB60
  DEFB $C5,$0B

; Message at FB62
  DEFM "PRECIPITAD"

; Data block at FB6C
  DEFB $CF,$03,$4D,$49,$D3,$08

; Message at FB72
  DEFM "ACCIONE"

; Data block at FB79
  DEFB $D3,$08

; Message at FB7B
  DEFM "DESPACI"

; Data block at FB82
  DEFB $CF,$07

; Message at FB84
  DEFM "LETRER"

; Data block at FB8A
  DEFB $CF,$03,$4C,$45,$C5,$59,$88,$B8
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$0F

; Message at FBEA
  DEFM "ESTABLECIMIENT"

; Data block at FBF8
  DEFB $CF,$07

; Message at FBFA
  DEFM "CERRAD"

; Data block at FC00
  DEFB $CF,$07

; Message at FC02
  DEFM "DESPUE"

; Data block at FC08
  DEFB $D3,$05

; Message at FC0A
  DEFM "JALE"

; Data block at FC0E
  DEFB $CF,$05

; Message at FC10
  DEFM "MIRA"

; Data block at FC14
  DEFB $D2,$05

; Message at FC16
  DEFM "NADI"

; Data block at FC1A
  DEFB $C5,$08

; Message at FC1C
  DEFM "RESPOND"

; Data block at FC23
  DEFB $C5,$03,$48,$4F,$D9,$08

; Message at FC29
  DEFM "AVERIAD"

; Data block at FC30
  DEFB $CF,$05

; Message at FC32
  DEFM "PAGU"

; Data block at FC36
  DEFB $C5,$25,$CA,$41,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$18,$18,$18,$18,$18,$00,$18
  DEFB $00,$36,$36,$00,$00,$00,$00,$00
  DEFB $00,$00,$24,$7E,$24,$24,$7E,$24
  DEFB $00,$08,$7F,$48,$7F,$09,$7F,$08
  DEFB $00,$00,$62,$64,$08,$10,$26,$46
  DEFB $00,$10,$28,$10

; Message at FD32
  DEFM "(EB="

; Data block at FD36
  DEFB $00,$18,$18,$10,$00,$00,$00,$00
  DEFB $00,$0C,$18,$18,$18,$18,$18,$0C
  DEFB $00,$18,$0C,$0C,$0C,$0C,$0C,$18
  DEFB $00,$00,$18,$7E,$3C,$7E,$18,$00
  DEFB $00,$0C,$0C,$3F,$3F,$0C,$0C,$00
  DEFB $00,$00,$00,$00,$00,$00,$18,$18
  DEFB $08,$00,$00,$3F,$3F,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$1C,$1C,$1C
  DEFB $00,$00,$00,$02,$04,$08,$10,$20
  DEFB $00,$3E,$7F

; Message at FD81
  DEFM "gks"

; Data block at FD84
  DEFB $7F,$3E,$00,$1C,$1C,$0C,$0C,$0C
  DEFB $3E,$3E,$00,$7E,$7F,$07,$1E,$38
  DEFB $7F,$7F,$00,$7E,$7F,$03,$7E,$03
  DEFB $7F,$7E,$00,$60,$66,$66,$7F,$7F
  DEFB $06,$06,$00,$7F,$7F,$60,$7E,$03
  DEFB $7F,$7E,$00,$3E,$7E,$60,$7E,$63
  DEFB $7F,$3E,$00,$7F,$7F,$07,$0E,$1C
  DEFB $38,$30,$00,$3E,$7F

; Message at FDC1
  DEFM "c>c"

; Data block at FDC4
  DEFB $7F,$3E,$00,$3E,$7F,$63,$3F,$03
  DEFB $3F,$3E,$00,$00,$00,$18,$18,$00
  DEFB $18,$18,$00,$00,$18,$18,$00,$18
  DEFB $18,$08,$00,$04,$0C,$1C,$3C,$1C
  DEFB $0C,$04,$00,$00,$7E,$7E,$00,$7E
  DEFB $7E,$00,$00

; Message at FDEF
  DEFM " 08<80 "

; Data block at FDF6
  DEFB $00,$7E,$7F,$03,$3F,$3E,$00,$30
  DEFB $30,$00

; Message at FE00
  DEFM ".TtTT"

; Data block at FE05
  DEFB $00,$00,$3E,$7F,$63,$7F,$7F,$63
  DEFB $63,$00,$7E,$7F,$03,$7E,$63,$7F
  DEFB $7E,$00,$3F,$7F,$60,$60,$60,$7F
  DEFB $3F,$00,$7E,$7F

; Message at FE21
  DEFM "ccc"

; Data block at FE24
  DEFB $7F,$7E,$00,$7F,$7F,$00,$7E,$60
  DEFB $7F,$3F,$00,$7F,$7F,$00,$7E,$60
  DEFB $60,$60,$00,$3F,$7F,$60,$6F,$63
  DEFB $7F,$3F,$00,$63,$63,$7B,$7B

; Message at FE43
  DEFM "ccc"

; Data block at FE46
  DEFB $00,$1C,$1C,$00,$1C,$1C,$1C,$1C
  DEFB $00,$7F,$7F,$00,$03,$03,$7F,$7E
  DEFB $00,$63,$67,$7E,$7C

; Message at FE5B
  DEFM "ngc"

; Data block at FE5E
  DEFB $00,$60,$60,$60,$60,$60,$7F,$7F
  DEFB $00,$7E,$7F

; Message at FE69
  DEFM "ckkkk"

; Data block at FE6E
  DEFB $00,$7E,$7F

; Message at FE71
  DEFM "ccccc"

; Data block at FE76
  DEFB $00,$3E,$7F

; Message at FE79
  DEFM "ccc"

; Data block at FE7C
  DEFB $7F,$3E,$00,$7E,$7F,$03,$7F,$7E
  DEFB $60,$60,$00,$3E,$7F

; Message at FE89
  DEFM "ccm"

; Data block at FE8C
  DEFB $7E,$3F,$03,$7E,$7F,$03,$7F,$7E
  DEFB $67,$63,$00,$38,$38,$1C,$0E,$07
  DEFB $7F,$7E,$00,$7F,$7F,$00,$60,$60
  DEFB $7F,$3F,$00

; Message at FEA7
  DEFM "ccccc"

; Data block at FEAC
  DEFB $7F,$3F,$00

; Message at FEAF
  DEFM "cccw>"

; Data block at FEB4
  DEFB $1C,$08,$00

; Message at FEB7
  DEFM "kkkkk"

; Data block at FEBC
  DEFB $7F,$3E,$00

; Message at FEBF
  DEFM "cw>"

; Data block at FEC2
  DEFB $1C

; Message at FEC3
  DEFM ">wc"

; Data block at FEC6
  DEFB $00,$63,$63,$7F,$3F,$03,$7F,$7E
  DEFB $00,$7F,$7F,$0E,$1C,$38,$7F,$7F
  DEFB $00,$00,$0E,$08,$08,$08,$08,$0E
  DEFB $00,$00,$00,$40,$20,$10,$08,$04
  DEFB $00,$00,$70,$10,$10,$10,$10,$70
  DEFB $00,$18,$3C,$7E,$18,$18,$18,$18
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $FF,$00,$1C

; Message at FF01
  DEFM "\"x  "

; Data block at FF05
  DEFB $7E,$00,$00,$00,$3E,$63,$7F,$63
  DEFB $63,$00,$00,$00,$7E,$03,$7E,$63
  DEFB $7E,$00,$00,$00,$3F,$60,$60,$60
  DEFB $3F,$00,$00,$00,$7E

; Message at FF22
  DEFM "ccc"

; Data block at FF25
  DEFB $7E,$00,$00,$00,$7F,$00,$7E,$60
  DEFB $3F,$00,$00,$00,$7F,$00,$7E,$60
  DEFB $60,$00,$00,$00,$3F,$60

; Message at FF3B
  DEFM "gc?"

; Data block at FF3E
  DEFB $00,$00,$00,$63,$63,$7B,$63,$63
  DEFB $00,$00,$00,$18,$00,$18,$18,$18
  DEFB $00,$00,$00,$7F,$00,$06,$06,$7C
  DEFB $00,$00,$00,$63,$66,$7C,$66,$63
  DEFB $00,$00,$00,$60,$60,$60,$60,$7F
  DEFB $00,$00,$00,$7E

; Message at FF6A
  DEFM "ckkk"

; Data block at FF6E
  DEFB $00,$00,$00,$7E

; Message at FF72
  DEFM "cccc"

; Unused
  DEFS $03

; Message at FF79
  DEFM ">ccc>"

; Data block at FF7E
  DEFB $00,$00,$00,$7E,$03,$7E,$60,$60
  DEFB $00,$00,$00

; Message at FF89
  DEFM ">ccm6"

; Data block at FF8E
  DEFB $03,$00,$00,$7E,$03,$7E,$67,$63
  DEFB $00,$00,$00,$1C,$0C,$06,$03,$7E
  DEFB $00,$00,$00,$7F,$00,$30,$30,$1F
  DEFB $00,$00,$00

; Message at FFA9
  DEFM "cccc?"

; Unused
  DEFS $03

; Message at FFB1
  DEFM "cc6"

; Data block at FFB4
  DEFB $1C,$08,$00,$00,$00

; Message at FFB9
  DEFM "ckkk6"

; Data block at FFBE
  DEFB $00,$00,$00,$63,$36,$1C,$36,$63
  DEFB $00,$00,$00

; Message at FFC9
  DEFM "cc?"

; Data block at FFCC
  DEFB $03,$7E,$00,$00,$00,$7F,$0E,$1C
  DEFB $38,$7F,$00,$00,$0E,$08,$30,$08
  DEFB $08,$0E,$00,$00,$08,$08,$DB,$02
  DEFB $4D,$00,$C8,$3E,$00,$00,$28,$50
  DEFB $5C,$08,$CE,$0B,$2F,$50,$06,$03
  DEFB $CE,$0B,$DB,$02,$4D,$00,$FF,$FF
  DEFB $0E,$01,$00,$00

