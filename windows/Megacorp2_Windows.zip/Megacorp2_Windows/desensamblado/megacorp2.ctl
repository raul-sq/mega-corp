@ $5C00 start
@ $5C00 org
b $5C00
t $5CD0
b $5CD6
t $5CD7
b $5CDC
t $5CE2
b $5CE6
t $5CEF
b $5CF4
t $5D04
b $5D0A
t $5D20
b $5D25
t $5DA8
b $5DAC
t $5DC0
b $5DCE
t $5E18
b $5E1B
t $5E1C
b $5E84
t $5E85
b $5F15
c $6318
  $6318 Jump to #R29015
b $631B
c $631E
  $631E Jump to #R28277
c $6321
  $6321 Jump to #R28982
c $6324
  $6324 Jump to #R29126
c $6327
  $6327 Jump to #R29098
b $632A
c $632D
  $632D Jump to #R25660
c $6330
  $6330 Jump to #R29007
c $6333
  $6333 Jump to #R29076
c $6336
  $6336 Jump to #R26818
b $6339
c $6364
  $6364 #REGhl=#N(0,4,,1)($)
  $6367 Jump to #R25457
c $6369
  $6369 #REGhl=#N(65450,4,,1)($)
  $636C Jump to #R25457
c $636E
  $636E #REGhl=#N(255,4,,1)($)
  $6371 POKE #N(25411,4,,1)($),#REGl; POKE #N(25412,4,,1)($),#REGh
  $6374 #REGe=PEEK #N(25409,4,,1)($); #REGd=PEEK #N(25410,4,,1)($)
  $6378 Push #REGde onto the stack
  $6379 CALL #R25817
  $637C Pop last item from stack into #REGbc
  $637D Return if the zero flag is not set
  $637E Push #REGbc onto the stack
  $637F Jump to #R25480
c $6381
  $6381 Push #REGde onto the stack
  $6382 CALL #R25817
  $6385 Pop last item from stack into #REGbc
  $6386 Jump to #R25491 if the zero flag is not set
  $6388 Push #REGbc onto the stack
  $6389 CALL #R25509
  $638C Pop last item from stack into #REGde
  $638D #REGd=#REGd+1
  $638E #REGa=#REGd
  $638F Set the zero flag if #REGa=#N(176,2,,1)($), or the carry flag if #REGa<#N(176,2,,1)($)
  $6391 Jump to #R25473 if #REGa<#N(176,2,,1)($)
  $6393 Pop last item from stack into #REGde
  $6394 #REGd=#REGd-1
  $6395 #REGa=#REGd
  $6396 Set the zero flag if #REGa=#N(48,2,,1)($), or the carry flag if #REGa<#N(48,2,,1)($)
  $6398 Return if #REGa<#N(48,2,,1)($)
  $6399 Push #REGde onto the stack
  $639A CALL #R25817
  $639D Pop last item from stack into #REGbc
  $639E Return if the zero flag is not set
  $639F Push #REGbc onto the stack
  $63A0 CALL #R25509
  $63A3 Jump to #R25491
c $63A5
  $63A5 Push #REGbc onto the stack
  $63A6 #REGl=PEEK #N(25411,4,,1)($); #REGh=PEEK #N(25412,4,,1)($)
  $63A9 #REGa=#REGl
  $63AA Set the zero flag if bit 0 of #REGb is 0
  $63AC Jump to #R25519 if bit 0 of #REGb is reset
  $63AE #REGa=#REGa^#REGh
  $63AF POKE #N(25413,4,,1)($),#REGa
  $63B2 #REGc=#REGc-1
  $63B3 #REGa=#REGc
  $63B4 #REGa=#REGa+1
  $63B5 CALL #R25567 if #REGa>0
  $63B8 Pop last item from stack into #REGbc
  $63B9 Jump to #R25532
  $63BC CALL #R25835
  $63BF #REGb=#REGa
  $63C0 #REGa=0
  $63C1 #REGb=#REGb+1
  $63C2 Set the carry flag
  $63C3 Rotate #REGa left through the carry flag
  $63C4 Decrement #REGb and jump to #R25539 if #REGb>0
  $63C6 #REGb=#REGa
  $63C7 CALL #R25637
  $63CA Set the zero flag if bit 0 of #REGc is 0
  $63CC Return if bit 0 of #REGc is reset
  $63CD #REGhl=#REGhl+1
  $63CE #REGa=#REGl
  $63CF Reset bits 5, 6 and 7 of #REGa
  $63D1 Return if #REGa=0
  $63D2 #REGa=PEEK #REGhl
  $63D3 Clear the carry flag and set the zero flag if #REGa=0
  $63D4 Jump to #R25635 if #REGa>0
  $63D6 #REGa=PEEK #N(25413,4,,1)($)
  $63D9 POKE #REGhl,#REGa
  $63DA CALL #R25652
  $63DD Jump to #R25549
c $63DF
  $63DF CALL #R25835
  $63E2 #REGb=#REGa
  $63E3 #REGa=0
  $63E4 #REGb=#REGb+1
  $63E5 Set the carry flag
  $63E6 Rotate #REGa left through the carry flag
  $63E7 Decrement #REGb and jump to #R25574 if #REGb>0
  $63E9 #REGb=#REGa
  $63EA CALL #R25606
  $63ED Set the zero flag if bit 7 of #REGc is 0
  $63EF Return if bit 7 of #REGc is reset
  $63F0 #REGhl=#REGhl-1
  $63F1 #REGa=#REGl
  $63F2 Reset bits 5, 6 and 7 of #REGa
  $63F4 Set the zero flag if #REGa=#N(31,2,,1)($), or the carry flag if #REGa<#N(31,2,,1)($)
  $63F6 Return if #REGa=#N(31,2,,1)($)
  $63F7 #REGa=PEEK #REGhl
  $63F8 Clear the carry flag and set the zero flag if #REGa=0
  $63F9 Jump to #R25604 if #REGa>0
  $63FB #REGa=PEEK #N(25413,4,,1)($)
  $63FE POKE #REGhl,#REGa
  $63FF CALL #R25652
  $6402 Jump to #R25584
  $6404 #REGb=#N(1,2,,1)($)
  $6406 #REGc=#N(0,2,,1)($)
  $6408 #REGa=#REGb
  $6409 #REGa=#REGa&PEEK #REGhl
  $640A Jump to #R25619 if #REGa>0
  $640C #REGa=#REGb
  $640D #REGa=#REGa|#REGc
  $640E #REGc=#REGa
  $640F Shift #REGb left (copying bit 7 into the carry flag, and resetting bit 0)
  $6411 Jump to #R25608 if the carry flag is not set
  $6413 #REGa=PEEK #N(25413,4,,1)($)
  $6416 #REGa=#REGa&#REGc
  $6417 #REGb=#REGa
  $6418 #REGa=#REGc
  $6419 #REGa=#N($FF,2,,1)($)-#REGa
  $641A #REGa=#REGa&PEEK #REGhl
  $641B #REGa=#REGa|#REGb
  $641C POKE #REGhl,#REGa
  $641D #REGa=#REGc
  $641E Clear the carry flag and set the zero flag if #REGa=0
  $641F CALL #R25652 if #REGa>0
  $6422 Return
c $6423
  $6423 #REGb=#N(128,2,,1)($)
  $6425 #REGc=#N(0,2,,1)($)
  $6427 #REGa=#REGb
  $6428 #REGa=#REGa&PEEK #REGhl
  $6429 Jump to #R25619 if #REGa>0
  $642B #REGa=#REGb
  $642C #REGa=#REGa|#REGc
  $642D #REGc=#REGa
  $642E Shift #REGb right (copying bit 0 into the carry flag, and resetting bit 7)
  $6430 Jump to #R25619 if the carry flag is set
  $6432 Jump to #R25639
c $6434
  $6434 Push #REGhl onto the stack
  $6435 Push #REGbc onto the stack
  $6436 CALL #R25792
  $6439 Pop last item from stack into #REGbc
  $643A Pop last item from stack into #REGhl
  $643B Return
c $643C
  $643C Set the zero flag if bit 7 of #REGd is 0
  $643E Jump to #R25673 if bit 7 of #REGd is set
  $6440 #REGa=#REGd
  $6441 Clear the carry flag and set the zero flag if #REGa=0
  $6442 Jump to #R25676 if #REGa=0
  $6444 #REGde=#N(255,4,,1)($)
  $6447 Jump to #R25676
  $6449 #REGde=#N(0,4,,1)($)
  $644C Set the zero flag if bit 7 of #REGh is 0
  $644E Jump to #R25698 if bit 7 of #REGh is set
  $6450 #REGa=#REGh
  $6451 Clear the carry flag and set the zero flag if #REGa=0
  $6452 Jump to #R25689 if #REGa=0
  $6454 #REGhl=#N(175,4,,1)($)
  $6457 Jump to #R25701
  $6459 #REGa=#REGl
  $645A Set the zero flag if #REGa=#N(176,2,,1)($), or the carry flag if #REGa<#N(176,2,,1)($)
  $645C Jump to #R25684 if #REGa>=#N(176,2,,1)($)
  $645E Set the zero flag if #REGa=#N(48,2,,1)($), or the carry flag if #REGa<#N(48,2,,1)($)
  $6460 Jump to #R25701 if #REGa>=#N(48,2,,1)($)
  $6462 #REGhl=#N(48,4,,1)($)
  $6465 #REGc=PEEK #N(23677,4,,1)($); #REGb=PEEK #N(23678,4,,1)($)
  $6469 Push #REGbc onto the stack
  $646A #REGa=#REGe
  $646B #REGa=#REGa-#REGc
  $646C #REGe=#N(1,2,,1)($)
  $646E Jump to #R25717 if the zero flag is set
  $6470 Jump to #R25718 if the carry flag is not set
  $6472 #REGa=#N(256,2,,1)($)-#REGa
  $6474 #REGe=#REGe-1
  $6475 #REGe=#REGe-1
  $6476 #REGc=#REGa
  $6477 #REGa=#REGl
  $6478 #REGa=#REGa-#REGb
  $6479 #REGd=#N(1,2,,1)($)
  $647B Jump to #R25730 if the zero flag is set
  $647D Jump to #R25731 if the carry flag is not set
  $647F #REGa=#N(256,2,,1)($)-#REGa
  $6481 #REGd=#REGd-1
  $6482 #REGd=#REGd-1
  $6483 #REGb=#REGa
  $6484 CALL #R9402
  $6487 Pop last item from stack into #REGbc
  $6488 Jump to #R25759
c $648A
  $648A #REGl=PEEK #N(25407,4,,1)($); #REGh=PEEK #N(25408,4,,1)($)
  $648D POKE #N(23677,4,,1)($),#REGl; POKE #N(23678,4,,1)($),#REGh
  $6490 #REGl=PEEK #N(25409,4,,1)($); #REGh=PEEK #N(25410,4,,1)($)
  $6493 #REGa=0
  $6494 #REGd=#REGa
  $6495 #REGe=#REGl
  $6496 #REGl=#REGh
  $6497 #REGh=#REGa
  $6498 Jump to #R25660
c $649B
  $649B #REGc=PEEK #N(25409,4,,1)($); #REGb=PEEK #N(25410,4,,1)($)
  $649F #REGl=PEEK #N(23693,4,,1)($); #REGh=PEEK #N(23694,4,,1)($)
  $64A2 POKE #N(23695,4,,1)($),#REGl; POKE #N(23696,4,,1)($),#REGh
  $64A5 Jump to #R8933
c $64A8
  $64A8 #REGhl=#N(22528,4,,1)($)
  $64AB #REGde=#N(41469,4,,1)($)
  $64AE #REGbc=#N(512,4,,1)($)
  $64B1 POKE #REGde,PEEK #REGhl; #REGhl=#REGhl+1; #REGde=#REGde+1; #REGbc=#REGbc-1; repeat until #REGbc=0
  $64B3 Return
b $64B4
c $64C0
  $64C0 #REGa=#REGh
  $64C1 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $64C2 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $64C3 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $64C4 Keep only bits 0 and 1 of #REGa
  $64C6 #REGa=#REGa+#N(88,2,,1)($)
  $64C8 #REGh=#REGa
  $64C9 #REGa=PEEK #N(23694,4,,1)($)
  $64CC #REGb=#REGa
  $64CD #REGa=#N($FF,2,,1)($)-#REGa
  $64CE #REGc=#REGa
  $64CF #REGa=PEEK #N(23693,4,,1)($)
  $64D2 #REGa=#REGa&#REGc
  $64D3 #REGc=#REGa
  $64D4 #REGa=#REGb
  $64D5 #REGa=#REGa&PEEK #REGhl
  $64D6 #REGa=#REGa|#REGc
  $64D7 POKE #REGhl,#REGa
  $64D8 Return
c $64D9
  $64D9 #REGa=#N(175,2,,1)($)
  $64DB #REGa=#REGa-#REGd
  $64DC #REGc=#REGe
  $64DD CALL #R25838
  $64E0 Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $64E1 Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $64E2 Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $64E3 #REGa=#REGa+#N(70,2,,1)($)
  $64E5 POKE #N(25833,4,,1)($),#REGa
  $64E8 Set the zero flag if bit 0 of (#REGhl) is 0
  $64EA Return
c $64EB
  $64EB #REGa=#N(175,2,,1)($)
  $64ED #REGa=#REGa-#REGb
  $64EE CALL #R8880
  $64F1 #REGa=#REGa-#N(7,2,,1)($)
  $64F3 #REGa=#N(256,2,,1)($)-#REGa
  $64F5 Clear the carry flag and set the zero flag if #REGa=0
  $64F6 Return
c $64F7
  $64F7 #REGe=PEEK #N(25407,4,,1)($); #REGd=PEEK #N(25408,4,,1)($)
  $64FB #REGl=PEEK #N(25409,4,,1)($); #REGh=PEEK #N(25410,4,,1)($)
  $64FE Push #REGde onto the stack
  $64FF #REGc=#REGl
  $6500 #REGb=#REGd
  $6501 Push #REGbc onto the stack
  $6502 Push #REGbc onto the stack
  $6503 Push #REGhl onto the stack
  $6504 Push #REGhl onto the stack
  $6505 #REGc=#REGe
  $6506 #REGb=#REGh
  $6507 Push #REGbc onto the stack
  $6508 Push #REGbc onto the stack
  $6509 Push #REGde onto the stack
  $650A #REGb=#N(4,2,,1)($)
  $650C Pop last item from stack into #REGhl
  $650D Pop last item from stack into #REGde
  $650E Push #REGbc onto the stack
  $650F CALL #R25878
  $6512 Pop last item from stack into #REGbc
  $6513 Decrement #REGb and jump to #R25868 if #REGb>0
  $6515 Return
c $6516
  $6516 POKE #N(23677,4,,1)($),#REGe; POKE #N(23678,4,,1)($),#REGd
  $651A Jump to #R25747
c $651D
  $651D #REGa=0
  $651E #REGl=PEEK #N(25407,4,,1)($); #REGh=PEEK #N(25408,4,,1)($)
  $6521 #REGe=#REGh
  $6522 #REGh=#REGa
  $6523 #REGd=#REGa
  $6524 POKE #N(42299,4,,1)($),#REGl; POKE #N(42300,4,,1)($),#REGh
  $6527 POKE #N(42301,4,,1)($),#REGe; POKE #N(42302,4,,1)($),#REGd
  $652B #REGe=PEEK #N(25409,4,,1)($); #REGd=PEEK #N(25410,4,,1)($)
  $652F #REGl=#REGd
  $6530 #REGh=#REGa
  $6531 #REGd=#REGa
  $6532 Jump to #R35070
b $6535
t $653C
b $653F
t $6556
b $655A
t $6560
b $6563
t $656B
b $656E
t $659D
b $65A1
t $65B1
b $65BD
t $65BE
b $65C3
t $65C7
b $65D5
t $65DC
b $65E4
t $65E8
b $65EC
t $65F1
b $65F5
t $6622
b $6625
t $663A
b $6644
t $6647
b $664A
c $664B
  $664B #REGa=#N(1,2,,1)($)
  $664D CALL #R27378
  $6650 #REGa=#N(15,2,,1)($)
  $6652 POKE #N(23624,4,,1)($),#REGa
  $6655 CALL #R28469
  $6658 #REGa=PEEK #N(25420,4,,1)($)
  $665B #REGa=#REGa+#N(2,2,,1)($)
  $665D POKE #N(28118,4,,1)($),#REGa
  $6660 CALL #R26232
  $6663 POKE #N(28050,4,,1)($),#REGa
  $6666 CALL #R26238
  $6669 POKE #N(28052,4,,1)($),#REGa
  $666C #REGhl=#N(28049,4,,1)($)
  $666F CALL #R26361
  $6672 CALL #R26381
  $6675 Jump to #R26261
c $6678
  $6678 #REGa=PEEK #N(23693,4,,1)($)
  $667B Keep only bits 0, 1 and 2 of #REGa
  $667D Return
c $667E
  $667E #REGa=PEEK #N(23693,4,,1)($)
  $6681 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $6682 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $6683 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $6684 Keep only bits 0, 1 and 2 of #REGa
  $6686 Return
b $6687
t $66A6
b $66AA
t $66AF
b $66B2
t $66C1
b $66C5
t $66D2
b $66E7
t $66EA
b $66F1
c $66F9
  $66F9 #REGa=PEEK #REGhl
  $66FA Set the zero flag if #REGa=#N(255,2,,1)($), or the carry flag if #REGa<#N(255,2,,1)($)
  $66FC Return if #REGa=#N(255,2,,1)($)
  $66FD Set the zero flag if #REGa=#N(10,2,,1)($), or the carry flag if #REGa<#N(10,2,,1)($)
  $66FF Jump to #R26374 if #REGa<>#N(10,2,,1)($)
  $6701 CALL #R28277
  $6704 Jump to #R26377
  $6706 CALL #R28842
  $6709 #REGhl=#REGhl+1
  $670A Jump to #R26361
b $670C
t $6717
b $671A
t $6737
b $673A
t $673C
b $6740
t $6755
b $6759
c $675D
  $675D #REGl=#N(56,2,,1)($)
  $675F #REGh=#N(0,2,,1)($)
  $6761 POKE #N(23693,4,,1)($),#REGl; POKE #N(23694,4,,1)($),#REGh
  $6764 POKE #N(23695,4,,1)($),#REGl; POKE #N(23696,4,,1)($),#REGh
  $6767 #REGhl=#N(23697,4,,1)($)
  $676A Reset bit 0 of (#REGhl)
  $676C Reset bit 2 of (#REGhl)
  $676E #REGhl=#N(28800,4,,1)($)
  $6771 POKE #N(25407,4,,1)($),#REGl; POKE #N(25408,4,,1)($),#REGh
  $6774 POKE #N(25409,4,,1)($),#REGl; POKE #N(25410,4,,1)($),#REGh
  $6777 #REGa=0
  $6778 Jump to #R29086
b $677B
t $678B
b $6790
t $67A2
b $67A5
t $67A7
b $67AB
t $67BF
b $67C2
t $67CF
b $67EC
t $67F0
b $6806
t $6817
b $681A
t $681E
b $6821
t $6831
b $6834
t $683A
b $683D
c $6850
  $6850 #REGixl=PEEK #N(42287,4,,1)($); #REGixh=PEEK #N(42288,4,,1)($)
  $6854 #REGl=PEEK (#REGix+#N(0,2,,1)($))
  $6857 #REGh=PEEK (#REGix+#N(1,2,,1)($))
  $685A #REGa=#REGh
  $685B #REGa=#REGa|#REGl
  $685C Return if #REGa=0
  $685D #REGc=PEEK (#REGix+#N(2,2,,1)($))
  $6860 #REGb=PEEK (#REGix+#N(3,2,,1)($))
  $6863 Clear the carry flag and set the zero flag if #REGa=0
  $6864 #REGhl=#REGhl-carry-#REGde
  $6866 Jump to #R26732 if #REGhl=0
  $6868 #REGix=#REGix+#REGbc
  $686A Jump to #R26708
  $686C #REGa=0
  $686D #REGa=#REGa+1
  $686E Return
b $686F
t $688A
b $688D
t $689F
b $68A3
t $68AF
b $68B2
t $68B8
b $68BB
c $68C2
  $68C2 #REGa=#N(201,2,,1)($)
  $68C4 POKE #N(25768,4,,1)($),#REGa
  $68C7 POKE #N(27560,4,,1)($),#REGa
  $68CA POKE #N(26187,4,,1)($),#REGa
  $68CD CALL #R26461
  $68D0 CALL #R28480
  $68D3 CALL #R27703
  $68D6 CALL #R26461
  $68D9 #REGa=#N(33,2,,1)($)
  $68DB POKE #N(25768,4,,1)($),#REGa
  $68DE #REGa=#N(62,2,,1)($)
  $68E0 POKE #N(27560,4,,1)($),#REGa
  $68E3 POKE #N(26187,4,,1)($),#REGa
  $68E6 Return
b $68E7
t $68F4
b $68F7
t $690B
b $690F
t $693B
b $693E
t $6940
b $6943
t $694D
b $6953
t $6956
b $695A
t $695B
b $6961
t $6962
b $6965
t $6972
b $6975
t $6983
b $6986
t $69AA
b $69B0
t $69D1
b $69D5
t $6A03
s $6A09
t $6A0A
b $6A11
t $6A19
b $6A1C
t $6A1F
b $6A22
t $6A23
b $6A26
t $6A32
b $6A36
t $6A4E
b $6A5F
t $6A63
b $6A76
t $6A7A
b $6A8B
t $6A8F
b $6AA1
t $6AA5
b $6AB9
t $6ABD
b $6AD6
t $6ADD
b $6AE0
t $6AE1
b $6AE4
t $6AE6
b $6AEA
c $6AF2
  $6AF2 #REGhl=#N(25426,4,,1)($)
  $6AF5 #REGd=PEEK #REGhl
  $6AF6 POKE #REGhl,#REGa
  $6AF7 Push #REGde onto the stack
  $6AF8 CALL #R5633
  $6AFB Pop last item from stack into #REGaf
  $6AFC Return
b $6AFD
t $6B14
b $6B17
t $6B30
b $6B33
t $6B3D
b $6B42
t $6B48
s $6B4B
t $6B4C
b $6B53
t $6B58
b $6B5B
t $6B61
b $6B65
t $6B6A
b $6B6D
t $6B6E
b $6B71
t $6B74
b $6B79
t $6B93
b $6B97
t $6B98
b $6B9D
t $6B9E
b $6BA2
c $6BA8
  $6BA8 #REGa=#N(1,2,,1)($)
  $6BAA CALL #R29086
  $6BAD Jump to #R25755
b $6BB0
c $6BC8
  $6BC8 #REGa=#N(1,2,,1)($)
  $6BCA POKE #N(25439,4,,1)($),#REGa
  $6BCD Jump to #R27560
b $6BD0
t $6BD2
b $6BD5
t $6BD8
b $6BDB
t $6BDC
b $6BDF
t $6C0E
b $6C11
t $6C17
b $6C1A
t $6C1B
b $6C21
c $6C37
  $6C37 #REGa=0
  $6C38 CALL #R29086
  $6C3B Push #REGix onto the stack
  $6C3D Pop last item from stack into #REGhl
  $6C3E #REGhl=#REGhl+1
  $6C3F #REGhl=#REGhl+1
  $6C40 #REGhl=#REGhl+1
  $6C41 #REGhl=#REGhl+1
  $6C42 #REGa=PEEK #REGhl
  $6C43 #REGhl=#REGhl+1
  $6C44 Exchange #REGde and #REGhl
  $6C45 #REGl=PEEK #N(25416,4,,1)($); #REGh=PEEK #N(25417,4,,1)($)
  $6C48 Push #REGhl onto the stack
  $6C49 #REGl=PEEK #N(25418,4,,1)($); #REGh=PEEK #N(25419,4,,1)($)
  $6C4C Push #REGhl onto the stack
  $6C4D POKE #N(25417,4,,1)($),#REGa
  $6C50 CALL #R27831
  $6C53 Pop last item from stack into #REGhl
  $6C54 POKE #N(25418,4,,1)($),#REGl; POKE #N(25419,4,,1)($),#REGh
  $6C57 Pop last item from stack into #REGhl
  $6C58 POKE #N(25416,4,,1)($),#REGl; POKE #N(25417,4,,1)($),#REGh
  $6C5B #REGa=#N(7,2,,1)($)
  $6C5D POKE #N(25443,4,,1)($),#REGa
  $6C60 Return
c $6C61
  $6C61 #REGa=#N(201,2,,1)($)
  $6C63 POKE #N(27871,4,,1)($),#REGa
  $6C66 Exchange #REGde and #REGhl
  $6C67 #REGe=PEEK #REGhl
  $6C68 #REGhl=#REGhl+1
  $6C69 #REGd=PEEK #REGhl
  $6C6A #REGhl=#REGhl+1
  $6C6B Push #REGhl onto the stack
  $6C6C #REGa=PEEK #N(25422,4,,1)($)
  $6C6F Push #REGaf onto the stack
  $6C70 CALL #R26704
  $6C73 CALL #R27703 if the zero flag is not set
  $6C76 Pop last item from stack into #REGaf
  $6C77 POKE #N(25422,4,,1)($),#REGa
  $6C7A #REGa=#N(205,2,,1)($)
  $6C7C POKE #N(27871,4,,1)($),#REGa
  $6C7F #REGa=0
  $6C80 CALL #R29086
  $6C83 Pop last item from stack into #REGde
  $6C84 Return
b $6C85
t $6C86
b $6C8B
t $6C9A
b $6C9D
t $6CA3
b $6CA6
t $6CAD
b $6CB0
c $6CB7
  $6CB7 POKE #N(25416,4,,1)($),#REGa
  $6CBA #REGa=#REGa+1
  $6CBB POKE #N(25422,4,,1)($),#REGa
  $6CBE #REGhl=#N(25422,4,,1)($)
  $6CC1 POKE #REGhl,(PEEK #REGhl)-1
  $6CC2 Jump to #R27867 if (PEEK #REGhl)=0
  $6CC4 #REGa=PEEK #REGde
  $6CC5 POKE #N(25443,4,,1)($),#REGa
  $6CC8 #REGde=#REGde+1
  $6CC9 Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $6CCA #REGhl=#N(28009,4,,1)($)
  $6CCD #REGa=#REGa+#REGl
  $6CCE Jump to #R27857 if the carry flag is not set
  $6CD0 #REGh=#REGh+1
  $6CD1 #REGl=#REGa
  $6CD2 #REGa=PEEK #REGhl
  $6CD3 #REGhl=#REGhl+1
  $6CD4 #REGh=PEEK #REGhl
  $6CD5 #REGl=#REGa
  $6CD6 #REGbc=#N(27838,4,,1)($)
  $6CD9 Push #REGbc onto the stack
  $6CDA Jump to #REGhl
  $6CDB POKE #N(25418,4,,1)($),#REGe; POKE #N(25419,4,,1)($),#REGd
  $6CDF CALL #R25768
  $6CE2 CALL #R26187
  $6CE5 Jump to #R27592
c $6CE8
  $6CE8 #REGa=PEEK #REGde
  $6CE9 #REGl=#REGa
  $6CEA #REGde=#REGde+1
  $6CEB #REGa=PEEK #REGde
  $6CEC #REGh=#REGa
  $6CED #REGde=#REGde+1
  $6CEE POKE #N(25407,4,,1)($),#REGl; POKE #N(25408,4,,1)($),#REGh
  $6CF1 #REGa=PEEK #REGde
  $6CF2 #REGl=#REGa
  $6CF3 #REGde=#REGde+1
  $6CF4 #REGa=PEEK #REGde
  $6CF5 #REGh=#REGa
  $6CF6 #REGde=#REGde+1
  $6CF7 POKE #N(25409,4,,1)($),#REGl; POKE #N(25410,4,,1)($),#REGh
  $6CFA Push #REGde onto the stack
  $6CFB CALL #R25454
  $6CFE Pop last item from stack into #REGde
  $6CFF Return
c $6D00
  $6D00 #REGhl=#N(25755,4,,1)($)
  $6D03 POKE #N(27900,4,,1)($),#REGl; POKE #N(27901,4,,1)($),#REGh
  $6D06 Jump to #R27889
c $6D08
  $6D08 #REGhl=#N(25885,4,,1)($)
  $6D0B POKE #N(27900,4,,1)($),#REGl; POKE #N(27901,4,,1)($),#REGh
  $6D0E Jump to #R27880
c $6D10
  $6D10 #REGhl=#N(25454,4,,1)($)
  $6D13 Jump to #R27907
c $6D15
  $6D15 #REGhl=#N(25444,4,,1)($)
  $6D18 Jump to #R27907
c $6D1A
  $6D1A #REGhl=#N(25449,4,,1)($)
  $6D1D Jump to #R27907
c $6D1F
  $6D1F #REGhl=#N(25847,4,,1)($)
  $6D22 Jump to #R27915
c $6D24
  $6D24 #REGhl=#N(25738,4,,1)($)
  $6D27 Jump to #R27915
c $6D29
  $6D29 #REGde=#REGde-1
  $6D2A #REGa=PEEK #REGde
  $6D2B CALL #R16
  $6D2C #REGde=#REGde+1
  $6D2D #REGa=PEEK #REGde
  $6D2E CALL #R16
  $6D2F #REGde=#REGde+1
  $6D30 #REGl=PEEK #N(23695,4,,1)($); #REGh=PEEK #N(23696,4,,1)($)
  $6D33 POKE #N(23693,4,,1)($),#REGl; POKE #N(23694,4,,1)($),#REGh
  $6D36 Return
c $6D37
  $6D37 #REGa=PEEK #REGde
  $6D38 #REGde=#REGde+1
  $6D39 Push #REGde onto the stack
  $6D3A Keep only bits 0, 1 and 2 of #REGa
  $6D3C OUT #N(254,2,,1)($),#REGa
  $6D3E #REGb=#N(0,2,,1)($)
  $6D40 Set the zero flag if bit 2 of #REGa is 0
  $6D42 Jump to #R27974 if bit 2 of #REGa is set
  $6D44 #REGb=#N(7,2,,1)($)
  $6D46 Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $6D47 Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $6D48 Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $6D49 #REGa=#REGa|#REGb
  $6D4A POKE #N(23624,4,,1)($),#REGa
  $6D4D #REGhl=#N(23040,4,,1)($)
  $6D50 #REGbc=#N(255,4,,1)($)
  $6D53 #REGd=#REGa
  $6D54 #REGa=PEEK #N(25423,4,,1)($)
  $6D57 #REGa=#REGa-1
  $6D58 Jump to #R28000 if #REGa=0
  $6D5A #REGhl=#N(22528,4,,1)($)
  $6D5D #REGbc=#N(767,4,,1)($)
  $6D60 #REGa=#REGd
  $6D61 #REGd=#REGh
  $6D62 #REGe=#REGl
  $6D63 #REGde=#REGde+1
  $6D64 POKE #REGhl,#REGa
  $6D65 POKE #REGde,PEEK #REGhl; #REGhl=#REGhl+1; #REGde=#REGde+1; #REGbc=#REGbc-1; repeat until #REGbc=0
  $6D67 Pop last item from stack into #REGde
  $6D68 Return
b $6D69
t $6D6A
b $6D6D
t $6D76
b $6D79
t $6D7A
b $6D7D
t $6D88
b $6D91
t $6DB0
b $6DCF
t $6DE3
b $6DE6
t $6DEA
b $6DED
t $6DF0
b $6DF4
t $6DFC
b $6E02
t $6E16
b $6E19
t $6E2C
b $6E2F
c $6E75
  $6E75 Push #REGaf onto the stack
  $6E76 Push #REGbc onto the stack
  $6E77 Push #REGde onto the stack
  $6E78 Push #REGhl onto the stack
  $6E79 Push #REGix onto the stack
  $6E7B #REGhl=#N(28357,4,,1)($)
  $6E7E Push #REGhl onto the stack
  $6E7F #REGl=PEEK #N(25428,4,,1)($); #REGh=PEEK #N(25429,4,,1)($)
  $6E82 #REGde=#N(25430,4,,1)($)
  $6E85 POKE #REGhl,#REGa
  $6E86 Clear the carry flag and set the zero flag if #REGa=0
  $6E87 #REGhl=#REGhl-carry-#REGde
  $6E89 Jump to #R28309 if #REGhl>0
  $6E8B Set the zero flag if #REGa=#N(32,2,,1)($), or the carry flag if #REGa<#N(32,2,,1)($)
  $6E8D Jump to #R28310 if #REGa<#N(32,2,,1)($)
  $6E8F Set the zero flag if #REGa=#N(165,2,,1)($), or the carry flag if #REGa<#N(165,2,,1)($)
  $6E91 Return if #REGa>=#N(165,2,,1)($)
  $6E92 Jump to #R28842
  $6E95 #REGa=PEEK #REGde
  $6E96 #REGb=#REGl
  $6E97 #REGhl=#N(28901,4,,1)($)
  $6E9A Push #REGaf onto the stack
  $6E9B #REGa=PEEK #REGhl
  $6E9C #REGa=#REGa+1
  $6E9D Jump to #R28325 if #REGa>0
  $6E9F Pop last item from stack into #REGaf
  $6EA0 POKE #N(25428,4,,1)($),#REGe; POKE #N(25429,4,,1)($),#REGd
  $6EA4 Return
  $6EA5 Pop last item from stack into #REGaf
  $6EA6 Set the zero flag if #REGa=PEEK #REGhl, or the carry flag if #REGa<PEEK #REGhl
  $6EA7 #REGhl=#REGhl+1
  $6EA8 Jump to #R28335 if the zero flag is set
  $6EAA #REGhl=#REGhl+1
  $6EAB #REGhl=#REGhl+1
  $6EAC #REGhl=#REGhl+1
  $6EAD Jump to #R28314
  $6EAF #REGa=PEEK #REGhl
  $6EB0 Set the zero flag if #REGa=#REGb, or the carry flag if #REGa<#REGb
  $6EB1 Jump to #R28347 if #REGa=#REGb
  $6EB3 #REGl=PEEK #N(25428,4,,1)($); #REGh=PEEK #N(25429,4,,1)($)
  $6EB6 #REGhl=#REGhl+1
  $6EB7 POKE #N(25428,4,,1)($),#REGl; POKE #N(25429,4,,1)($),#REGh
  $6EBA Return
  $6EBB POKE #N(25428,4,,1)($),#REGe; POKE #N(25429,4,,1)($),#REGd
  $6EBF #REGhl=#REGhl+1
  $6EC0 #REGa=PEEK #REGhl
  $6EC1 #REGhl=#REGhl+1
  $6EC2 #REGh=PEEK #REGhl
  $6EC3 #REGl=#REGa
  $6EC4 Jump to #REGhl
c $6EC5
  $6EC5 Pop last item from stack into #REGix
  $6EC7 Pop last item from stack into #REGhl
  $6EC8 Pop last item from stack into #REGde
  $6EC9 Pop last item from stack into #REGbc
  $6ECA Pop last item from stack into #REGaf
  $6ECB Return
c $6ECC
  $6ECC #REGde=#REGde+1
  $6ECD #REGa=PEEK #REGde
  $6ECE Set the zero flag if #REGa=#N(32,2,,1)($), or the carry flag if #REGa<#N(32,2,,1)($)
  $6ED0 Jump to #R28372 if #REGa>=#N(32,2,,1)($)
  $6ED2 #REGa=#N(144,2,,1)($)
  $6ED4 CALL #R28842
  $6ED7 Return
b $6ED8
c $6EFD
  $6EFD CALL #R28803
  $6F00 #REGa=#REGa+1
  $6F01 #REGb=#REGa
  $6F02 #REGa=PEEK #N(25423,4,,1)($)
  $6F05 #REGc=#N(8,2,,1)($)
  $6F07 Set the zero flag if #REGa=#N(2,2,,1)($), or the carry flag if #REGa<#N(2,2,,1)($)
  $6F09 Jump to #R28429 if #REGa<>#N(2,2,,1)($)
  $6F0B #REGc=#N(23,2,,1)($)
  $6F0D #REGa=#REGb
  $6F0E Set the zero flag if #REGa=#REGc, or the carry flag if #REGa<#REGc
  $6F0F Jump to #R28448 if #REGa<#REGc
  $6F11 #REGb=#REGb-1
  $6F12 Push #REGbc onto the stack
  $6F13 #REGb=#REGc
  $6F14 #REGa=#REGb
  $6F15 Set the zero flag if #REGa=#N(23,2,,1)($), or the carry flag if #REGa<#N(23,2,,1)($)
  $6F17 Jump to #R28442 if #REGa=#N(23,2,,1)($)
  $6F19 #REGb=#REGb-1
  $6F1A CALL #R3584
  $6F1D Pop last item from stack into #REGbc
  $6F1E Jump to #R28429
  $6F20 Push #REGaf onto the stack
  $6F21 #REGa=#N(22,2,,1)($)
  $6F23 CALL #R16
  $6F24 Pop last item from stack into #REGaf
  $6F25 CALL #R16
  $6F26 CALL #R28786
  $6F29 CALL #R16
  $6F2A Return
c $6F2B
  $6F2B #REGa=PEEK #N(25423,4,,1)($)
  $6F2E Clear the carry flag and set the zero flag if #REGa=0
  $6F2F Jump to #R28480 if #REGa=0
  $6F31 Set the zero flag if #REGa=#N(2,2,,1)($), or the carry flag if #REGa<#N(2,2,,1)($)
  $6F33 Jump to #R28496 if #REGa=#N(2,2,,1)($)
  $6F35 #REGb=#N(3,2,,1)($)
  $6F37 #REGa=PEEK #N(23624,4,,1)($)
  $6F3A CALL #R28538
  $6F3D Jump to #R28765
  $6F40 #REGb=#N(1,2,,1)($)
  $6F42 #REGa=PEEK #N(23693,4,,1)($)
  $6F45 CALL #R28538
  $6F48 #REGb=#N(2,2,,1)($)
  $6F4A CALL #R28538
  $6F4D Jump to #R28765
  $6F50 #REGb=#N(1,2,,1)($)
  $6F52 #REGa=PEEK #N(23624,4,,1)($)
  $6F55 CALL #R28538
  $6F58 #REGb=#N(2,2,,1)($)
  $6F5A CALL #R28538
  $6F5D #REGb=#N(3,2,,1)($)
  $6F5F CALL #R28538
  $6F62 Reset bits 0, 1 and 2 of #REGa
  $6F64 #REGb=#REGa
  $6F65 Keep only bits 3, 4 and 5 of #REGa
  $6F67 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $6F68 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $6F69 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $6F6A #REGa=#REGa|#REGb
  $6F6B #REGhl=#N(22528,4,,1)($)
  $6F6E #REGde=#N(22529,4,,1)($)
  $6F71 #REGbc=#N(31,4,,1)($)
  $6F74 POKE #REGhl,#REGa
  $6F75 POKE #REGde,PEEK #REGhl; #REGhl=#REGhl+1; #REGde=#REGde+1; #REGbc=#REGbc-1; repeat until #REGbc=0
  $6F77 Jump to #R28765
c $6F7A
  $6F7A Push #REGaf onto the stack
  $6F7B #REGa=#REGb
  $6F7C #REGhl=#N(14336,4,,1)($)
  $6F7F #REGde=#N(2048,4,,1)($)
  $6F82 #REGhl=#REGhl+#REGde
  $6F83 Decrement #REGb and jump to #R28546 if #REGb>0
  $6F85 #REGd=#REGh
  $6F86 #REGe=#N(1,2,,1)($)
  $6F88 #REGbc=#N(2047,4,,1)($)
  $6F8B POKE #REGhl,#N(0,2,,1)($)
  $6F8D POKE #REGde,PEEK #REGhl; #REGhl=#REGhl+1; #REGde=#REGde+1; #REGbc=#REGbc-1; repeat until #REGbc=0
  $6F8F #REGa=#REGa+#N(87,2,,1)($)
  $6F91 #REGh=#REGa
  $6F92 #REGl=#N(0,2,,1)($)
  $6F94 #REGd=#REGa
  $6F95 #REGe=#N(1,2,,1)($)
  $6F97 #REGbc=#N(255,4,,1)($)
  $6F9A Pop last item from stack into #REGaf
  $6F9B POKE #REGhl,#REGa
  $6F9C POKE #REGde,PEEK #REGhl; #REGhl=#REGhl+1; #REGde=#REGde+1; #REGbc=#REGbc-1; repeat until #REGbc=0
  $6F9E Return
c $6F9F
  $6F9F #REGa=#N(22,2,,1)($)
  $6FA1 CALL #R16
  $6FA2 CALL #R28803
  $6FA5 CALL #R16
  $6FA6 #REGa=0
  $6FA7 CALL #R16
  $6FA8 Return
b $6FA9
t $6FBB
b $6FBF
t $6FCB
b $6FD0
t $6FEC
b $6FEF
t $6FF9
b $6FFC
t $6FFE
b $7003
t $703E
b $7041
c $7043
  $7043 #REGde=#REGde+1
  $7044 #REGa=PEEK #REGde
  $7045 POKE #N(25423,4,,1)($),#REGa
  $7048 #REGa=#N($FF,2,,1)($)-#REGa
  $7049 #REGa=#REGa+#N(3,2,,1)($)
  $704B CALL #R27378
  $704E #REGa=PEEK #N(25423,4,,1)($)
  $7051 Set the zero flag if #REGa=#N(2,2,,1)($), or the carry flag if #REGa<#N(2,2,,1)($)
  $7053 #REGa=#N(8,2,,1)($)
  $7055 Jump to #R28761 if the zero flag is not set
  $7057 #REGa=#N(22,2,,1)($)
  $7059 POKE #N(23659,4,,1)($),#REGa
  $705C Return
c $705D
  $705D #REGa=#N(22,2,,1)($)
  $705F CALL #R16
  $7060 #REGa=0
  $7061 CALL #R16
  $7062 #REGa=0
  $7063 CALL #R16
  $7064 Return
c $7065
  $7065 #REGa=#N(22,2,,1)($)
  $7067 CALL #R16
  $7068 #REGde=#REGde+1
  $7069 #REGde=#REGde+1
  $706A #REGa=PEEK #REGde
  $706B #REGa=#REGa-1
  $706C CALL #R16
  $706D #REGde=#REGde-1
  $706E #REGa=PEEK #REGde
  $706F #REGa=#REGa-1
  $7070 CALL #R16
  $7071 Return
c $7072
  $7072 Push #REGhl onto the stack
  $7073 #REGa=PEEK #N(25423,4,,1)($)
  $7076 #REGhl=#N(23690,4,,1)($)
  $7079 Clear the carry flag and set the zero flag if #REGa=0
  $707A Jump to #R28798 if #REGa>0
  $707C #REGhl=#REGhl-1
  $707D #REGhl=#REGhl-1
  $707E #REGa=#N(33,2,,1)($)
  $7080 #REGa=#REGa-PEEK #REGhl
  $7081 Pop last item from stack into #REGhl
  $7082 Return
c $7083
  $7083 Push #REGhl onto the stack
  $7084 #REGa=PEEK #N(25423,4,,1)($)
  $7087 #REGhl=#N(23691,4,,1)($)
  $708A Clear the carry flag and set the zero flag if #REGa=0
  $708B Jump to #R28815 if #REGa>0
  $708D #REGhl=#REGhl-1
  $708E #REGhl=#REGhl-1
  $708F #REGa=#N(24,2,,1)($)
  $7091 #REGa=#REGa-PEEK #REGhl
  $7092 Pop last item from stack into #REGhl
  $7093 Return
b $7094
c $70AA
  $70AA Push #REGaf onto the stack
  $70AB Set the zero flag if #REGa=#N(32,2,,1)($), or the carry flag if #REGa<#N(32,2,,1)($)
  $70AD Jump to #R28898 if #REGa<#N(32,2,,1)($)
  $70AF #REGa=PEEK #N(23690,4,,1)($)
  $70B2 #REGa=#REGa-1
  $70B3 Jump to #R28898 if #REGa>0
  $70B5 #REGa=PEEK #N(25423,4,,1)($)
  $70B8 #REGa=#REGa-1
  $70B9 #REGa=PEEK #N(23691,4,,1)($)
  $70BC Jump to #R28868 if the zero flag is set
  $70BE Set the zero flag if #REGa=#N(2,2,,1)($), or the carry flag if #REGa<#N(2,2,,1)($)
  $70C0 Jump to #R28898 if #REGa<>#N(2,2,,1)($)
  $70C2 Jump to #R28872
  $70C4 Set the zero flag if #REGa=#N(17,2,,1)($), or the carry flag if #REGa<#N(17,2,,1)($)
  $70C6 Jump to #R28898 if #REGa<>#N(17,2,,1)($)
  $70C8 Push #REGbc onto the stack
  $70C9 Push #REGde onto the stack
  $70CA Push #REGhl onto the stack
  $70CB #REGa=#N(256,2,,1)($)-#REGa
  $70CD #REGa=#REGa+#N(24,2,,1)($)
  $70CF #REGb=#REGa
  $70D0 #REGa=#N(22,2,,1)($)
  $70D2 CALL #R16
  $70D3 #REGa=#REGb
  $70D4 Set the zero flag if #REGa=#N(22,2,,1)($), or the carry flag if #REGa<#N(22,2,,1)($)
  $70D6 Jump to #R28889 if #REGa<>#N(22,2,,1)($)
  $70D8 #REGb=#REGb+1
  $70D9 CALL #R16
  $70DA #REGa=0
  $70DB CALL #R16
  $70DC CALL #R3584
  $70DF Pop last item from stack into #REGhl
  $70E0 Pop last item from stack into #REGde
  $70E1 Pop last item from stack into #REGbc
  $70E2 Pop last item from stack into #REGaf
  $70E3 CALL #R16
  $70E4 Return
b $70E5
c $7136
  $7136 #REGa=PEEK #N(25423,4,,1)($)
  $7139 #REGl=PEEK #N(23690,4,,1)($); #REGh=PEEK #N(23691,4,,1)($)
  $713C Clear the carry flag and set the zero flag if #REGa=0
  $713D Jump to #R28994 if #REGa>0
  $713F #REGl=PEEK #N(23688,4,,1)($); #REGh=PEEK #N(23689,4,,1)($)
  $7142 #REGa=#N(34,2,,1)($)
  $7144 #REGa=#REGa-#REGl
  $7145 #REGl=#REGa
  $7146 #REGa=#N(25,2,,1)($)
  $7148 #REGa=#REGa-#REGh
  $7149 #REGh=#REGl
  $714A #REGl=#REGa
  $714B #REGa=PEEK #N(23692,4,,1)($)
  $714E Return
c $714F
  $714F #REGa=#N(2,2,,1)($)
  $7151 CALL #R28741
  $7154 Jump to #R28459
c $7157
  $7157 Push #REGhl onto the stack
  $7158 CALL #R29159
  $715B Jump to #R29036 if the zero flag is not set
  $715D #REGhl=#N(23611,4,,1)($)
  $7160 Reset bit 5 of (#REGhl)
  $7162 Set the zero flag if bit 5 of (#REGhl) is 0
  $7164 CALL #R29257
  $7167 Jump to #R29026 if the zero flag is set
  $7169 #REGa=PEEK #N(23560,4,,1)($)
  $716C Set the zero flag if #REGa=#N(32,2,,1)($), or the carry flag if #REGa<#N(32,2,,1)($)
  $716E Jump to #R29051 if #REGa<>#N(32,2,,1)($)
  $7170 CALL #R8020
  $7173 #REGa=#N(32,2,,1)($)
  $7175 Jump to #R29066 if the carry flag is set
  $7177 #REGa=#N(252,2,,1)($)
  $7179 Jump to #R29066
  $717B Set the zero flag if #REGa=#N(13,2,,1)($), or the carry flag if #REGa<#N(13,2,,1)($)
  $717D Jump to #R29066 if #REGa>=#N(13,2,,1)($)
  $717F #REGa=#REGa-#N(6,2,,1)($)
  $7181 #REGhl=#N(29069,4,,1)($)
  $7184 #REGa=#REGa+#REGl
  $7185 Jump to #R29064 if the carry flag is not set
  $7187 #REGh=#REGh+1
  $7188 #REGl=#REGa
  $7189 #REGa=PEEK #REGhl
  $718A Pop last item from stack into #REGhl
  $718B Set the carry flag
  $718C Return
b $718D
c $7194
  $7194 #REGe=PEEK #N(23674,4,,1)($); #REGd=PEEK #N(23675,4,,1)($)
  $7198 #REGl=PEEK #N(23672,4,,1)($); #REGh=PEEK #N(23673,4,,1)($)
  $719B #REGd=#N(0,2,,1)($)
  $719D Return
c $719E
  $719E #REGhl=#N(23697,4,,1)($)
  $71A1 Keep only bits 0 and 2 of #REGa
  $71A3 #REGb=#REGa
  $71A4 #REGa=PEEK #REGhl
  $71A5 Reset bits 0 and 2 of #REGa
  $71A7 #REGa=#REGa|#REGb
  $71A8 POKE #REGhl,#REGa
  $71A9 Return
c $71AA
  $71AA Push #REGaf onto the stack
  $71AB Push #REGhl onto the stack
  $71AC #REGa=0
  $71AD #REGhl=#N(29136,4,,1)($)
  $71B0 POKE #N(25438,4,,1)($),#REGa
  $71B3 #REGa=PEEK #N(23697,4,,1)($)
  $71B6 Push #REGaf onto the stack
  $71B7 Set bit 0 of #REGa
  $71B9 POKE #N(23697,4,,1)($),#REGa
  $71BC CALL #R26361
  $71BF Pop last item from stack into #REGaf
  $71C0 POKE #N(23697,4,,1)($),#REGa
  $71C3 Pop last item from stack into #REGhl
  $71C4 Pop last item from stack into #REGaf
  $71C5 Return
c $71C6
  $71C6 Push #REGaf onto the stack
  $71C7 Push #REGhl onto the stack
  $71C8 #REGa=#N(1,2,,1)($)
  $71CA #REGhl=#N(29139,4,,1)($)
  $71CD Jump to #R29104
b $71D0
t $71E3
b $71E6
c $71E7
  $71E7 #REGa=PEEK #N(25442,4,,1)($)
  $71EA Clear the carry flag and set the zero flag if #REGa=0
  $71EB Return if #REGa=0
  $71EC #REGhl=#N(25442,4,,1)($)
  $71EF POKE #REGhl,#N(0,2,,1)($)
  $71F1 Return
b $71F2
c $7202
  $7202 Push #REGde onto the stack
  $7203 Push #REGhl onto the stack
  $7204 CALL #R25389
  $7207 Pop last item from stack into #REGhl
  $7208 Pop last item from stack into #REGde
  $7209 #REGa=#REGd
  $720A Clear the carry flag and set the zero flag if #REGa=0
  $720B Jump to #R29207 if #REGa=0
  $720D Set the zero flag if bit 7 of #REGa is 0
  $720F Jump to #R29204 if bit 7 of #REGa is reset
  $7211 #REGa=0
  $7212 Jump to #R29206
  $7214 #REGa=#N(255,2,,1)($)
  $7216 #REGe=#REGa
  $7217 #REGa=#REGh
  $7218 Clear the carry flag and set the zero flag if #REGa=0
  $7219 Jump to #R29232 if #REGa>0
  $721B #REGa=#REGl
  $721C Set the zero flag if #REGa=#N(48,2,,1)($), or the carry flag if #REGa<#N(48,2,,1)($)
  $721E Jump to #R29224 if #REGa<#N(48,2,,1)($)
  $7220 Set the zero flag if #REGa=#N(176,2,,1)($), or the carry flag if #REGa<#N(176,2,,1)($)
  $7222 Jump to #R29226 if #REGa<#N(176,2,,1)($)
  $7224 #REGa=#N(175,2,,1)($)
  $7226 Jump to #R29226
  $7228 #REGa=#N(48,2,,1)($)
  $722A #REGd=#REGa
  $722B POKE #N(23677,4,,1)($),#REGe; POKE #N(23678,4,,1)($),#REGd
  $722F Return
  $7230 Set the zero flag if bit 7 of #REGa is 0
  $7232 Jump to #R29220 if bit 7 of #REGa is reset
  $7234 Jump to #R29224
b $7236
c $7249
  $7249 Push #REGaf onto the stack
  $724A Push #REGhl onto the stack
  $724B #REGhl=#N(29275,4,,1)($)
  $724E #REGa=PEEK #REGhl
  $724F Clear the carry flag and set the zero flag if #REGa=0
  $7250 Jump to #R29286 if #REGa=0
  $7252 #REGa=IN (#N(256,,,1)($)*#REGa+#N(254,2,,1)($))
  $7254 #REGhl=#REGhl+1
  $7255 #REGa=#REGa&PEEK #REGhl
  $7256 Jump to #R29339 if #REGa>0
  $7258 #REGhl=#REGhl+1
  $7259 Jump to #R29262
b $725B
t $726C
b $726F
t $728C
b $7291
c $729B
  $729B Pop last item from stack into #REGhl
  $729C Pop last item from stack into #REGaf
  $729D Return
b $729E
t $72A2
b $72A5
c $72AE
  $72AE #REGhl=#N(42215,4,,1)($)
  $72B1 Reset bit 7 of (#REGhl)
  $72B3 Return
c $72B4
  $72B4 #REGhl=#N(38454,4,,1)($)
  $72B7 CALL #R38357
  $72BA Return
b $72BB
c $72C7
  $72C7 Pop last item from stack into #REGhl
  $72C8 POKE #N(42241,4,,1)($),#REGsp-lo; POKE #N(42242,4,,1)($),#REGsp-hi
  $72CC Jump to #REGhl
b $72CD
c $72F9
  $72F9 #REGl=PEEK #N(42295,4,,1)($); #REGh=PEEK #N(42296,4,,1)($)
  $72FC Push #REGhl onto the stack
  $72FD Push #REGde onto the stack
  $72FE #REGde=#N(42147,4,,1)($)
  $7301 Clear the carry flag and set the zero flag if #REGa=0
  $7302 #REGhl=#REGhl-carry-#REGde
  $7304 Pop last item from stack into #REGde
  $7305 Pop last item from stack into #REGhl
  $7306 CALL #R32712 if the zero flag is set
  $7309 Do nothing
  $730A Push #REGde onto the stack
  $730B #REGhl=#REGhl-1
  $730C #REGd=PEEK #REGhl
  $730D #REGhl=#REGhl-1
  $730E #REGe=PEEK #REGhl
  $730F POKE #N(42295,4,,1)($),#REGl; POKE #N(42296,4,,1)($),#REGh
  $7312 Pop last item from stack into #REGhl
  $7313 Exchange #REGde and #REGhl
  $7314 Return
c $7315
  $7315 Exchange #REGde and #REGhl
  $7316 Push #REGhl onto the stack
  $7317 #REGl=PEEK #N(42295,4,,1)($); #REGh=PEEK #N(42296,4,,1)($)
  $731A Push #REGhl onto the stack
  $731B Push #REGde onto the stack
  $731C #REGde=#N(42211,4,,1)($)
  $731F Clear the carry flag and set the zero flag if #REGa=0
  $7320 #REGhl=#REGhl-carry-#REGde
  $7322 Pop last item from stack into #REGde
  $7323 Pop last item from stack into #REGhl
  $7324 Jump to #R29482 if the zero flag is not set
  $7326 CALL #R32712
  $7329 #REGbc=#N(9075,4,,1)($)
  $732C POKE #REGhl,#REGd
  $732D #REGhl=#REGhl+1
  $732E POKE #N(42295,4,,1)($),#REGl; POKE #N(42296,4,,1)($),#REGh
  $7331 Pop last item from stack into #REGhl
  $7332 Exchange #REGde and #REGhl
  $7333 Return
c $7334
  $7334 #REGhl=#N(42147,4,,1)($)
  $7337 POKE #N(42295,4,,1)($),#REGl; POKE #N(42296,4,,1)($),#REGh
  $733A Return
c $733B
  $733B #REGhl=#N(32767,4,,1)($)
  $733E Jump to #R29461
b $7341
c $734F
  $734F CALL #R29433
  $7352 CALL #R29461
  $7355 Jump to #R29461
c $7358
  $7358 CALL #R29433
  $735B #REGa=#REGh
  $735C #REGa=#REGa|#REGl
  $735D #REGhl=#N(0,4,,1)($)
  $7360 Jump to #R29539 if the zero flag is not set
  $7362 #REGhl=#REGhl+1
  $7363 Jump to #R29461
b $7366
c $7371
  $7371 CALL #R29433
  $7374 Exchange #REGde and #REGhl
  $7375 CALL #R29433
  $7378 Clear the carry flag and set the zero flag if #REGa=0
  $7379 #REGhl=#REGhl-carry-#REGde
  $737B Jump to #R29461
b $737E
c $738D
  $738D #REGl=PEEK #N(42221,4,,1)($); #REGh=PEEK #N(42222,4,,1)($)
  $7390 Jump to #R29461
c $7393
  $7393 CALL #R29433
  $7396 Exchange #REGde and #REGhl
  $7397 CALL #R29433
  $739A #REGa=#REGh
  $739B #REGa=#REGa&#REGd
  $739C #REGh=#REGa
  $739D #REGa=#REGl
  $739E #REGa=#REGa&#REGe
  $739F #REGl=#REGa
  $73A0 Jump to #R29461
c $73A3
  $73A3 CALL #R29433
  $73A6 Exchange #REGde and #REGhl
  $73A7 CALL #R29433
  $73AA #REGa=#REGh
  $73AB #REGa=#REGa|#REGd
  $73AC #REGh=#REGa
  $73AD #REGa=#REGl
  $73AE #REGa=#REGa|#REGe
  $73AF #REGl=#REGa
  $73B0 Jump to #R29461
c $73B3
  $73B3 CALL #R29433
  $73B6 Exchange #REGde and #REGhl
  $73B7 CALL #R29433
  $73BA #REGa=#REGh
  $73BB #REGa=#REGa^#REGd
  $73BC #REGh=#REGa
  $73BD #REGa=#REGl
  $73BE #REGa=#REGa^#REGe
  $73BF #REGl=#REGa
  $73C0 Jump to #R29461
b $73C3
t $73C6
b $73CA
t $73CB
b $73CE
c $73E1
  $73E1 CALL #R29433
  $73E4 #REGa=#REGh
  $73E5 #REGa=#REGa|#REGl
  $73E6 #REGl=PEEK #N(42216,4,,1)($); #REGh=PEEK #N(42217,4,,1)($)
  $73E9 Jump to #R29683 if the zero flag is set
  $73EB #REGa=PEEK #N(42215,4,,1)($)
  $73EE Set bit 3 of #REGa
  $73F0 POKE #N(42215,4,,1)($),#REGa
  $73F3 Return if the zero flag is not set
  $73F4 Set the zero flag if bit 7 of (#REGhl) is 0
  $73F6 Jump to #R29692 if bit 7 of PEEK #REGhl is reset
  $73F8 #REGhl=#REGhl+1
  $73F9 #REGhl=#REGhl+1
  $73FA Jump to #R29684
  $73FC #REGa=PEEK #REGhl
  $73FD Set the zero flag if #REGa=#N(63,2,,1)($), or the carry flag if #REGa<#N(63,2,,1)($)
  $73FF Jump to #R29703 if #REGa=#N(63,2,,1)($)
  $7401 Clear the carry flag and set the zero flag if #REGa=0
  $7402 Jump to #R29703 if #REGa=0
  $7404 #REGhl=#REGhl+1
  $7405 Jump to #R29684
  $7407 POKE #N(42216,4,,1)($),#REGl; POKE #N(42217,4,,1)($),#REGh
  $740A Return
c $740B
  $740B CALL #R29433
  $740E #REGa=#REGh
  $740F Clear the carry flag and set the zero flag if #REGa=0
  $7410 Jump to #R29718 if #REGa=0
  $7412 CALL #R32712
  $7415 Exchange #REGaf and #REGaf'
  $7416 #REGb=#REGl
  $7417 #REGb=#REGb+1
  $7418 #REGhl=#N(42114,4,,1)($)
  $741B #REGa=#N(128,2,,1)($)
  $741D Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $741E Jump to #R29729 if the carry flag is not set
  $7420 #REGhl=#REGhl+1
  $7421 Decrement #REGb and jump to #R29725 if #REGb>0
  $7423 #REGe=#REGa
  $7424 Flip every bit of #REGa
  $7426 #REGd=#REGa
  $7427 Return
c $7428
  $7428 CALL #R29707
  $742B #REGa=PEEK #REGhl
  $742C #REGa=#REGa|#REGe
  $742D POKE #REGhl,#REGa
  $742E Return
b $742F
c $7444
  $7444 CALL #R29707
  $7447 #REGa=PEEK #REGhl
  $7448 #REGa=#REGa&#REGe
  $7449 #REGhl=#N(0,4,,1)($)
  $744C Jump to #R29775 if the zero flag is not set
  $744E #REGhl=#REGhl+1
  $744F Jump to #R29461
b $7452
t $7469
b $746C
t $7482
b $7486
c $749C
  $749C CALL #R29619
  $749F Jump to #R29528
c $74A2
  $74A2 CALL #R29553
  $74A5 CALL #R29433
  $74A8 Set the zero flag if bit 7 of #REGh is 0
  $74AA #REGhl=#N(0,4,,1)($)
  $74AD Jump to #R29872 if the zero flag is set
  $74AF #REGhl=#REGhl+1
  $74B0 Jump to #R29461
b $74B3
c $74B8
  $74B8 CALL #R29433
  $74BB #REGa=#REGh
  $74BC Clear the carry flag and set the zero flag if #REGa=0
  $74BD Jump to #R29891 if #REGa=0
  $74BF CALL #R32712
  $74C2 #REGb=#REGb-1
  $74C3 Exchange #REGde and #REGhl
  $74C4 #REGhl=#N(41469,4,,1)($)
  $74C7 #REGhl=#REGhl+#REGde
  $74C8 #REGhl=#REGhl+#REGde
  $74C9 Return
b $74CA
c $7508
  $7508 #REGa=#REGh
  $7509 Clear the carry flag and set the zero flag if #REGa=0
  $750A Jump to #R29968 if #REGa=0
  $750C CALL #R32712
  $750F #REGb=#REGb-1
  $7510 #REGc=#REGl
  $7511 #REGl=PEEK #N(42275,4,,1)($); #REGh=PEEK #N(42276,4,,1)($)
  $7514 CALL #R35445
  $7517 Jump to #R29964 if the carry flag is set
  $7519 #REGhl=#REGhl+1
  $751A #REGhl=#REGhl+1
  $751B #REGhl=#REGhl+1
  $751C #REGde=#N(24088,4,,1)($)
  $751F CALL #R34639
  $7522 #REGde=#REGde-1
  $7523 #REGa=#REGa-1
  $7524 POKE #REGde,#REGa
  $7525 #REGhl=#N(24088,4,,1)($)
  $7528 CALL #R34924
  $752B Return
c $752C
  $752C CALL #R29433
  $752F #REGa=#REGh
  $7530 Clear the carry flag and set the zero flag if #REGa=0
  $7531 Jump to #R30007 if #REGa=0
  $7533 CALL #R32712
  $7536 #REGb=#N(77,2,,1)($)
  $7538 #REGl=PEEK #N(42285,4,,1)($); #REGh=PEEK #N(42286,4,,1)($)
  $753B CALL #R35445
  $753E Jump to #R30003 if the carry flag is set
  $7540 #REGde=#N(24088,4,,1)($)
  $7543 CALL #R34639
  $7546 #REGde=#REGde-1
  $7547 #REGa=#REGa-1
  $7548 POKE #REGde,#REGa
  $7549 #REGhl=#N(24088,4,,1)($)
  $754C Jump to #R34924
c $754F
  $754F #REGhl=#N(38577,4,,1)($)
  $7552 CALL #R34924
  $7555 Return
b $7556
t $7568
b $756B
t $756D
b $7570
c $75B6
  $75B6 CALL #R29433
  $75B9 #REGa=PEEK #N(42115,4,,1)($)
  $75BC Keep only bits 1 and 2 of #REGa
  $75BE Jump to #R30163 if #REGa>0
  $75C0 #REGa=PEEK #N(42215,4,,1)($)
  $75C3 Keep only bit 7 of #REGa
  $75C5 Jump to #R30157 if #REGa>0
  $75C7 CALL #R29364
  $75CA CALL #R29376
  $75CD #REGc=#N(251,2,,1)($)
  $75CF CALL #R30008
  $75D2 Return
  $75D3 #REGa=PEEK #N(42115,4,,1)($)
  $75D6 Set bit 0 of #REGa
  $75D8 POKE #N(42115,4,,1)($),#REGa
  $75DB #REGa=PEEK #N(42215,4,,1)($)
  $75DE Keep only bit 7 of #REGa
  $75E0 Jump to #R30221 if #REGa>0
  $75E2 Push #REGhl onto the stack
  $75E3 CALL #R29461
  $75E6 Pop last item from stack into #REGbc
  $75E7 #REGl=PEEK #N(42277,4,,1)($); #REGh=PEEK #N(42278,4,,1)($)
  $75EA CALL #R35391
  $75ED #REGc=PEEK #REGhl
  $75EE #REGhl=#REGhl+1
  $75EF #REGb=PEEK #REGhl
  $75F0 #REGa=#REGb
  $75F1 #REGa=#REGa|#REGc
  $75F2 Jump to #R30209 if #REGa=0
  $75F4 Push #REGbc onto the stack
  $75F5 CALL #R29364
  $75F8 Pop last item from stack into #REGbc
  $75F9 #REGl=PEEK #N(42287,4,,1)($); #REGh=PEEK #N(42288,4,,1)($)
  $75FC CALL #R35417
  $75FF Jump to #R30213
  $7601 CALL #R29376
  $7604 Set the carry flag
  $7605 Jump to #R30218 if the carry flag is set
  $7607 CALL #R30281
  $760A CALL #R29433
  $760D #REGb=#REGh
  $760E #REGc=#REGl
  $760F #REGl=PEEK #N(42277,4,,1)($); #REGh=PEEK #N(42278,4,,1)($)
  $7612 CALL #R35391
  $7615 #REGhl=#REGhl+1
  $7616 #REGhl=#REGhl+1
  $7617 Jump to #R30237 if the carry flag is not set
  $7619 CALL #R32712
  $761C #REGb=#REGb+1
  $761D #REGa=PEEK #REGhl
  $761E Clear the carry flag and set the zero flag if #REGa=0
  $761F Jump to #R30246 if #REGa=0
  $7621 #REGhl=#REGhl+1
  $7622 #REGhl=#REGhl+1
  $7623 #REGhl=#REGhl+1
  $7624 Jump to #R30237
  $7626 #REGhl=#REGhl+1
  $7627 CALL #R29980
  $762A #REGl=PEEK #N(42295,4,,1)($); #REGh=PEEK #N(42296,4,,1)($)
  $762D #REGe=PEEK #REGhl
  $762E #REGhl=#REGhl+1
  $762F #REGd=PEEK #REGhl
  $7630 Exchange #REGde and #REGhl
  $7631 Push #REGhl onto the stack
  $7632 #REGa=#N(201,2,,1)($)
  $7634 POKE #N(25374,4,,1)($),#REGa
  $7637 CALL #R30313
  $763A CALL #R30537
  $763D Pop last item from stack into #REGhl
  $763E Return if the zero flag is set
  $763F Push #REGhl onto the stack
  $7640 #REGc=#N(253,2,,1)($)
  $7642 CALL #R30008
  $7645 Pop last item from stack into #REGhl
  $7646 Jump to #R30313
c $7649
  $7649 Push #REGix onto the stack
  $764B Push #REGhl onto the stack
  $764C Pop last item from stack into #REGix
  $764E CALL #R25398
  $7651 Pop last item from stack into #REGix
  $7653 #REGhl=#N(38457,4,,1)($)
  $7656 CALL #R34924
  $7659 #REGhl=#N(38577,4,,1)($)
  $765C CALL #R34924
  $765F Return
c $7660
  $7660 CALL #R29581
  $7663 Jump to #R30134
c $7666
  $7666 CALL #R29433
  $7669 #REGa=#REGh
  $766A #REGa=#REGa|#REGl
  $766B Jump to #R30321 if #REGa>0
  $766D CALL #R32712
  $7670 Exchange #REGaf and #REGaf'
  $7671 Exchange #REGde and #REGhl
  $7672 #REGhl=#N(41469,4,,1)($)
  $7675 #REGa=0
  $7676 POKE #N(42224,4,,1)($),#REGa
  $7679 #REGc=PEEK #REGhl
  $767A #REGhl=#REGhl+1
  $767B #REGb=PEEK #REGhl
  $767C #REGhl=#REGhl-1
  $767D Push #REGde onto the stack
  $767E Push #REGhl onto the stack
  $767F Push #REGaf onto the stack
  $7680 #REGa=#REGb
  $7681 #REGa=#REGa^#REGd
  $7682 Jump to #R30363 if #REGa>0
  $7684 #REGa=#REGc
  $7685 #REGa=#REGa^#REGe
  $7686 Jump to #R30363 if #REGa>0
  $7688 #REGa=PEEK #N(42224,4,,1)($)
  $768B CALL #R25374
  $768E Pop last item from stack into #REGaf
  $768F Push #REGaf onto the stack
  $7690 #REGl=#REGa
  $7691 #REGh=#N(0,2,,1)($)
  $7693 CALL #R29960
  $7696 #REGa=#N(44,2,,1)($)
  $7698 POKE #N(42224,4,,1)($),#REGa
  $769B Pop last item from stack into #REGaf
  $769C Pop last item from stack into #REGhl
  $769D Pop last item from stack into #REGde
  $769E #REGhl=#REGhl+1
  $769F #REGhl=#REGhl+1
  $76A0 #REGa=#REGa+1
  $76A1 Jump to #R30329 if #REGa>0
  $76A3 #REGa=PEEK #N(42224,4,,1)($)
  $76A6 Clear the carry flag and set the zero flag if #REGa=0
  $76A7 Return
c $76A8
  $76A8 CALL #R30310
  $76AB Return if the zero flag is not set
  $76AC #REGhl=#N(38580,4,,1)($)
  $76AF CALL #R34924
  $76B2 Return
c $76B3
  $76B3 CALL #R29519
  $76B6 CALL #R29880
  $76B9 #REGe=PEEK #REGhl
  $76BA #REGhl=#REGhl+1
  $76BB #REGd=PEEK #REGhl
  $76BC #REGhl=#REGhl-1
  $76BD Exchange #REGde and #REGhl
  $76BE #REGc=PEEK #N(42221,4,,1)($); #REGb=PEEK #N(42222,4,,1)($)
  $76C2 #REGa=#REGh
  $76C3 Set the zero flag if #REGa=#N(127,2,,1)($), or the carry flag if #REGa<#N(127,2,,1)($)
  $76C5 Jump to #R30432 if #REGa<>#N(127,2,,1)($)
  $76C7 #REGc=#N(245,2,,1)($)
  $76C9 CALL #R30008
  $76CC CALL #R29433
  $76CF Jump to #R30962
b $76D2
c $76E0
  $76E0 Clear the carry flag and set the zero flag if #REGa=0
  $76E1 #REGhl=#REGhl-carry-#REGbc
  $76E3 Jump to #R30454 if #REGhl=0
  $76E5 #REGc=#N(247,2,,1)($)
  $76E7 CALL #R30008
  $76EA Jump to #R30412
b $76EC
c $76F6
  $76F6 Push #REGde onto the stack
  $76F7 CALL #R29519
  $76FA CALL #R29433
  $76FD #REGc=#REGl
  $76FE #REGl=PEEK #N(42275,4,,1)($); #REGh=PEEK #N(42276,4,,1)($)
  $7701 CALL #R35445
  $7704 Jump to #R30474 if the carry flag is not set
  $7706 CALL #R32712
  $7709 #REGb=#REGb-1
  $770A #REGe=PEEK #REGhl
  $770B #REGa=PEEK #N(42223,4,,1)($)
  $770E #REGa=#REGa+#REGe
  $770F #REGhl=#N(42218,4,,1)($)
  $7712 Set the zero flag if #REGa=PEEK #REGhl, or the carry flag if #REGa<PEEK #REGhl
  $7713 Jump to #R30497 if #REGa>=PEEK #REGhl
  $7715 POKE #N(42223,4,,1)($),#REGa
  $7718 Pop last item from stack into #REGhl
  $7719 POKE #REGhl,#N(255,2,,1)($)
  $771B #REGhl=#REGhl+1
  $771C POKE #REGhl,#N(127,2,,1)($)
  $771E Jump to #R29433
  $7721 #REGc=#N(248,2,,1)($)
  $7723 CALL #R30008
  $7726 Jump to #R30533
b $7728
t $772B
b $772E
c $7749
  $7749 Push #REGaf onto the stack
  $774A #REGa=#N(195,2,,1)($)
  $774C POKE #N(25374,4,,1)($),#REGa
  $774F Pop last item from stack into #REGaf
  $7750 Return
c $7751
  $7751 CALL #R29880
  $7754 #REGhl=#REGhl+1
  $7755 #REGa=PEEK #REGhl
  $7756 Set the zero flag if #REGa=#N(127,2,,1)($), or the carry flag if #REGa<#N(127,2,,1)($)
  $7758 #REGhl=#N(0,4,,1)($)
  $775B Jump to #R30558 if the zero flag is not set
  $775D #REGhl=#REGhl+1
  $775E Jump to #R29461
c $7761
  $7761 CALL #R29880
  $7764 #REGe=PEEK #REGhl
  $7765 #REGhl=#REGhl+1
  $7766 #REGd=PEEK #REGhl
  $7767 #REGl=PEEK #N(42221,4,,1)($); #REGh=PEEK #N(42222,4,,1)($)
  $776A Clear the carry flag and set the zero flag if #REGa=0
  $776B #REGhl=#REGhl-carry-#REGde
  $776D Jump to #R30552
b $776F
c $778A
  $778A CALL #R25374
  $778D CALL #R34379
  $7790 Return if the zero flag is not set
  $7791 Push #REGhl onto the stack
  $7792 Push #REGhl onto the stack
  $7793 CALL #R25377
  $7796 #REGb=#REGh
  $7797 Pop last item from stack into #REGhl
  $7798 #REGhl=#REGhl+1
  $7799 #REGa=PEEK #REGhl
  $779A #REGb=#REGb+1
  $779B CALL #R34379
  $779E Jump to #R30626 if the zero flag is set
  $77A0 Set the zero flag if #REGa=#N(255,2,,1)($), or the carry flag if #REGa<#N(255,2,,1)($)
  $77A2 Jump to #R30616 if #REGa<>#N(255,2,,1)($)
  $77A4 #REGa=#REGb
  $77A5 Set the zero flag if #REGa=#N(33,2,,1)($), or the carry flag if #REGa<#N(33,2,,1)($)
  $77A7 CALL #R30031 if #REGa>=#N(33,2,,1)($)
  $77AA Pop last item from stack into #REGhl
  $77AB Return
c $77AC
  $77AC CALL #R29433
  $77AF Push #REGhl onto the stack
  $77B0 CALL #R29880
  $77B3 Pop last item from stack into #REGde
  $77B4 POKE #REGhl,#REGe
  $77B5 #REGhl=#REGhl+1
  $77B6 POKE #REGhl,#REGd
  $77B7 Return
c $77B8
  $77B8 CALL #R30031
  $77BB Jump to #R30008
b $77BE
t $77D0
b $77D3
c $7805
  $7805 CALL #R29433
  $7808 POKE #N(42221,4,,1)($),#REGl; POKE #N(42222,4,,1)($),#REGh
  $780B Jump to #R30304
b $780E
c $7813
  $7813 #REGa=PEEK #N(42213,4,,1)($)
  $7816 Jump to #R30747
b $7818
c $781B
  $781B #REGl=#REGa
  $781C #REGh=#N(0,2,,1)($)
  $781E Jump to #R29461
b $7821
t $78F0
b $78F3
c $78F8
  $78F8 #REGa=PEEK #N(42215,4,,1)($)
  $78FB Set bit 6 of #REGa
  $78FD POKE #N(42215,4,,1)($),#REGa
  $7900 Return
b $7901
c $7924
  $7924 #REGa=PEEK #N(42211,4,,1)($)
  $7927 Jump to #R31020
b $7929
c $792C
  $792C #REGe=#REGa
  $792D CALL #R29433
  $7930 #REGa=#REGh
  $7931 Clear the carry flag and set the zero flag if #REGa=0
  $7932 Jump to #R31032 if #REGa=0
  $7934 CALL #R32712
  $7937 Exchange #REGaf and #REGaf'
  $7938 #REGa=#REGl
  $7939 Set the zero flag if #REGa=#REGe, or the carry flag if #REGa<#REGe
  $793A #REGhl=#N(0,4,,1)($)
  $793D Jump to #R31040 if the zero flag is not set
  $793F #REGhl=#REGhl+1
  $7940 Jump to #R29461
c $7943
  $7943 CALL #R29433
  $7946 #REGa=#REGh
  $7947 Clear the carry flag and set the zero flag if #REGa=0
  $7948 Jump to #R31054 if #REGa=0
  $794A CALL #R32712
  $794D Exchange #REGaf and #REGaf'
  $794E #REGa=#REGl
  $794F #REGl=PEEK #N(42213,4,,1)($); #REGh=PEEK #N(42214,4,,1)($)
  $7952 Set the zero flag if #REGa=#REGh, or the carry flag if #REGa<#REGh
  $7953 Jump to #R31062 if #REGa=#REGh
  $7955 Set the zero flag if #REGa=#REGl, or the carry flag if #REGa<#REGl
  $7956 Jump to #R31034
b $7958
c $7966
  $7966 Return
c $7967
  $7967 #REGa=PEEK #N(42215,4,,1)($)
  $796A Reset bits 5 and 6 of #REGa
  $796C POKE #N(42215,4,,1)($),#REGa
  $796F POKE #N(42216,4,,1)($),#REGl; POKE #N(42217,4,,1)($),#REGh
  $7972 CALL #R29492
  $7975 #REGl=PEEK #N(42216,4,,1)($); #REGh=PEEK #N(42217,4,,1)($)
  $7978 Jump to #R33456
c $797B
  $797B Set the zero flag if bit 7 of (#REGhl) is 0
  $797D #REGhl=#REGhl+1
  $797E Jump to #R31137 if the zero flag is not set
  $7980 POKE #N(42216,4,,1)($),#REGl; POKE #N(42217,4,,1)($),#REGh
  $7983 Reset bits 6 and 7 of #REGa
  $7985 #REGl=#REGa
  $7986 #REGh=#N(0,2,,1)($)
  $7988 #REGhl=#REGhl+#REGhl
  $7989 #REGde=#N(41301,4,,1)($)
  $798C #REGhl=#REGhl+#REGde
  $798D #REGix=#N(42271,4,,1)($)
  $7991 #REGe=PEEK #REGhl
  $7992 #REGhl=#REGhl+1
  $7993 #REGd=PEEK #REGhl
  $7994 CALL #R31135
  $7997 #REGa=PEEK #N(42215,4,,1)($)
  $799A Keep only bits 5 and 6 of #REGa
  $799C Jump to #R31093 if #REGa=0
  $799E Return
c $799F
  $799F Push #REGde onto the stack
  $79A0 Return
c $79A1
  $79A1 Reset bit 7 of #REGa
  $79A3 #REGd=#REGa
  $79A4 #REGa=PEEK #REGhl
  $79A5 #REGhl=#REGhl+1
  $79A6 #REGe=#REGa
  $79A7 POKE #N(42216,4,,1)($),#REGl; POKE #N(42217,4,,1)($),#REGh
  $79AA Exchange #REGde and #REGhl
  $79AB CALL #R29461
  $79AE Jump to #R31093
c $79B0
  $79B0 #REGl=PEEK #N(42275,4,,1)($); #REGh=PEEK #N(42276,4,,1)($)
  $79B3 #REGa=PEEK #REGhl
  $79B4 Clear the carry flag and set the zero flag if #REGa=0
  $79B5 Return if #REGa=0
  $79B6 #REGhl=#REGhl+1
  $79B7 #REGe=PEEK #REGhl
  $79B8 #REGd=#N(0,2,,1)($)
  $79BA #REGhl=#REGhl+1
  $79BB Push #REGde onto the stack
  $79BC Push #REGhl onto the stack
  $79BD #REGhl=#REGhl+1
  $79BE #REGc=PEEK #REGhl
  $79BF #REGhl=#REGhl+1
  $79C0 #REGb=PEEK #REGhl
  $79C1 #REGl=#REGa
  $79C2 #REGh=#N(0,2,,1)($)
  $79C4 #REGhl=#REGhl+#REGhl
  $79C5 #REGde=#N(41469,4,,1)($)
  $79C8 #REGhl=#REGhl+#REGde
  $79C9 POKE #REGhl,#REGc
  $79CA #REGhl=#REGhl+1
  $79CB POKE #REGhl,#REGb
  $79CC Pop last item from stack into #REGhl
  $79CD Pop last item from stack into #REGde
  $79CE #REGhl=#REGhl+#REGde
  $79CF Jump to #R31155
c $79D1
  $79D1 Push #REGde onto the stack
  $79D2 #REGl=PEEK #N(42289,4,,1)($); #REGh=PEEK #N(42290,4,,1)($)
  $79D5 #REGe=PEEK #REGhl
  $79D6 #REGa=#REGb
  $79D7 #REGa=#REGa|#REGc
  $79D8 #REGhl=#REGhl+1
  $79D9 Jump to #R31197 if the zero flag is not set
  $79DB Pop last item from stack into #REGde
  $79DC Return
  $79DD #REGd=#N(0,2,,1)($)
  $79DF #REGhl=#REGhl+#REGde
  $79E0 #REGbc=#REGbc-1
  $79E1 Jump to #R31189
c $79E3
  $79E3 #REGa=PEEK #REGhl
  $79E4 Clear the carry flag and set the zero flag if #REGa=0
  $79E5 Return if #REGa=0
  $79E6 Push #REGhl onto the stack
  $79E7 Push #REGde onto the stack
  $79E8 #REGhl=#REGhl+1
  $79E9 #REGc=PEEK #REGhl
  $79EA #REGhl=#REGhl+1
  $79EB #REGa=PEEK #REGhl
  $79EC Keep only bits 0, 1 and 2 of #REGa
  $79EE #REGb=#REGa
  $79EF CALL #R31185
  $79F2 #REGa=PEEK #REGhl
  $79F3 Reset bit 7 of #REGa
  $79F5 #REGc=#REGa
  $79F6 #REGa=PEEK #REGde
  $79F7 Reset bit 7 of #REGa
  $79F9 Set the zero flag if #REGa=#N(97,2,,1)($), or the carry flag if #REGa<#N(97,2,,1)($)
  $79FB Jump to #R31231 if #REGa<#N(97,2,,1)($)
  $79FD Reset bits 5 and 7 of #REGa
  $79FF Set the zero flag if #REGa=#REGc, or the carry flag if #REGa<#REGc
  $7A00 Jump to #R31241 if #REGa=#REGc
  $7A02 Pop last item from stack into #REGde
  $7A03 Pop last item from stack into #REGhl
  $7A04 #REGhl=#REGhl+1
  $7A05 #REGhl=#REGhl+1
  $7A06 #REGhl=#REGhl+1
  $7A07 Jump to #R31203
  $7A09 #REGhl=#REGhl+1
  $7A0A #REGde=#REGde+1
  $7A0B #REGa=PEEK #REGde
  $7A0C CALL #R34379
  $7A0F Jump to #R31218 if the zero flag is not set
  $7A11 Pop last item from stack into #REGde
  $7A12 Pop last item from stack into #REGhl
  $7A13 #REGa=PEEK #REGhl
  $7A14 Return
c $7A15
  $7A15 #REGa=PEEK #N(42211,4,,1)($)
  $7A18 Clear the carry flag and set the zero flag if #REGa=0
  $7A19 Return if #REGa>0
  $7A1A #REGhl=#N(42319,4,,1)($)
  $7A1D CALL #R31203
  $7A20 POKE #N(42211,4,,1)($),#REGa
  $7A23 Clear the carry flag and set the zero flag if #REGa=0
  $7A24 Jump to #R31271 if #REGa=0
  $7A26 Set the carry flag
  $7A27 Return
c $7A28
  $7A28 #REGa=PEEK #N(42212,4,,1)($)
  $7A2B Clear the carry flag and set the zero flag if #REGa=0
  $7A2C Return if #REGa>0
  $7A2D #REGl=PEEK #N(42273,4,,1)($); #REGh=PEEK #N(42274,4,,1)($)
  $7A30 CALL #R31203
  $7A33 POKE #N(42212,4,,1)($),#REGa
  $7A36 Clear the carry flag and set the zero flag if #REGa=0
  $7A37 Jump to #R31290 if #REGa=0
  $7A39 Set the carry flag
  $7A3A Return
c $7A3B
  $7A3B #REGl=PEEK #N(42213,4,,1)($); #REGh=PEEK #N(42214,4,,1)($)
  $7A3E #REGa=#REGl
  $7A3F #REGa=#REGa|#REGh
  $7A40 #REGa=#REGa&#REGh
  $7A41 Return if #REGa>0
  $7A42 #REGl=PEEK #N(42271,4,,1)($); #REGh=PEEK #N(42272,4,,1)($)
  $7A45 CALL #R31203
  $7A48 #REGhl=#N(42213,4,,1)($)
  $7A4B #REGb=#REGa
  $7A4C #REGa=PEEK #REGhl
  $7A4D Clear the carry flag and set the zero flag if #REGa=0
  $7A4E Jump to #R31313 if #REGa=0
  $7A50 #REGhl=#REGhl+1
  $7A51 POKE #REGhl,#REGb
  $7A52 Return
c $7A53
  $7A53 CALL #R31253
  $7A56 Return if the carry flag is set
  $7A57 CALL #R31272
  $7A5A Return if the carry flag is set
  $7A5B Jump to #R31291
b $7A5E
c $7A64
  $7A64 #REGl=PEEK #N(42228,4,,1)($); #REGh=PEEK #N(42229,4,,1)($)
  $7A67 #REGa=PEEK #REGhl
  $7A68 CALL #R34379
  $7A6B Jump to #R31344 if the zero flag is set
  $7A6D #REGhl=#REGhl+1
  $7A6E Jump to #R31335
  $7A70 #REGhl=#REGhl+1
  $7A71 POKE #N(42228,4,,1)($),#REGl; POKE #N(42229,4,,1)($),#REGh
  $7A74 #REGhl=#REGhl-1
  $7A75 Clear the carry flag and set the zero flag if #REGa=0
  $7A76 Return if #REGa=0
  $7A77 Set the zero flag if #REGa=#N(44,2,,1)($), or the carry flag if #REGa<#N(44,2,,1)($)
  $7A79 Return if #REGa=#N(44,2,,1)($)
  $7A7A Set the zero flag if #REGa=#N(46,2,,1)($), or the carry flag if #REGa<#N(46,2,,1)($)
  $7A7C Return if #REGa=#N(46,2,,1)($)
  $7A7D Set the zero flag if #REGa=#N(59,2,,1)($), or the carry flag if #REGa<#N(59,2,,1)($)
  $7A7F Return if #REGa=#N(59,2,,1)($)
  $7A80 Set the zero flag if #REGa=#N(33,2,,1)($), or the carry flag if #REGa<#N(33,2,,1)($)
  $7A82 Return if #REGa=#N(33,2,,1)($)
  $7A83 Reset bits 5 and 7 of #REGa
  $7A85 Set the zero flag if #REGa=#N(65,2,,1)($), or the carry flag if #REGa<#N(65,2,,1)($)
  $7A87 Jump to #R31383 if #REGa=#N(65,2,,1)($)
  $7A89 Set the zero flag if #REGa=#N(84,2,,1)($), or the carry flag if #REGa<#N(84,2,,1)($)
  $7A8B Jump to #R31413 if #REGa=#N(84,2,,1)($)
  $7A8D #REGa=PEEK #REGhl
  $7A8E CALL #R34379
  $7A91 #REGhl=#REGhl+1
  $7A92 #REGa=PEEK #REGhl
  $7A93 Jump to #R31344 if the zero flag is set
  $7A95 Jump to #R31453
  $7A97 Push #REGhl onto the stack
  $7A98 #REGhl=#REGhl+1
  $7A99 #REGa=PEEK #REGhl
  $7A9A Reset bits 5 and 7 of #REGa
  $7A9C Set the zero flag if #REGa=#N(78,2,,1)($), or the carry flag if #REGa<#N(78,2,,1)($)
  $7A9E Jump to #R31410 if #REGa<>#N(78,2,,1)($)
  $7AA0 #REGhl=#REGhl+1
  $7AA1 #REGa=PEEK #REGhl
  $7AA2 Reset bits 5 and 7 of #REGa
  $7AA4 Set the zero flag if #REGa=#N(68,2,,1)($), or the carry flag if #REGa<#N(68,2,,1)($)
  $7AA6 Jump to #R31410 if #REGa<>#N(68,2,,1)($)
  $7AA8 #REGhl=#REGhl+1
  $7AA9 #REGa=PEEK #REGhl
  $7AAA CALL #R34379
  $7AAD Jump to #R31410 if the zero flag is not set
  $7AAF Pop last item from stack into #REGde
  $7AB0 Jump to #R31446
  $7AB2 Pop last item from stack into #REGhl
  $7AB3 Jump to #R31373
  $7AB5 Push #REGhl onto the stack
  $7AB6 #REGhl=#REGhl+1
  $7AB7 #REGa=PEEK #REGhl
  $7AB8 Reset bits 5 and 7 of #REGa
  $7ABA Set the zero flag if #REGa=#N(72,2,,1)($), or the carry flag if #REGa<#N(72,2,,1)($)
  $7ABC Jump to #R31410 if #REGa<>#N(72,2,,1)($)
  $7ABE #REGhl=#REGhl+1
  $7ABF #REGa=PEEK #REGhl
  $7AC0 Reset bits 5 and 7 of #REGa
  $7AC2 Set the zero flag if #REGa=#N(69,2,,1)($), or the carry flag if #REGa<#N(69,2,,1)($)
  $7AC4 Jump to #R31410 if #REGa<>#N(69,2,,1)($)
  $7AC6 #REGhl=#REGhl+1
  $7AC7 #REGa=PEEK #REGhl
  $7AC8 Reset bits 5 and 7 of #REGa
  $7ACA Set the zero flag if #REGa=#N(78,2,,1)($), or the carry flag if #REGa<#N(78,2,,1)($)
  $7ACC Jump to #R31410 if #REGa<>#N(78,2,,1)($)
  $7ACE #REGhl=#REGhl+1
  $7ACF #REGa=PEEK #REGhl
  $7AD0 CALL #R34379
  $7AD3 Jump to #R31410 if the zero flag is not set
  $7AD5 Pop last item from stack into #REGde
  $7AD6 #REGa=0
  $7AD7 POKE #N(42228,4,,1)($),#REGl; POKE #N(42229,4,,1)($),#REGh
  $7ADA #REGa=#N(33,2,,1)($)
  $7ADC Return
  $7ADD #REGhl=#REGhl-1
  $7ADE POKE #N(42228,4,,1)($),#REGl; POKE #N(42229,4,,1)($),#REGh
  $7AE1 Return
c $7AE2
  $7AE2 #REGe=PEEK #REGhl
  $7AE3 #REGhl=#REGhl+1
  $7AE4 #REGd=PEEK #REGhl
  $7AE5 #REGhl=#REGhl+1
  $7AE6 #REGa=#REGd
  $7AE7 #REGa=#REGa|#REGe
  $7AE8 Jump to #R31468 if #REGa>0
  $7AEA Complement the carry flag
  $7AEB Return
  $7AEC #REGa=#REGd
  $7AED Set the zero flag if #REGa=#REGb, or the carry flag if #REGa<#REGb
  $7AEE Jump to #R31475 if #REGa<>#REGb
  $7AF0 #REGa=#REGe
  $7AF1 Set the zero flag if #REGa=#REGc, or the carry flag if #REGa<#REGc
  $7AF2 Return if #REGa=#REGc
  $7AF3 #REGa=PEEK #REGhl
  $7AF4 Keep only bit 7 of #REGa
  $7AF6 Jump to #R31484 if #REGa=0
  $7AF8 #REGhl=#REGhl+1
  $7AF9 #REGhl=#REGhl+1
  $7AFA Jump to #R31475
  $7AFC #REGa=PEEK #REGhl
  $7AFD Clear the carry flag and set the zero flag if #REGa=0
  $7AFE #REGhl=#REGhl+1
  $7AFF Jump to #R31458 if the zero flag is set
  $7B01 Jump to #R31475
c $7B03
  $7B03 #REGa=PEEK #N(42215,4,,1)($)
  $7B06 Reset bit 3 of #REGa
  $7B08 POKE #N(42215,4,,1)($),#REGa
  $7B0B #REGl=PEEK #N(42281,4,,1)($); #REGh=PEEK #N(42282,4,,1)($)
  $7B0E #REGc=PEEK #N(42221,4,,1)($); #REGb=PEEK #N(42222,4,,1)($)
  $7B12 CALL #R31458
  $7B15 Jump to #R31520 if the carry flag is set
  $7B17 CALL #R31079
  $7B1A #REGa=PEEK #N(42215,4,,1)($)
  $7B1D Keep only bits 5 and 6 of #REGa
  $7B1F Return if #REGa>0
  $7B20 #REGl=PEEK #N(42283,4,,1)($); #REGh=PEEK #N(42284,4,,1)($)
  $7B23 CALL #R31079
  $7B26 #REGa=PEEK #N(42215,4,,1)($)
  $7B29 Keep only bit 3 of #REGa
  $7B2B Return if #REGa>0
  $7B2C #REGc=#N(241,2,,1)($)
  $7B2E #REGl=PEEK #N(42211,4,,1)($); #REGh=PEEK #N(42212,4,,1)($)
  $7B31 #REGa=#REGh
  $7B32 #REGa=#REGa|#REGl
  $7B33 #REGl=PEEK #N(42213,4,,1)($); #REGh=PEEK #N(42214,4,,1)($)
  $7B36 #REGa=#REGa|#REGh
  $7B37 #REGa=#REGa|#REGl
  $7B38 Jump to #R31548 if #REGa>0
  $7B3A #REGc=#N(242,2,,1)($)
  $7B3C Jump to #R30008
c $7B3F
  $7B3F #REGhl=#N(41469,4,,1)($)
  $7B42 #REGde=#N(41470,4,,1)($)
  $7B45 #REGbc=#N(754,4,,1)($)
  $7B48 POKE #REGhl,#N(0,2,,1)($)
  $7B4A POKE #REGde,PEEK #REGhl; #REGhl=#REGhl+1; #REGde=#REGde+1; #REGbc=#REGbc-1; repeat until #REGbc=0
  $7B4C CALL #R31152
  $7B4F #REGa=#N(2,2,,1)($)
  $7B51 POKE #N(42115,4,,1)($),#REGa
  $7B54 #REGa=#N(250,2,,1)($)
  $7B56 POKE #N(42218,4,,1)($),#REGa
  $7B59 CALL #R25395
  $7B5C POKE #N(42219,4,,1)($),#REGl; POKE #N(42220,4,,1)($),#REGh
  $7B5F #REGl=PEEK #N(42293,4,,1)($); #REGh=PEEK #N(42294,4,,1)($)
  $7B62 POKE #N(42221,4,,1)($),#REGl; POKE #N(42222,4,,1)($),#REGh
  $7B65 #REGa=#N(1,2,,1)($)
  $7B67 CALL #R25392
  $7B6A #REGa=#N(16,2,,1)($)
  $7B6C POKE #N(42215,4,,1)($),#REGa
  $7B6F CALL #R29492
  $7B72 CALL #R29358
  $7B75 CALL #R30304
  $7B78 Return
c $7B79
  $7B79 #REGc=PEEK #N(42221,4,,1)($); #REGb=PEEK #N(42222,4,,1)($)
  $7B7D #REGl=PEEK #N(42277,4,,1)($); #REGh=PEEK #N(42278,4,,1)($)
  $7B80 CALL #R35391
  $7B83 #REGhl=#REGhl+1
  $7B84 #REGhl=#REGhl+1
  $7B85 Jump to #R31627 if the carry flag is not set
  $7B87 CALL #R32712
  $7B8A #REGb=#REGb+1
  $7B8B #REGa=PEEK #N(42211,4,,1)($)
  $7B8E #REGb=#REGa
  $7B8F #REGa=PEEK #REGhl
  $7B90 Clear the carry flag and set the zero flag if #REGa=0
  $7B91 Return if #REGa=0
  $7B92 Set the zero flag if #REGa=#REGb, or the carry flag if #REGa<#REGb
  $7B93 #REGhl=#REGhl+1
  $7B94 Jump to #R31642 if the zero flag is set
  $7B96 #REGhl=#REGhl+1
  $7B97 #REGhl=#REGhl+1
  $7B98 Jump to #R31631
  $7B9A #REGe=PEEK #REGhl
  $7B9B #REGhl=#REGhl+1
  $7B9C #REGd=PEEK #REGhl
  $7B9D Exchange #REGde and #REGhl
  $7B9E CALL #R30728
  $7BA1 #REGa=0
  $7BA2 #REGa=#REGa+1
  $7BA3 Return
c $7BA4
  $7BA4 #REGa=PEEK #N(42214,4,,1)($)
  $7BA7 #REGl=PEEK #N(42113,4,,1)($); #REGh=PEEK #N(42114,4,,1)($)
  $7BAA #REGhl=#REGhl+1
  $7BAB POKE #N(42113,4,,1)($),#REGl; POKE #N(42114,4,,1)($),#REGh
  $7BAE Clear the carry flag and set the zero flag if #REGa=0
  $7BAF Jump to #R31673 if #REGa=0
  $7BB1 #REGl=PEEK #N(42213,4,,1)($); #REGh=PEEK #N(42214,4,,1)($)
  $7BB4 POKE #N(42225,4,,1)($),#REGl; POKE #N(42226,4,,1)($),#REGh
  $7BB7 Jump to #R31682
  $7BB9 #REGa=PEEK #N(42213,4,,1)($)
  $7BBC Clear the carry flag and set the zero flag if #REGa=0
  $7BBD Jump to #R31682 if #REGa=0
  $7BBF POKE #N(42226,4,,1)($),#REGa
  $7BC2 #REGhl=#N(0,4,,1)($)
  $7BC5 POKE #N(42211,4,,1)($),#REGl; POKE #N(42212,4,,1)($),#REGh
  $7BC8 POKE #N(42213,4,,1)($),#REGl; POKE #N(42214,4,,1)($),#REGh
  $7BCB #REGa=PEEK #N(42215,4,,1)($)
  $7BCE Keep only bit 4 of #REGa
  $7BD0 Jump to #R31730 if #REGa=0
  $7BD2 #REGc=#N(240,2,,1)($)
  $7BD4 CALL #R30648
  $7BD7 #REGhl=#N(23296,4,,1)($)
  $7BDA POKE #N(42228,4,,1)($),#REGl; POKE #N(42229,4,,1)($),#REGh
  $7BDD POKE #REGhl,#N(0,2,,1)($)
  $7BDF CALL #R34268
  $7BE2 Jump to #R31698 if the carry flag is not set
  $7BE4 #REGa=PEEK #N(42215,4,,1)($)
  $7BE7 Reset bit 4 of #REGa
  $7BE9 POKE #N(42215,4,,1)($),#REGa
  $7BEC #REGa=PEEK #N(23296,4,,1)($)
  $7BEF Clear the carry flag and set the zero flag if #REGa=0
  $7BF0 Jump to #R31698 if #REGa=0
  $7BF2 #REGe=PEEK #N(42228,4,,1)($); #REGd=PEEK #N(42229,4,,1)($)
  $7BF6 CALL #R31315
  $7BF9 CALL #R31332
  $7BFC Jump to #R31730 if the zero flag is not set
  $7BFE Clear the carry flag and set the zero flag if #REGa=0
  $7BFF Jump to #R31753 if #REGa>0
  $7C01 #REGa=PEEK #N(42215,4,,1)($)
  $7C04 Set bit 4 of #REGa
  $7C06 POKE #N(42215,4,,1)($),#REGa
  $7C09 Return
c $7C0A
  $7C0A #REGa=PEEK #N(42211,4,,1)($)
  $7C0D Clear the carry flag and set the zero flag if #REGa=0
  $7C0E Jump to #R31763 if #REGa=0
  $7C10 POKE #N(42227,4,,1)($),#REGa
  $7C13 CALL #R31652
  $7C16 #REGa=PEEK #N(42213,4,,1)($)
  $7C19 #REGa=#REGa+1
  $7C1A Jump to #R31778 if #REGa>0
  $7C1C #REGa=PEEK #N(42226,4,,1)($)
  $7C1F POKE #N(42213,4,,1)($),#REGa
  $7C22 #REGa=PEEK #N(42214,4,,1)($)
  $7C25 #REGa=#REGa+1
  $7C26 Jump to #R31790 if #REGa>0
  $7C28 #REGa=PEEK #N(42226,4,,1)($)
  $7C2B POKE #N(42214,4,,1)($),#REGa
  $7C2E Return
c $7C2F
  $7C2F #REGl=PEEK #N(42317,4,,1)($); #REGh=PEEK #N(42318,4,,1)($)
  $7C32 POKE #N(42293,4,,1)($),#REGl; POKE #N(42294,4,,1)($),#REGh
  $7C35 CALL #R31807
  $7C38 #REGhl=#N(25374,4,,1)($)
  $7C3B POKE #N(34930,4,,1)($),#REGl; POKE #N(34931,4,,1)($),#REGh
  $7C3E Return
c $7C3F
  $7C3F CALL #R29383
  $7C42 #REGhl=#N(30602,4,,1)($)
  $7C45 POKE #N(34930,4,,1)($),#REGl; POKE #N(34931,4,,1)($),#REGh
  $7C48 #REGa=#N(1,2,,1)($)
  $7C4A CALL #R25392
  $7C4D #REGa=#N(128,2,,1)($)
  $7C4F POKE #N(42305,4,,1)($),#REGa
  $7C52 #REGa=#N(1,2,,1)($)
  $7C54 CALL #R25392
  $7C57 CALL #R25383
  $7C5A CALL #R31551
  $7C5D #REGl=PEEK #N(42279,4,,1)($); #REGh=PEEK #N(42280,4,,1)($)
  $7C60 CALL #R31079
  $7C63 #REGa=PEEK #N(42215,4,,1)($)
  $7C66 Keep only bit 5 of #REGa
  $7C68 Jump to #R31874 if #REGa>0
  $7C6A CALL #R31754
  $7C6D #REGhl=#N(38577,4,,1)($)
  $7C70 CALL #R34924
  $7C73 CALL #R31609
  $7C76 Jump to #R31837 if the zero flag is not set
  $7C78 CALL #R31491
  $7C7B #REGa=PEEK #N(42215,4,,1)($)
  $7C7E Keep only bit 5 of #REGa
  $7C80 Jump to #R31837 if #REGa=0
  $7C82 #REGc=#N(243,2,,1)($)
  $7C84 CALL #R30008
  $7C87 CALL #R25380
  $7C8A CALL #R25368
  $7C8D Jump to #R31810
b $7C8F
t $7DDF
b $7DE2
t $7ED3
b $7ED6
t $8023
b $8026
t $8042
b $8045
t $8047
b $804C
t $804E
b $8051
t $80CC
b $80D0
t $80DC
b $80E1
c $815B
  $815B Push #REGhl onto the stack
  $815C #REGb=#N(0,2,,1)($)
  $815E #REGa=PEEK #REGhl
  $815F Clear the carry flag and set the zero flag if #REGa=0
  $8160 Jump to #R33135 if #REGa=0
  $8162 #REGa=#N(1,2,,1)($)
  $8164 CALL #R25374
  $8167 #REGa=PEEK #REGhl
  $8168 CALL #R25374
  $816B #REGhl=#REGhl+1
  $816C #REGb=#REGb+1
  $816D Jump to #R33118
  $816F Pop last item from stack into #REGhl
  $8170 Return
c $8171
  $8171 #REGa=#REGb
  $8172 Clear the carry flag and set the zero flag if #REGa=0
  $8173 Return if #REGa=0
  $8174 #REGa=#N(8,2,,1)($)
  $8176 CALL #R25374
  $8179 Decrement #REGb and jump to #R33142 if #REGb>0
  $817B Return
c $817C
  $817C CALL #R33115
  $817F Jump to #R33137
b $8182
c $81BE
  $81BE #REGb=#REGa
  $81BF #REGa=#REGd
  $81C0 Set the zero flag if #REGa=#REGe, or the carry flag if #REGa<#REGe
  $81C1 Jump to #R33224 if #REGa<#REGe
  $81C3 #REGa=#N(7,2,,1)($)
  $81C5 Jump to #R25374
  $81C8 #REGa=#N(1,2,,1)($)
  $81CA CALL #R25374
  $81CD #REGa=#REGb
  $81CE CALL #R25374
  $81D1 Push #REGhl onto the stack
  $81D2 #REGa=PEEK #REGhl
  $81D3 POKE #REGhl,#REGb
  $81D4 #REGhl=#REGhl+1
  $81D5 #REGb=#REGa
  $81D6 Clear the carry flag and set the zero flag if #REGa=0
  $81D7 Jump to #R33234 if #REGa>0
  $81D9 POKE #REGhl,#REGb
  $81DA Pop last item from stack into #REGhl
  $81DB #REGhl=#REGhl+1
  $81DC #REGc=#REGc+1
  $81DD #REGd=#REGd+1
  $81DE Jump to #R33148
c $81E1
  $81E1 Push #REGhl onto the stack
  $81E2 Push #REGde onto the stack
  $81E3 Push #REGbc onto the stack
  $81E4 Push #REGhl onto the stack
  $81E5 #REGd=#N(0,2,,1)($)
  $81E7 #REGa=PEEK #REGhl
  $81E8 Clear the carry flag and set the zero flag if #REGa=0
  $81E9 Jump to #R33263 if #REGa=0
  $81EB #REGhl=#REGhl+1
  $81EC #REGd=#REGd+1
  $81ED Jump to #R33255
  $81EF Pop last item from stack into #REGhl
  $81F0 CALL #R33148
  $81F3 CALL #R25380
  $81F6 CALL #R25368
  $81F9 CALL #R25383
  $81FC Push #REGaf onto the stack
  $81FD Push #REGbc onto the stack
  $81FE Push #REGde onto the stack
  $81FF Push #REGhl onto the stack
  $8200 Push #REGix onto the stack
  $8202 #REGd=#N(0,2,,1)($)
  $8204 #REGa=PEEK #N(23609,4,,1)($)
  $8207 #REGe=#REGa
  $8208 #REGhl=#N(255,4,,1)($)
  $820B CALL #R949
  $820E Pop last item from stack into #REGix
  $8210 Pop last item from stack into #REGhl
  $8211 Pop last item from stack into #REGde
  $8212 Pop last item from stack into #REGbc
  $8213 Pop last item from stack into #REGaf
  $8214 Set the zero flag if #REGa=#N(252,2,,1)($), or the carry flag if #REGa<#N(252,2,,1)($)
  $8216 Jump to #R33332 if #REGa<>#N(252,2,,1)($)
  $8218 CALL #R33115
  $821B #REGa=PEEK #N(23624,4,,1)($)
  $821E Keep only bits 0, 1 and 2 of #REGa
  $8220 Push #REGaf onto the stack
  $8221 #REGhl=#N(39044,4,,1)($)
  $8224 CALL #R34924
  $8227 #REGa=#N(15,2,,1)($)
  $8229 CALL #R25374
  $822C Pop last item from stack into #REGaf
  $822D CALL #R25374
  $8230 Pop last item from stack into #REGbc
  $8231 Pop last item from stack into #REGde
  $8232 Pop last item from stack into #REGhl
  $8233 Return
  $8234 Set the zero flag if #REGa=#N(253,2,,1)($), or the carry flag if #REGa<#N(253,2,,1)($)
  $8236 Jump to #R33346 if #REGa<>#N(253,2,,1)($)
  $8238 #REGa=PEEK #N(23658,4,,1)($)
  $823B Flip bit 3 of #REGa
  $823D POKE #N(23658,4,,1)($),#REGa
  $8240 Jump to #R33267
  $8242 Set the zero flag if #REGa=#N(13,2,,1)($), or the carry flag if #REGa<#N(13,2,,1)($)
  $8244 Jump to #R33353 if #REGa<>#N(13,2,,1)($)
  $8246 Jump to #R33679
  $8249 Set the zero flag if #REGa=#N(127,2,,1)($), or the carry flag if #REGa<#N(127,2,,1)($)
  $824B Jump to #R33362 if #REGa<>#N(127,2,,1)($)
  $824D CALL #R33166
  $8250 Jump to #R33267
  $8252 Set the zero flag if #REGa=#N(16,2,,1)($), or the carry flag if #REGa<#N(16,2,,1)($)
  $8254 Jump to #R33371 if #REGa<>#N(16,2,,1)($)
  $8256 CALL #R33191
  $8259 Jump to #R33360
  $825B Set the zero flag if #REGa=#N(242,2,,1)($), or the carry flag if #REGa<#N(242,2,,1)($)
  $825D Jump to #R33392 if #REGa<>#N(242,2,,1)($)
  $825F #REGa=#REGc
  $8260 Clear the carry flag and set the zero flag if #REGa=0
  $8261 Jump to #R33386 if #REGa>0
  $8263 #REGa=#N(7,2,,1)($)
  $8265 CALL #R25374
  $8268 Jump to #R33369
  $826A #REGhl=#REGhl-1
  $826B #REGc=#REGc-1
  $826C #REGa=#N(8,2,,1)($)
  $826E Jump to #R33381
  $8270 Set the zero flag if #REGa=#N(243,2,,1)($), or the carry flag if #REGa<#N(243,2,,1)($)
  $8272 Jump to #R33413 if #REGa<>#N(243,2,,1)($)
  $8274 #REGa=PEEK #REGhl
  $8275 Clear the carry flag and set the zero flag if #REGa=0
  $8276 Jump to #R33407 if #REGa>0
  $8278 #REGa=#N(7,2,,1)($)
  $827A CALL #R25374
  $827D Jump to #R33384
  $827F #REGhl=#REGhl+1
  $8280 #REGc=#REGc+1
  $8281 #REGa=#N(9,2,,1)($)
  $8283 Jump to #R33402
  $8285 CALL #R33444
  $8288 Jump to #R33405
c $828A
  $828A #REGc=#N(0,2,,1)($)
  $828C Jump to #R33249
b $828F
c $829B
  $829B #REGe=#N(255,2,,1)($)
  $829D Jump to #R33418
b $82A0
c $82A4
  $82A4 Set the zero flag if #REGa=#N(252,2,,1)($), or the carry flag if #REGa<#N(252,2,,1)($)
  $82A6 Return if #REGa=#N(252,2,,1)($)
  $82A7 Set the zero flag if #REGa=#N(128,2,,1)($), or the carry flag if #REGa<#N(128,2,,1)($)
  $82A9 Return if #REGa>=#N(128,2,,1)($)
  $82AA Set the zero flag if #REGa=#N(32,2,,1)($), or the carry flag if #REGa<#N(32,2,,1)($)
  $82AC Return if #REGa<#N(32,2,,1)($)
  $82AD Jump to #R33214
c $82B0
  $82B0 #REGa=PEEK #REGhl
  $82B1 Clear the carry flag and set the zero flag if #REGa=0
  $82B2 Jump to #R31099 if #REGa>0
  $82B5 Push #REGhl onto the stack
  $82B6 #REGhl=#N(0,4,,1)($)
  $82B9 POKE #N(42216,4,,1)($),#REGl; POKE #N(42217,4,,1)($),#REGh
  $82BC Pop last item from stack into #REGhl
  $82BD Return
b $82BE
t $836E
b $8371
c $8378
  $8378 CALL #R29581
  $837B Jump to #R29852
b $837E
c $838F
  $838F CALL #R33115
  $8392 Set the carry flag
  $8393 Jump to #R33328
b $8396
t $839C
b $839F
t $83A6
b $83A9
t $83CC
b $83CF
t $8439
b $843C
t $8455
b $8459
t $848D
b $8490
c $8505
  $8505 Pop last item from stack into #REGde
  $8506 Pop last item from stack into #REGhl
  $8507 #REGl=PEEK #N(42301,4,,1)($); #REGh=PEEK #N(42302,4,,1)($)
  $850A #REGe=PEEK #N(42299,4,,1)($); #REGd=PEEK #N(42300,4,,1)($)
  $850E Jump to #R29193
b $8511
c $8538
  $8538 #REGhl=#N(34129,4,,1)($)
  $853B POKE #N(23613,4,,1)($),#REGl; POKE #N(23614,4,,1)($),#REGh
  $853E #REGsp=#N(23999,4,,1)($)
  $8541 #REGa=#N(24,2,,1)($)
  $8543 POKE #N(33302,4,,1)($),#REGa
  $8546 #REGhl=#N(65535,4,,1)($)
  $8549 POKE #N(42269,4,,1)($),#REGl; POKE #N(42270,4,,1)($),#REGh
  $854C Jump to #R31791
b $854F
t $8598
b $859B
c $85DC
  $85DC CALL #R33435
  $85DF Return if the carry flag is set
  $85E0 Jump to #R33607
b $85E3
t $8618
b $861B
t $8638
b $863B
c $864B
  $864B Clear the carry flag and set the zero flag if #REGa=0
  $864C Return if #REGa=0
  $864D Set the zero flag if #REGa=#N(32,2,,1)($), or the carry flag if #REGa<#N(32,2,,1)($)
  $864F Return if #REGa=#N(32,2,,1)($)
  $8650 Set the zero flag if #REGa=#N(46,2,,1)($), or the carry flag if #REGa<#N(46,2,,1)($)
  $8652 Return if #REGa=#N(46,2,,1)($)
  $8653 Set the zero flag if #REGa=#N(44,2,,1)($), or the carry flag if #REGa<#N(44,2,,1)($)
  $8655 Return if #REGa=#N(44,2,,1)($)
  $8656 Set the zero flag if #REGa=#N(45,2,,1)($), or the carry flag if #REGa<#N(45,2,,1)($)
  $8658 Return if #REGa=#N(45,2,,1)($)
  $8659 Set the zero flag if #REGa=#N(33,2,,1)($), or the carry flag if #REGa<#N(33,2,,1)($)
  $865B Return if #REGa=#N(33,2,,1)($)
  $865C Set the zero flag if #REGa=#N(63,2,,1)($), or the carry flag if #REGa<#N(63,2,,1)($)
  $865E Return if #REGa=#N(63,2,,1)($)
  $865F Set the zero flag if #REGa=#N(58,2,,1)($), or the carry flag if #REGa<#N(58,2,,1)($)
  $8661 Return
b $8662
t $86D6
b $86D9
c $874F
  $874F Push #REGbc onto the stack
  $8750 #REGc=PEEK #REGhl
  $8751 #REGhl=#REGhl+1
  $8752 #REGa=PEEK #REGhl
  $8753 #REGhl=#REGhl+1
  $8754 #REGb=#REGa
  $8755 Keep only bits 6 and 7 of #REGa
  $8757 Set the zero flag if #REGa=#N(192,2,,1)($), or the carry flag if #REGa<#N(192,2,,1)($)
  $8759 Jump to #R34741 if #REGa=#N(192,2,,1)($)
  $875C Push #REGhl onto the stack
  $875D Push #REGde onto the stack
  $875E Push #REGbc onto the stack
  $875F #REGa=#REGb
  $8760 Keep only bits 0, 1 and 2 of #REGa
  $8762 #REGb=#REGa
  $8763 #REGl=PEEK #N(42289,4,,1)($); #REGh=PEEK #N(42290,4,,1)($)
  $8766 #REGa=#REGb
  $8767 #REGa=#REGa|#REGc
  $8768 Jump to #R34674 if #REGa=0
  $876A #REGe=PEEK #REGhl
  $876B #REGd=#N(0,2,,1)($)
  $876D #REGhl=#REGhl+1
  $876E #REGbc=#REGbc-1
  $876F #REGhl=#REGhl+#REGde
  $8770 Jump to #R34662
  $8772 #REGhl=#REGhl+1
  $8773 Pop last item from stack into #REGbc
  $8774 Pop last item from stack into #REGde
  $8775 #REGa=#REGb
  $8776 Keep only bits 6 and 7 of #REGa
  $8778 Set the zero flag if #REGa=#N(64,2,,1)($), or the carry flag if #REGa<#N(64,2,,1)($)
  $877A Jump to #R34696 if #REGa<>#N(64,2,,1)($)
  $877C #REGa=PEEK #REGhl
  $877D Keep only bit 6 of #REGa
  $877F Set the zero flag if #REGa=#N(64,2,,1)($), or the carry flag if #REGa<#N(64,2,,1)($)
  $8781 #REGa=PEEK #REGhl
  $8782 Jump to #R34706 if the zero flag is not set
  $8784 Set bit 5 of #REGa
  $8786 Jump to #R34706
  $8788 Set the zero flag if #REGa=#N(128,2,,1)($), or the carry flag if #REGa<#N(128,2,,1)($)
  $878A Jump to #R34703 if #REGa<>#N(128,2,,1)($)
  $878C #REGa=PEEK #REGhl
  $878D Jump to #R34706
  $878F #REGa=PEEK #REGhl
  $8790 Set bit 6 of #REGb
  $8792 Reset bit 7 of #REGa
  $8794 POKE #REGde,#REGa
  $8795 #REGa=PEEK #REGhl
  $8796 #REGhl=#REGhl+1
  $8797 #REGde=#REGde+1
  $8798 Keep only bit 7 of #REGa
  $879A Jump to #R34677 if #REGa=0
  $879C #REGa=#REGb
  $879D Keep only bits 3, 4 and 5 of #REGa
  $879F Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $87A0 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $87A1 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $87A2 Push #REGhl onto the stack
  $87A3 #REGhl=#N(41445,4,,1)($)
  $87A6 #REGc=#REGa
  $87A7 #REGb=#N(0,2,,1)($)
  $87A9 #REGhl=#REGhl+#REGbc
  $87AA #REGa=PEEK #REGhl
  $87AB Pop last item from stack into #REGhl
  $87AC POKE #REGde,#REGa
  $87AD #REGde=#REGde+1
  $87AE Pop last item from stack into #REGhl
  $87AF Clear the carry flag and set the zero flag if #REGa=0
  $87B0 Jump to #R34640 if #REGa>0
  $87B3 Pop last item from stack into #REGbc
  $87B4 Return
  $87B5 #REGa=#REGb
  $87B6 Keep only bits 3, 4 and 5 of #REGa
  $87B8 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $87B9 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $87BA Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $87BB Push #REGbc onto the stack
  $87BC Push #REGhl onto the stack
  $87BD #REGhl=#N(41445,4,,1)($)
  $87C0 #REGc=#REGa
  $87C1 #REGb=#N(0,2,,1)($)
  $87C3 #REGhl=#REGhl+#REGbc
  $87C4 #REGa=PEEK #REGhl
  $87C5 Pop last item from stack into #REGhl
  $87C6 Pop last item from stack into #REGbc
  $87C7 #REGb=#REGc
  $87C8 POKE #REGde,#REGa
  $87C9 #REGde=#REGde+1
  $87CA Clear the carry flag and set the zero flag if #REGa=0
  $87CB Jump to #R34739 if #REGa=0
  $87CD Decrement #REGb and jump to #R34760 if #REGb>0
  $87CF Jump to #R34640
b $87D2
t $87DD
b $87E2
c $8859
  $8859 #REGhl=#N(0,4,,1)($)
  $885C Push #REGde onto the stack
  $885D Push #REGbc onto the stack
  $885E #REGd=#N(0,2,,1)($)
  $8860 #REGb=#N(8,2,,1)($)
  $8862 #REGhl=#REGhl+#REGhl
  $8863 Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $8864 Jump to #R34919 if the carry flag is not set
  $8866 #REGhl=#REGhl+#REGde
  $8867 Decrement #REGb and jump to #R34914 if #REGb>0
  $8869 Pop last item from stack into #REGbc
  $886A Pop last item from stack into #REGde
  $886B Return
c $886C
  $886C #REGa=PEEK #REGhl
  $886D #REGhl=#REGhl+1
  $886E Set the zero flag if #REGa=#N(255,2,,1)($), or the carry flag if #REGa<#N(255,2,,1)($)
  $8870 Return if #REGa=#N(255,2,,1)($)
  $8871 CALL #R25374
  $8874 Jump to #R34924
b $8876
t $88C9
b $88CD
c $88D9
  $88D9 Push #REGix onto the stack
  $88DB Push #REGhl onto the stack
  $88DC Push #REGde onto the stack
  $88DD #REGix=#N(41453,4,,1)($)
  $88E1 #REGb=#N(0,2,,1)($)
  $88E3 #REGix=#REGix+#REGbc
  $88E5 #REGe=PEEK (#REGix+#N(0,2,,1)($))
  $88E8 #REGa=PEEK #N(42303,4,,1)($)
  $88EB CALL #R34905
  $88EE #REGb=#REGh
  $88EF #REGe=PEEK (#REGix+#N(8,2,,1)($))
  $88F2 #REGa=PEEK #N(42304,4,,1)($)
  $88F5 CALL #R34905
  $88F8 #REGc=#REGh
  $88F9 Pop last item from stack into #REGde
  $88FA Pop last item from stack into #REGhl
  $88FB Pop last item from stack into #REGix
  $88FD Return
c $88FE
  $88FE Push #REGhl onto the stack
  $88FF Push #REGde onto the stack
  $8900 #REGc=PEEK #N(42301,4,,1)($); #REGb=PEEK #N(42302,4,,1)($)
  $8904 Clear the carry flag and set the zero flag if #REGa=0
  $8905 #REGhl=#REGhl-carry-#REGbc
  $8907 Jump to #R35090 if the carry flag is not set
  $8909 #REGhl=#REGhl+#REGbc
  $890A Push #REGhl onto the stack
  $890B #REGl=PEEK #N(42301,4,,1)($); #REGh=PEEK #N(42302,4,,1)($)
  $890E Pop last item from stack into #REGbc
  $890F Clear the carry flag and set the zero flag if #REGa=0
  $8910 #REGhl=#REGhl-carry-#REGbc
  $8912 #REGa=#REGl
  $8913 POKE #N(42304,4,,1)($),#REGa
  $8916 #REGl=PEEK #N(42299,4,,1)($); #REGh=PEEK #N(42300,4,,1)($)
  $8919 Clear the carry flag and set the zero flag if #REGa=0
  $891A #REGhl=#REGhl-carry-#REGde
  $891C Jump to #R35111 if the carry flag is not set
  $891E Push #REGde onto the stack
  $891F #REGe=PEEK #N(42299,4,,1)($); #REGd=PEEK #N(42300,4,,1)($)
  $8923 Pop last item from stack into #REGhl
  $8924 Clear the carry flag and set the zero flag if #REGa=0
  $8925 #REGhl=#REGhl-carry-#REGde
  $8927 #REGa=#REGl
  $8928 POKE #N(42303,4,,1)($),#REGa
  $892B #REGd=#N(0,2,,1)($)
  $892D #REGa=PEEK #N(42303,4,,1)($)
  $8930 #REGe=#REGa
  $8931 #REGl=PEEK #N(42299,4,,1)($); #REGh=PEEK #N(42300,4,,1)($)
  $8934 #REGhl=#REGhl+#REGde
  $8935 Exchange #REGde and #REGhl
  $8936 #REGl=PEEK #N(42301,4,,1)($); #REGh=PEEK #N(42302,4,,1)($)
  $8939 CALL #R29193
  $893C #REGc=#N(0,2,,1)($)
  $893E Push #REGbc onto the stack
  $893F CALL #R35033
  $8942 #REGl=PEEK #N(42301,4,,1)($); #REGh=PEEK #N(42302,4,,1)($)
  $8945 Push #REGbc onto the stack
  $8946 #REGb=#N(0,2,,1)($)
  $8948 #REGhl=#REGhl+#REGbc
  $8949 Pop last item from stack into #REGbc
  $894A Exchange #REGde and #REGhl
  $894B #REGc=#REGb
  $894C #REGb=#N(0,2,,1)($)
  $894E #REGl=PEEK #N(42299,4,,1)($); #REGh=PEEK #N(42300,4,,1)($)
  $8951 #REGhl=#REGhl+#REGbc
  $8952 Exchange #REGde and #REGhl
  $8953 CALL #R29186
  $8956 Pop last item from stack into #REGbc
  $8957 #REGc=#REGc+1
  $8958 #REGa=#REGc
  $8959 Set the zero flag if #REGa=#N(8,2,,1)($), or the carry flag if #REGa<#N(8,2,,1)($)
  $895B Jump to #R35134 if #REGa<>#N(8,2,,1)($)
  $895D #REGd=#N(0,2,,1)($)
  $895F #REGa=PEEK #N(42303,4,,1)($)
  $8962 #REGe=#REGa
  $8963 #REGl=PEEK #N(42299,4,,1)($); #REGh=PEEK #N(42300,4,,1)($)
  $8966 #REGhl=#REGhl+#REGde
  $8967 Exchange #REGde and #REGhl
  $8968 #REGl=PEEK #N(42301,4,,1)($); #REGh=PEEK #N(42302,4,,1)($)
  $896B CALL #R29193
  $896E #REGc=#N(0,2,,1)($)
  $8970 Push #REGbc onto the stack
  $8971 CALL #R35033
  $8974 #REGl=PEEK #N(42301,4,,1)($); #REGh=PEEK #N(42302,4,,1)($)
  $8977 Push #REGbc onto the stack
  $8978 #REGb=#N(0,2,,1)($)
  $897A Clear the carry flag and set the zero flag if #REGa=0
  $897B #REGhl=#REGhl-carry-#REGbc
  $897D Pop last item from stack into #REGbc
  $897E Exchange #REGde and #REGhl
  $897F #REGc=#REGb
  $8980 #REGb=#N(0,2,,1)($)
  $8982 #REGl=PEEK #N(42299,4,,1)($); #REGh=PEEK #N(42300,4,,1)($)
  $8985 #REGhl=#REGhl+#REGbc
  $8986 Exchange #REGde and #REGhl
  $8987 CALL #R29186
  $898A Pop last item from stack into #REGbc
  $898B #REGc=#REGc+1
  $898C #REGa=#REGc
  $898D Set the zero flag if #REGa=#N(8,2,,1)($), or the carry flag if #REGa<#N(8,2,,1)($)
  $898F Jump to #R35184 if #REGa<>#N(8,2,,1)($)
  $8991 #REGd=#N(0,2,,1)($)
  $8993 #REGa=PEEK #N(42303,4,,1)($)
  $8996 #REGe=#REGa
  $8997 #REGl=PEEK #N(42299,4,,1)($); #REGh=PEEK #N(42300,4,,1)($)
  $899A Clear the carry flag and set the zero flag if #REGa=0
  $899B #REGhl=#REGhl-carry-#REGde
  $899D Exchange #REGde and #REGhl
  $899E #REGl=PEEK #N(42301,4,,1)($); #REGh=PEEK #N(42302,4,,1)($)
  $89A1 CALL #R29193
  $89A4 #REGc=#N(0,2,,1)($)
  $89A6 Push #REGbc onto the stack
  $89A7 CALL #R35033
  $89AA #REGl=PEEK #N(42301,4,,1)($); #REGh=PEEK #N(42302,4,,1)($)
  $89AD Push #REGbc onto the stack
  $89AE #REGb=#N(0,2,,1)($)
  $89B0 Clear the carry flag and set the zero flag if #REGa=0
  $89B1 #REGhl=#REGhl-carry-#REGbc
  $89B3 Pop last item from stack into #REGbc
  $89B4 Exchange #REGde and #REGhl
  $89B5 #REGc=#REGb
  $89B6 #REGb=#N(0,2,,1)($)
  $89B8 #REGl=PEEK #N(42299,4,,1)($); #REGh=PEEK #N(42300,4,,1)($)
  $89BB Clear the carry flag and set the zero flag if #REGa=0
  $89BC #REGhl=#REGhl-carry-#REGbc
  $89BE Exchange #REGde and #REGhl
  $89BF CALL #R29186
  $89C2 Pop last item from stack into #REGbc
  $89C3 #REGc=#REGc+1
  $89C4 #REGa=#REGc
  $89C5 Set the zero flag if #REGa=#N(8,2,,1)($), or the carry flag if #REGa<#N(8,2,,1)($)
  $89C7 Jump to #R35238 if #REGa<>#N(8,2,,1)($)
  $89C9 #REGd=#N(0,2,,1)($)
  $89CB #REGa=PEEK #N(42303,4,,1)($)
  $89CE #REGe=#REGa
  $89CF #REGl=PEEK #N(42299,4,,1)($); #REGh=PEEK #N(42300,4,,1)($)
  $89D2 Clear the carry flag and set the zero flag if #REGa=0
  $89D3 #REGhl=#REGhl-carry-#REGde
  $89D5 Exchange #REGde and #REGhl
  $89D6 #REGl=PEEK #N(42301,4,,1)($); #REGh=PEEK #N(42302,4,,1)($)
  $89D9 CALL #R29193
  $89DC #REGc=#N(0,2,,1)($)
  $89DE Push #REGbc onto the stack
  $89DF CALL #R35033
  $89E2 #REGl=PEEK #N(42301,4,,1)($); #REGh=PEEK #N(42302,4,,1)($)
  $89E5 Push #REGbc onto the stack
  $89E6 #REGb=#N(0,2,,1)($)
  $89E8 #REGhl=#REGhl+#REGbc
  $89E9 Pop last item from stack into #REGbc
  $89EA Exchange #REGde and #REGhl
  $89EB #REGc=#REGb
  $89EC #REGb=#N(0,2,,1)($)
  $89EE #REGl=PEEK #N(42299,4,,1)($); #REGh=PEEK #N(42300,4,,1)($)
  $89F1 Clear the carry flag and set the zero flag if #REGa=0
  $89F2 #REGhl=#REGhl-carry-#REGbc
  $89F4 Exchange #REGde and #REGhl
  $89F5 CALL #R29186
  $89F8 Pop last item from stack into #REGbc
  $89F9 #REGc=#REGc+1
  $89FA #REGa=#REGc
  $89FB Set the zero flag if #REGa=#N(8,2,,1)($), or the carry flag if #REGa<#N(8,2,,1)($)
  $89FD Jump to #R35294 if #REGa<>#N(8,2,,1)($)
  $89FF Jump to #R34053
b $8A02
t $8A36
b $8A39
c $8A3F
  $8A3F #REGe=PEEK #REGhl
  $8A40 #REGhl=#REGhl+1
  $8A41 #REGd=PEEK #REGhl
  $8A42 #REGhl=#REGhl+1
  $8A43 #REGa=#REGd
  $8A44 #REGa=#REGa|#REGe
  $8A45 Jump to #R35401 if #REGa>0
  $8A47 Set the carry flag
  $8A48 Return
  $8A49 #REGa=#REGe
  $8A4A Set the zero flag if #REGa=#REGc, or the carry flag if #REGa<#REGc
  $8A4B Jump to #R35407 if #REGa<>#REGc
  $8A4D #REGa=#REGd
  $8A4E Set the zero flag if #REGa=#REGb, or the carry flag if #REGa<#REGb
  $8A4F #REGe=PEEK #REGhl
  $8A50 #REGhl=#REGhl+1
  $8A51 #REGd=PEEK #REGhl
  $8A52 #REGhl=#REGhl+1
  $8A53 Do nothing
  $8A54 Do nothing
  $8A55 Return if the zero flag is set
  $8A56 #REGhl=#REGhl+#REGde
  $8A57 Jump to #R35391
c $8A59
  $8A59 #REGa=#N(43,2,,1)($)
  $8A5B POKE #N(35410,4,,1)($),#REGa
  $8A5E POKE #N(35411,4,,1)($),#REGa
  $8A61 POKE #N(35412,4,,1)($),#REGa
  $8A64 CALL #R35391
  $8A67 #REGa=#N(35,2,,1)($)
  $8A69 POKE #N(35410,4,,1)($),#REGa
  $8A6C #REGa=#N(0,2,,1)($)
  $8A6E POKE #N(35411,4,,1)($),#REGa
  $8A71 POKE #N(35412,4,,1)($),#REGa
  $8A74 Return
c $8A75
  $8A75 #REGd=#N(0,2,,1)($)
  $8A77 #REGa=PEEK #REGhl
  $8A78 Clear the carry flag and set the zero flag if #REGa=0
  $8A79 Jump to #R35453 if #REGa>0
  $8A7B Set the carry flag
  $8A7C Return
  $8A7D #REGhl=#REGhl+1
  $8A7E #REGe=PEEK #REGhl
  $8A7F #REGhl=#REGhl+1
  $8A80 Set the zero flag if #REGa=#REGc, or the carry flag if #REGa<#REGc
  $8A81 Return if #REGa=#REGc
  $8A82 #REGhl=#REGhl+#REGde
  $8A83 Jump to #R35447
b $8A85
t $8AA2
b $8AA5
t $8ABE
b $8AC1
t $8B08
b $8B0C
t $8D0B
b $8D0E
t $8D94
b $8D97
t $8DAE
b $8DB1
t $8E07
b $8E0B
t $8E4E
b $8E51
t $8E93
b $8E96
t $8F51
b $8F54
t $8FCE
b $8FD2
t $9017
b $901A
t $903F
b $9042
t $9084
b $9088
t $9095
b $9098
t $90A6
b $90AA
t $90BC
b $90BF
t $910B
b $910E
t $913C
b $9140
t $9261
b $9264
t $9284
b $9288
t $928F
b $9293
t $939D
b $93A0
t $93C2
b $93C6
t $93E4
b $93E8
t $943A
b $943D
t $9464
b $9467
c $95D5
  $95D5 #REGa=PEEK #REGhl
  $95D6 #REGhl=#REGhl+1
  $95D7 Set the zero flag if #REGa=#N(255,2,,1)($), or the carry flag if #REGa<#N(255,2,,1)($)
  $95D9 Return if #REGa=#N(255,2,,1)($)
  $95DA CALL #R25374
  $95DD Jump to #R38357
b $95DF
t $964E
b $9666
t $966A
b $969B
t $96A0
b $96B0
t $96B4
b $96BB
t $96BE
b $96CB
t $96CD
b $96DD
t $96DF
b $96F5
t $9711
s $9719
t $971A
s $9721
t $9722
s $973B
t $973C
s $9741
t $9742
s $9747
t $9748
b $974F
t $9758
b $975E
t $975F
b $9769
t $9771
b $9780
t $9781
s $9798
t $9799
b $97A9
t $97B0
b $97B8
t $97BC
b $97C3
t $97CA
b $97D7
t $97DD
b $97F2
t $97F4
b $9811
t $9813
b $9826
t $982A
b $982D
t $9831
b $9834
t $9846
b $9849
t $984D
b $9850
t $9854
b $9857
t $986B
b $9883
t $9886
b $9889
t $988F
b $98A7
t $98AE
b $98CC
t $98D1
b $98EB
t $98ED
b $98FC
t $9902
b $9911
t $9921
b $993A
t $994B
b $9953
t $9955
b $9959
t $995B
b $995F
t $9960
b $9970
t $9973
b $9983
t $9984
b $998A
t $998D
b $999C
t $99AB
b $99C6
t $99C9
b $99E4
t $99E7
b $99FD
t $9A04
b $9A13
t $9A19
b $9A34
t $9A38
b $9A51
t $9A54
b $9A70
t $9A72
b $9A81
t $9A82
b $9A88
t $9A8E
b $9A9F
t $9AA3
b $9AB5
t $9ABA
b $9AD0
t $9AD2
b $9ADE
t $9AE0
b $9AF8
t $9AFA
b $9B0D
t $9B18
b $9B35
t $9B4E
b $9B5C
t $9B64
b $9B72
t $9B7A
b $9B8A
t $9B8D
b $9BAD
t $9BAF
b $9BC2
t $9BC6
b $9BDE
t $9BE0
b $9BE7
t $9BEC
b $9BFB
t $9C00
b $9C0B
t $9C0F
b $9C25
t $9C27
b $9C2C
t $9C31
b $9C43
t $9C49
b $9C5B
t $9C60
b $9C7E
t $9C82
b $9C9B
t $9C9E
b $9CB2
t $9CB7
b $9CD3
t $9CD6
b $9CE9
t $9CEA
b $9D09
t $9D0B
b $9D14
t $9D17
b $9D27
t $9D30
b $9D39
t $9D40
b $9D47
t $9D4D
b $9D5A
t $9D60
b $9D72
t $9D78
b $9D80
t $9D86
b $9D9E
t $9DA4
b $9DBB
t $9DC1
b $9DC9
t $9DCF
b $9DD4
t $9DDA
b $9DE1
t $9DE7
b $9DF3
t $9DF9
b $9E0A
t $9E10
b $9E1E
t $9E24
b $9E34
t $9E3A
b $9E3F
t $9E45
b $9E56
t $9E5A
b $9E60
t $9E61
b $9E72
t $9E76
b $9E95
t $9E99
b $9EAF
t $9EB3
b $9EB8
t $9EBD
s $9ECE
t $9ECF
s $9EE0
t $9EE1
b $9EE8
t $9EE9
b $9EF5
t $9EFE
b $9F1E
t $9F21
b $9F2F
t $9F31
b $9F3B
t $9F4A
b $9F66
t $9F69
b $9F7D
t $9F7F
b $9F9B
t $9F9D
b $9FA0
t $9FA1
b $9FA4
t $9FA5
b $A0A5
t $A0E8
b $A0F3
t $A0F8
b $A102
t $A107
b $A10E
t $A110
b $A118
t $A11A
b $A11F
t $A121
b $A128
t $A12A
b $A132
t $A135
b $A13D
t $A144
b $A151
t $A15A
b $A15D
t $A162
b $A165
t $A16A
b $A175
t $A176
b $A17B
t $A180
b $A185
t $A190
b $A19B
t $A1A0
b $A1A3
t $A1A4
b $A1A9
t $A1B2
b $A1B9
t $A1C6
b $A1D1
t $A1D2
b $A1D5
t $A1D6
b $A1DE
t $A1DF
b $A1E3
t $A1E6
b $A1ED
t $A539
b $A53C
t $A6AA
b $A6B1
t $A6B2
b $A6C3
t $A6CE
b $A6D5
t $A6D6
b $A6E5
t $A6F0
b $A6F7
t $A6F8
b $A709
t $A714
b $A71B
t $A71C
b $A72B
t $A736
b $A73D
t $A73E
b $A74D
t $A758
b $A75F
t $A760
b $A76F
t $A77A
b $A781
t $A782
b $A791
t $A79C
b $A7A3
t $A7A4
b $A7B3
t $A7BE
b $A7C5
t $A7C6
b $A7D7
t $A7E2
b $A7E9
t $A7EA
b $A7F9
t $A804
b $A80B
t $A80C
b $A81B
t $A826
b $A82D
t $A82E
b $A83D
t $A848
b $A84F
t $A850
b $A85F
t $A86C
b $A871
t $A872
b $A885
t $A892
b $A897
t $A898
b $A8A7
t $A8B2
b $A8B9
t $A8BA
b $A8CB
t $A8EB
b $A8EE
t $A91D
b $A921
t $A938
b $A93C
t $A93F
b $A943
t $A944
b $A94C
t $A95D
b $A962
t $A98B
s $A990
t $A991
b $A994
t $A9B6
b $A9BB
t $A9EA
b $A9F8
t $AA11
b $AA1A
t $AA21
b $AA27
t $AA3E
b $AA48
t $AA73
b $AA76
t $AAA6
b $AAA9
t $AAAA
b $AAAE
t $AAC5
b $AACA
t $AACC
b $AAD3
t $AAE7
b $AAEA
t $AAFD
b $AB01
t $AB06
b $AB0B
t $AB0E
b $AB11
t $AB31
b $AB35
t $AB3A
b $AB3F
t $AB40
b $AB43
t $AB5F
b $AB63
t $AB64
b $AB6B
t $AB6C
b $AB70
t $AB9A
b $AB9D
t $AB9E
b $ABA2
t $ABB3
b $ABB7
t $ABC1
b $ABCB
t $AC17
b $AC1C
t $AC24
b $AC27
t $AC31
b $AC3D
t $AC53
b $AC5B
t $AC61
b $AC64
t $AC84
b $AC87
t $ACAF
b $ACB2
t $ACDA
b $ACDD
t $AD05
b $AD08
t $AD0F
b $AD12
t $AD34
b $AD37
t $AD4C
b $AD50
t $AD53
b $AD56
t $AD77
b $AD7C
t $ADEE
b $ADF1
t $ADFF
b $AE07
t $AE11
b $AE14
t $AE78
b $AE7B
t $AEF5
b $AEF8
t $AF3F
b $AF42
t $AFBA
b $AFBD
t $B008
b $B00B
t $B05F
b $B062
t $B0D2
b $B0D5
t $B0DF
b $B0E2
t $B102
b $B105
t $B178
b $B17B
t $B185
b $B188
t $B192
b $B195
t $B281
b $B284
t $B2DE
b $B2E1
t $B2ED
b $B2F0
t $B354
b $B357
t $B3FB
b $B3FE
t $B409
b $B40C
t $B417
b $B41A
t $B42E
b $B432
t $B434
b $B438
t $B4B6
b $B4B9
t $B4E5
b $B4E8
t $B536
b $B539
t $B546
b $B549
t $B66A
b $B66D
t $B688
b $B68B
t $B6C6
b $B6C9
t $B77E
b $B781
t $B794
b $B797
t $B7DF
b $B7E3
t $B800
b $B803
t $B81A
b $B81D
t $B82A
b $B82D
t $B83A
b $B840
t $B84E
b $B851
t $B86A
b $B86D
t $B873
b $B877
t $B878
b $B87B
t $B87C
b $B883
t $B887
b $B88D
t $B89C
b $B8A3
t $B8AD
b $B8B1
t $B8B6
b $B8B9
t $B8C0
b $B8C3
t $B8CC
b $B8CF
t $B8D0
b $B8D6
t $B8DB
b $B8E1
t $B8E2
b $B8E5
t $B8FF
b $B905
t $B906
b $B90D
t $B918
b $B91B
t $B926
b $B92D
t $B939
b $B93E
t $B94A
b $B94D
t $B950
b $B953
t $B95A
b $B95E
t $B989
b $B993
t $B994
b $B998
t $B99A
b $B99D
t $B99E
b $B9A1
t $B9A2
b $B9A6
t $B9A9
b $B9AF
t $B9B0
b $B9B5
t $B9B7
b $B9BC
t $B9C0
s $B9C3
t $B9C4
b $B9C7
t $B9CC
b $B9CF
t $B9D4
b $B9D7
t $B9E0
b $B9F0
t $B9F6
b $B9FB
t $BA02
b $BA16
t $BA17
b $BA1B
t $BA1E
b $BA23
t $BA28
b $BA31
t $BA32
b $BA3A
t $BA3C
b $BA43
t $BA44
b $BA4B
t $BA4C
b $BA53
t $BA54
b $BA5A
t $BA5C
b $BA61
t $BA62
b $BA6C
t $BA70
b $BA75
t $BA97
b $BA9A
t $BAA0
b $BAA3
t $BAA6
b $BAA9
t $BAAE
b $BAB3
t $BAB6
b $BAB9
t $BACD
b $BAD2
t $BAD6
b $BADB
t $BAE0
b $BAE4
t $BAE8
b $BAF1
t $BAFA
b $BAFD
t $BAFE
b $BB02
t $BB07
b $BB0D
t $BB24
b $BB27
t $BB28
b $BB2D
t $BB32
b $BB35
t $BB3C
b $BB3F
t $BB4E
b $BB51
t $BB55
b $BB58
t $BB5E
b $BB61
t $BB6C
b $BB70
t $BB74
b $BB79
t $BB7B
b $BB7E
t $BB86
b $BB8B
t $BB8C
b $BB8F
t $BB9A
b $BB9E
t $BBA8
b $BBAF
t $BBB6
b $BBB9
t $BBC6
b $BBCD
t $BBD5
b $BBDD
t $BBE2
b $BBE9
t $BBF4
b $BBFB
t $BC08
b $BC0B
t $BC14
b $BC17
t $BC1A
b $BC1D
t $BC22
b $BC2A
t $BC30
b $BC33
t $BC4C
b $BC4F
t $BC57
b $BC5D
t $BC62
b $BC65
t $BC66
b $BC69
t $BC78
b $BC7B
t $BC84
b $BC87
t $BC8C
b $BC8F
t $BC91
b $BC97
t $BC9C
b $BC9F
t $BCA0
b $BCA3
t $BCB2
b $BCB5
t $BCBE
b $BCC3
t $BCC8
b $BCCC
t $BCDE
b $BCE1
t $BCF4
b $BCF7
t $BD06
b $BD09
t $BD14
b $BD19
t $BD1E
b $BD21
t $BD34
b $BD37
t $BD4E
b $BD51
t $BD5A
b $BD5D
t $BD65
b $BD68
t $BD82
b $BD85
t $BD92
b $BD96
t $BDA2
b $BDA5
t $BDA6
b $BDA9
t $BDAA
b $BDAD
t $BDB8
b $BDBB
t $BDCF
b $BDD4
t $BDDA
b $BDDD
t $BDEA
b $BDED
t $BDF8
b $BDFB
t $BDFE
b $BE01
t $BE2E
b $BE31
t $BE40
b $BE43
t $BE4C
b $BE53
t $BE5A
b $BE5F
t $BE6A
b $BE6D
t $BE6E
b $BE71
t $BE74
b $BE79
t $BE7C
b $BE7F
t $BE98
b $BE9B
t $BE9E
b $BEA1
t $BEAA
b $BEAF
t $BEB4
b $BEB7
t $BEDC
b $BEDF
t $BEE6
b $BEEB
t $BEF6
b $BEF9
t $BF0E
b $BF13
t $BF14
b $BF17
t $BF1A
b $BF1D
t $BF4E
b $BF51
t $BF5A
b $BF5D
t $BF66
b $BF69
t $BF77
b $BF7B
t $BF86
b $BF89
t $BFA2
b $BFA5
t $BFB6
b $BFB9
t $BFBC
b $BFC1
t $BFC5
b $BFC9
t $BFE2
b $BFE5
t $BFE7
b $BFEA
t $BFF2
b $BFF7
t $C032
b $C037
t $C03A
b $C03F
t $C048
b $C04D
t $C04E
b $C051
t $C05A
b $C060
t $C06C
b $C06F
t $C072
s $C077
t $C078
b $C07C
t $C07F
b $C083
t $C08C
b $C094
t $C095
b $C099
t $C09C
b $C09F
t $C0B0
b $C0B3
t $C0B4
b $C0B7
t $C0B8
b $C0BB
t $C0C4
b $C0CF
t $C0D2
b $C0DA
t $C0DD
b $C0E1
t $C0FE
b $C103
t $C10C
b $C111
t $C116
b $C119
t $C11A
b $C11D
t $C120
b $C123
t $C12E
b $C132
t $C136
b $C139
t $C13C
b $C140
t $C144
b $C147
t $C148
b $C14C
t $C14F
b $C154
t $C158
b $C161
t $C164
b $C167
t $C16A
b $C171
t $C17A
b $C17D
t $C17F
b $C182
t $C183
b $C187
t $C188
b $C18B
t $C18C
b $C190
t $C192
b $C19B
t $C19C
b $C1A1
t $C1A2
b $C1A5
t $C1AC
b $C1B1
t $C1BC
b $C1C0
t $C1C3
b $C1C7
t $C1CC
b $C1CF
t $C1D2
b $C1D5
t $C1DB
b $C1DE
t $C1E6
b $C1E9
t $C225
b $C228
t $C22A
b $C22E
t $C22F
b $C232
t $C2B8
b $C2BB
t $C2D5
b $C2D8
t $C2F8
b $C2FB
t $C49C
b $C4A0
t $C4A7
b $C4AA
t $C4AB
b $C4AF
t $C4B0
b $C4B4
t $C4B5
b $C4B8
t $C4CF
b $C4D2
t $C4D3
b $C4D7
t $C582
b $C585
t $C5D2
b $C5D5
t $C5D7
b $C5DA
t $C622
b $C625
t $C627
b $C62B
t $C62C
b $C630
t $C631
b $C635
t $C636
b $C63A
t $C63B
b $C63F
t $C640
b $C644
t $C645
b $C649
t $C64A
b $C64E
t $C64F
b $C653
t $C654
b $C658
t $C65E
b $C661
t $C681
b $C684
t $C69E
b $C6A2
t $C6A3
b $C6A7
t $C6A8
b $C6AB
t $C6CB
b $C6CF
t $C6F1
b $C6F5
t $C703
b $C706
t $C718
b $C71C
t $C71D
b $C720
t $C73F
b $C742
t $C7CE
b $C7D2
t $C7E7
b $C7EB
t $C7F1
b $C7F4
t $C92E
b $C931
t $C95F
b $C962
t $C963
b $C967
t $C968
b $C96C
t $C96D
b $C971
t $C972
b $C976
t $CA05
b $CA08
t $CA09
b $CA0D
t $CA14
b $CA17
t $CA18
b $CA1C
t $CA2C
b $CA30
t $CA31
b $CA35
t $CA4F
b $CA53
t $CA54
b $CA58
t $CA59
b $CA5D
t $CA5E
b $CA62
t $CA63
b $CA67
t $CA68
b $CA6C
t $CA6D
b $CA71
t $CA72
b $CA76
t $CA77
b $CA7B
t $CA7C
b $CA80
t $CA81
b $CA85
t $CA86
b $CA8A
t $CA8B
b $CA8F
t $CA90
b $CA94
t $CA95
b $CA99
t $CAD6
b $CADA
t $CADB
b $CADF
t $CB01
b $CB04
t $CB4A
b $CB4E
t $CBBA
b $CBBD
t $CBC4
b $CBC7
t $CBD4
b $CBD7
t $CBDE
b $CBE1
t $CC3D
b $CC40
t $CC9E
b $CCA2
t $CCA8
b $CCAC
t $CCAD
b $CCB1
t $CCB2
b $CCB6
t $CCB7
b $CCBB
t $CCBC
b $CCC0
t $CCE3
b $CCE6
t $CCE7
b $CCEB
t $CCF2
b $CCF5
t $CCF6
b $CCFA
t $CD18
b $CD1B
t $CD21
b $CD25
t $CD2B
b $CD2E
t $CD4A
b $CD4E
t $CD57
b $CD5B
t $CDD2
b $CDD5
t $CDD7
b $CDDB
t $CDDC
b $CDE0
t $CE8A
b $CE8D
t $CE94
b $CE97
t $CE9E
b $CEA2
t $CEA3
b $CEA7
t $CEA8
b $CEAC
t $CEAD
b $CEB1
t $CEDB
b $CEDE
t $CEE6
b $CEE9
t $CF90
b $CF93
t $CFB3
b $CFB6
t $CFC3
b $CFC6
t $CFEF
b $CFF3
t $D018
b $D01B
t $D023
b $D026
t $D068
b $D06C
t $D0EC
b $D0EF
t $D116
b $D11A
t $D11B
b $D11F
t $D120
b $D124
t $D125
b $D129
t $D12F
b $D133
t $D13C
b $D140
t $D168
b $D16B
t $D17B
b $D17F
t $D180
b $D184
t $D258
b $D25B
t $D262
b $D265
t $D30F
b $D313
t $D314
b $D318
t $D347
b $D34B
t $D35B
b $D35F
t $D360
b $D364
t $D365
b $D369
t $D36F
b $D373
t $D374
b $D378
t $D379
b $D37D
t $D37E
b $D382
t $D3E3
b $D3E7
t $D417
b $D41A
t $D5F2
b $D5F5
t $D5F6
b $D5FA
t $D5FB
b $D5FE
t $D605
b $D609
t $D60A
b $D60E
t $D60F
b $D613
t $D614
b $D618
t $D619
b $D61D
t $D72A
b $D72D
t $D737
b $D73B
t $D742
b $D746
t $D758
b $D75C
t $D780
b $D783
t $D78A
b $D78D
t $D794
b $D798
t $D7BF
b $D7C3
t $D7C4
b $D7C7
t $D7D3
b $D7D7
t $D7DD
b $D7E0
t $D7F2
b $D7F5
t $D7F6
b $D7FA
t $D7FB
b $D7FF
t $D800
b $D804
t $D805
b $D809
t $D80A
b $D80E
t $D810
b $D813
t $D814
b $D818
t $D819
b $D81D
t $D81E
b $D822
t $D823
b $D827
t $D828
b $D82C
t $D82D
b $D831
t $D832
b $D836
t $D837
b $D83B
t $D83C
b $D840
t $D841
b $D845
t $D846
b $D84A
t $D84B
b $D84F
t $D850
b $D854
t $D856
b $D859
t $D85A
b $D85E
t $D85F
b $D863
t $D864
b $D868
t $D869
b $D86C
t $D86E
b $D872
t $D873
b $D876
t $D88B
b $D88F
t $D890
b $D894
t $D995
b $D998
t $D9A4
b $D9A8
t $D9B4
b $D9B7
t $DA52
b $DA55
t $DAC7
b $DACB
t $DACC
b $DAD0
t $DADB
b $DADF
t $DB5A
b $DB5D
t $DB65
b $DB68
t $DB9B
b $DB9F
t $DBA0
b $DBA4
t $DBA5
b $DBA9
t $DBAA
b $DBAE
t $DBAF
b $DBB3
t $DBB4
b $DBB8
t $DBB9
b $DBBD
t $DBBE
b $DBC2
t $DBCD
b $DBD1
t $DC21
b $DC24
t $DC25
b $DC29
t $DC3F
b $DC42
t $DC75
b $DC79
t $DC7A
b $DC7E
t $DCD5
b $DCD9
t $DCFF
b $DD03
t $DD09
b $DD0D
t $DD0E
b $DD12
t $DD13
b $DD17
t $DD18
b $DD1C
t $DD1D
b $DD21
t $DD22
b $DD26
t $DD31
b $DD35
t $DD4F
b $DD53
t $DD5E
b $DD62
t $DD63
b $DD67
t $DD68
b $DD6B
t $DD72
b $DD76
t $DD77
b $DD7B
t $DD82
b $DD85
t $DD8B
b $DD8F
t $DF27
b $DF2A
t $DF2B
b $DF2F
t $DF30
b $DF34
t $DF35
b $DF39
t $DF3F
b $DF43
t $DF44
b $DF48
t $DF53
b $DF57
t $DF58
b $DF5C
t $DF5D
b $DF61
t $DF68
b $DF6B
t $DF6C
b $DF6F
t $DF7B
b $DF7F
t $DF81
b $DF84
t $E050
b $E054
t $E055
b $E059
t $E05A
b $E05E
t $E05F
b $E063
t $E09C
b $E09F
t $E0A9
b $E0AD
t $E0B1
b $E0B5
t $E0E3
b $E0E6
t $E0E7
b $E0EB
t $E0EC
b $E0F0
t $E0F2
b $E0F5
t $E0FE
b $E102
t $E103
b $E107
t $E127
b $E12B
t $E15A
b $E15D
t $E18B
b $E18F
t $E2A0
b $E2A4
t $E2A5
b $E2A9
t $E2AA
b $E2AE
t $E2AF
b $E2B3
t $E2B4
b $E2B8
t $E2B9
b $E2BD
t $E2BE
b $E2C1
t $E2C8
b $E2CC
t $E2DF
b $E2E3
t $E2E4
b $E2E8
t $E2E9
b $E2ED
t $E2F4
b $E2F8
t $E2F9
b $E2FD
t $E2FE
b $E302
t $E303
b $E307
t $E30B
b $E30F
t $E316
b $E31A
t $E31B
b $E31F
t $E320
b $E324
t $E325
b $E329
t $E330
b $E334
t $E335
b $E339
t $E33A
b $E33E
t $E342
b $E346
t $E347
b $E34B
t $E34C
b $E350
t $E351
b $E355
t $E356
b $E35A
t $E35B
b $E35F
t $E360
b $E364
t $E365
b $E369
t $E36A
b $E36E
t $E43D
b $E440
t $E456
b $E45A
t $E45B
b $E45F
t $E460
b $E464
t $E465
b $E468
t $E492
b $E495
t $E497
b $E49B
t $E4F2
b $E4F6
t $E4F7
b $E4FB
t $E4FC
b $E4FF
t $E506
b $E50A
t $E50B
b $E50F
t $E5D3
b $E5D6
t $E605
b $E609
t $E63A
b $E63D
t $E63E
b $E641
t $E68F
b $E693
t $E6B8
b $E6BB
t $E6BD
b $E6C0
t $E8BF
b $E8C3
t $E8C7
b $E8CB
t $E8CC
b $E8D0
t $E8D1
b $E8D5
t $E8D6
b $E8DA
t $E8DB
b $E8DF
t $E8E0
b $E8E4
t $E922
b $E925
t $E945
b $E949
t $E94A
b $E94E
t $E94F
b $E953
t $E954
b $E958
t $E959
b $E95D
t $E95E
b $E961
t $E987
b $E98B
t $E98C
b $E990
t $E9A5
b $E9A9
t $E9B1
b $E9B4
t $E9B5
b $E9B9
t $E9D4
b $E9D7
t $EA23
b $EA27
t $EA29
b $EA2D
t $EA35
b $EA3A
t $EA3C
b $EA42
t $EA44
b $EA48
t $EA4A
b $EA4D
t $EA4E
b $EA6E
t $EA74
b $EA78
t $EA7A
b $EA7D
t $EA7F
b $EA82
t $EA84
b $EA87
t $EA89
b $EA8C
t $EA8E
b $EA94
t $EA96
b $EA9C
t $EA9E
b $EAA3
t $EAA5
b $EAAA
t $EAAC
b $EAAF
t $EAB1
b $EAB4
t $EABA
b $EAC0
t $EAC2
b $EAC6
t $EACC
b $EACF
t $EAD1
b $EAD5
t $EAD7
b $EADD
t $EADF
b $EAE2
t $EAE4
b $EAE8
t $EAEA
b $EAED
t $EAEF
b $EAF3
t $EAF5
b $EAF9
t $EAFB
b $EAFE
t $EB00
b $EB07
t $EB09
b $EB0E
t $EB10
b $EB16
t $EB18
b $EB1B
t $EB21
b $EB25
t $EB27
b $EB2B
t $EB3B
b $EB3F
t $EB44
b $EB47
t $EB4D
b $EB52
t $EB54
b $EB5E
t $EB63
b $EB6A
t $EB6C
b $EB74
t $EB76
b $EB7B
t $EB81
b $EB89
t $EB8B
b $EB91
t $EB93
b $EB99
t $EB9B
b $EBA0
t $EBAB
b $EBAE
t $EBB0
b $EBB9
t $EBBB
b $EBC1
t $EBC6
b $EBCB
t $EBD1
b $EBD5
t $EBD7
b $EBDA
t $EBDC
b $EBE3
t $EBE8
b $EBEC
t $EBF1
b $EBF9
t $EBFB
b $EC02
t $EC04
b $EC0B
t $EC0D
b $EC11
t $EC17
b $EC1C
t $EC1E
b $EC24
t $EC26
b $EC2C
t $EC2E
b $EC35
t $EC37
b $EC3C
t $EC3E
b $EC45
t $EC47
b $EC4C
t $EC4E
b $EC53
t $EC55
b $EC59
t $EC5B
b $EC60
t $EC62
b $EC66
t $EC68
b $EC6E
t $EC70
b $EC77
t $EC79
b $EC80
t $EC85
b $EC89
t $EC8B
b $EC8E
t $EC90
b $EC97
t $EC99
b $EC9E
t $ECA0
b $ECA7
t $ECA9
b $ECB1
t $ECB3
b $ECB7
t $ECB9
b $ECBE
t $ECC0
b $ECC5
t $ECC7
b $ECCC
t $ECCE
b $ECDA
t $ECDC
b $ECE1
t $ECE3
b $ECE9
t $ECEE
b $ECF2
t $ECF8
b $ED01
t $ED03
b $ED07
t $ED09
b $ED0D
t $ED0F
b $ED13
t $ED15
b $ED18
t $ED1A
b $ED21
t $ED23
b $ED2A
t $ED2C
b $ED30
t $ED32
b $ED3D
t $ED3F
b $ED43
t $ED45
b $ED4D
t $ED53
b $ED57
t $ED59
b $ED60
t $ED62
b $ED6A
t $ED6C
b $ED73
t $ED75
b $ED79
t $ED7B
b $ED81
t $ED83
b $ED88
t $ED8D
b $ED91
t $ED97
b $ED9B
t $ED9D
b $EDA4
t $EDA6
b $EDAC
t $EDAE
b $EDB6
t $EDB8
b $EDBC
t $EDBE
b $EDC2
t $EDC4
b $EDC8
t $EDCA
b $EDD0
t $EDD2
b $EDD7
t $EDD9
b $EDDD
t $EDDF
b $EDE5
t $EDE7
b $EDF0
t $EDF2
b $EDF8
t $EDFA
b $EDFE
t $EE00
b $EE0D
t $EE0F
b $EE12
t $EE14
b $EE1B
t $EE1D
b $EE24
t $EE26
b $EE2A
t $EE2C
b $EE31
t $EE33
b $EE3D
t $EE3F
b $EE43
t $EE45
b $EE4A
t $EE4C
b $EE51
t $EE53
b $EE56
t $EE58
b $EE5E
t $EE60
b $EE65
t $EE67
b $EE6C
t $EE6E
b $EE71
t $EE73
b $EE7D
t $EE7F
b $EE85
t $EE87
b $EE8B
t $EE8D
b $EE91
t $EE93
b $EE9B
t $EE9D
b $EEA4
t $EEA6
b $EEAC
t $EEAE
b $EEB4
t $EEB6
b $EEB9
t $EEBB
b $EEBE
t $EEC0
b $EEC5
t $EEC7
b $EED0
t $EED2
b $EED6
t $EED8
b $EEDC
t $EEDE
b $EEE2
t $EEE4
b $EEE7
t $EEE9
b $EEEE
t $EEF0
b $EEF4
t $EEF6
b $EEF9
t $EEFB
b $EF00
t $EF02
b $EF06
t $EF0E
b $EF12
t $EF14
b $EF18
t $EF1A
b $EF22
t $EF24
b $EF27
t $EF2C
b $EF35
t $EF3D
b $EF43
t $EF49
b $EF4E
t $EF50
b $EF53
t $EF55
b $EF59
t $EF5B
b $EF65
t $EF6B
b $EF6E
t $EF70
b $EF77
t $EF79
b $EF7F
t $EF81
b $EF87
t $EF8D
b $EF93
t $EF95
b $EF9D
t $EF9F
b $EFA8
t $EFAA
b $EFAF
t $EFB1
b $EFB6
t $EFB8
b $EFC1
t $EFC3
b $EFC9
t $EFCB
b $EFCE
t $EFD0
b $EFD4
t $EFD6
b $EFDA
t $EFDC
b $EFDF
t $EFE1
b $EFED
t $EFEF
b $EFF2
t $EFF4
b $EFFA
t $EFFC
b $F004
t $F006
b $F00B
t $F00D
b $F017
t $F019
b $F026
t $F028
b $F030
t $F032
b $F03B
t $F03D
b $F043
t $F045
b $F04A
t $F04C
b $F052
t $F054
b $F05B
t $F05D
b $F060
t $F062
b $F066
t $F068
b $F06C
t $F071
b $F079
t $F07B
b $F07F
t $F081
b $F085
t $F087
b $F08C
t $F08E
b $F094
t $F096
b $F09A
t $F09C
b $F0A4
t $F0A6
b $F0AE
t $F0B0
b $F0B8
t $F0BA
b $F0C0
t $F0C2
b $F0CA
t $F0CE
b $F0D4
t $F0D6
b $F0DC
t $F0DE
b $F0E1
t $F0E3
b $F0EB
t $F0ED
b $F0F8
t $F0FA
b $F100
t $F102
b $F109
t $F114
b $F11B
t $F11D
b $F123
t $F125
b $F129
t $F12F
b $F136
t $F138
b $F13F
t $F141
b $F145
t $F147
b $F14C
t $F14E
b $F153
t $F155
b $F15C
t $F15E
b $F164
t $F166
b $F16B
t $F16D
b $F172
t $F174
b $F17D
t $F182
b $F186
t $F188
b $F18E
t $F199
b $F19E
t $F1A0
b $F1A5
t $F1A7
b $F1B0
t $F1B2
b $F1BA
t $F1BE
b $F1C3
t $F1C5
b $F1CA
t $F1CC
b $F1D2
t $F1D7
b $F1DB
t $F1DD
b $F1E9
t $F1EB
b $F1F6
t $F1F8
b $F1FE
t $F200
b $F203
t $F205
b $F20B
t $F20D
b $F210
t $F21E
b $F22B
t $F22D
b $F236
t $F238
b $F240
t $F242
b $F245
t $F247
b $F24C
t $F24E
b $F251
t $F253
b $F257
t $F259
b $F25E
t $F264
b $F26A
t $F26C
b $F273
t $F275
b $F278
t $F27A
b $F283
t $F285
b $F28C
t $F28E
b $F293
t $F295
b $F298
t $F29A
b $F29F
t $F2A1
b $F2A7
t $F2A9
b $F2B6
t $F2B8
b $F2BC
t $F2BE
b $F2C4
t $F2C6
b $F2C9
t $F2CB
b $F2D0
t $F2D2
b $F2D6
t $F2D8
b $F2E1
t $F2E5
b $F2EB
t $F2ED
b $F2F4
t $F2F6
b $F2F9
t $F2FB
b $F2FE
t $F300
b $F303
t $F305
b $F30A
t $F30C
b $F312
t $F314
b $F31C
t $F31E
b $F328
t $F32A
b $F32F
t $F331
b $F337
t $F339
b $F33F
t $F341
b $F349
t $F34B
b $F350
t $F352
b $F35C
t $F35E
b $F363
t $F365
b $F36C
t $F36E
b $F372
t $F374
b $F37F
t $F381
b $F384
t $F386
b $F38E
t $F390
b $F394
t $F396
b $F39C
t $F39E
b $F3AB
t $F3AD
b $F3B2
t $F3B4
b $F3BA
t $F3BC
b $F3C2
t $F3C4
b $F3CC
t $F3CE
b $F3D6
t $F3D8
b $F3DF
t $F3E5
b $F3EA
t $F3EC
b $F3F1
t $F3F3
b $F3FB
t $F3FD
b $F402
t $F404
b $F408
t $F40A
b $F40F
t $F411
b $F414
t $F41A
b $F422
t $F424
b $F42B
t $F42D
b $F432
t $F434
b $F43C
t $F43E
b $F442
t $F444
b $F448
t $F44A
b $F44D
t $F44F
b $F45A
t $F45C
b $F464
t $F466
b $F46D
t $F46F
b $F47A
t $F47C
b $F47F
t $F481
b $F484
t $F486
b $F48C
t $F48E
b $F496
t $F498
b $F49D
t $F49F
b $F4A4
t $F4A6
b $F4AA
t $F4AC
b $F4B5
t $F4B7
b $F4BE
t $F4C0
b $F4C5
t $F4C7
b $F4CD
t $F4D3
b $F4DD
t $F4DF
b $F4E5
t $F4E7
b $F4EA
t $F4EC
b $F4F1
t $F4F3
b $F4F7
t $F4F9
b $F501
t $F507
b $F50B
t $F50D
b $F514
t $F516
b $F51B
t $F51D
b $F521
t $F523
b $F528
t $F52A
b $F533
t $F535
b $F53C
t $F53E
b $F541
t $F543
b $F547
t $F549
b $F54D
t $F54F
b $F553
t $F555
b $F55D
t $F55F
b $F562
t $F564
b $F567
t $F569
b $F570
t $F572
b $F577
t $F579
b $F582
t $F584
b $F589
t $F58B
b $F590
t $F592
b $F598
t $F59A
b $F5A1
t $F5A3
b $F5AC
t $F5AE
b $F5B9
t $F5BB
b $F5BF
t $F5C1
b $F5C7
t $F5C9
b $F5CD
t $F5CF
b $F5D8
t $F5DA
b $F5E4
t $F5E6
b $F5F3
t $F5F5
b $F5F8
t $F5FE
b $F602
t $F604
b $F60B
t $F60D
b $F614
t $F616
b $F61A
t $F620
b $F626
t $F628
b $F62D
t $F62F
b $F633
t $F635
b $F639
t $F63B
b $F641
t $F643
b $F649
t $F64B
b $F651
t $F653
b $F657
t $F659
b $F660
t $F662
b $F669
t $F66B
b $F66F
t $F671
b $F676
t $F678
b $F67C
t $F67E
b $F684
t $F686
b $F68A
t $F68C
b $F68F
t $F691
b $F695
t $F697
b $F69B
t $F69D
b $F6A1
t $F6A7
b $F6AD
t $F6AF
b $F6B3
t $F6B5
b $F6B8
t $F6BE
b $F6C1
t $F6C3
b $F6CA
t $F6CC
b $F6D2
t $F6D4
b $F6DB
t $F6DD
b $F6E3
t $F6E5
b $F6EF
t $F6F1
b $F6F8
t $F6FA
b $F6FF
t $F709
b $F70E
t $F710
b $F718
t $F71A
b $F722
t $F724
b $F72A
t $F72C
b $F737
t $F739
b $F742
t $F748
b $F751
t $F753
b $F75B
t $F75D
b $F763
t $F765
b $F76B
t $F76D
b $F778
t $F77A
b $F780
t $F782
b $F786
t $F788
b $F78D
t $F78F
b $F793
t $F795
b $F798
t $F79A
b $F79F
t $F7A1
b $F7A6
t $F7A8
b $F7AC
t $F7AE
b $F7B5
t $F7B7
b $F7C1
t $F7C3
b $F7C7
t $F7C9
b $F7CF
t $F7D1
b $F7DB
t $F7DD
b $F7E1
t $F7E3
b $F7E8
t $F7EA
b $F7EE
t $F7F0
b $F7F6
t $F7F8
b $F7FC
t $F7FE
b $F803
t $F805
b $F80A
t $F80C
b $F810
t $F812
b $F818
t $F81A
b $F81D
t $F81F
b $F822
t $F824
b $F829
t $F82B
b $F834
t $F836
b $F839
t $F83B
b $F840
t $F842
b $F847
t $F849
b $F853
t $F855
b $F85B
t $F85D
b $F860
t $F862
b $F867
t $F869
b $F86F
t $F871
b $F87A
t $F87C
b $F884
t $F886
b $F88C
t $F88E
b $F892
t $F894
b $F89A
t $F89C
b $F89F
t $F8A1
b $F8A7
t $F8A9
b $F8AC
t $F8AE
b $F8BB
t $F8BD
b $F8C3
t $F8C5
b $F8CB
t $F8CD
b $F8D2
t $F8D4
b $F8D9
t $F8DB
b $F8E1
t $F8E3
b $F8EC
t $F8EE
b $F8F3
t $F8F5
b $F8F8
t $F8FA
b $F8FE
t $F900
b $F905
t $F907
b $F90C
t $F90E
b $F917
t $F919
b $F927
t $F929
b $F92F
t $F931
b $F935
t $F937
b $F93E
t $F940
b $F943
t $F945
b $F94D
t $F94F
b $F957
t $F959
b $F960
t $F962
b $F96B
t $F971
b $F977
t $F97C
b $F986
t $F988
b $F991
t $F993
b $F999
t $F99B
b $F99F
t $F9A1
b $F9A9
t $F9AB
b $F9B5
t $F9B7
b $F9C0
t $F9C2
b $F9C7
t $F9C9
b $F9CE
t $F9D0
b $F9D7
t $F9D9
b $F9DD
t $F9DF
b $F9E5
t $F9E7
b $F9EA
t $F9EC
b $F9F0
t $F9F2
b $F9F8
t $F9FA
b $F9FD
t $F9FF
b $FA07
t $FA09
b $FA0D
t $FA0F
b $FA12
t $FA14
b $FA1B
t $FA1D
b $FA21
t $FA23
b $FA2A
t $FA2C
b $FA32
t $FA34
b $FA3B
t $FA3D
b $FA43
t $FA45
b $FA4A
t $FA4C
b $FA50
t $FA52
b $FA59
t $FA5B
b $FA60
t $FA62
b $FA65
t $FA67
b $FA6E
t $FA70
b $FA78
t $FA7E
b $FA89
t $FA8B
b $FA90
t $FA92
b $FA9B
t $FA9D
b $FAA1
t $FAA3
b $FAAA
t $FAAC
b $FAB1
t $FAB3
b $FABB
t $FAC4
b $FAC9
t $FACB
b $FAD6
t $FAD8
b $FADF
t $FAE1
b $FAE9
t $FAEB
b $FAF2
t $FAF4
b $FAF8
t $FAFA
b $FAFE
t $FB00
b $FB08
t $FB0A
b $FB10
t $FB12
b $FB16
t $FB18
b $FB1C
t $FB1E
b $FB24
t $FB26
b $FB2A
t $FB2C
b $FB30
t $FB32
b $FB38
t $FB3A
b $FB44
t $FB46
b $FB4A
t $FB4C
b $FB4F
t $FB51
b $FB59
t $FB5B
b $FB60
t $FB62
b $FB6C
t $FB72
b $FB79
t $FB7B
b $FB82
t $FB84
b $FB8A
t $FBEA
b $FBF8
t $FBFA
b $FC00
t $FC02
b $FC08
t $FC0A
b $FC0E
t $FC10
b $FC14
t $FC16
b $FC1A
t $FC1C
b $FC23
t $FC29
b $FC30
t $FC32
b $FC36
t $FD32
b $FD36
t $FD81
b $FD84
t $FDC1
b $FDC4
t $FDEF
b $FDF6
t $FE00
b $FE05
t $FE21
b $FE24
t $FE43
b $FE46
t $FE5B
b $FE5E
t $FE69
b $FE6E
t $FE71
b $FE76
t $FE79
b $FE7C
t $FE89
b $FE8C
t $FEA7
b $FEAC
t $FEAF
b $FEB4
t $FEB7
b $FEBC
t $FEBF
b $FEC2
t $FEC3
b $FEC6
t $FF01
b $FF05
t $FF22
b $FF25
t $FF3B
b $FF3E
t $FF6A
b $FF6E
t $FF72
s $FF76
t $FF79
b $FF7E
t $FF89
b $FF8E
t $FFA9
s $FFAE
t $FFB1
b $FFB4
t $FFB9
b $FFBE
t $FFC9
b $FFCC
