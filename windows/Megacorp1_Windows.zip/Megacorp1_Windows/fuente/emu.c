// emu.c - ZX Spectrum 48K (nucleo floooh/chips) + carga rapida de TZX
// mediante trampa en la rutina LD-BYTES (0x0556) de la ROM.
#include <string.h>
#define CHIPS_IMPL
#include "chips/chips_common.h"
#include "chips/z80.h"
#include "chips/beeper.h"
#include "chips/ay38910.h"
#include "chips/kbd.h"
#include "chips/clk.h"
#include "chips/mem.h"
#include "systems/zx.h"
#include "emu.h"

extern const unsigned char tape_tzx[];
extern const unsigned int tape_tzx_len;
extern const unsigned char rom_zx48k[16384];

#define LD_BYTES     0x0556
#define GAME_ENTRY   0x8538   // RANDOMIZE USR 34104
#define MAX_BLOCKS   64

static zx_t sys;
static emu_audio_fn audio_fn;
static void* audio_user;
static int audio_rate;

static struct { const uint8_t* data; uint32_t len; } blocks[MAX_BLOCKS];
static int num_blocks, next_block;
static bool game_started;
static bool hold_screen;     // SCREEN$ congelado hasta pulsar una tecla
static uint8_t* exec_map;
void (*emu_mem_hook)(uint16_t addr, uint8_t data, int write, uint16_t pc);

// ---- cola de teclas (escritura automatica y texto) ------------------------
#define KEYQ 256
static struct { int key; uint32_t hold_us; } keyq[KEYQ];
static int kq_head, kq_tail;
static int kq_active = -1;      // tecla pulsada actualmente por la cola
static int64_t kq_timer;        // microsegundos restantes en la fase actual
static bool kq_gap;

static void kq_push(int key, uint32_t hold) {
    int n = (kq_tail + 1) % KEYQ;
    if (n == kq_head) return;
    keyq[kq_tail].key = key; keyq[kq_tail].hold_us = hold; kq_tail = n;
}

static void kq_update(uint32_t us) {
    kq_timer -= us;
    if (kq_timer > 0) return;
    if (kq_active >= 0 && !kq_gap) {        // soltar y dejar un hueco
        if (kq_active > 0) zx_key_up(&sys, kq_active);
        kq_gap = true; kq_timer = 130000; return;
    }
    kq_active = -1; kq_gap = false;
    if (kq_head == kq_tail) return;
    int k = keyq[kq_head].key; kq_timer = keyq[kq_head].hold_us;
    kq_head = (kq_head + 1) % KEYQ;
    kq_active = k;                           // k==0: solo espera
    if (k > 0) zx_key_down(&sys, k);
}

// ---- TZX ------------------------------------------------------------------
static void parse_tzx(void) {
    const uint8_t* d = tape_tzx; uint32_t n = tape_tzx_len, p = 10;
    num_blocks = 0;
    if (n < 10 || memcmp(d, "ZXTape!\x1a", 8) != 0) return;
    while (p < n && num_blocks < MAX_BLOCKS) {
        uint8_t id = d[p++]; uint32_t len;
        switch (id) {
        case 0x10: len = d[p+2] | d[p+3]<<8;
                   blocks[num_blocks].data = d+p+4; blocks[num_blocks++].len = len; p += 4+len; break;
        case 0x11: len = d[p+15] | d[p+16]<<8 | d[p+17]<<16;
                   blocks[num_blocks].data = d+p+18; blocks[num_blocks++].len = len; p += 18+len; break;
        case 0x14: len = d[p+7] | d[p+8]<<8 | d[p+9]<<16;
                   blocks[num_blocks].data = d+p+10; blocks[num_blocks++].len = len; p += 10+len; break;
        case 0x12: p += 4; break;
        case 0x13: p += 1 + 2*d[p]; break;
        case 0x15: p += 8 + (d[p+5] | d[p+6]<<8 | d[p+7]<<16); break;
        case 0x20: case 0x23: case 0x24: p += 2; break;
        case 0x21: case 0x30: p += 1 + d[p]; break;
        case 0x22: case 0x25: case 0x27: break;
        case 0x31: p += 2 + d[p+1]; break;
        case 0x32: p += 2 + (d[p] | d[p+1]<<8); break;
        case 0x33: p += 1 + 3*d[p]; break;
        case 0x35: p += 20 + (d[p+16] | d[p+17]<<8 | d[p+18]<<16 | (uint32_t)d[p+19]<<24); break;
        default: return;
        }
    }
}

static inline uint8_t rd(uint16_t a) { return mem_rd(&sys.mem, a); }
static inline void wr(uint16_t a, uint8_t v) { mem_wr(&sys.mem, a, v); }

// Emula LD-BYTES: A=flag, IX=destino, DE=longitud, Carry=LOAD(1)/VERIFY(0)
static uint64_t ld_bytes_trap(void) {
    z80_t* c = &sys.cpu;
    uint16_t sp = c->sp;
    bool ok = false;
    // LD-BYTES hace PUSH 0x053F (SA/LD-RET) antes de cargar
    wr(sp-2, 0x3F); wr(sp-1, 0x05);
    if (next_block < num_blocks) {
        const uint8_t* b = blocks[next_block].data; uint32_t len = blocks[next_block].len;
        next_block++;
        bool load = c->f & Z80_CF;
        if (len >= 2 && b[0] == c->a) {
            uint32_t want = c->de, have = len - 2;   // sin flag ni checksum
            if (load) {
                uint32_t nn = want < have ? want : have;
                for (uint32_t i = 0; i < nn; i++) wr(c->ix + i, b[1+i]);
                c->ix += nn; c->de -= nn;
            }
            ok = (want <= have);
        }
    }
    c->iff1 = c->iff2 = false;               // LD-BYTES ejecuta DI
    if (ok) c->f |= Z80_CF; else c->f &= ~Z80_CF;
    // el RET final saca de la pila lo que haya en sp-2 (puede haberlo
    // sobrescrito la propia carga, como ocurre en este juego)
    uint16_t ret = rd(sp-2) | rd(sp-1)<<8;
    c->sp = sp;
    return z80_prefetch(c, ret);
}

// ---- API ------------------------------------------------------------------
static void audio_thunk(const float* s, int n, void* u) { (void)u; if (audio_fn) audio_fn(s, n, audio_user); }

static void boot(void) {
    zx_desc_t desc = {0};
    desc.type = ZX_TYPE_48K;
    desc.joystick_type = ZX_JOYSTICKTYPE_NONE;
    desc.audio.callback.func = audio_thunk;
    desc.audio.sample_rate = audio_rate;
    desc.audio.beeper_volume = 0.35f;
    desc.roms.zx48k.ptr = (void*)rom_zx48k;
    desc.roms.zx48k.size = 16384;
    zx_init(&sys, &desc);
    parse_tzx();
    next_block = 0; game_started = false; hold_screen = false;
    kq_head = kq_tail = 0; kq_active = -1; kq_timer = 0; kq_gap = false;
    // esperar al mensaje de copyright y teclear: LOAD "" <ENTER>
    kq_push(0, 2500000);
    kq_push('j', 100000);           // en modo K, J = LOAD
    kq_push('"', 100000);
    kq_push('"', 100000);
    kq_push(0x0D, 100000);
}

void emu_init(emu_audio_fn cb, void* user, int sample_rate) {
    audio_fn = cb; audio_user = user; audio_rate = sample_rate > 0 ? sample_rate : 44100;
    boot();
}
void emu_reset(void) { zx_discard(&sys); boot(); }

void emu_run(uint32_t us) {
    if (hold_screen) return;                // emulacion detenida sobre el SCREEN$
    uint32_t ticks = clk_us_to_ticks(sys.freq_hz, us);
    uint64_t pins = sys.pins;
    for (uint32_t t = 0; t < ticks; t++) {
        pins = _zx_tick(&sys, pins);
        if (emu_mem_hook && (pins & Z80_MREQ) && !(pins & Z80_M1) && (pins & (Z80_RD|Z80_WR)))
            emu_mem_hook(Z80_GET_ADDR(pins), Z80_GET_DATA(pins), (pins & Z80_WR) != 0, sys.cpu.pc);
        if (z80_opdone(&sys.cpu)) {
            uint16_t a = Z80_GET_ADDR(pins);
            if (exec_map) exec_map[a] = 1;
            if (a == LD_BYTES) pins = ld_bytes_trap();
            else if (a == GAME_ENTRY && !game_started) {
                // el volcado de 48K ya ha dejado la pantalla de carga en
                // $4000: congelarla aqui, antes de que el juego la borre
                game_started = true; hold_screen = true;
                break;
            }
        }
    }
    sys.pins = pins;
    kbd_update(&sys.kbd, us);
    kq_update(us);
}

bool emu_game_started(void) { return game_started; }
bool emu_screen_held(void) { return hold_screen; }
void emu_release_screen(void) { hold_screen = false; }
void emu_key_down(int k) { zx_key_down(&sys, k); }
void emu_key_up(int k) { zx_key_up(&sys, k); }
void emu_type_char(int k) { kq_push(k, 70000); }
uint8_t emu_peek(uint16_t a) { return rd(a); }
uint16_t emu_pc(void) { return sys.cpu.pc; }
void emu_set_exec_map(uint8_t* m) { exec_map = m; }

void emu_render_argb(uint32_t* dst) {
    chips_display_info_t di = zx_display_info(&sys);
    const uint32_t* pal = (const uint32_t*)di.palette.ptr;   // 0xAABBGGRR
    const uint8_t* fb = sys.fb;
    if (hold_screen) {
        // dibujar directamente desde la memoria de video ($4000-$5AFF)
        const int bx = (EMU_DISPLAY_W - 256) / 2, by = (EMU_DISPLAY_H - 192) / 2;
        for (int y = 0; y < EMU_DISPLAY_H; y++) {
            for (int x = 0; x < EMU_DISPLAY_W; x++) {
                int idx = sys.border_color & 7;
                int sx = x - bx, sy = y - by;
                if (sx >= 0 && sx < 256 && sy >= 0 && sy < 192) {
                    uint16_t pa = 0x4000 | ((sy & 0xC0) << 5) | ((sy & 7) << 8) | ((sy & 0x38) << 2) | (sx >> 3);
                    uint8_t at = rd(0x5800 + (sy >> 3) * 32 + (sx >> 3));
                    bool ink = (rd(pa) >> (7 - (sx & 7))) & 1;
                    idx = (ink ? (at & 7) : ((at >> 3) & 7)) | ((at & 0x40) ? 8 : 0);
                }
                uint32_t c = pal[idx];
                dst[y*EMU_DISPLAY_W + x] = (c & 0xFF00FF00) | ((c & 0xFF) << 16) | ((c >> 16) & 0xFF);
            }
        }
        return;
    }
    for (int y = 0; y < EMU_DISPLAY_H; y++) {
        for (int x = 0; x < EMU_DISPLAY_W; x++) {
            uint32_t c = pal[fb[y*ZX_FRAMEBUFFER_WIDTH + x] & 15];
            dst[y*EMU_DISPLAY_W + x] = (c & 0xFF00FF00) | ((c & 0xFF) << 16) | ((c >> 16) & 0xFF);
        }
    }
}
