// emu.h - nucleo ZX Spectrum 48K con la cinta de Megacorp incrustada
#pragma once
#include <stdint.h>
#include <stdbool.h>

#define EMU_DISPLAY_W 320
#define EMU_DISPLAY_H 256

typedef void (*emu_audio_fn)(const float* samples, int num_samples, void* user);

void emu_init(emu_audio_fn audio_cb, void* audio_user, int sample_rate);
void emu_reset(void);                     // reinicia y vuelve a cargar la cinta
void emu_run(uint32_t micro_seconds);     // avanza la emulacion
bool emu_game_started(void);              // true cuando el juego ha llegado a 0x8538
bool emu_screen_held(void);               // true mientras se muestra el SCREEN$ congelado
void emu_release_screen(void);            // continuar el juego tras la pantalla de carga
void emu_key_down(int zx_key);
void emu_key_up(int zx_key);
void emu_type_char(int zx_key);           // pulsacion breve encolada (para texto)
// copia la imagen visible (320x256) como pixeles 0xAARRGGBB
void emu_render_argb(uint32_t* dst);
// acceso para pruebas / volcado de mapa de ejecucion
uint8_t emu_peek(uint16_t addr);
uint16_t emu_pc(void);
void emu_set_exec_map(uint8_t* map65536);
