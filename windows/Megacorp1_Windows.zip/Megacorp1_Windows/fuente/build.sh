#!/bin/sh
# Compilación cruzada desde Linux (zig: pip install ziglang)
# Requiere las cabeceras de https://github.com/floooh/chips (commit 9e88298) en ./chips
python3 -m ziglang cc -target x86_64-windows-gnu -O2 -s -I./chips \
  -Wl,--subsystem,windows -o Megacorp1.exe win_main.c emu.c data_ram1.c \
  -lwinmm -lgdi32 -luser32
# Con MinGW en Windows:
#   gcc -O2 -s -I./chips -mwindows -o Megacorp1.exe win_main.c emu.c data_ram1.c -lwinmm -lgdi32
