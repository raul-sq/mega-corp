#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "emu.h"
static uint32_t px[EMU_DISPLAY_W*EMU_DISPLAY_H];
static uint8_t map[65536];
static void shot(const char* fn){ emu_render_argb(px); FILE*f=fopen(fn,"wb");
 fprintf(f,"P6 %d %d 255\n",EMU_DISPLAY_W,EMU_DISPLAY_H);
 for(int i=0;i<EMU_DISPLAY_W*EMU_DISPLAY_H;i++){fputc(px[i]>>16&255,f);fputc(px[i]>>8&255,f);fputc(px[i]&255,f);} fclose(f);}
static void run_s(double s){ for(int i=0;i<(int)(s*50);i++) emu_run(20000); }
static void type(const char* s){ for(;*s;s++) emu_type_char(*s=='\n'?0x0D:*s); }
int main(int argc,char**argv){
  emu_init(0,0,44100); emu_set_exec_map(map);
  int f=0; while(!emu_game_started() && f<50*30){ emu_run(20000); f++; }
  printf("game started=%d after %.2fs pc=%04x\n",emu_game_started(),f/50.0,emu_pc());
  printf("held=%d\n",emu_screen_held());
  run_s(5); shot("held.ppm"); printf("still held after 5s=%d pc=%04x\n",emu_screen_held(),emu_pc());
  emu_release_screen();
  run_s(3); shot("t0.ppm");
  for(int i=2;i<argc;i++){ type(argv[i]); type("\n"); run_s(8); char fn[32]; sprintf(fn,"t%d.ppm",i-1); shot(fn); }
  FILE* m=fopen(argv[1],"w"); for(int a=0;a<65536;a++) if(map[a]) fprintf(m,"%d\n",a); fclose(m);
  return 0; }
