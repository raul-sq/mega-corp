// win_main.c - frontend Win32 para Megacorp (Parte 1), ZX Spectrum 48K
// Video: GDI StretchDIBits. Audio: waveOut. Sin dependencias externas.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <mmsystem.h>
#include <string.h>
#include "emu.h"

#ifndef GAME_TITLE
#define GAME_TITLE "Megacorp (Parte 1) - Dinamic 1987 - ZX Spectrum 48K"
#endif

#define SAMPLE_RATE 44100
#define NBUF 4
#define BUFLEN 1024
#define RING (SAMPLE_RATE)

static uint32_t pixels[EMU_DISPLAY_W * EMU_DISPLAY_H];
static BITMAPINFO bmi;
static HWND hwnd;
static int scale = 2;

// ---- audio ------------------------------------------------------------------
static HWAVEOUT wo;
static WAVEHDR hdr[NBUF];
static short abuf[NBUF][BUFLEN];
static short ring[RING];
static volatile int r_rd, r_wr;
static bool audio_on;
static bool muted;               // silencio interno (carga acelerada)
static bool sound_on = true;     // eleccion del usuario (menu Juego > Sonido)
static bool dismiss_armed;       // tecla pulsada sobre la pantalla de carga
static HMENU game_menu;

#define ID_RESET 101
#define ID_SOUND 102
#define ID_EXIT  103

static void audio_cb(const float* s, int n, void* u) {
    (void)u;
    if (!audio_on || muted || !sound_on) return;
    for (int i = 0; i < n; i++) {
        int nx = (r_wr + 1) % RING;
        if (nx == r_rd) break;                 // lleno: descartar
        float v = s[i]; if (v > 1) v = 1; if (v < -1) v = -1;
        ring[r_wr] = (short)(v * 32000); r_wr = nx;
    }
}

static void audio_pump(void) {
    if (!audio_on) return;
    for (int b = 0; b < NBUF; b++) {
        if (!(hdr[b].dwFlags & WHDR_DONE)) continue;
        for (int i = 0; i < BUFLEN; i++) {
            if (r_rd != r_wr) { abuf[b][i] = ring[r_rd]; r_rd = (r_rd + 1) % RING; }
            else abuf[b][i] = i ? abuf[b][i-1] : 0;
        }
        hdr[b].dwFlags &= ~WHDR_DONE;
        waveOutWrite(wo, &hdr[b], sizeof(WAVEHDR));
    }
    // si el emulador se adelanta demasiado, recortar latencia
    int avail = (r_wr - r_rd + RING) % RING;
    if (avail > SAMPLE_RATE / 4) r_rd = (r_wr - SAMPLE_RATE / 10 + RING) % RING;
}

static void audio_init(void) {
    WAVEFORMATEX wf = {0};
    wf.wFormatTag = WAVE_FORMAT_PCM; wf.nChannels = 1; wf.nSamplesPerSec = SAMPLE_RATE;
    wf.wBitsPerSample = 16; wf.nBlockAlign = 2; wf.nAvgBytesPerSec = SAMPLE_RATE * 2;
    if (waveOutOpen(&wo, WAVE_MAPPER, &wf, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) return;
    for (int b = 0; b < NBUF; b++) {
        memset(&hdr[b], 0, sizeof(WAVEHDR));
        hdr[b].lpData = (LPSTR)abuf[b]; hdr[b].dwBufferLength = BUFLEN * 2;
        waveOutPrepareHeader(wo, &hdr[b], sizeof(WAVEHDR));
        hdr[b].dwFlags |= WHDR_DONE;
    }
    audio_on = true;
}

// ---- teclado ------------------------------------------------------------------
// Teclas "fisicas" (se mantienen mientras estan pulsadas): letras, numeros,
// espacio, Enter, cursores, borrar. Simbolos (WM_CHAR) van por la cola.
static int vk_to_zx(WPARAM vk) {
    if (vk >= 'A' && vk <= 'Z') return (int)(vk - 'A' + 'a');
    if (vk >= '0' && vk <= '9') return (int)vk;
    switch (vk) {
    case VK_SPACE: return ' ';
    case VK_RETURN: return 0x0D;
    case VK_BACK: return 0x0C;
    case VK_LEFT: return 0x08;
    case VK_RIGHT: return 0x09;
    case VK_DOWN: return 0x0A;
    case VK_UP: return 0x0B;
    }
    return 0;
}

static bool is_sym(WPARAM ch) {
    return ch && strchr(":?/<>!@#$%_)('&\";=+-^.,*", (int)ch) != NULL;
}

static void present(HDC dc) {
    RECT rc; GetClientRect(hwnd, &rc);
    int w = rc.right, h = rc.bottom;
    int s = w / EMU_DISPLAY_W; if (h / EMU_DISPLAY_H < s) s = h / EMU_DISPLAY_H; if (s < 1) s = 1;
    int dw = EMU_DISPLAY_W * s, dh = EMU_DISPLAY_H * s;
    int ox = (w - dw) / 2, oy = (h - dh) / 2;
    SetStretchBltMode(dc, COLORONCOLOR);
    StretchDIBits(dc, ox, oy, dw, dh, 0, 0, EMU_DISPLAY_W, EMU_DISPLAY_H,
                  pixels, &bmi, DIB_RGB_COLORS, SRCCOPY);
    HBRUSH br = (HBRUSH)GetStockObject(BLACK_BRUSH);
    RECT r1 = {0, 0, w, oy}, r2 = {0, oy + dh, w, h}, r3 = {0, oy, ox, oy + dh}, r4 = {ox + dw, oy, w, oy + dh};
    FillRect(dc, &r1, br); FillRect(dc, &r2, br); FillRect(dc, &r3, br); FillRect(dc, &r4, br);
}

static LRESULT CALLBACK wndproc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_KEYDOWN: case WM_SYSKEYDOWN: {
        bool ctrl_only = (GetKeyState(VK_CONTROL) & 0x8000) && !(GetKeyState(VK_MENU) & 0x8000);
        if (ctrl_only && wp == 'R') { SendMessageA(h, WM_COMMAND, ID_RESET, 0); return 0; }
        if (ctrl_only && wp == 'M') { SendMessageA(h, WM_COMMAND, ID_SOUND, 0); return 0; }
        if (emu_screen_held()) {
            // pantalla de carga: cualquier tecla (salvo modificadores) la cierra
            // al soltarla; esa pulsacion no llega al juego
            if (wp != VK_CONTROL && wp != VK_MENU && wp != VK_LWIN && wp != VK_RWIN) dismiss_armed = true;
            if (msg == WM_SYSKEYDOWN) break;
            return 0;
        }
        int k = vk_to_zx(wp);
        if (k && !(lp & (1 << 30))) {
            bool shift = GetKeyState(VK_SHIFT) & 0x8000;
            bool ctrl  = GetKeyState(VK_CONTROL) & 0x8000;
            // con Shift/AltGr se escribe un simbolo: dejarlo a WM_CHAR
            if (!(shift && k >= '0' && k <= '9') && !ctrl) {
                if (shift && k >= 'a' && k <= 'z') k = k - 'a' + 'A';
                emu_key_down(k);
            }
        }
        if (msg == WM_SYSKEYDOWN) break;
        return 0;
    }
    case WM_KEYUP: case WM_SYSKEYUP: {
        if (emu_screen_held()) {
            if (dismiss_armed) { dismiss_armed = false; emu_release_screen(); }
            if (msg == WM_SYSKEYUP) break;
            return 0;
        }
        int k = vk_to_zx(wp);
        if (k) {
            emu_key_up(k);
            if (k >= 'a' && k <= 'z') emu_key_up(k - 'a' + 'A');
        }
        if (msg == WM_SYSKEYUP) break;
        return 0;
    }
    case WM_CHAR:
        if (!emu_screen_held() && is_sym(wp)) emu_type_char((int)wp);
        return 0;
    case WM_LBUTTONUP:
        if (emu_screen_held()) emu_release_screen();
        return 0;
    case WM_COMMAND:
        switch (LOWORD(wp)) {
        case ID_RESET:
            dismiss_armed = false; muted = true; emu_reset(); return 0;
        case ID_SOUND:
            sound_on = !sound_on;
            CheckMenuItem(game_menu, ID_SOUND, MF_BYCOMMAND | (sound_on ? MF_CHECKED : MF_UNCHECKED));
            r_rd = r_wr; return 0;
        case ID_EXIT:
            DestroyWindow(h); return 0;
        }
        break;
    case WM_PAINT: {
        PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps); present(dc); EndPaint(h, &ps); return 0;
    }
    case WM_ERASEBKGND: return 1;
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcA(h, msg, wp, lp);
}

int WINAPI WinMain(HINSTANCE inst, HINSTANCE prev, LPSTR cmd, int show) {
    (void)prev; (void)cmd;
    timeBeginPeriod(1);
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = EMU_DISPLAY_W;
    bmi.bmiHeader.biHeight = -EMU_DISPLAY_H;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    WNDCLASSA wc = {0};
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = wndproc;
    wc.hInstance = inst;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hIcon = LoadIcon(inst, MAKEINTRESOURCE(1));
    wc.lpszClassName = "MegacorpZX";
    RegisterClassA(&wc);
    RECT r = {0, 0, EMU_DISPLAY_W * scale, EMU_DISPLAY_H * scale};
    HMENU bar = CreateMenu();
    game_menu = CreatePopupMenu();
    AppendMenuA(game_menu, MF_STRING, ID_RESET, "&Reiniciar\tCtrl+R");
    AppendMenuA(game_menu, MF_STRING | MF_CHECKED, ID_SOUND, "&Sonido\tCtrl+M");
    AppendMenuA(game_menu, MF_SEPARATOR, 0, NULL);
    AppendMenuA(game_menu, MF_STRING, ID_EXIT, "Sa&lir");
    AppendMenuA(bar, MF_POPUP, (UINT_PTR)game_menu, "&Juego");
    AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, TRUE);
    hwnd = CreateWindowA("MegacorpZX", GAME_TITLE,
                         WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
                         r.right - r.left, r.bottom - r.top, NULL, bar, inst, NULL);
    ShowWindow(hwnd, show);

    audio_init();
    muted = true;                      // silencio durante la carga acelerada
    emu_init(audio_cb, NULL, SAMPLE_RATE);

    LARGE_INTEGER freq, last, now;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&last);
    bool running = true;
    while (running) {
        MSG m;
        while (PeekMessageA(&m, NULL, 0, 0, PM_REMOVE)) {
            if (m.message == WM_QUIT) running = false;
            TranslateMessage(&m); DispatchMessageA(&m);
        }
        if (!running) break;
        if (!emu_game_started()) {
            // carga acelerada: arranque de ROM + LOAD "" a maxima velocidad
            muted = true;
            for (int i = 0; i < 25 && !emu_game_started(); i++) emu_run(20000);
            if (emu_game_started()) { muted = false; r_rd = r_wr; }
            QueryPerformanceCounter(&last);
        } else {
            QueryPerformanceCounter(&now);
            double us = (double)(now.QuadPart - last.QuadPart) * 1e6 / (double)freq.QuadPart;
            if (us > 100000) us = 100000;
            if (us >= 1000) { emu_run((uint32_t)us); last = now; }
        }
        audio_pump();
        emu_render_argb(pixels);
        HDC dc = GetDC(hwnd); present(dc); ReleaseDC(hwnd, dc);
        Sleep(emu_game_started() ? 8 : 0);
    }
    if (audio_on) { waveOutReset(wo); waveOutClose(wo); }
    timeEndPeriod(1);
    return 0;
}
