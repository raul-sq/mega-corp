; ============================================================================
;  MEGACORP (1ª parte) - Dinamic Software, 1987 - ZX Spectrum 48K
;  Autores: N. Lecuona y L. Franco
;  Desensamblado generado a partir de "Megacorp - Part 1.tzx"
; ----------------------------------------------------------------------------
;  Estructura de la cinta:
;    Bloque 0/1  Programa BASIC "MEGACORP1" (44 bytes):
;                10 BORDER 0: PAPER 0: INK 0: POKE 23624,0: CLEAR 23999:
;                   LOAD "" CODE
;    Bloque 2/3  Bytes "megacode": 49152 bytes en 16384 ($4000-$FFFF),
;                es decir, un volcado completo de la RAM (pantalla de
;                carga incluida, variables del sistema y pila).
;
;  Arranque (no hay USR en el cargador): el bloque de 48K sobrescribe la
;  pila de la máquina mientras carga. En $5DB6 quedan las direcciones
;  $053F, $053F, $1B76: al terminar LD-BYTES la ROM vuelve dos veces por
;  SA/LD-RET y después a STMT-RET, de modo que el intérprete BASIC sigue
;  ejecutando un programa nuevo que viene dentro del volcado (PROG=$5CCB):
;                1 SAVE "vars" CODE 23552,447: RANDOMIZE USR 34104
;  El juego empieza en $8538 (34104).
;
;  Este listado parte del estado de la memoria justo al llegar a $8538 y
;  cubre $5C00-$FFFF. Código ejecutado observado: $6318-$95DD. La
;  separación código/datos se hizo con un mapa de ejecución real
;  (pantalla de título + varias órdenes de juego); las rutinas que no se
;  llegaron a ejecutar pueden aparecer como DEFB.
;
;  Verificación: reensamblado (skool2bin) = memoria original, 0 bytes
;  de diferencia.
;  Herramientas: SkoolKit (tap2sna, trace, sna2ctl, sna2skool, skool2asm).
; ============================================================================

  ORG $5C00

; Data block at 5C00
  DEFB $FF,$00,$19,$20,$FF,$00,$23,$0D
  DEFB $0D,$23,$05,$00,$00,$00,$10,$00
  DEFB $01,$00,$06,$00,$0B,$00,$01,$00
  DEFB $01,$00,$06,$00,$10,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$FF,$FB
  DEFB $40,$05,$FF,$CC,$01,$BC,$5D,$BC
  DEFB $5D,$00,$00,$00,$FF,$01,$00,$02
  DEFB $07,$01,$00,$FB,$5C,$00,$00,$B6
  DEFB $5C,$B6,$5C,$CB,$5C,$FB,$5C,$CA
  DEFB $5C,$FC,$5C,$FD,$5C,$FA,$5C,$FD
  DEFB $00,$FF,$5C,$FF,$5C,$FF,$5C,$2D
  DEFB $92,$5C,$08,$02,$00,$00,$FE,$FF
  DEFB $01,$00,$00,$00,$B6,$1A,$81,$96
  DEFB $9A,$23,$00,$58,$FF,$00,$00,$21
  DEFB $00,$5B,$21,$17,$00,$40,$E0,$50
  DEFB $21,$18,$21,$17,$01,$07,$00,$07
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$0A,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$BF,$5D,$FF,$FF,$F4,$09
  DEFB $A8,$10,$4B,$F4,$09,$C4,$15,$53
  DEFB $81,$0F,$C4,$15,$52,$F4,$09,$C4
  DEFB $15,$50,$80,$00,$01,$2C,$00,$F8

; Message at 5CD0
  DEFM "\"vars\""

; Data block at 5CD6
  DEFB $AF

; Message at 5CD7
  DEFM "23552"

; Data block at 5CDC
  DEFB $0E,$00,$00,$00,$5C,$00

; Message at 5CE2
  DEFM ",447"

; Data block at 5CE6
  DEFB $0E,$00,$00,$BF,$01,$00,$3A,$F9
  DEFB $C0

; Message at 5CEF
  DEFM "34104"

; Data block at 5CF4
  DEFB $0E,$00,$00,$38,$85,$00,$0D,$80
  DEFB $F7,$0D,$80,$00,$00,$38,$85,$00

; Message at 5D04
  DEFM "      "

; Data block at 5D0A
  DEFB $BF,$01,$00,$5C,$00,$80,$00,$00
  DEFB $00,$5C,$00,$00,$00,$BF,$01,$00
  DEFB $BF,$01,$00,$3A,$F9,$C0

; Message at 5D20
  DEFM "34104"

; Data block at 5D25
  DEFB $0E,$00,$00,$38,$85,$00,$0D,$80
  DEFB $00,$00,$00,$0A,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$E0,$57,$71
  DEFB $0E,$00,$01,$30,$0D,$F3,$0D,$DB
  DEFB $02,$4D,$00,$F3,$0D,$CE,$0B,$E2
  DEFB $50,$CE,$0B,$E3,$50,$1E,$17,$DC
  DEFB $0A,$CE,$0B,$E4,$50,$1D,$17,$DB
  DEFB $02,$4D,$00,$07,$00,$00,$00,$F7
  DEFB $5A,$5C,$07,$B7,$2D,$FF,$5C,$FA
  DEFB $5C,$38,$85

; Message at 5DA8
  DEFM "+-e3"

; Data block at 5DAC
  DEFB $00,$00,$ED,$10,$0D,$00,$09,$00
  DEFB $85,$1C,$10,$1C,$52,$1B,$76,$1B
  DEFB $00,$00,$00,$00

; Message at 5DC0
  DEFM "8DDDDDDDDDDD(("

; Data block at 5DCE
  DEFB $10,$10,$3F,$3F,$00,$00,$00,$00
  DEFB $00,$00,$FF,$FF,$00,$00,$00,$00
  DEFB $00,$00,$FC,$FC,$00,$00,$00,$00
  DEFB $00,$00,$FF,$FF,$FF,$FF,$FF,$FF
  DEFB $FF,$FF,$08,$0C,$0E,$FF,$FF,$0E
  DEFB $0C,$08,$18,$3C,$7E,$FF,$18,$18
  DEFB $18,$18,$18,$18,$18,$18,$FF,$7E
  DEFB $3C,$18,$00,$3C,$66,$C3,$C3,$66
  DEFB $3C,$00,$00,$3C,$7E,$FF,$FF,$7E
  DEFB $3C,$00

; Message at 5E18
  DEFM ">>>"

; Data block at 5E1B
  DEFB $FF

; Message at 5E1C
  DEFM "abina de la nave. Salidas:Sur.********************************"

; Data block at 5E5A
  DEFB $FF

; Message at 5E5B
  DEFM "tura/grafico/conversacional    por N.Lecuona y L.Franco        --"
  DEFM "- PULSE UNA TECLA ---                                         DIN"
  DEFM "AMIC SOFTWARE 1987                                      "

; Data block at 5F15
  DEFB $FF,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$D5,$3C,$B2,$3C,$68
  DEFB $FF,$45,$20,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00

; Routine at 6318
;
; Used by the routines at 7C3F and 81E1.
  JP $7157                ; Jump to 7157

; Data block at 631B
  DEFB $C3,$DA,$71

; Routine at 631E
;
; Used by the routines at 7669, 778A, 815B, 8171, 81BE, 81E1, 886C and 95D5.
  JP $6E75                ; Jump to 6E75

; Routine at 6321
;
; Used by the routine at 778A.
  JP $7136                ; Jump to 7136

; Routine at 6324
;
; Used by the routines at 7C3F and 81E1.
  JP $71C6                ; Jump to 71C6

; Routine at 6327
;
; Used by the routines at 7C3F and 81E1.
  JP $71AA                ; Jump to 71AA

; Data block at 632A
  DEFB $C3,$E1,$6D,$C3,$3C,$64

; Routine at 6330
;
; Used by the routines at 7B3F and 7C3F.
  JP $714F                ; Jump to 714F

; Routine at 6333
;
; Used by the routine at 7B3F.
  JP $7194                ; Jump to 7194

; Routine at 6336
;
; Used by the routine at 7649.
  JP $68C2                ; Jump to 68C2

; Data block at 6339
  DEFB $C3,$35,$65,$C3,$E3,$71,$80,$70
  DEFB $80,$70,$00,$00,$00,$00,$00,$00
  DEFB $00,$18,$5E,$00,$00,$00,$02,$40
  DEFB $9C,$00,$00,$56,$63,$1F,$01,$0C
  DEFB $00,$00,$00,$00,$00,$00,$01,$00
  DEFB $00,$00,$07

; Routine at 6364
;
; Used by the routine at 6CE8.
  LD HL,$0000             ; HL=$0000
  JR $6371                ; Jump to 6371

; Routine at 6369
  LD HL,$FFAA             ; HL=$FFAA
  JR $6371                ; Jump to 6371

; Routine at 636E
  LD HL,$00FF             ; HL=$00FF
; This entry point is used by the routines at 6364 and 6369.
  LD ($6343),HL           ; POKE $6343,L; POKE $6344,H
  LD DE,($6341)           ; E=PEEK $6341; D=PEEK $6342
  PUSH DE                 ; Push DE onto the stack
  CALL $64D9              ; CALL 64D9
  POP BC                  ; Pop last item from stack into BC
  RET NZ                  ; Return if the zero flag is not set
  PUSH BC                 ; Push BC onto the stack
  JR $6388                ; Jump to 6388

; Routine at 6381
  PUSH DE                 ; Push DE onto the stack
  CALL $64D9              ; CALL 64D9
  POP BC                  ; Pop last item from stack into BC
  JR NZ,$6393             ; Jump to 6393 if the zero flag is not set
; This entry point is used by the routine at 636E.
  PUSH BC                 ; Push BC onto the stack
  CALL $63A5              ; CALL 63A5
  POP DE                  ; Pop last item from stack into DE
  INC D                   ; D=D+1
  LD A,D                  ; A=D
  CP $B0                  ; Set the zero flag if A=$B0, or the carry flag if
                          ; A<$B0
  JR C,$6381              ; Jump to 6381 if A<$B0
  POP DE                  ; Pop last item from stack into DE
  DEC D                   ; D=D-1
  LD A,D                  ; A=D
  CP $30                  ; Set the zero flag if A=$30, or the carry flag if
                          ; A<$30
  RET C                   ; Return if A<$30
  PUSH DE                 ; Push DE onto the stack
  CALL $64D9              ; CALL 64D9
  POP BC                  ; Pop last item from stack into BC
  RET NZ                  ; Return if the zero flag is not set
  PUSH BC                 ; Push BC onto the stack
  CALL $63A5              ; CALL 63A5
  JR $6393                ; Jump to 6393

; Routine at 63A5
;
; Used by the routine at 6381.
  PUSH BC                 ; Push BC onto the stack
  LD HL,($6343)           ; L=PEEK $6343; H=PEEK $6344
  LD A,L                  ; A=L
  BIT 0,B                 ; Set the zero flag if bit 0 of B is 0
  JR Z,$63AF              ; Jump to 63AF if bit 0 of B is reset
  XOR H                   ; A=A^H
  LD ($6345),A            ; POKE $6345,A
  DEC C                   ; C=C-1
  LD A,C                  ; A=C
  INC A                   ; A=A+1
  CALL NZ,$63DF           ; CALL 63DF if A>0
  POP BC                  ; Pop last item from stack into BC
  JP $63BC                ; Jump to 63BC
  CALL $64EB              ; CALL 64EB
  LD B,A                  ; B=A
  XOR A                   ; A=0
  INC B                   ; B=B+1
  SCF                     ; Set the carry flag
  RLA                     ; Rotate A left through the carry flag
  DJNZ $63C3              ; Decrement B and jump to 63C3 if B>0
  LD B,A                  ; B=A
  CALL $6425              ; CALL 6425
  BIT 0,C                 ; Set the zero flag if bit 0 of C is 0
  RET Z                   ; Return if bit 0 of C is reset
  INC HL                  ; HL=HL+1
  LD A,L                  ; A=L
  AND $1F                 ; Reset bits 5, 6 and 7 of A
  RET Z                   ; Return if A=0
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$6423             ; Jump to 6423 if A>0
  LD A,($6345)            ; A=PEEK $6345
  LD (HL),A               ; POKE HL,A
  CALL $6434              ; CALL 6434
  JR $63CD                ; Jump to 63CD

; Routine at 63DF
;
; Used by the routine at 63A5.
  CALL $64EB              ; CALL 64EB
  LD B,A                  ; B=A
  XOR A                   ; A=0
  INC B                   ; B=B+1
  SCF                     ; Set the carry flag
  RLA                     ; Rotate A left through the carry flag
  DJNZ $63E6              ; Decrement B and jump to 63E6 if B>0
  LD B,A                  ; B=A
  CALL $6406              ; CALL 6406
  BIT 7,C                 ; Set the zero flag if bit 7 of C is 0
  RET Z                   ; Return if bit 7 of C is reset
  DEC HL                  ; HL=HL-1
  LD A,L                  ; A=L
  AND $1F                 ; Reset bits 5, 6 and 7 of A
  CP $1F                  ; Set the zero flag if A=$1F, or the carry flag if
                          ; A<$1F
  RET Z                   ; Return if A=$1F
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$6404             ; Jump to 6404 if A>0
  LD A,($6345)            ; A=PEEK $6345
  LD (HL),A               ; POKE HL,A
  CALL $6434              ; CALL 6434
  JR $63F0                ; Jump to 63F0
  LD B,$01                ; B=$01
  LD C,$00                ; C=$00
  LD A,B                  ; A=B
  AND (HL)                ; A=A&PEEK HL
  JR NZ,$6413             ; Jump to 6413 if A>0
  LD A,B                  ; A=B
  OR C                    ; A=A|C
  LD C,A                  ; C=A
  SLA B                   ; Shift B left (copying bit 7 into the carry flag,
                          ; and resetting bit 0)
  JR NC,$6408             ; Jump to 6408 if the carry flag is not set
; This entry point is used by the routine at 6423.
  LD A,($6345)            ; A=PEEK $6345
  AND C                   ; A=A&C
  LD B,A                  ; B=A
  LD A,C                  ; A=C
  CPL                     ; A=$FF-A
  AND (HL)                ; A=A&PEEK HL
  OR B                    ; A=A|B
  LD (HL),A               ; POKE HL,A
  LD A,C                  ; A=C
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  CALL NZ,$6434           ; CALL 6434 if A>0
  RET                     ; Return

; Routine at 6423
;
; Used by the routine at 63A5.
  LD B,$80                ; B=$80
; This entry point is used by the routine at 63A5.
  LD C,$00                ; C=$00
  LD A,B                  ; A=B
  AND (HL)                ; A=A&PEEK HL
  JR NZ,$6413             ; Jump to 6413 if A>0
  LD A,B                  ; A=B
  OR C                    ; A=A|C
  LD C,A                  ; C=A
  SRL B                   ; Shift B right (copying bit 0 into the carry flag,
                          ; and resetting bit 7)
  JR C,$6413              ; Jump to 6413 if the carry flag is set
  JR $6427                ; Jump to 6427

; Routine at 6434
;
; Used by the routines at 63A5 and 63DF.
  PUSH HL                 ; Push HL onto the stack
  PUSH BC                 ; Push BC onto the stack
  CALL $64C0              ; CALL 64C0
  POP BC                  ; Pop last item from stack into BC
  POP HL                  ; Pop last item from stack into HL
  RET                     ; Return

; Routine at 643C
;
; Used by the routine at 648A.
  BIT 7,D                 ; Set the zero flag if bit 7 of D is 0
  JR NZ,$6449             ; Jump to 6449 if bit 7 of D is set
  LD A,D                  ; A=D
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$644C              ; Jump to 644C if A=0
  LD DE,$00FF             ; DE=$00FF
  JR $644C                ; Jump to 644C
  LD DE,$0000             ; DE=$0000
  BIT 7,H                 ; Set the zero flag if bit 7 of H is 0
  JR NZ,$6462             ; Jump to 6462 if bit 7 of H is set
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$6459              ; Jump to 6459 if A=0
  LD HL,$00AF             ; HL=$00AF
  JR $6465                ; Jump to 6465
  LD A,L                  ; A=L
  CP $B0                  ; Set the zero flag if A=$B0, or the carry flag if
                          ; A<$B0
  JR NC,$6454             ; Jump to 6454 if A>=$B0
  CP $30                  ; Set the zero flag if A=$30, or the carry flag if
                          ; A<$30
  JR NC,$6465             ; Jump to 6465 if A>=$30
  LD HL,$0030             ; HL=$0030
  LD BC,($5C7D)           ; C=PEEK $5C7D; B=PEEK $5C7E
  PUSH BC                 ; Push BC onto the stack
  LD A,E                  ; A=E
  SUB C                   ; A=A-C
  LD E,$01                ; E=$01
  JR Z,$6475              ; Jump to 6475 if the zero flag is set
  JR NC,$6476             ; Jump to 6476 if the carry flag is not set
  NEG                     ; A=$100-A
  DEC E                   ; E=E-1
  DEC E                   ; E=E-1
  LD C,A                  ; C=A
  LD A,L                  ; A=L
  SUB B                   ; A=A-B
  LD D,$01                ; D=$01
  JR Z,$6482              ; Jump to 6482 if the zero flag is set
  JR NC,$6483             ; Jump to 6483 if the carry flag is not set
  NEG                     ; A=$100-A
  DEC D                   ; D=D-1
  DEC D                   ; D=D-1
  LD B,A                  ; B=A
  CALL $24BA              ; CALL 24BA
  POP BC                  ; Pop last item from stack into BC
  JR $649F                ; Jump to 649F

; Routine at 648A
  LD HL,($633F)           ; L=PEEK $633F; H=PEEK $6340
  LD ($5C7D),HL           ; POKE $5C7D,L; POKE $5C7E,H
  LD HL,($6341)           ; L=PEEK $6341; H=PEEK $6342
; This entry point is used by the routine at 6516.
  XOR A                   ; A=0
  LD D,A                  ; D=A
  LD E,L                  ; E=L
  LD L,H                  ; L=H
  LD H,A                  ; H=A
  JP $643C                ; Jump to 643C

; Routine at 649B
;
; Used by the routine at 6BA8.
  LD BC,($6341)           ; C=PEEK $6341; B=PEEK $6342
; This entry point is used by the routine at 643C.
  LD HL,($5C8D)           ; L=PEEK $5C8D; H=PEEK $5C8E
  LD ($5C8F),HL           ; POKE $5C8F,L; POKE $5C90,H
  JP $22E5                ; Jump to 22E5

; Routine at 64A8
;
; Used by the routine at 6CB7.
  LD HL,$5800             ; HL=$5800
  LD DE,$A1FD             ; DE=$A1FD
  LD BC,$0200             ; BC=$0200
  LDIR                    ; POKE DE,PEEK HL; HL=HL+1; DE=DE+1; BC=BC-1; repeat
                          ; until BC=0
  RET                     ; Return

; Data block at 64B4
  DEFB $21,$FD,$A1,$11,$00,$58,$01,$00
  DEFB $02,$ED,$B0,$C9

; Routine at 64C0
;
; Used by the routine at 6434.
  LD A,H                  ; A=H
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  AND $03                 ; Keep only bits 0 and 1 of A
  ADD A,$58               ; A=A+$58
  LD H,A                  ; H=A
  LD A,($5C8E)            ; A=PEEK $5C8E
  LD B,A                  ; B=A
  CPL                     ; A=$FF-A
  LD C,A                  ; C=A
  LD A,($5C8D)            ; A=PEEK $5C8D
  AND C                   ; A=A&C
  LD C,A                  ; C=A
  LD A,B                  ; A=B
  AND (HL)                ; A=A&PEEK HL
  OR C                    ; A=A|C
  LD (HL),A               ; POKE HL,A
  RET                     ; Return

; Routine at 64D9
;
; Used by the routines at 636E and 6381.
  LD A,$AF                ; A=$AF
  SUB D                   ; A=A-D
  LD C,E                  ; C=E
  CALL $64EE              ; CALL 64EE
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  ADD A,$46               ; A=A+$46
  LD ($64E9),A            ; POKE $64E9,A
  BIT 5,(HL)              ; Set the zero flag if bit 5 of (HL) is 0
  RET                     ; Return

; Routine at 64EB
;
; Used by the routines at 63A5 and 63DF.
  LD A,$AF                ; A=$AF
  SUB B                   ; A=A-B
; This entry point is used by the routine at 64D9.
  CALL $22B0              ; CALL 22B0
  SUB $07                 ; A=A-$07
  NEG                     ; A=$100-A
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET                     ; Return

; Routine at 64F7
  LD DE,($633F)           ; E=PEEK $633F; D=PEEK $6340
  LD HL,($6341)           ; L=PEEK $6341; H=PEEK $6342
  PUSH DE                 ; Push DE onto the stack
  LD C,L                  ; C=L
  LD B,D                  ; B=D
  PUSH BC                 ; Push BC onto the stack
  PUSH BC                 ; Push BC onto the stack
  PUSH HL                 ; Push HL onto the stack
  PUSH HL                 ; Push HL onto the stack
  LD C,E                  ; C=E
  LD B,H                  ; B=H
  PUSH BC                 ; Push BC onto the stack
  PUSH BC                 ; Push BC onto the stack
  PUSH DE                 ; Push DE onto the stack
  LD B,$04                ; B=$04
  POP HL                  ; Pop last item from stack into HL
  POP DE                  ; Pop last item from stack into DE
  PUSH BC                 ; Push BC onto the stack
  CALL $6516              ; CALL 6516
  POP BC                  ; Pop last item from stack into BC
  DJNZ $650C              ; Decrement B and jump to 650C if B>0
  RET                     ; Return

; Routine at 6516
;
; Used by the routine at 64F7.
  LD ($5C7D),DE           ; POKE $5C7D,E; POKE $5C7E,D
  JP $6493                ; Jump to 6493

; Data block at 651D
  DEFB $AF

; Message at 651E
  DEFM "*?c"

; Data block at 6521
  DEFB $5C

; Message at 6522
  DEFM "gW\";"

; Data block at 6526
  DEFB $A5,$ED,$53,$3D,$A5,$ED

; Message at 652C
  DEFM "[AcjgW"

; Data block at 6532
  DEFB $C3,$FE,$88,$DD,$E5,$3E,$01,$D3
  DEFB $FE,$CD

; Message at 653C
  DEFM "Ep>"

; Data block at 653F
  DEFB $07,$CD,$A1,$70,$CD,$5D,$67,$CD
  DEFB $40,$6F,$CD,$38,$66,$CD,$4B,$66
  DEFB $CD,$23,$67,$CD,$A8,$64,$AF

; Message at 6556
  DEFM "2cc>"

; Data block at 655A
  DEFB $01,$CD,$F2,$6A,$CD,$95

; Message at 6560
  DEFM "f:j"

; Data block at 6563
  DEFB $5C,$F5,$CB,$DF,$32,$6A,$5C,$CD

; Message at 656B
  DEFM "Wqo"

; Data block at 656E
  DEFB $F1,$32,$6A,$5C,$7D,$21,$8F,$65
  DEFB $BE,$28,$09,$34,$28,$10,$35,$23
  DEFB $23,$23,$18,$F4,$23,$7E,$23,$66
  DEFB $6F,$01,$59,$65,$C5,$E9,$35,$18
  DEFB $CA,$43,$F0,$65,$47,$1E,$66,$35
  DEFB $13,$69,$36,$18,$69,$37,$1D

; Message at 659D
  DEFM "i8\"i"

; Data block at 65A1
  DEFB $F2,$27,$69,$F1,$2C,$69,$F0,$31
  DEFB $69,$F3,$36,$69,$7F,$3B,$69,$0F

; Message at 65B1
  DEFM "[iWbiZhi%pi'"

; Data block at 65BD
  DEFB $7D

; Message at 65BE
  DEFM "i&li("

; Data block at 65C3
  DEFB $81,$69,$49,$23

; Message at 65C7
  DEFM "jP+jV3jB;jTCjD"

; Data block at 65D5
  DEFB $FD,$6A,$45,$DA,$6B,$46,$0B

; Message at 65DC
  DEFM "kA kS'kM"

; Data block at 65E4
  DEFB $EE,$6B,$52,$D0

; Message at 65E8
  DEFM "kL.k"

; Data block at 65EC
  DEFB $FC,$1D,$67,$FF,$ED

; Message at 65F1
  DEFM "KAc>"

; Data block at 65F5
  DEFB $AF,$90,$E6,$F8,$26,$16,$CB,$27
  DEFB $CB,$14,$CB,$27,$CB,$14,$CB,$39
  DEFB $CB,$39,$CB,$39,$81,$6F,$7E,$F5
  DEFB $CB,$FE,$CD,$15,$66,$F1,$77,$C9
  DEFB $AF,$DB,$FE,$F6,$E0,$3C,$20,$F8
  DEFB $C9,$0E,$10,$21,$00

; Message at 6622
  DEFM "X>8"

; Data block at 6625
  DEFB $06,$20,$77,$23,$EE,$40,$10,$FA
  DEFB $EE,$40,$0D,$20,$F3,$CD,$15,$66
  DEFB $C3,$B4,$64,$21,$80

; Message at 663A
  DEFM "X\"?c\"Ac> 2"

; Data block at 6644
  DEFB $DF,$6D,$AF

; Message at 6647
  DEFM "2Lc"

; Data block at 664A
  DEFB $C9

; Routine at 664B
;
; Used by the routine at 6CB7.
  LD A,$01                ; A=$01
  CALL $6AF2              ; CALL 6AF2
  LD A,$0F                ; A=$0F
  LD ($5C48),A            ; POKE $5C48,A
  CALL $6F35              ; CALL 6F35
  LD A,($634C)            ; A=PEEK $634C
  ADD A,$02               ; A=A+$02
  LD ($6DD6),A            ; POKE $6DD6,A
  CALL $6678              ; CALL 6678
  LD ($6D92),A            ; POKE $6D92,A
  CALL $667E              ; CALL 667E
  LD ($6D94),A            ; POKE $6D94,A
  LD HL,$6D91             ; HL=$6D91
  CALL $66F9              ; CALL 66F9
  CALL $670D              ; CALL 670D
  JP $6695                ; Jump to 6695

; Routine at 6678
;
; Used by the routine at 664B.
  LD A,($5C8D)            ; A=PEEK $5C8D
  AND $07                 ; Keep only bits 0, 1 and 2 of A
  RET                     ; Return

; Routine at 667E
;
; Used by the routine at 664B.
  LD A,($5C8D)            ; A=PEEK $5C8D
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  AND $07                 ; Keep only bits 0, 1 and 2 of A
  RET                     ; Return

; Data block at 6687
  DEFB $3E,$16,$D7,$3E,$03,$D7,$78,$D7
  DEFB $06,$00,$CD,$1B,$1A,$C9,$AF,$CD
  DEFB $9E,$71,$3E,$01,$CD,$F2,$6A,$21
  DEFB $E7,$66,$CD,$F9,$66,$06,$0E

; Message at 66A6
  DEFM ":AcO"

; Data block at 66AA
  DEFB $CD,$87,$66,$06,$12

; Message at 66AF
  DEFM ":Bc"

; Data block at 66B2
  DEFB $D6,$30,$4F,$CD,$87,$66,$3E,$16
  DEFB $D7,$3E,$03,$D7,$3E,$18,$D7

; Message at 66C1
  DEFM ":cc!"

; Data block at 66C5
  DEFB $D3,$66,$85,$6F,$30,$01,$24,$7E
  DEFB $D7,$3E,$02,$C3,$F2

; Message at 66D2
  DEFM "j TDEFASMRL??????IPVB"

; Data block at 66E7
  DEFB $16,$03,$0E

; Message at 66EA
  DEFM "       "

; Data block at 66F1
  DEFB $FF,$E5,$3E,$01,$CD,$F2,$6A,$E1

; Routine at 66F9
;
; Used by the routines at 664B and 71AA.
  LD A,(HL)               ; A=PEEK HL
  CP $FF                  ; Set the zero flag if A=$FF, or the carry flag if
                          ; A<$FF
  RET Z                   ; Return if A=$FF
  CP $0A                  ; Set the zero flag if A=$0A, or the carry flag if
                          ; A<$0A
  JR NZ,$6706             ; Jump to 6706 if A<>$0A
  CALL $6E75              ; CALL 6E75
  JR $6709                ; Jump to 6709
  CALL $70AA              ; CALL 70AA
  INC HL                  ; HL=HL+1
  JR $66F9                ; Jump to 66F9

; Data block at 670C
  DEFB $C9,$3E,$16,$D7,$3E,$03,$D7,$3E
  DEFB $1C,$D7,$ED

; Message at 6717
  DEFM "KFc"

; Data block at 671A
  DEFB $C3,$1B,$1A,$CD,$A1,$67,$CD,$07
  DEFB $68,$3E,$01,$CD,$F2,$6A,$21,$BA
  DEFB $6A,$CD,$F9,$66,$CD,$04,$8A,$38
  DEFB $03,$C3,$E4,$6B,$E5

; Message at 6737
  DEFM "\"Fc"

; Data block at 673A
  DEFB $D1,$CD

; Message at 673C
  DEFM "Ph(;"

; Data block at 6740
  DEFB $DD,$E5,$E1,$23,$23,$23,$23,$23
  DEFB $0B,$0B,$0B,$0B,$0B,$11,$18,$5E
  DEFB $ED,$B0,$DD,$7E,$04

; Message at 6755
  DEFM "2Ic>"

; Data block at 6759
  DEFB $FF,$C3,$A1,$6C

; Routine at 675D
;
; Used by the routine at 68C2.
  LD L,$38                ; L=$38
  LD H,$00                ; H=$00
  LD ($5C8D),HL           ; POKE $5C8D,L; POKE $5C8E,H
  LD ($5C8F),HL           ; POKE $5C8F,L; POKE $5C90,H
  LD HL,$5C91             ; HL=$5C91
  RES 0,(HL)              ; Reset bit 0 of (HL)
  RES 2,(HL)              ; Reset bit 2 of (HL)
  LD HL,$7080             ; HL=$7080
  LD ($633F),HL           ; POKE $633F,L; POKE $6340,H
  LD ($6341),HL           ; POKE $6341,L; POKE $6342,H
  XOR A                   ; A=0
  JP $719E                ; Jump to 719E

; Data block at 677B
  DEFB $2A,$33,$A5,$01,$0A,$00,$09,$38
  DEFB $42,$01,$05,$00,$2A,$31,$A5,$CD

; Message at 678B
  DEFM "oh++s"

; Data block at 6790
  DEFB $23,$72,$23,$36,$05,$AF,$23,$77
  DEFB $23,$77,$23,$77,$23,$77,$AF,$18
  DEFB $B4,$ED

; Message at 67A2
  DEFM "[Fc"

; Data block at 67A5
  DEFB $CD,$95

; Message at 67A7
  DEFM "h*Jc"

; Data block at 67AB
  DEFB $11,$0E,$5E,$A7,$ED,$52,$ED,$5B
  DEFB $33,$A5,$19,$D0,$F1,$21,$CC,$67
  DEFB $CD,$F2,$66,$CD

; Message at 67BF
  DEFM "Wq>"

; Data block at 67C2
  DEFB $11,$C3,$75,$6E,$CD,$B8,$67,$C3
  DEFB $E4,$6B,$16,$07,$00

; Message at 67CF
  DEFM "You have run out of memory..."

; Data block at 67EC
  DEFB $FF,$16,$07,$00

; Message at 67F0
  DEFM "Picture buffer full..."

; Data block at 6806
  DEFB $FF,$3E,$FF,$CD,$A1,$6C,$DD,$2A
  DEFB $31,$A5,$DD,$2B,$DD,$2B,$11,$18
  DEFB $5E

; Message at 6817
  DEFM "*Jc"

; Data block at 681A
  DEFB $A7,$ED,$52,$C8

; Message at 681E
  DEFM "DM!"

; Data block at 6821
  DEFB $05,$00,$09,$C5,$44,$4D,$CD,$6F
  DEFB $68,$C1,$DD,$75,$02,$DD,$74,$03

; Message at 6831
  DEFM "*Fc"

; Data block at 6834
  DEFB $DD,$75,$00,$DD,$74,$01

; Message at 683A
  DEFM ":Ic"

; Data block at 683D
  DEFB $DD,$77,$04,$DD,$E5,$E1,$23,$23
  DEFB $23,$23,$23,$EB,$ED,$B0,$AF,$12
  DEFB $13,$12,$C9

; Routine at 6850
;
; Used by the routine at 6C61.
  LD IX,($A52F)           ; IXl=PEEK $A52F; IXh=PEEK $A530
  LD L,(IX+$00)           ; L=PEEK (IX+$00)
  LD H,(IX+$01)           ; H=PEEK (IX+$01)
  LD A,H                  ; A=H
  OR L                    ; A=A|L
  RET Z                   ; Return if A=0
  LD C,(IX+$02)           ; C=PEEK (IX+$02)
  LD B,(IX+$03)           ; B=PEEK (IX+$03)
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,DE               ; HL=HL-carry-DE
  JR Z,$686C              ; Jump to 686C if HL=0
  ADD IX,BC               ; IX=IX+BC
  JR $6854                ; Jump to 6854
  XOR A                   ; A=0
  INC A                   ; A=A+1
  RET                     ; Return

; Data block at 686F
  DEFB $E5,$D5,$C5,$2A,$31,$A5,$E5,$09
  DEFB $22,$31,$A5,$2A,$33,$A5,$E5,$09
  DEFB $22,$33,$A5,$23,$EB,$E1,$C1,$23
  DEFB $E5,$A7,$ED

; Message at 688A
  DEFM "BDM"

; Data block at 688D
  DEFB $03,$E1,$ED,$B8,$C1,$D1,$E1,$C9
  DEFB $CD,$50,$68,$C8,$DD,$E5,$E1,$E5
  DEFB $09,$E5

; Message at 689F
  DEFM "T]*3"

; Data block at 68A3
  DEFB $A5,$A7,$ED,$52,$23,$23,$E5,$2A
  DEFB $31,$A5,$A7,$ED

; Message at 68AF
  DEFM "B\"1"

; Data block at 68B2
  DEFB $A5,$2A,$33,$A5,$A7,$ED

; Message at 68B8
  DEFM "B\"3"

; Data block at 68BB
  DEFB $A5,$C1,$E1,$D1,$ED,$B0,$C9

; Routine at 68C2
;
; Used by the routine at 6336.
  LD A,$C9                ; A=$C9
  LD ($64A8),A            ; POKE $64A8,A
  LD ($6BA8),A            ; POKE $6BA8,A
  LD ($664B),A            ; POKE $664B,A
  CALL $675D              ; CALL 675D
  CALL $6F40              ; CALL 6F40
  CALL $6C37              ; CALL 6C37
  CALL $675D              ; CALL 675D
  LD A,$21                ; A=$21
  LD ($64A8),A            ; POKE $64A8,A
  LD A,$3E                ; A=$3E
  LD ($6BA8),A            ; POKE $6BA8,A
  LD ($664B),A            ; POKE $664B,A
  RET                     ; Return

; Data block at 68E7
  DEFB $C5,$3E,$01,$CD,$9E,$71,$CD,$0F
  DEFB $69,$CD,$B4,$64,$C1

; Message at 68F4
  DEFM "*Ac"

; Data block at 68F7
  DEFB $7D,$81,$CB,$79,$28,$01,$3F,$38
  DEFB $01,$6F,$7C,$80,$FE,$B0,$30,$05
  DEFB $FE,$30,$38,$01

; Message at 690B
  DEFM "g\"Ac"

; Data block at 690F
  DEFB $CD,$9B,$64,$C9,$01,$FF,$00,$18
  DEFB $CF,$01,$00,$FF,$18,$CA,$01,$00
  DEFB $01,$18,$C5,$01,$01,$00,$18,$C0
  DEFB $01,$F8,$00,$18,$BB,$01,$00,$F8
  DEFB $18,$B6,$01,$00,$08,$18,$B1,$01
  DEFB $08,$00,$18,$AC

; Message at 693B
  DEFM ":Hc"

; Data block at 693E
  DEFB $A7,$C8

; Message at 6940
  DEFM "*Jc"

; Data block at 6943
  DEFB $E5,$CD,$70,$69,$D1,$21,$17,$63
  DEFB $A7,$ED

; Message at 694D
  DEFM "RDM*Jc"

; Data block at 6953
  DEFB $EB,$ED,$B0

; Message at 6956
  DEFM "!Ic5"

; Data block at 695A
  DEFB $C9

; Message at 695B
  DEFM ":Hc2Ic"

; Data block at 6961
  DEFB $C9

; Message at 6962
  DEFM ":Ic"

; Data block at 6965
  DEFB $C3,$A1,$6C,$AF,$C3,$A1,$6C,$06
  DEFB $05,$18,$02,$06,$01

; Message at 6972
  DEFM ":Hc"

; Data block at 6975
  DEFB $90,$D2,$A1,$6C,$AF,$C3,$A1,$6C
  DEFB $06,$05,$18,$02,$06,$01

; Message at 6983
  DEFM ":Hc"

; Data block at 6986
  DEFB $80,$D2,$A1,$6C,$3E,$FF,$C3,$A1
  DEFB $6C,$CD,$85,$6C,$C5,$E5,$3E,$01
  DEFB $CD,$F2,$6A,$E1,$CD,$F9,$66,$1E
  DEFB $01,$21,$00,$5B,$36,$00,$CD,$8A
  DEFB $82,$C1,$38,$09

; Message at 69AA
  DEFM "!Ic5+5"

; Data block at 69B0
  DEFB $C3,$4B,$66,$11,$00,$5B,$EB,$7E
  DEFB $D6,$30,$FE,$0A,$30,$EC,$77,$79
  DEFB $FE,$12,$38,$0A,$7E,$FE,$08,$28
  DEFB $05,$E6,$0E,$C2,$AA,$69,$7E,$71
  DEFB $23

; Message at 69D1
  DEFM "Gy= "

; Data block at 69D5
  DEFB $11,$11,$01,$5B,$78,$12,$CD,$37
  DEFB $6D,$CD,$4B,$66,$01,$02,$00,$C3
  DEFB $05,$6A,$70,$23,$36,$FF,$3E,$02
  DEFB $CD,$F2,$6A,$21,$00,$5B,$CD,$F9
  DEFB $66,$2A,$8F,$5C,$22,$8D,$5C,$01
  DEFB $02,$00,$CD,$05,$6A,$C3

; Message at 6A03
  DEFM "Kf!Hc:"

; Unused
  DEFS $01

; Message at 6A0A
  DEFM "[2cc:Ic"

; Data block at 6A11
  DEFB $BE,$C4,$D7,$6A,$21,$00,$5B,$ED

; Message at 6A19
  DEFM "[Jc"

; Data block at 6A1C
  DEFB $ED,$B0,$ED

; Message at 6A1F
  DEFM "SJc"

; Data block at 6A22
  DEFB $C9

; Message at 6A23
  DEFM "!Kj"

; Data block at 6A26
  DEFB $0E,$10,$C3,$8F,$69,$21,$60,$6A
  DEFB $0E,$11,$C3,$8F

; Message at 6A32
  DEFM "i!wj"

; Data block at 6A36
  DEFB $0E,$12,$C3,$8F,$69,$21,$8C,$6A
  DEFB $0E,$13,$C3,$8F,$69,$21,$A2,$6A
  DEFB $0E,$01,$C3,$8F,$69,$16,$07,$00

; Message at 6A4E
  DEFM "Which ink?(0..9) "

; Data block at 6A5F
  DEFB $FF,$16,$07,$00

; Message at 6A63
  DEFM "Which paper?(0..9) "

; Data block at 6A76
  DEFB $FF,$16,$07,$00

; Message at 6A7A
  DEFM "Flash?(0,1 or 8) "

; Data block at 6A8B
  DEFB $FF,$16,$07,$00

; Message at 6A8F
  DEFM "Bright?(0,1 or 8) "

; Data block at 6AA1
  DEFB $FF,$16,$07,$00

; Message at 6AA5
  DEFM "Which border?(0..7) "

; Data block at 6AB9
  DEFB $FF,$16,$07,$00

; Message at 6ABD
  DEFM "Which picture number ?..."

; Data block at 6AD6
  DEFB $FF,$C5,$21,$17,$63,$A7,$ED

; Message at 6ADD
  DEFM "BT]"

; Data block at 6AE0
  DEFB $ED

; Message at 6AE1
  DEFM "KJc"

; Data block at 6AE4
  DEFB $A7,$ED

; Message at 6AE6
  DEFM "BDM!"

; Data block at 6AEA
  DEFB $17,$63,$EB,$03,$ED,$B8,$C1,$C9

; Routine at 6AF2
;
; Used by the routines at 664B and 7043.
  LD HL,$6352             ; HL=$6352
  LD D,(HL)               ; D=PEEK HL
  LD (HL),A               ; POKE HL,A
  PUSH DE                 ; Push DE onto the stack
  CALL $1601              ; CALL 1601
  POP AF                  ; Pop last item from stack into AF
  RET                     ; Return

; Data block at 6AFD
  DEFB $CD,$85,$6C,$3E,$02,$32,$00,$5B
  DEFB $CD,$A8,$6B,$C3,$5E,$6B,$21,$FF
  DEFB $00,$3E,$04,$CD,$85,$6C,$F5

; Message at 6B14
  DEFM "\"Cc"

; Data block at 6B17
  DEFB $CD,$A8,$6B,$CD,$74,$63,$F1,$18
  DEFB $E2,$21,$00,$00,$3E,$05,$18,$E9
  DEFB $21,$AA,$FF,$3E,$06,$18,$E2,$21
  DEFB $8A

; Message at 6B30
  DEFM "d>L"

; Data block at 6B33
  DEFB $06,$09,$CD,$85,$6C,$22,$10,$69
  DEFB $32,$AD

; Message at 6B3D
  DEFM "e!ik\""

; Data block at 6B42
  DEFB $AE,$65,$3E,$FF,$32,$B0

; Message at 6B48
  DEFM "ex2"

; Unused
  DEFS $01

; Message at 6B4C
  DEFM "[*Ac\"?c"

; Data block at 6B53
  DEFB $CD,$BC,$6B,$3E,$01

; Message at 6B58
  DEFM "2Lc"

; Data block at 6B5B
  DEFB $C3,$4B,$66,$01,$03,$00

; Message at 6B61
  DEFM "*Ac\""

; Data block at 6B65
  DEFB $01,$5B,$18,$36,$AF

; Message at 6B6A
  DEFM "2Lc"

; Data block at 6B6D
  DEFB $CD

; Message at 6B6E
  DEFM "Kf>"

; Data block at 6B71
  DEFB $7F,$32,$AD

; Message at 6B74
  DEFM "e!;i\""

; Data block at 6B79
  DEFB $AE,$65,$3E,$0F,$32,$B0,$65,$AF
  DEFB $CD,$9E,$71,$CD,$0F,$69,$21,$9B
  DEFB $64,$22,$10,$69,$CD,$B0,$6B,$01
  DEFB $05,$00

; Message at 6B93
  DEFM "*?c\""

; Data block at 6B97
  DEFB $01

; Message at 6B98
  DEFM "[*Ac\""

; Data block at 6B9D
  DEFB $03

; Message at 6B9E
  DEFM "[\"?c"

; Data block at 6BA2
  DEFB $CD,$05,$6A,$C3,$A8,$64

; Routine at 6BA8
;
; Used by the routine at 6BC8.
  LD A,$01                ; A=$01
  CALL $719E              ; CALL 719E
  JP $649B                ; Jump to 649B

; Data block at 6BB0
  DEFB $3A,$5F,$63,$A7,$C0,$3C,$32,$5F
  DEFB $63,$C3,$A8,$6B,$3A,$5F,$63,$A7
  DEFB $C8,$3D,$32,$5F,$63,$C3,$A8,$6B

; Routine at 6BC8
;
; Used by the routine at 6CB7.
  LD A,$01                ; A=$01
  LD ($635F),A            ; POKE $635F,A
  JP $6BA8                ; Jump to 6BA8

; Data block at 6BD0
  DEFB $21,$F7

; Message at 6BD2
  DEFM "d>R"

; Data block at 6BD5
  DEFB $06,$08,$C3

; Message at 6BD8
  DEFM "5k!"

; Data block at 6BDB
  DEFB $1D

; Message at 6BDC
  DEFM "e>E"

; Data block at 6BDF
  DEFB $06,$03,$C3,$35,$6B,$E1,$DD,$E1
  DEFB $3E,$07,$D3,$FE,$C3,$5D,$67,$CD
  DEFB $85,$6C,$3E,$01,$CD,$F2,$6A,$21
  DEFB $BA,$6A,$CD,$F9,$66,$CD,$04,$8A
  DEFB $3E,$11,$CD,$75,$6E,$D2,$1B,$6C
  DEFB $E5,$3E,$02,$CD,$F2,$6A,$D1

; Message at 6C0E
  DEFM "*Fc"

; Data block at 6C11
  DEFB $A7,$ED,$52,$28,$05,$CD

; Message at 6C17
  DEFM "Ph "

; Data block at 6C1A
  DEFB $07

; Message at 6C1B
  DEFM "!Ic5+5"

; Data block at 6C21
  DEFB $C9,$3E,$07,$32,$00,$5B,$ED,$53
  DEFB $01,$5B,$01,$03,$00,$CD,$05,$6A
  DEFB $CD,$BC,$6B,$CD,$4B,$66

; Routine at 6C37
;
; Used by the routines at 68C2 and 6C61.
  XOR A                   ; A=0
  CALL $719E              ; CALL 719E
  PUSH IX                 ; Push IX onto the stack
  POP HL                  ; Pop last item from stack into HL
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  INC HL                  ; HL=HL+1
  EX DE,HL                ; Exchange DE and HL
  LD HL,($6348)           ; L=PEEK $6348; H=PEEK $6349
  PUSH HL                 ; Push HL onto the stack
  LD HL,($634A)           ; L=PEEK $634A; H=PEEK $634B
  PUSH HL                 ; Push HL onto the stack
  LD ($6349),A            ; POKE $6349,A
  CALL $6CB7              ; CALL 6CB7
  POP HL                  ; Pop last item from stack into HL
  LD ($634A),HL           ; POKE $634A,L; POKE $634B,H
  POP HL                  ; Pop last item from stack into HL
  LD ($6348),HL           ; POKE $6348,L; POKE $6349,H
  LD A,$07                ; A=$07
  LD ($6363),A            ; POKE $6363,A
  RET                     ; Return

; Routine at 6C61
  LD A,$C9                ; A=$C9
  LD ($6CDF),A            ; POKE $6CDF,A
  EX DE,HL                ; Exchange DE and HL
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  INC HL                  ; HL=HL+1
  PUSH HL                 ; Push HL onto the stack
  LD A,($634E)            ; A=PEEK $634E
  PUSH AF                 ; Push AF onto the stack
  CALL $6850              ; CALL 6850
  CALL NZ,$6C37           ; CALL 6C37 if the zero flag is not set
  POP AF                  ; Pop last item from stack into AF
  LD ($634E),A            ; POKE $634E,A
  LD A,$CD                ; A=$CD
  LD ($6CDF),A            ; POKE $6CDF,A
  XOR A                   ; A=0
  CALL $719E              ; CALL 719E
  POP DE                  ; Pop last item from stack into DE
  RET                     ; Return

; Data block at 6C85
  DEFB $E5

; Message at 6C86
  DEFM "!Ic4("

; Data block at 6C8B
  DEFB $04,$2B,$34,$E1,$C9,$35,$E1,$E1
  DEFB $21,$ED,$67,$CD,$F2,$66,$CD

; Message at 6C9A
  DEFM "Wq>"

; Data block at 6C9D
  DEFB $11,$C3,$75,$6E,$F5,$AF

; Message at 6CA3
  DEFM "2cc"

; Data block at 6CA6
  DEFB $CD,$5D,$67,$CD,$40,$6F,$F1

; Message at 6CAD
  DEFM "!Ic"

; Data block at 6CB0
  DEFB $BE,$38,$01,$7E,$11,$18,$5E

; Routine at 6CB7
;
; Used by the routine at 6C37.
  LD ($6348),A            ; POKE $6348,A
  INC A                   ; A=A+1
  LD ($634E),A            ; POKE $634E,A
  LD HL,$634E             ; HL=$634E
  DEC (HL)                ; POKE HL,(PEEK HL)-1
  JR Z,$6CDB              ; Jump to 6CDB if (PEEK HL)=0
  LD A,(DE)               ; A=PEEK DE
  LD ($6363),A            ; POKE $6363,A
  INC DE                  ; DE=DE+1
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  LD HL,$6D69             ; HL=$6D69
  ADD A,L                 ; A=A+L
  JR NC,$6CD1             ; Jump to 6CD1 if the carry flag is not set
  INC H                   ; H=H+1
  LD L,A                  ; L=A
  LD A,(HL)               ; A=PEEK HL
  INC HL                  ; HL=HL+1
  LD H,(HL)               ; H=PEEK HL
  LD L,A                  ; L=A
  LD BC,$6CBE             ; BC=$6CBE
  PUSH BC                 ; Push BC onto the stack
  JP (HL)                 ; Jump to HL
  LD ($634A),DE           ; POKE $634A,E; POKE $634B,D
  CALL $64A8              ; CALL 64A8
  CALL $664B              ; CALL 664B
  JP $6BC8                ; Jump to 6BC8

; Routine at 6CE8
;
; Used by the routine at 6D0B.
  LD A,(DE)               ; A=PEEK DE
  LD L,A                  ; L=A
  INC DE                  ; DE=DE+1
  LD A,(DE)               ; A=PEEK DE
  LD H,A                  ; H=A
  INC DE                  ; DE=DE+1
  LD ($633F),HL           ; POKE $633F,L; POKE $6340,H
; This entry point is used by the routine at 6D00.
  LD A,(DE)               ; A=PEEK DE
  LD L,A                  ; L=A
  INC DE                  ; DE=DE+1
  LD A,(DE)               ; A=PEEK DE
  LD H,A                  ; H=A
  INC DE                  ; DE=DE+1
  LD ($6341),HL           ; POKE $6341,L; POKE $6342,H
  PUSH DE                 ; Push DE onto the stack
  CALL $6364              ; CALL 6364
  POP DE                  ; Pop last item from stack into DE
  RET                     ; Return

; Routine at 6D00
  LD HL,$649B             ; HL=$649B
; This entry point is used by the routines at 6D10, 6D15 and 6D1A.
  LD ($6CFC),HL           ; POKE $6CFC,L; POKE $6CFD,H
  JR $6CF1                ; Jump to 6CF1

; Data block at 6D08
  DEFB $21,$1D,$65

; Routine at 6D0B
;
; Used by the routines at 6D1F and 6D24.
  LD ($6CFC),HL           ; POKE $6CFC,L; POKE $6CFD,H
  JR $6CE8                ; Jump to 6CE8

; Routine at 6D10
  LD HL,$636E             ; HL=$636E
  JR $6D03                ; Jump to 6D03

; Routine at 6D15
  LD HL,$6364             ; HL=$6364
  JR $6D03                ; Jump to 6D03

; Routine at 6D1A
  LD HL,$6369             ; HL=$6369
  JR $6D03                ; Jump to 6D03

; Routine at 6D1F
  LD HL,$64F7             ; HL=$64F7
  JR $6D0B                ; Jump to 6D0B

; Routine at 6D24
  LD HL,$648A             ; HL=$648A
  JR $6D0B                ; Jump to 6D0B

; Routine at 6D29
  DEC DE                  ; DE=DE-1
  LD A,(DE)               ; A=PEEK DE
  RST $10                 ; CALL 0010
  INC DE                  ; DE=DE+1
  LD A,(DE)               ; A=PEEK DE
  RST $10                 ; CALL 0010
  INC DE                  ; DE=DE+1
  LD HL,($5C8F)           ; L=PEEK $5C8F; H=PEEK $5C90
  LD ($5C8D),HL           ; POKE $5C8D,L; POKE $5C8E,H
  RET                     ; Return

; Routine at 6D37
  LD A,(DE)               ; A=PEEK DE
  INC DE                  ; DE=DE+1
  PUSH DE                 ; Push DE onto the stack
  AND $07                 ; Keep only bits 0, 1 and 2 of A
  OUT ($FE),A             ; OUT $FE,A
  LD B,$00                ; B=$00
  BIT 2,A                 ; Set the zero flag if bit 2 of A is 0
  JR NZ,$6D46             ; Jump to 6D46 if bit 2 of A is set
  LD B,$07                ; B=$07
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  OR B                    ; A=A|B
  LD ($5C48),A            ; POKE $5C48,A
  LD HL,$5A00             ; HL=$5A00
  LD BC,$00FF             ; BC=$00FF
  LD D,A                  ; D=A
  LD A,($634F)            ; A=PEEK $634F
  DEC A                   ; A=A-1
  JR Z,$6D60              ; Jump to 6D60 if A=0
  LD HL,$5800             ; HL=$5800
  LD BC,$02FF             ; BC=$02FF
  LD A,D                  ; A=D
  LD D,H                  ; D=H
  LD E,L                  ; E=L
  INC DE                  ; DE=DE+1
  LD (HL),A               ; POKE HL,A
  LDIR                    ; POKE DE,PEEK HL; HL=HL+1; DE=DE+1; BC=BC-1; repeat
                          ; until BC=0
  POP DE                  ; Pop last item from stack into DE
  RET                     ; Return

; Data block at 6D69
  DEFB $FF

; Message at 6D6A
  DEFM "l7m"

; Data block at 6D6D
  DEFB $00,$6D,$08,$6D,$10,$6D,$15,$6D
  DEFB $1A

; Message at 6D76
  DEFM "mal"

; Data block at 6D79
  DEFB $1F

; Message at 6D7A
  DEFM "m$m"

; Data block at 6D7D
  DEFB $FF,$6C,$FF,$6C,$FF,$6C,$FF,$6C
  DEFB $FF,$6C,$FF

; Message at 6D88
  DEFM "l)m)m)m)m"

; Data block at 6D91
  DEFB $10,$00,$11,$07,$16,$03,$05,$95
  DEFB $95,$16,$03,$09,$20,$20,$16,$04
  DEFB $05,$95,$95,$16,$04,$09,$20,$20
  DEFB $16,$01,$00,$10,$07,$11,$01

; Message at 6DB0
  DEFM "PEN  INK PAP   X   Y   LAST PIC"

; Data block at 6DCF
  DEFB $16,$05,$00,$92,$93,$94,$16,$02
  DEFB $01,$90,$08,$0A,$91,$16,$03,$18
  DEFB $2F,$FF,$E6,$03

; Message at 6DE3
  DEFM "!Sc"

; Data block at 6DE6
  DEFB $BE,$C8,$C5,$D5

; Message at 6DEA
  DEFM "Fwx"

; Data block at 6DED
  DEFB $F5,$CD,$FB

; Message at 6DF0
  DEFM "m:Sc"

; Data block at 6DF4
  DEFB $CD,$12,$6E,$F1,$D1,$C1,$C9,$CD

; Message at 6DFC
  DEFM "(n:Ocw"

; Data block at 6E02
  DEFB $23,$3A,$48,$5C,$77,$23,$11,$84
  DEFB $5C,$EB,$01,$0E,$00,$ED,$B0,$C9
  DEFB $CD,$28,$6E,$7E

; Message at 6E16
  DEFM "2Oc"

; Data block at 6E19
  DEFB $23,$7E,$32,$48,$5C,$23,$11,$84
  DEFB $5C,$01,$0E,$00,$ED,$B0,$C9,$07
  DEFB $07,$07,$07

; Message at 6E2C
  DEFM "!5n"

; Data block at 6E2F
  DEFB $85,$30,$01,$24,$6F,$C9,$02,$38
  DEFB $00,$40,$00,$50,$21,$18,$21,$18
  DEFB $FF,$38,$00,$38,$00,$00,$02,$38
  DEFB $00,$40,$00,$50,$21,$18,$21,$18
  DEFB $FF,$38,$00,$38,$00,$00,$02,$38
  DEFB $00,$40,$00,$50,$21,$18,$21,$18
  DEFB $FF,$38,$00,$38,$00,$00,$02,$38
  DEFB $00,$40,$00,$50,$21,$18,$21,$18
  DEFB $FF,$38,$00,$38,$00,$00

; Routine at 6E75
;
; Used by the routines at 631E and 66F9.
  PUSH AF                 ; Push AF onto the stack
  PUSH BC                 ; Push BC onto the stack
  PUSH DE                 ; Push DE onto the stack
  PUSH HL                 ; Push HL onto the stack
  PUSH IX                 ; Push IX onto the stack
  LD HL,$6EC5             ; HL=$6EC5
  PUSH HL                 ; Push HL onto the stack
  LD HL,($6354)           ; L=PEEK $6354; H=PEEK $6355
  LD DE,$6356             ; DE=$6356
  LD (HL),A               ; POKE HL,A
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,DE               ; HL=HL-carry-DE
  JR NZ,$6E95             ; Jump to 6E95 if HL>0
  CP $20                  ; Set the zero flag if A=$20, or the carry flag if
                          ; A<$20
  JR C,$6E96              ; Jump to 6E96 if A<$20
  CP $A5                  ; Set the zero flag if A=$A5, or the carry flag if
                          ; A<$A5
  RET NC                  ; Return if A>=$A5
  JP $70AA                ; Jump to 70AA
  LD A,(DE)               ; A=PEEK DE
  LD B,L                  ; B=L
  LD HL,$70E5             ; HL=$70E5
  PUSH AF                 ; Push AF onto the stack
  LD A,(HL)               ; A=PEEK HL
  INC A                   ; A=A+1
  JR NZ,$6EA5             ; Jump to 6EA5 if A>0
  POP AF                  ; Pop last item from stack into AF
  LD ($6354),DE           ; POKE $6354,E; POKE $6355,D
  RET                     ; Return
  POP AF                  ; Pop last item from stack into AF
  CP (HL)                 ; Set the zero flag if A=PEEK HL, or the carry flag
                          ; if A<PEEK HL
  INC HL                  ; HL=HL+1
  JR Z,$6EAF              ; Jump to 6EAF if the zero flag is set
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  JR $6E9A                ; Jump to 6E9A
  LD A,(HL)               ; A=PEEK HL
  CP B                    ; Set the zero flag if A=B, or the carry flag if A<B
  JR Z,$6EBB              ; Jump to 6EBB if A=B
  LD HL,($6354)           ; L=PEEK $6354; H=PEEK $6355
  INC HL                  ; HL=HL+1
  LD ($6354),HL           ; POKE $6354,L; POKE $6355,H
  RET                     ; Return
  LD ($6354),DE           ; POKE $6354,E; POKE $6355,D
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  INC HL                  ; HL=HL+1
  LD H,(HL)               ; H=PEEK HL
  LD L,A                  ; L=A
  JP (HL)                 ; Jump to HL

; Routine at 6EC5
  POP IX                  ; Pop last item from stack into IX
  POP HL                  ; Pop last item from stack into HL
  POP DE                  ; Pop last item from stack into DE
  POP BC                  ; Pop last item from stack into BC
  POP AF                  ; Pop last item from stack into AF
  RET                     ; Return

; Routine at 6ECC
  INC DE                  ; DE=DE+1
  LD A,(DE)               ; A=PEEK DE
  CP $20                  ; Set the zero flag if A=$20, or the carry flag if
                          ; A<$20
  JR NC,$6ED4             ; Jump to 6ED4 if A>=$20
  LD A,$90                ; A=$90
  CALL $70AA              ; CALL 70AA
  RET                     ; Return

; Data block at 6ED8
  DEFB $21,$58,$02,$11,$82,$00,$C3,$B5
  DEFB $03,$3E,$08,$D7,$C9,$3A,$91,$5C
  DEFB $F5,$FD,$36,$57,$01,$3E,$20,$CD
  DEFB $AA,$70,$F1,$32,$91,$5C,$C9,$CD
  DEFB $83,$70,$3D,$18,$23

; Routine at 6EFD
  CALL $7083              ; CALL 7083
  INC A                   ; A=A+1
  LD B,A                  ; B=A
  LD A,($634F)            ; A=PEEK $634F
  LD C,$08                ; C=$08
  CP $02                  ; Set the zero flag if A=$02, or the carry flag if
                          ; A<$02
  JR NZ,$6F0D             ; Jump to 6F0D if A<>$02
  LD C,$17                ; C=$17
  LD A,B                  ; A=B
  CP C                    ; Set the zero flag if A=C, or the carry flag if A<C
  JR C,$6F20              ; Jump to 6F20 if A<C
  DEC B                   ; B=B-1
  PUSH BC                 ; Push BC onto the stack
  LD B,C                  ; B=C
  LD A,B                  ; A=B
  CP $17                  ; Set the zero flag if A=$17, or the carry flag if
                          ; A<$17
  JR Z,$6F1A              ; Jump to 6F1A if A=$17
  DEC B                   ; B=B-1
  CALL $0E00              ; CALL 0E00
  POP BC                  ; Pop last item from stack into BC
  JR $6F0D                ; Jump to 6F0D
  PUSH AF                 ; Push AF onto the stack
  LD A,$16                ; A=$16
  RST $10                 ; CALL 0010
  POP AF                  ; Pop last item from stack into AF
  RST $10                 ; CALL 0010
  CALL $7072              ; CALL 7072
  RST $10                 ; CALL 0010
  RET                     ; Return

; Routine at 6F2B
;
; Used by the routine at 714F.
  LD A,($634F)            ; A=PEEK $634F
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$6F40              ; Jump to 6F40 if A=0
  CP $02                  ; Set the zero flag if A=$02, or the carry flag if
                          ; A<$02
  JR Z,$6F50              ; Jump to 6F50 if A=$02
; This entry point is used by the routine at 664B.
  LD B,$03                ; B=$03
  LD A,($5C48)            ; A=PEEK $5C48
  CALL $6F7A              ; CALL 6F7A
  JP $705D                ; Jump to 705D
; This entry point is used by the routine at 68C2.
  LD B,$01                ; B=$01
  LD A,($5C8D)            ; A=PEEK $5C8D
  CALL $6F7A              ; CALL 6F7A
  LD B,$02                ; B=$02
  CALL $6F7A              ; CALL 6F7A
  JP $705D                ; Jump to 705D
  LD B,$01                ; B=$01
  LD A,($5C48)            ; A=PEEK $5C48
  CALL $6F7A              ; CALL 6F7A
  LD B,$02                ; B=$02
  CALL $6F7A              ; CALL 6F7A
  LD B,$03                ; B=$03
  CALL $6F7A              ; CALL 6F7A
  AND $F8                 ; Reset bits 0, 1 and 2 of A
  LD B,A                  ; B=A
  AND $38                 ; Keep only bits 3, 4 and 5 of A
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  OR B                    ; A=A|B
  LD HL,$5800             ; HL=$5800
  LD DE,$5801             ; DE=$5801
  LD BC,$001F             ; BC=$001F
  LD (HL),A               ; POKE HL,A
  LDIR                    ; POKE DE,PEEK HL; HL=HL+1; DE=DE+1; BC=BC-1; repeat
                          ; until BC=0
  JP $705D                ; Jump to 705D

; Routine at 6F7A
;
; Used by the routine at 6F2B.
  PUSH AF                 ; Push AF onto the stack
  LD A,B                  ; A=B
  LD HL,$3800             ; HL=$3800
  LD DE,$0800             ; DE=$0800
  ADD HL,DE               ; HL=HL+DE
  DJNZ $6F82              ; Decrement B and jump to 6F82 if B>0
  LD D,H                  ; D=H
  LD E,$01                ; E=$01
  LD BC,$07FF             ; BC=$07FF
  LD (HL),$00             ; POKE HL,$00
  LDIR                    ; POKE DE,PEEK HL; HL=HL+1; DE=DE+1; BC=BC-1; repeat
                          ; until BC=0
  ADD A,$57               ; A=A+$57
  LD H,A                  ; H=A
  LD L,$00                ; L=$00
  LD D,A                  ; D=A
  LD E,$01                ; E=$01
  LD BC,$00FF             ; BC=$00FF
  POP AF                  ; Pop last item from stack into AF
  LD (HL),A               ; POKE HL,A
  LDIR                    ; POKE DE,PEEK HL; HL=HL+1; DE=DE+1; BC=BC-1; repeat
                          ; until BC=0
  RET                     ; Return

; Routine at 6F9F
  LD A,$16                ; A=$16
  RST $10                 ; CALL 0010
  CALL $7083              ; CALL 7083
  RST $10                 ; CALL 0010
  XOR A                   ; A=0
  RST $10                 ; CALL 0010
  RET                     ; Return

; Data block at 6FA9
  DEFB $3E,$08,$D7,$3E,$20,$D7,$3E,$08
  DEFB $D7,$C9,$CD,$72,$70,$08,$CD,$9F
  DEFB $6F,$08

; Message at 6FBB
  DEFM "<G> "

; Data block at 6FBF
  DEFB $D7,$10,$FB,$3E,$08,$D7,$C9,$CD
  DEFB $83,$70,$F5,$CD

; Message at 6FCB
  DEFM "rpO> "

; Data block at 6FD0
  DEFB $91,$47,$CD,$BD,$6F,$3E,$16,$D7
  DEFB $F1,$D7,$79,$D7,$C9,$CD,$83,$70
  DEFB $A7,$28,$D0,$4F,$CD,$72,$70,$F5
  DEFB $CD,$5D,$70,$06

; Message at 6FEC
  DEFM " > "

; Data block at 6FEF
  DEFB $D7,$10,$FB,$0D,$20,$F6,$F1,$18
  DEFB $BE,$CD

; Message at 6FF9
  DEFM "rpO"

; Data block at 6FFC
  DEFB $CD,$83

; Message at 6FFE
  DEFM "pG:Oc"

; Data block at 7003
  DEFB $A7,$28,$08,$FE,$02,$28,$08,$3E
  DEFB $07,$18,$06,$3E,$0F,$18,$02,$3E
  DEFB $16,$90,$28,$AF,$C5,$11,$20,$00
  DEFB $21,$00,$00,$19,$10,$FD,$3E,$20
  DEFB $91,$4F,$09,$3E,$20,$D7,$2B,$7C
  DEFB $B5,$20,$F8,$C1,$3E,$16,$D7,$78
  DEFB $D7,$79,$D7,$C9,$3E,$14,$D7,$3E
  DEFB $00,$EE,$01

; Message at 703E
  DEFM "2;p"

; Data block at 7041
  DEFB $D7,$C9

; Routine at 7043
  INC DE                  ; DE=DE+1
  LD A,(DE)               ; A=PEEK DE
; This entry point is used by the routine at 714F.
  LD ($634F),A            ; POKE $634F,A
  CPL                     ; A=$FF-A
  ADD A,$03               ; A=A+$03
  CALL $6AF2              ; CALL 6AF2
  LD A,($634F)            ; A=PEEK $634F
  CP $02                  ; Set the zero flag if A=$02, or the carry flag if
                          ; A<$02
  LD A,$08                ; A=$08
  JR NZ,$7059             ; Jump to 7059 if the zero flag is not set
  LD A,$16                ; A=$16
  LD ($5C6B),A            ; POKE $5C6B,A
  RET                     ; Return

; Routine at 705D
;
; Used by the routine at 6F2B.
  LD A,$16                ; A=$16
  RST $10                 ; CALL 0010
  XOR A                   ; A=0
  RST $10                 ; CALL 0010
  XOR A                   ; A=0
  RST $10                 ; CALL 0010
  RET                     ; Return

; Routine at 7065
  LD A,$16                ; A=$16
  RST $10                 ; CALL 0010
  INC DE                  ; DE=DE+1
  INC DE                  ; DE=DE+1
  LD A,(DE)               ; A=PEEK DE
  DEC A                   ; A=A-1
  RST $10                 ; CALL 0010
  DEC DE                  ; DE=DE-1
  LD A,(DE)               ; A=PEEK DE
  DEC A                   ; A=A-1
  RST $10                 ; CALL 0010
  RET                     ; Return

; Routine at 7072
;
; Used by the routine at 6EFD.
  PUSH HL                 ; Push HL onto the stack
  LD A,($634F)            ; A=PEEK $634F
  LD HL,$5C8A             ; HL=$5C8A
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$707E             ; Jump to 707E if A>0
  DEC HL                  ; HL=HL-1
  DEC HL                  ; HL=HL-1
  LD A,$21                ; A=$21
  SUB (HL)                ; A=A-PEEK HL
  POP HL                  ; Pop last item from stack into HL
  RET                     ; Return

; Routine at 7083
;
; Used by the routines at 6EFD and 6F9F.
  PUSH HL                 ; Push HL onto the stack
  LD A,($634F)            ; A=PEEK $634F
  LD HL,$5C8B             ; HL=$5C8B
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$708F             ; Jump to 708F if A>0
  DEC HL                  ; HL=HL-1
  DEC HL                  ; HL=HL-1
  LD A,$18                ; A=$18
  SUB (HL)                ; A=A-PEEK HL
  POP HL                  ; Pop last item from stack into HL
  RET                     ; Return

; Data block at 7094
  DEFB $13,$1A,$F5,$3E,$11,$D7,$F1,$E6
  DEFB $07,$D7,$C9,$13,$1A,$F5,$3E,$10
  DEFB $D7,$F1,$E6,$07,$D7,$C9

; Routine at 70AA
;
; Used by the routines at 66F9, 6E75 and 6ECC.
  PUSH AF                 ; Push AF onto the stack
  CP $20                  ; Set the zero flag if A=$20, or the carry flag if
                          ; A<$20
  JR C,$70E2              ; Jump to 70E2 if A<$20
  LD A,($5C8A)            ; A=PEEK $5C8A
  DEC A                   ; A=A-1
  JR NZ,$70E2             ; Jump to 70E2 if A>0
  LD A,($634F)            ; A=PEEK $634F
  DEC A                   ; A=A-1
  LD A,($5C8B)            ; A=PEEK $5C8B
  JR Z,$70C4              ; Jump to 70C4 if the zero flag is set
  CP $02                  ; Set the zero flag if A=$02, or the carry flag if
                          ; A<$02
  JR NZ,$70E2             ; Jump to 70E2 if A<>$02
  JR $70C8                ; Jump to 70C8
  CP $11                  ; Set the zero flag if A=$11, or the carry flag if
                          ; A<$11
  JR NZ,$70E2             ; Jump to 70E2 if A<>$11
  PUSH BC                 ; Push BC onto the stack
  PUSH DE                 ; Push DE onto the stack
  PUSH HL                 ; Push HL onto the stack
  NEG                     ; A=$100-A
  ADD A,$18               ; A=A+$18
  LD B,A                  ; B=A
  LD A,$16                ; A=$16
  RST $10                 ; CALL 0010
  LD A,B                  ; A=B
  CP $16                  ; Set the zero flag if A=$16, or the carry flag if
                          ; A<$16
  JR NZ,$70D9             ; Jump to 70D9 if A<>$16
  INC B                   ; B=B+1
  RST $10                 ; CALL 0010
  XOR A                   ; A=0
  RST $10                 ; CALL 0010
  CALL $0E00              ; CALL 0E00
  POP HL                  ; Pop last item from stack into HL
  POP DE                  ; Pop last item from stack into DE
  POP BC                  ; Pop last item from stack into BC
  POP AF                  ; Pop last item from stack into AF
  RST $10                 ; CALL 0010
  RET                     ; Return

; Data block at 70E5
  DEFB $01,$01,$CC,$6E,$04,$01,$FF,$6C
  DEFB $07,$00,$D8,$6E,$08,$00,$E1,$6E
  DEFB $09,$00,$E5,$6E,$0A,$00,$FD,$6E
  DEFB $0B,$00,$F7,$6E,$0C,$00,$2B,$6F
  DEFB $0D,$00,$9F,$6F,$0E,$01,$94,$70
  DEFB $0F,$01,$9F,$70,$10,$00,$A9,$6F
  DEFB $11,$00,$B3,$6F,$12,$00,$C6,$6F
  DEFB $13,$00,$DD,$6F,$14,$00,$F8,$6F
  DEFB $18,$00,$37,$70,$1A,$01,$43,$70
  DEFB $1E,$00,$5D,$70,$1F,$02,$65,$70
  DEFB $FF

; Routine at 7136
;
; Used by the routine at 6321.
  LD A,($634F)            ; A=PEEK $634F
  LD HL,($5C8A)           ; L=PEEK $5C8A; H=PEEK $5C8B
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$7142             ; Jump to 7142 if A>0
  LD HL,($5C88)           ; L=PEEK $5C88; H=PEEK $5C89
  LD A,$22                ; A=$22
  SUB L                   ; A=A-L
  LD L,A                  ; L=A
  LD A,$19                ; A=$19
  SUB H                   ; A=A-H
  LD H,L                  ; H=L
  LD L,A                  ; L=A
  LD A,($5C8C)            ; A=PEEK $5C8C
  RET                     ; Return

; Routine at 714F
;
; Used by the routine at 6330.
  LD A,$02                ; A=$02
  CALL $7045              ; CALL 7045
  JP $6F2B                ; Jump to 6F2B

; Routine at 7157
;
; Used by the routine at 6318.
  PUSH HL                 ; Push HL onto the stack
  CALL $71E7              ; CALL 71E7
  JR NZ,$716C             ; Jump to 716C if the zero flag is not set
  LD HL,$5C3B             ; HL=$5C3B
  RES 5,(HL)              ; Reset bit 5 of (HL)
  BIT 5,(HL)              ; Set the zero flag if bit 5 of (HL) is 0
  CALL $7249              ; CALL 7249
  JR Z,$7162              ; Jump to 7162 if the zero flag is set
  LD A,($5C08)            ; A=PEEK $5C08
  CP $20                  ; Set the zero flag if A=$20, or the carry flag if
                          ; A<$20
  JR NZ,$717B             ; Jump to 717B if A<>$20
  CALL $1F54              ; CALL 1F54
  LD A,$20                ; A=$20
  JR C,$718A              ; Jump to 718A if the carry flag is set
  LD A,$FC                ; A=$FC
  JR $718A                ; Jump to 718A
  CP $0D                  ; Set the zero flag if A=$0D, or the carry flag if
                          ; A<$0D
  JR NC,$718A             ; Jump to 718A if A>=$0D
  SUB $06                 ; A=A-$06
  LD HL,$718D             ; HL=$718D
  ADD A,L                 ; A=A+L
  JR NC,$7188             ; Jump to 7188 if the carry flag is not set
  INC H                   ; H=H+1
  LD L,A                  ; L=A
  LD A,(HL)               ; A=PEEK HL
  POP HL                  ; Pop last item from stack into HL
  SCF                     ; Set the carry flag
  RET                     ; Return

; Data block at 718D
  DEFB $FD,$10,$F2,$F3,$F1,$F0,$7F

; Routine at 7194
;
; Used by the routine at 6333.
  LD DE,($5C7A)           ; E=PEEK $5C7A; D=PEEK $5C7B
  LD HL,($5C78)           ; L=PEEK $5C78; H=PEEK $5C79
  LD D,$00                ; D=$00
  RET                     ; Return

; Routine at 719E
;
; Used by the routines at 675D, 6BA8, 6C37 and 6C61.
  LD HL,$5C91             ; HL=$5C91
  AND $05                 ; Keep only bits 0 and 2 of A
  LD B,A                  ; B=A
  LD A,(HL)               ; A=PEEK HL
  AND $FA                 ; Reset bits 0 and 2 of A
  OR B                    ; A=A|B
  LD (HL),A               ; POKE HL,A
  RET                     ; Return

; Routine at 71AA
;
; Used by the routine at 6327.
  PUSH AF                 ; Push AF onto the stack
  PUSH HL                 ; Push HL onto the stack
  XOR A                   ; A=0
  LD HL,$71D0             ; HL=$71D0
; This entry point is used by the routine at 71C6.
  LD ($635E),A            ; POKE $635E,A
  LD A,($5C91)            ; A=PEEK $5C91
  PUSH AF                 ; Push AF onto the stack
  SET 0,A                 ; Set bit 0 of A
  LD ($5C91),A            ; POKE $5C91,A
  CALL $66F9              ; CALL 66F9
  POP AF                  ; Pop last item from stack into AF
  LD ($5C91),A            ; POKE $5C91,A
  POP HL                  ; Pop last item from stack into HL
  POP AF                  ; Pop last item from stack into AF
  RET                     ; Return

; Routine at 71C6
;
; Used by the routine at 6324.
  PUSH AF                 ; Push AF onto the stack
  PUSH HL                 ; Push HL onto the stack
  LD A,$01                ; A=$01
  LD HL,$71D3             ; HL=$71D3
  JP $71B0                ; Jump to 71B0

; Data block at 71D0
  DEFB $20,$08,$FF,$12,$01,$20,$12,$00
  DEFB $08,$FF,$CD,$54,$1F,$17,$E6,$01
  DEFB $EE,$01,$C9

; Message at 71E3
  DEFM "2bc"

; Data block at 71E6
  DEFB $C9

; Routine at 71E7
;
; Used by the routine at 7157.
  LD A,($6362)            ; A=PEEK $6362
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET Z                   ; Return if A=0
  LD HL,$6362             ; HL=$6362
  LD (HL),$00             ; POKE HL,$00
  RET                     ; Return

; Data block at 71F2
  DEFB $FE,$88,$2F,$A5,$FD,$A1,$04,$8A
  DEFB $8A,$82,$4F,$A5,$26,$85,$49,$72
  DEFB $D5,$E5,$CD,$2D,$63,$E1,$D1,$7A
  DEFB $A7,$28,$0A,$CB,$7F,$28,$03,$AF
  DEFB $18,$02,$3E,$FF,$5F,$7C,$A7,$20
  DEFB $15,$7D,$FE,$30,$38,$08,$FE,$B0
  DEFB $38,$06,$3E,$AF,$18,$02

; Message at 7228
  DEFM ">0W"

; Data block at 722B
  DEFB $ED,$53,$7D,$5C,$C9,$CB,$7F,$28
  DEFB $F0,$18,$F2,$E5,$2A,$51,$5C,$E5
  DEFB $F5,$3E,$03,$CD,$01,$16,$F1,$D7
  DEFB $E1,$22,$51,$5C,$E1,$C9

; Routine at 7249
;
; Used by the routine at 7157.
  PUSH AF                 ; Push AF onto the stack
  PUSH HL                 ; Push HL onto the stack
  LD HL,$725B             ; HL=$725B
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7266              ; Jump to 7266 if A=0
  IN A,($FE)              ; A=IN ($0100*A+$FE)
  INC HL                  ; HL=HL+1
  AND (HL)                ; A=A&PEEK HL
  JR NZ,$729B             ; Jump to 729B if A>0
  INC HL                  ; HL=HL+1
  JR $724E                ; Jump to 724E

; Data block at 725B
  DEFB $7F,$18,$FB,$06,$FD,$14,$BF,$0B
  DEFB $DF,$10,$00,$3E,$03,$CD,$2A,$63
  DEFB $F5

; Message at 726C
  DEFM "!zr"

; Data block at 726F
  DEFB $7E,$C6,$64,$28,$18,$CD,$1E,$63
  DEFB $23,$18,$F5,$BB,$9D,$9D,$E6,$FD
  DEFB $04,$BC,$DE,$0E,$01,$0A,$00,$FD
  DEFB $0A,$BC,$BD,$BD,$9C

; Message at 728C
  DEFM ">2v= "

; Data block at 7291
  DEFB $FC,$3E,$11,$CD,$1E,$63,$F1,$CD
  DEFB $2A,$63

; Routine at 729B
;
; Used by the routine at 7249.
  POP HL                  ; Pop last item from stack into HL
  POP AF                  ; Pop last item from stack into AF
  RET                     ; Return

; Data block at 729E
  DEFB $00,$22,$18,$5E

; Message at 72A2
  DEFM "ex\""

; Data block at 72A5
  DEFB $18,$5E,$21,$00,$00,$22,$E3,$A4
  DEFB $C9

; Routine at 72AE
;
; Used by the routine at 7B3F.
  LD HL,$A4E7             ; HL=$A4E7
  RES 7,(HL)              ; Reset bit 7 of (HL)
  RET                     ; Return

; Routine at 72B4
;
; Used by the routine at 75B6.
  LD HL,$9636             ; HL=$9636
  CALL $95D5              ; CALL 95D5
  RET                     ; Return

; Routine at 72BB
  LD HL,$A4E7             ; HL=$A4E7
  SET 7,(HL)              ; Set bit 7 of (HL)
; This entry point is used by the routine at 75B6.
  LD HL,$963F             ; HL=$963F
  CALL $95D5              ; CALL 95D5
  RET                     ; Return

; Routine at 72C7
;
; Used by the routine at 7C3F.
  POP HL                  ; Pop last item from stack into HL
  LD ($A501),SP           ; POKE $A501,SP-lo; POKE $A502,SP-hi
  JP (HL)                 ; Jump to HL

; Data block at 72CD
  DEFB $7E,$A7,$C8,$E5,$CD,$E6,$77,$CD
  DEFB $93,$8C,$21,$18,$5E,$CD,$96,$7C
  DEFB $E1,$7E,$A7,$C8,$23,$FE,$3F,$28
  DEFB $E7,$E6,$80,$28,$F4,$23,$18,$F1
  DEFB $21,$4E,$96,$CD,$96,$7C,$2A,$27
  DEFB $A5,$C3,$CD,$72

; Routine at 72F9
;
; Used by the routines at 734F, 7358, 7371, 7393, 73A3, 73B3, 73E1, 740B, 7452,
; 7477, 748A, 74A2, 74B8, 752C, 75B6, 76B3, 76F6, 77AC, 7805, 792C, 7943, 7958
; and 8A24.
  LD HL,($A537)           ; L=PEEK $A537; H=PEEK $A538
  PUSH HL                 ; Push HL onto the stack
  PUSH DE                 ; Push DE onto the stack
  LD DE,$A4A3             ; DE=$A4A3
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,DE               ; HL=HL-carry-DE
  POP DE                  ; Pop last item from stack into DE
  POP HL                  ; Pop last item from stack into HL
  CALL Z,$7FC8            ; CALL 7FC8 if the zero flag is set
  NOP                     ; Do nothing
  PUSH DE                 ; Push DE onto the stack
  DEC HL                  ; HL=HL-1
  LD D,(HL)               ; D=PEEK HL
  DEC HL                  ; HL=HL-1
  LD E,(HL)               ; E=PEEK HL
  LD ($A537),HL           ; POKE $A537,L; POKE $A538,H
  POP HL                  ; Pop last item from stack into HL
  EX DE,HL                ; Exchange DE and HL
  RET                     ; Return

; Routine at 7315
;
; Used by the routines at 734F, 7358, 7371, 738D, 7393, 73A3, 73B3, 7436, 7444,
; 748A, 74A2, 75B6, 7751, 781B, 792C and 79A1.
  EX DE,HL                ; Exchange DE and HL
  PUSH HL                 ; Push HL onto the stack
  LD HL,($A537)           ; L=PEEK $A537; H=PEEK $A538
  PUSH HL                 ; Push HL onto the stack
  PUSH DE                 ; Push DE onto the stack
  LD DE,$A4E3             ; DE=$A4E3
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,DE               ; HL=HL-carry-DE
  POP DE                  ; Pop last item from stack into DE
  POP HL                  ; Pop last item from stack into HL
  JR NZ,$732A             ; Jump to 732A if the zero flag is not set
  CALL $7FC8              ; CALL 7FC8
  LD BC,$2373             ; BC=$2373
  LD (HL),D               ; POKE HL,D
  INC HL                  ; HL=HL+1
  LD ($A537),HL           ; POKE $A537,L; POKE $A538,H
  POP HL                  ; Pop last item from stack into HL
  EX DE,HL                ; Exchange DE and HL
  RET                     ; Return

; Routine at 7334
;
; Used by the routines at 7967 and 7B3F.
  LD HL,$A4A3             ; HL=$A4A3
  LD ($A537),HL           ; POKE $A537,L; POKE $A538,H
  RET                     ; Return

; Data block at 733B
  DEFB $21,$FF,$7F,$C3,$15,$73,$CD,$F9
  DEFB $72,$C3,$92,$88,$AF,$32,$E3,$A4
  DEFB $C3,$96,$83,$00

; Routine at 734F
;
; Used by the routines at 76B3 and 76F6.
  CALL $72F9              ; CALL 72F9
  CALL $7315              ; CALL 7315
  JP $7315                ; Jump to 7315

; Routine at 7358
;
; Used by the routine at 749C.
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  OR L                    ; A=A|L
  LD HL,$0000             ; HL=$0000
  JR NZ,$7363             ; Jump to 7363 if the zero flag is not set
  INC HL                  ; HL=HL+1
  JP $7315                ; Jump to 7315

; Data block at 7366
  DEFB $CD,$F9,$72,$EB,$CD,$F9,$72,$19
  DEFB $C3,$15,$73

; Routine at 7371
;
; Used by the routine at 74A2.
  CALL $72F9              ; CALL 72F9
  EX DE,HL                ; Exchange DE and HL
  CALL $72F9              ; CALL 72F9
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,DE               ; HL=HL-carry-DE
  JP $7315                ; Jump to 7315

; Data block at 737E
  DEFB $CD,$F9,$72,$EB,$CD,$F9,$72,$EB
  DEFB $CD,$15,$73,$EB,$C3,$15,$73

; Routine at 738D
;
; Used by the routines at 7660 and 8378.
  LD HL,($A4ED)           ; L=PEEK $A4ED; H=PEEK $A4EE
  JP $7315                ; Jump to 7315

; Routine at 7393
  CALL $72F9              ; CALL 72F9
  EX DE,HL                ; Exchange DE and HL
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  AND D                   ; A=A&D
  LD H,A                  ; H=A
  LD A,L                  ; A=L
  AND E                   ; A=A&E
  LD L,A                  ; L=A
  JP $7315                ; Jump to 7315

; Routine at 73A3
  CALL $72F9              ; CALL 72F9
  EX DE,HL                ; Exchange DE and HL
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  OR D                    ; A=A|D
  LD H,A                  ; H=A
  LD A,L                  ; A=L
  OR E                    ; A=A|E
  LD L,A                  ; L=A
  JP $7315                ; Jump to 7315

; Routine at 73B3
;
; Used by the routine at 749C.
  CALL $72F9              ; CALL 72F9
  EX DE,HL                ; Exchange DE and HL
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  XOR D                   ; A=A^D
  LD H,A                  ; H=A
  LD A,L                  ; A=L
  XOR E                   ; A=A^E
  LD L,A                  ; L=A
  JP $7315                ; Jump to 7315

; Data block at 73C3
  DEFB $2A,$EB,$A4

; Message at 73C6
  DEFM "DM))"

; Data block at 73CA
  DEFB $09

; Message at 73CB
  DEFM ")))"

; Data block at 73CE
  DEFB $09,$23,$22,$EB,$A4,$EB,$CD,$F9
  DEFB $72,$7D,$CD,$59,$88,$6C,$26,$00
  DEFB $C3,$15,$73

; Routine at 73E1
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  OR L                    ; A=A|L
  LD HL,($A4E8)           ; L=PEEK $A4E8; H=PEEK $A4E9
  JR Z,$73F3              ; Jump to 73F3 if the zero flag is set
  LD A,($A4E7)            ; A=PEEK $A4E7
  OR $08                  ; Set bit 3 of A
  LD ($A4E7),A            ; POKE $A4E7,A
  RET NZ                  ; Return if the zero flag is not set
  BIT 7,(HL)              ; Set the zero flag if bit 7 of (HL) is 0
  JR Z,$73FC              ; Jump to 73FC if bit 7 of PEEK HL is reset
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  JR $73F4                ; Jump to 73F4
  LD A,(HL)               ; A=PEEK HL
  CP $3F                  ; Set the zero flag if A=$3F, or the carry flag if
                          ; A<$3F
  JR Z,$7407              ; Jump to 7407 if A=$3F
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7407              ; Jump to 7407 if A=0
  INC HL                  ; HL=HL+1
  JR $73F4                ; Jump to 73F4
  LD ($A4E8),HL           ; POKE $A4E8,L; POKE $A4E9,H
  RET                     ; Return

; Routine at 740B
;
; Used by the routines at 7428, 7436 and 7444.
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7416              ; Jump to 7416 if A=0
  CALL $7FC8              ; CALL 7FC8
  EX AF,AF'               ; Exchange AF and AF'
  LD B,L                  ; B=L
  INC B                   ; B=B+1
  LD HL,$A482             ; HL=$A482
  LD A,$80                ; A=$80
  RLCA                    ; Rotate A left circular (copying bit 7 into bit 0
                          ; and into the carry flag)
  JR NC,$7421             ; Jump to 7421 if the carry flag is not set
  INC HL                  ; HL=HL+1
  DJNZ $741D              ; Decrement B and jump to 741D if B>0
  LD E,A                  ; E=A
  XOR $FF                 ; Flip every bit of A
  LD D,A                  ; D=A
  RET                     ; Return

; Routine at 7428
  CALL $740B              ; CALL 740B
  LD A,(HL)               ; A=PEEK HL
  OR E                    ; A=A|E
  LD (HL),A               ; POKE HL,A
  RET                     ; Return

; Data block at 742F
  DEFB $CD,$0B,$74,$7E,$A2,$77,$C9

; Routine at 7436
  CALL $740B              ; CALL 740B
  LD A,(HL)               ; A=PEEK HL
  AND E                   ; A=A&E
  LD HL,$0000             ; HL=$0000
  JR Z,$7441              ; Jump to 7441 if the zero flag is set
  INC HL                  ; HL=HL+1
  JP $7315                ; Jump to 7315

; Routine at 7444
  CALL $740B              ; CALL 740B
  LD A,(HL)               ; A=PEEK HL
  AND E                   ; A=A&E
  LD HL,$0000             ; HL=$0000
  JR NZ,$744F             ; Jump to 744F if the zero flag is not set
  INC HL                  ; HL=HL+1
  JP $7315                ; Jump to 7315

; Routine at 7452
;
; Used by the routines at 7477 and 748A.
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$745E             ; Jump to 745E if A>0
  LD A,L                  ; A=L
  AND $80                 ; Keep only bit 7 of A
  JR Z,$7462              ; Jump to 7462 if A=0
  CALL $7FC8              ; CALL 7FC8
  EX AF,AF'               ; Exchange AF and AF'
  EX DE,HL                ; Exchange DE and HL
  LD HL,$A403             ; HL=$A403
  ADD HL,DE               ; HL=HL+DE
  RET                     ; Return

; Data block at 7468
  DEFB $CD

; Message at 7469
  DEFM "Rt4"

; Data block at 746C
  DEFB $C0,$35,$C9,$CD,$52,$74,$7E,$A7
  DEFB $C8,$35,$C9

; Routine at 7477
  CALL $7452              ; CALL 7452
  EX DE,HL                ; Exchange DE and HL
  CALL $72F9              ; CALL 72F9
  LD A,L                  ; A=L
  LD (DE),A               ; POKE DE,A
  RET                     ; Return

; Data block at 7481
  DEFB $CD

; Message at 7482
  DEFM "Rtn&"

; Data block at 7486
  DEFB $00,$C3,$15,$73

; Routine at 748A
  CALL $7452              ; CALL 7452
  EX DE,HL                ; Exchange DE and HL
  CALL $72F9              ; CALL 72F9
  LD A,(DE)               ; A=PEEK DE
  CP L                    ; Set the zero flag if A=L, or the carry flag if A<L
  LD HL,$0000             ; HL=$0000
  JR NZ,$7499             ; Jump to 7499 if the zero flag is not set
  INC HL                  ; HL=HL+1
  JP $7315                ; Jump to 7315

; Routine at 749C
;
; Used by the routine at 8378.
  CALL $73B3              ; CALL 73B3
  JP $7358                ; Jump to 7358

; Routine at 74A2
  CALL $7371              ; CALL 7371
  CALL $72F9              ; CALL 72F9
  BIT 7,H                 ; Set the zero flag if bit 7 of H is 0
  LD HL,$0000             ; HL=$0000
  JR Z,$74B0              ; Jump to 74B0 if the zero flag is set
  INC HL                  ; HL=HL+1
  JP $7315                ; Jump to 7315

; Data block at 74B3
  DEFB $CD,$7E,$73,$18,$EA

; Routine at 74B8
;
; Used by the routines at 76B3, 7751, 7761 and 77AC.
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$74C3              ; Jump to 74C3 if A=0
  CALL $7FC8              ; CALL 7FC8
  DEC B                   ; B=B-1
  EX DE,HL                ; Exchange DE and HL
  LD HL,$A1FD             ; HL=$A1FD
  ADD HL,DE               ; HL=HL+DE
  ADD HL,DE               ; HL=HL+DE
  RET                     ; Return

; Data block at 74CA
  DEFB $21,$67,$96,$CD,$6C,$88,$CD,$8F
  DEFB $8E,$21,$3E,$9F,$CD,$6C,$88,$3A
  DEFB $00,$5B,$A7,$20,$05,$3E,$FF,$32
  DEFB $00,$5B,$CD,$E0,$8E,$21,$1F,$A5
  DEFB $DD,$21,$00,$5B,$DD,$36,$00,$03
  DEFB $DD,$36,$0B,$00,$DD,$36,$0C,$80
  DEFB $3E,$01,$32,$74,$5C,$01,$5A,$07
  DEFB $C3,$53,$85,$CD,$F9,$72

; Routine at 7508
;
; Used by the routine at 7669.
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7510              ; Jump to 7510 if A=0
  CALL $7FC8              ; CALL 7FC8
  DEC B                   ; B=B-1
  LD C,L                  ; C=L
  LD HL,($A523)           ; L=PEEK $A523; H=PEEK $A524
  CALL $8A75              ; CALL 8A75
  JR C,$750C              ; Jump to 750C if the carry flag is set
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
; This entry point is used by the routine at 75B6.
  LD DE,$5E18             ; DE=$5E18
  CALL $874F              ; CALL 874F
  DEC DE                  ; DE=DE-1
  DEC A                   ; A=A-1
  LD (DE),A               ; POKE DE,A
  LD HL,$5E18             ; HL=$5E18
  CALL $886C              ; CALL 886C
  RET                     ; Return

; Routine at 752C
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7537              ; Jump to 7537 if A=0
  CALL $7FC8              ; CALL 7FC8
  LD B,$4D                ; B=$4D
; This entry point is used by the routines at 75B6, 76B3, 76E0, 76F6, 77B8,
; 7B03 and 7C3F.
  LD HL,($A52D)           ; L=PEEK $A52D; H=PEEK $A52E
  CALL $8A75              ; CALL 8A75
  JR C,$7533              ; Jump to 7533 if the carry flag is set
  LD DE,$5E18             ; DE=$5E18
  CALL $874F              ; CALL 874F
  DEC DE                  ; DE=DE-1
  DEC A                   ; A=A-1
  LD (DE),A               ; POKE DE,A
  LD HL,$5E18             ; HL=$5E18
  JP $886C                ; Jump to 886C

; Routine at 754F
;
; Used by the routines at 778A and 77B8.
  LD HL,$96B1             ; HL=$96B1
  CALL $886C              ; CALL 886C
  RET                     ; Return

; Data block at 7556
  DEFB $CD,$4F,$73,$CD,$B8,$74,$5E,$23
  DEFB $56,$7E,$FE,$7F,$20,$1F,$ED,$5B
  DEFB $ED,$A4

; Message at 7568
  DEFM "r+s"

; Data block at 756B
  DEFB $CD,$F9

; Message at 756D
  DEFM "rM*"

; Data block at 7570
  DEFB $23,$A5,$CD,$75,$8A,$30,$04,$CD
  DEFB $C8,$7F,$05,$3A,$EF,$A4,$96,$32
  DEFB $EF,$A4,$C9,$CD,$F9,$72,$E5,$0E
  DEFB $F6,$CD,$38,$75,$E1,$C3,$F2,$78
  DEFB $11,$19,$5E,$18,$03,$21,$00,$5B
  DEFB $7E,$FE,$20,$C0,$23,$18,$F9,$CD
  DEFB $B8,$74,$E5,$CD,$B8,$74,$D1,$1A
  DEFB $47,$7E,$12,$78,$77,$13,$23,$1A
  DEFB $47,$7E,$12,$78,$77,$C9

; Routine at 75B6
;
; Used by the routine at 7660.
  CALL $72F9              ; CALL 72F9
  LD A,($A483)            ; A=PEEK $A483
  AND $06                 ; Keep only bits 1 and 2 of A
  JR NZ,$75D3             ; Jump to 75D3 if A>0
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $80                 ; Keep only bit 7 of A
  JR NZ,$75CD             ; Jump to 75CD if A>0
  CALL $72B4              ; CALL 72B4
  CALL $72C0              ; CALL 72C0
  LD C,$FB                ; C=$FB
  CALL $7538              ; CALL 7538
  RET                     ; Return
  LD A,($A483)            ; A=PEEK $A483
  OR $01                  ; Set bit 0 of A
  LD ($A483),A            ; POKE $A483,A
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $80                 ; Keep only bit 7 of A
  JR NZ,$760D             ; Jump to 760D if A>0
  PUSH HL                 ; Push HL onto the stack
  CALL $7315              ; CALL 7315
  POP BC                  ; Pop last item from stack into BC
  LD HL,($A525)           ; L=PEEK $A525; H=PEEK $A526
  CALL $8A3F              ; CALL 8A3F
  LD C,(HL)               ; C=PEEK HL
  INC HL                  ; HL=HL+1
  LD B,(HL)               ; B=PEEK HL
  LD A,B                  ; A=B
  OR C                    ; A=A|C
  JR Z,$7601              ; Jump to 7601 if A=0
  PUSH BC                 ; Push BC onto the stack
  CALL $72B4              ; CALL 72B4
  POP BC                  ; Pop last item from stack into BC
  LD HL,($A52F)           ; L=PEEK $A52F; H=PEEK $A530
  CALL $8A59              ; CALL 8A59
  JR $7605                ; Jump to 7605
  CALL $72C0              ; CALL 72C0
  SCF                     ; Set the carry flag
  JR C,$760A              ; Jump to 760A if the carry flag is set
  CALL $7649              ; CALL 7649
  CALL $72F9              ; CALL 72F9
  LD B,H                  ; B=H
  LD C,L                  ; C=L
  LD HL,($A525)           ; L=PEEK $A525; H=PEEK $A526
  CALL $8A3F              ; CALL 8A3F
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  JR NC,$761D             ; Jump to 761D if the carry flag is not set
  CALL $7FC8              ; CALL 7FC8
  INC B                   ; B=B+1
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7626              ; Jump to 7626 if A=0
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  JR $761D                ; Jump to 761D
  INC HL                  ; HL=HL+1
  CALL $751C              ; CALL 751C
  LD HL,($A537)           ; L=PEEK $A537; H=PEEK $A538
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  EX DE,HL                ; Exchange DE and HL
  PUSH HL                 ; Push HL onto the stack
  LD A,$C9                ; A=$C9
  LD ($631E),A            ; POKE $631E,A
  CALL $7669              ; CALL 7669
  CALL $7749              ; CALL 7749
  POP HL                  ; Pop last item from stack into HL
  RET Z                   ; Return if the zero flag is set
  PUSH HL                 ; Push HL onto the stack
  LD C,$FD                ; C=$FD
  CALL $7538              ; CALL 7538
  POP HL                  ; Pop last item from stack into HL
  JP $7669                ; Jump to 7669

; Routine at 7649
;
; Used by the routine at 75B6.
  PUSH IX                 ; Push IX onto the stack
  PUSH HL                 ; Push HL onto the stack
  POP IX                  ; Pop last item from stack into IX
  CALL $6336              ; CALL 6336
  POP IX                  ; Pop last item from stack into IX
  LD HL,$9639             ; HL=$9639
  CALL $886C              ; CALL 886C
  LD HL,$96B1             ; HL=$96B1
  CALL $886C              ; CALL 886C
  RET                     ; Return

; Routine at 7660
;
; Used by the routines at 7805 and 7B3F.
  CALL $738D              ; CALL 738D
  JP $75B6                ; Jump to 75B6

; Data block at 7666
  DEFB $CD,$F9,$72

; Routine at 7669
;
; Used by the routine at 75B6.
  LD A,H                  ; A=H
  OR L                    ; A=A|L
  JR NZ,$7671             ; Jump to 7671 if A>0
  CALL $7FC8              ; CALL 7FC8
  EX AF,AF'               ; Exchange AF and AF'
  EX DE,HL                ; Exchange DE and HL
  LD HL,$A1FD             ; HL=$A1FD
  XOR A                   ; A=0
  LD ($A4F0),A            ; POKE $A4F0,A
  LD C,(HL)               ; C=PEEK HL
  INC HL                  ; HL=HL+1
  LD B,(HL)               ; B=PEEK HL
  DEC HL                  ; HL=HL-1
  PUSH DE                 ; Push DE onto the stack
  PUSH HL                 ; Push HL onto the stack
  PUSH AF                 ; Push AF onto the stack
  LD A,B                  ; A=B
  XOR D                   ; A=A^D
  JR NZ,$769B             ; Jump to 769B if A>0
  LD A,C                  ; A=C
  XOR E                   ; A=A^E
  JR NZ,$769B             ; Jump to 769B if A>0
  LD A,($A4F0)            ; A=PEEK $A4F0
  CALL $631E              ; CALL 631E
  POP AF                  ; Pop last item from stack into AF
  PUSH AF                 ; Push AF onto the stack
  LD L,A                  ; L=A
  LD H,$00                ; H=$00
  CALL $7508              ; CALL 7508
  LD A,$2C                ; A=$2C
  LD ($A4F0),A            ; POKE $A4F0,A
  POP AF                  ; Pop last item from stack into AF
  POP HL                  ; Pop last item from stack into HL
  POP DE                  ; Pop last item from stack into DE
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  INC A                   ; A=A+1
  JR NZ,$7679             ; Jump to 7679 if A>0
  LD A,($A4F0)            ; A=PEEK $A4F0
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET                     ; Return

; Data block at 76A8
  DEFB $CD,$66,$76,$C0,$21,$B4,$96,$CD
  DEFB $6C,$88,$C9

; Routine at 76B3
  CALL $734F              ; CALL 734F
  CALL $74B8              ; CALL 74B8
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  DEC HL                  ; HL=HL-1
  EX DE,HL                ; Exchange DE and HL
  LD BC,($A4ED)           ; C=PEEK $A4ED; B=PEEK $A4EE
  LD A,H                  ; A=H
  CP $7F                  ; Set the zero flag if A=$7F, or the carry flag if
                          ; A<$7F
  JR NZ,$76E0             ; Jump to 76E0 if A<>$7F
  LD C,$F5                ; C=$F5
  CALL $7538              ; CALL 7538
; This entry point is used by the routine at 76E0.
  CALL $72F9              ; CALL 72F9
  JP $78F2                ; Jump to 78F2

; Data block at 76D2
  DEFB $3A,$83,$A4,$E6,$08,$CC,$4F,$75
  DEFB $CC,$28,$77,$C3,$4F,$75

; Routine at 76E0
;
; Used by the routine at 76B3.
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,BC               ; HL=HL-carry-BC
  JR Z,$76F6              ; Jump to 76F6 if HL=0
  LD C,$F7                ; C=$F7
  CALL $7538              ; CALL 7538
  JR $76CC                ; Jump to 76CC

; Data block at 76EC
  DEFB $3E,$20,$12,$13,$7B,$FE,$04,$20
  DEFB $F7,$C9

; Routine at 76F6
;
; Used by the routine at 76E0.
  PUSH DE                 ; Push DE onto the stack
  CALL $734F              ; CALL 734F
  CALL $72F9              ; CALL 72F9
  LD C,L                  ; C=L
  LD HL,($A523)           ; L=PEEK $A523; H=PEEK $A524
  CALL $8A75              ; CALL 8A75
  JR NC,$770A             ; Jump to 770A if the carry flag is not set
  CALL $7FC8              ; CALL 7FC8
  DEC B                   ; B=B-1
  LD E,(HL)               ; E=PEEK HL
  LD A,($A4EF)            ; A=PEEK $A4EF
  ADD A,E                 ; A=A+E
  LD HL,$A4EA             ; HL=$A4EA
  CP (HL)                 ; Set the zero flag if A=PEEK HL, or the carry flag
                          ; if A<PEEK HL
  JR NC,$7721             ; Jump to 7721 if A>=PEEK HL
  LD ($A4EF),A            ; POKE $A4EF,A
  POP HL                  ; Pop last item from stack into HL
  LD (HL),$FF             ; POKE HL,$FF
  INC HL                  ; HL=HL+1
  LD (HL),$7F             ; POKE HL,$7F
  JP $72F9                ; Jump to 72F9
  LD C,$F8                ; C=$F8
  CALL $7538              ; CALL 7538
  JR $7745                ; Jump to 7745

; Data block at 7728
  DEFB $0E,$F9,$CD

; Message at 772B
  DEFM "8u*"

; Data block at 772E
  DEFB $03,$A4,$26,$00,$CD,$92,$88,$0E
  DEFB $FA,$CD,$38,$75,$CD,$7E,$83,$CD
  DEFB $41,$73,$0E,$FF,$C3,$38,$75,$D1
  DEFB $C3,$CC,$76

; Routine at 7749
;
; Used by the routine at 75B6.
  PUSH AF                 ; Push AF onto the stack
  LD A,$C3                ; A=$C3
  LD ($631E),A            ; POKE $631E,A
  POP AF                  ; Pop last item from stack into AF
  RET                     ; Return

; Routine at 7751
  CALL $74B8              ; CALL 74B8
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  CP $7F                  ; Set the zero flag if A=$7F, or the carry flag if
                          ; A<$7F
; This entry point is used by the routine at 7761.
  LD HL,$0000             ; HL=$0000
  JR NZ,$775E             ; Jump to 775E if the zero flag is not set
  INC HL                  ; HL=HL+1
  JP $7315                ; Jump to 7315

; Routine at 7761
  CALL $74B8              ; CALL 74B8
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  LD HL,($A4ED)           ; L=PEEK $A4ED; H=PEEK $A4EE
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  SBC HL,DE               ; HL=HL-carry-DE
  JR $7758                ; Jump to 7758

; Data block at 776F
  DEFB $CD,$B8,$74,$5E,$23,$56,$7A,$FE
  DEFB $7F,$28,$F3,$18,$EB,$CD,$B8,$74
  DEFB $5E,$23,$56,$CD,$F9,$72,$A7,$ED
  DEFB $52,$18,$E3

; Routine at 778A
  CALL $631E              ; CALL 631E
  CALL $864B              ; CALL 864B
  RET NZ                  ; Return if the zero flag is not set
  PUSH HL                 ; Push HL onto the stack
  PUSH HL                 ; Push HL onto the stack
  CALL $6321              ; CALL 6321
  LD B,H                  ; B=H
  POP HL                  ; Pop last item from stack into HL
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  INC B                   ; B=B+1
  CALL $864B              ; CALL 864B
  JR Z,$77A2              ; Jump to 77A2 if the zero flag is set
  CP $FF                  ; Set the zero flag if A=$FF, or the carry flag if
                          ; A<$FF
  JR NZ,$7798             ; Jump to 7798 if A<>$FF
  LD A,B                  ; A=B
  CP $21                  ; Set the zero flag if A=$21, or the carry flag if
                          ; A<$21
  CALL NC,$754F           ; CALL 754F if A>=$21
  POP HL                  ; Pop last item from stack into HL
  RET                     ; Return

; Routine at 77AC
  CALL $72F9              ; CALL 72F9
  PUSH HL                 ; Push HL onto the stack
  CALL $74B8              ; CALL 74B8
  POP DE                  ; Pop last item from stack into DE
  LD (HL),E               ; POKE HL,E
  INC HL                  ; HL=HL+1
  LD (HL),D               ; POKE HL,D
  RET                     ; Return

; Routine at 77B8
;
; Used by the routine at 7BA4.
  CALL $754F              ; CALL 754F
  JP $7538                ; Jump to 7538

; Data block at 77BE
  DEFB $CD,$B8,$74,$5E,$23,$56,$7A,$FE
  DEFB $7F,$28,$16,$B3,$28,$08,$ED,$5B
  DEFB $ED,$A4

; Message at 77D0
  DEFM "r+s"

; Data block at 77D3
  DEFB $C9,$0E,$FC,$CD,$38,$75,$C3,$F2
  DEFB $78,$C3,$30,$63,$0E,$F5,$CD,$38
  DEFB $75,$18,$F3,$E5,$CD,$F1,$84,$E1
  DEFB $C9,$3A,$E3,$A4,$A7,$CA,$5F,$8F
  DEFB $AF,$32,$E3,$A4,$C3,$10,$90,$CA
  DEFB $5F,$8F,$3E,$FF,$32,$E3,$A4,$C3
  DEFB $F4,$8F

; Routine at 7805
  CALL $72F9              ; CALL 72F9
; This entry point is used by the routine at 7B79.
  LD ($A4ED),HL           ; POKE $A4ED,L; POKE $A4EE,H
  JP $7660                ; Jump to 7660

; Data block at 780E
  DEFB $3A,$E3,$A4,$18,$08

; Routine at 7813
  LD A,($A4E5)            ; A=PEEK $A4E5
  JR $781B                ; Jump to 781B

; Data block at 7818
  DEFB $3A,$E6,$A4

; Routine at 781B
;
; Used by the routine at 7813.
  LD L,A                  ; L=A
  LD H,$00                ; H=$00
  JP $7315                ; Jump to 7315

; Data block at 7821
  DEFB $3A,$E3,$A4,$C3,$1B,$78,$CD,$B8
  DEFB $74,$23,$7E,$FE,$7F,$C8,$2B,$B6
  DEFB $CA,$D4,$77,$5E,$23,$56,$EB,$C3
  DEFB $08,$78,$CD,$F9,$72,$7C,$A7,$28
  DEFB $04,$CD,$C8,$7F,$05,$4D,$2A,$23
  DEFB $A5,$CD,$75,$8A,$38,$F3,$7E,$6F
  DEFB $26,$00,$C3,$15,$73,$ED,$4B,$ED
  DEFB $A4,$2A,$25,$A5,$CD,$3F,$8A,$23
  DEFB $23,$30,$04,$CD,$C8,$7F,$04,$EB
  DEFB $CD,$F9,$72,$7C,$A7,$28,$04,$CD
  DEFB $C8,$7F,$08,$EB,$7E,$A7,$20,$06
  DEFB $21,$00,$00,$C3,$15,$73,$BB,$28
  DEFB $05,$23,$23,$23,$18,$EE,$23,$5E
  DEFB $23,$56,$EB,$C3,$15,$73,$DD,$E5
  DEFB $21,$BC,$96,$CD,$6C,$88,$CD,$8F
  DEFB $8E,$21,$3E,$9F,$CD,$6C,$88,$CD
  DEFB $E0,$8E,$21,$FD,$A4,$11,$FD,$A1
  DEFB $CD,$BE,$8E,$DD,$E1,$C9,$00,$00
  DEFB $00,$00,$DD,$E5,$2A,$E8,$A4,$22
  DEFB $AF,$78,$2A,$F4,$A4,$22,$B1,$78
  DEFB $21,$BC,$96,$CD,$6C,$88,$21,$FD
  DEFB $A1,$22,$E8,$74,$CD,$D0,$74,$21
  DEFB $1F,$A5,$22,$E8,$74,$2A,$AF,$78
  DEFB $22,$E8,$A4,$2A,$B1,$78,$22,$F4
  DEFB $A4,$DD,$E1,$21,$36,$96,$CD,$6C
  DEFB $88,$C3,$4F,$75,$0E,$FE,$CD

; Message at 78F0
  DEFM "8u!"

; Data block at 78F3
  DEFB $B1,$96,$CD,$6C,$88,$3A,$E7,$A4
  DEFB $F6,$40,$32,$E7,$A4,$C9,$00,$0E
  DEFB $F4,$CD,$38,$75,$00,$18,$00,$CD
  DEFB $24,$63,$CD,$18,$63,$CD,$27,$63
  DEFB $E6,$DF,$FE,$4E,$C8,$3A,$E7,$A4
  DEFB $F6,$20,$32,$E7,$A4,$C3,$D2,$76
  DEFB $00

; Routine at 7924
  LD A,($A4E3)            ; A=PEEK $A4E3
  JR $792C                ; Jump to 792C

; Data block at 7929
  DEFB $3A,$E4,$A4

; Routine at 792C
;
; Used by the routine at 7924.
  LD E,A                  ; E=A
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7938              ; Jump to 7938 if A=0
  CALL $7FC8              ; CALL 7FC8
  EX AF,AF'               ; Exchange AF and AF'
  LD A,L                  ; A=L
  CP E                    ; Set the zero flag if A=E, or the carry flag if A<E
; This entry point is used by the routine at 7943.
  LD HL,$0000             ; HL=$0000
  JR NZ,$7940             ; Jump to 7940 if the zero flag is not set
  INC HL                  ; HL=HL+1
  JP $7315                ; Jump to 7315

; Routine at 7943
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$794E              ; Jump to 794E if A=0
  CALL $7FC8              ; CALL 7FC8
  EX AF,AF'               ; Exchange AF and AF'
  LD A,L                  ; A=L
  LD HL,($A4E5)           ; L=PEEK $A4E5; H=PEEK $A4E6
  CP H                    ; Set the zero flag if A=H, or the carry flag if A<H
  JR Z,$7956              ; Jump to 7956 if A=H
  CP L                    ; Set the zero flag if A=L, or the carry flag if A<L
  JR $793A                ; Jump to 793A

; Routine at 7958
  CALL $72F9              ; CALL 72F9
  LD A,H                  ; A=H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7963              ; Jump to 7963 if A=0
  CALL $7FC8              ; CALL 7FC8
  EX AF,AF'               ; Exchange AF and AF'
  LD ($A4EA),HL           ; POKE $A4EA,L; POKE $A4EB,H
  RET                     ; Return

; Routine at 7967
;
; Used by the routines at 7B03 and 7C3F.
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $9F                 ; Reset bits 5 and 6 of A
  LD ($A4E7),A            ; POKE $A4E7,A
  LD ($A4E8),HL           ; POKE $A4E8,L; POKE $A4E9,H
  CALL $7334              ; CALL 7334
; This entry point is used by the routines at 797B and 79A1.
  LD HL,($A4E8)           ; L=PEEK $A4E8; H=PEEK $A4E9
  JP $82B0                ; Jump to 82B0

; Routine at 797B
;
; Used by the routine at 82B0.
  BIT 7,(HL)              ; Set the zero flag if bit 7 of (HL) is 0
  INC HL                  ; HL=HL+1
  JR NZ,$79A1             ; Jump to 79A1 if the zero flag is not set
  LD ($A4E8),HL           ; POKE $A4E8,L; POKE $A4E9,H
  AND $3F                 ; Reset bits 6 and 7 of A
  LD L,A                  ; L=A
  LD H,$00                ; H=$00
  ADD HL,HL               ; HL=HL+HL
  LD DE,$A155             ; DE=$A155
  ADD HL,DE               ; HL=HL+DE
  LD IX,$A51F             ; IX=$A51F
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  CALL $799F              ; CALL 799F
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $60                 ; Keep only bits 5 and 6 of A
  JR Z,$7975              ; Jump to 7975 if A=0
  RET                     ; Return

; Routine at 799F
;
; Used by the routine at 797B.
  PUSH DE                 ; Push DE onto the stack
  RET                     ; Return

; Routine at 79A1
;
; Used by the routine at 797B.
  AND $7F                 ; Reset bit 7 of A
  LD D,A                  ; D=A
  LD A,(HL)               ; A=PEEK HL
  INC HL                  ; HL=HL+1
  LD E,A                  ; E=A
  LD ($A4E8),HL           ; POKE $A4E8,L; POKE $A4E9,H
  EX DE,HL                ; Exchange DE and HL
  CALL $7315              ; CALL 7315
  JR $7975                ; Jump to 7975

; Routine at 79B0
;
; Used by the routine at 7B3F.
  LD HL,($A523)           ; L=PEEK $A523; H=PEEK $A524
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET Z                   ; Return if A=0
  INC HL                  ; HL=HL+1
  LD E,(HL)               ; E=PEEK HL
  LD D,$00                ; D=$00
  INC HL                  ; HL=HL+1
  PUSH DE                 ; Push DE onto the stack
  PUSH HL                 ; Push HL onto the stack
  INC HL                  ; HL=HL+1
  LD C,(HL)               ; C=PEEK HL
  INC HL                  ; HL=HL+1
  LD B,(HL)               ; B=PEEK HL
  LD L,A                  ; L=A
  LD H,$00                ; H=$00
  ADD HL,HL               ; HL=HL+HL
  LD DE,$A1FD             ; DE=$A1FD
  ADD HL,DE               ; HL=HL+DE
  LD (HL),C               ; POKE HL,C
  INC HL                  ; HL=HL+1
  LD (HL),B               ; POKE HL,B
  POP HL                  ; Pop last item from stack into HL
  POP DE                  ; Pop last item from stack into DE
  ADD HL,DE               ; HL=HL+DE
  JR $79B3                ; Jump to 79B3

; Routine at 79D1
;
; Used by the routine at 79E3.
  PUSH DE                 ; Push DE onto the stack
  LD HL,($A531)           ; L=PEEK $A531; H=PEEK $A532
  LD E,(HL)               ; E=PEEK HL
  LD A,B                  ; A=B
  OR C                    ; A=A|C
  INC HL                  ; HL=HL+1
  JR NZ,$79DD             ; Jump to 79DD if the zero flag is not set
  POP DE                  ; Pop last item from stack into DE
  RET                     ; Return
  LD D,$00                ; D=$00
  ADD HL,DE               ; HL=HL+DE
  DEC BC                  ; BC=BC-1
  JR $79D5                ; Jump to 79D5

; Routine at 79E3
;
; Used by the routines at 7A15, 7A28 and 7A3B.
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET Z                   ; Return if A=0
  PUSH HL                 ; Push HL onto the stack
  PUSH DE                 ; Push DE onto the stack
  INC HL                  ; HL=HL+1
  LD C,(HL)               ; C=PEEK HL
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  AND $07                 ; Keep only bits 0, 1 and 2 of A
  LD B,A                  ; B=A
  CALL $79D1              ; CALL 79D1
  LD A,(HL)               ; A=PEEK HL
  AND $7F                 ; Reset bit 7 of A
  LD C,A                  ; C=A
  LD A,(DE)               ; A=PEEK DE
  AND $7F                 ; Reset bit 7 of A
  CP $61                  ; Set the zero flag if A=$61, or the carry flag if
                          ; A<$61
  JR C,$79FF              ; Jump to 79FF if A<$61
  AND $5F                 ; Reset bits 5 and 7 of A
  CP C                    ; Set the zero flag if A=C, or the carry flag if A<C
  JR Z,$7A09              ; Jump to 7A09 if A=C
  POP DE                  ; Pop last item from stack into DE
  POP HL                  ; Pop last item from stack into HL
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  JR $79E3                ; Jump to 79E3
  INC HL                  ; HL=HL+1
  INC DE                  ; DE=DE+1
  LD A,(DE)               ; A=PEEK DE
  CALL $864B              ; CALL 864B
  JR NZ,$79F2             ; Jump to 79F2 if the zero flag is not set
  POP DE                  ; Pop last item from stack into DE
  POP HL                  ; Pop last item from stack into HL
  LD A,(HL)               ; A=PEEK HL
  RET                     ; Return

; Routine at 7A15
;
; Used by the routine at 7A53.
  LD A,($A4E3)            ; A=PEEK $A4E3
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET NZ                  ; Return if A>0
  LD HL,$A54F             ; HL=$A54F
  CALL $79E3              ; CALL 79E3
  LD ($A4E3),A            ; POKE $A4E3,A
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7A27              ; Jump to 7A27 if A=0
  SCF                     ; Set the carry flag
  RET                     ; Return

; Routine at 7A28
;
; Used by the routine at 7A53.
  LD A,($A4E4)            ; A=PEEK $A4E4
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET NZ                  ; Return if A>0
  LD HL,($A521)           ; L=PEEK $A521; H=PEEK $A522
  CALL $79E3              ; CALL 79E3
  LD ($A4E4),A            ; POKE $A4E4,A
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7A3A              ; Jump to 7A3A if A=0
  SCF                     ; Set the carry flag
  RET                     ; Return

; Routine at 7A3B
;
; Used by the routine at 7A53.
  LD HL,($A4E5)           ; L=PEEK $A4E5; H=PEEK $A4E6
  LD A,L                  ; A=L
  OR H                    ; A=A|H
  AND H                   ; A=A&H
  RET NZ                  ; Return if A>0
  LD HL,($A51F)           ; L=PEEK $A51F; H=PEEK $A520
  CALL $79E3              ; CALL 79E3
  LD HL,$A4E5             ; HL=$A4E5
  LD B,A                  ; B=A
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7A51              ; Jump to 7A51 if A=0
  INC HL                  ; HL=HL+1
  LD (HL),B               ; POKE HL,B
  RET                     ; Return

; Routine at 7A53
;
; Used by the routine at 7BA4.
  CALL $7A15              ; CALL 7A15
  RET C                   ; Return if the carry flag is set
  CALL $7A28              ; CALL 7A28
  RET C                   ; Return if the carry flag is set
  JP $7A3B                ; Jump to 7A3B

; Data block at 7A5E
  DEFB $11,$00,$00,$C3,$B4,$88

; Routine at 7A64
;
; Used by the routine at 7BA4.
  LD HL,($A4F4)           ; L=PEEK $A4F4; H=PEEK $A4F5
  LD A,(HL)               ; A=PEEK HL
  CALL $864B              ; CALL 864B
  JR Z,$7A70              ; Jump to 7A70 if the zero flag is set
  INC HL                  ; HL=HL+1
  JR $7A67                ; Jump to 7A67
  INC HL                  ; HL=HL+1
  LD ($A4F4),HL           ; POKE $A4F4,L; POKE $A4F5,H
  DEC HL                  ; HL=HL-1
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET Z                   ; Return if A=0
  CP $2C                  ; Set the zero flag if A=$2C, or the carry flag if
                          ; A<$2C
  RET Z                   ; Return if A=$2C
  CP $2E                  ; Set the zero flag if A=$2E, or the carry flag if
                          ; A<$2E
  RET Z                   ; Return if A=$2E
  CP $3B                  ; Set the zero flag if A=$3B, or the carry flag if
                          ; A<$3B
  RET Z                   ; Return if A=$3B
  CP $21                  ; Set the zero flag if A=$21, or the carry flag if
                          ; A<$21
  RET Z                   ; Return if A=$21
  AND $5F                 ; Reset bits 5 and 7 of A
  CP $41                  ; Set the zero flag if A=$41, or the carry flag if
                          ; A<$41
  JR Z,$7A97              ; Jump to 7A97 if A=$41
  CP $54                  ; Set the zero flag if A=$54, or the carry flag if
                          ; A<$54
  JR Z,$7AB5              ; Jump to 7AB5 if A=$54
  LD A,(HL)               ; A=PEEK HL
  CALL $864B              ; CALL 864B
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  JR Z,$7A70              ; Jump to 7A70 if the zero flag is set
  JR $7ADD                ; Jump to 7ADD
  PUSH HL                 ; Push HL onto the stack
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  AND $5F                 ; Reset bits 5 and 7 of A
  CP $4E                  ; Set the zero flag if A=$4E, or the carry flag if
                          ; A<$4E
  JR NZ,$7AB2             ; Jump to 7AB2 if A<>$4E
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  AND $5F                 ; Reset bits 5 and 7 of A
  CP $44                  ; Set the zero flag if A=$44, or the carry flag if
                          ; A<$44
  JR NZ,$7AB2             ; Jump to 7AB2 if A<>$44
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  CALL $864B              ; CALL 864B
  JR NZ,$7AB2             ; Jump to 7AB2 if the zero flag is not set
  POP DE                  ; Pop last item from stack into DE
  JR $7AD6                ; Jump to 7AD6
  POP HL                  ; Pop last item from stack into HL
  JR $7A8D                ; Jump to 7A8D
  PUSH HL                 ; Push HL onto the stack
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  AND $5F                 ; Reset bits 5 and 7 of A
  CP $48                  ; Set the zero flag if A=$48, or the carry flag if
                          ; A<$48
  JR NZ,$7AB2             ; Jump to 7AB2 if A<>$48
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  AND $5F                 ; Reset bits 5 and 7 of A
  CP $45                  ; Set the zero flag if A=$45, or the carry flag if
                          ; A<$45
  JR NZ,$7AB2             ; Jump to 7AB2 if A<>$45
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  AND $5F                 ; Reset bits 5 and 7 of A
  CP $4E                  ; Set the zero flag if A=$4E, or the carry flag if
                          ; A<$4E
  JR NZ,$7AB2             ; Jump to 7AB2 if A<>$4E
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  CALL $864B              ; CALL 864B
  JR NZ,$7AB2             ; Jump to 7AB2 if the zero flag is not set
  POP DE                  ; Pop last item from stack into DE
  XOR A                   ; A=0
  LD ($A4F4),HL           ; POKE $A4F4,L; POKE $A4F5,H
  LD A,$21                ; A=$21
  RET                     ; Return
  DEC HL                  ; HL=HL-1
  LD ($A4F4),HL           ; POKE $A4F4,L; POKE $A4F5,H
  RET                     ; Return

; Routine at 7AE2
;
; Used by the routine at 7B03.
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  INC HL                  ; HL=HL+1
  LD A,D                  ; A=D
  OR E                    ; A=A|E
  JR NZ,$7AEC             ; Jump to 7AEC if A>0
  CCF                     ; Complement the carry flag
  RET                     ; Return
  LD A,D                  ; A=D
  CP B                    ; Set the zero flag if A=B, or the carry flag if A<B
  JR NZ,$7AF3             ; Jump to 7AF3 if A<>B
  LD A,E                  ; A=E
  CP C                    ; Set the zero flag if A=C, or the carry flag if A<C
  RET Z                   ; Return if A=C
  LD A,(HL)               ; A=PEEK HL
  AND $80                 ; Keep only bit 7 of A
  JR Z,$7AFC              ; Jump to 7AFC if A=0
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  JR $7AF3                ; Jump to 7AF3
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  INC HL                  ; HL=HL+1
  JR Z,$7AE2              ; Jump to 7AE2 if the zero flag is set
  JR $7AF3                ; Jump to 7AF3

; Routine at 7B03
;
; Used by the routine at 7C3F.
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $F7                 ; Reset bit 3 of A
  LD ($A4E7),A            ; POKE $A4E7,A
  LD HL,($A529)           ; L=PEEK $A529; H=PEEK $A52A
  LD BC,($A4ED)           ; C=PEEK $A4ED; B=PEEK $A4EE
  CALL $7AE2              ; CALL 7AE2
  JR C,$7B20              ; Jump to 7B20 if the carry flag is set
  CALL $7967              ; CALL 7967
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $60                 ; Keep only bits 5 and 6 of A
  RET NZ                  ; Return if A>0
  LD HL,($A52B)           ; L=PEEK $A52B; H=PEEK $A52C
  CALL $7967              ; CALL 7967
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $08                 ; Keep only bit 3 of A
  RET NZ                  ; Return if A>0
  LD C,$F1                ; C=$F1
  LD HL,($A4E3)           ; L=PEEK $A4E3; H=PEEK $A4E4
  LD A,H                  ; A=H
  OR L                    ; A=A|L
  LD HL,($A4E5)           ; L=PEEK $A4E5; H=PEEK $A4E6
  OR H                    ; A=A|H
  OR L                    ; A=A|L
  JR NZ,$7B3C             ; Jump to 7B3C if A>0
  LD C,$F2                ; C=$F2
  JP $7538                ; Jump to 7538

; Routine at 7B3F
;
; Used by the routine at 7C3F.
  LD HL,$A1FD             ; HL=$A1FD
  LD DE,$A1FE             ; DE=$A1FE
  LD BC,$02F2             ; BC=$02F2
  LD (HL),$00             ; POKE HL,$00
  LDIR                    ; POKE DE,PEEK HL; HL=HL+1; DE=DE+1; BC=BC-1; repeat
                          ; until BC=0
  CALL $79B0              ; CALL 79B0
  LD A,$02                ; A=$02
  LD ($A483),A            ; POKE $A483,A
  LD A,$FA                ; A=$FA
  LD ($A4EA),A            ; POKE $A4EA,A
  CALL $6333              ; CALL 6333
  LD ($A4EB),HL           ; POKE $A4EB,L; POKE $A4EC,H
  LD HL,($A535)           ; L=PEEK $A535; H=PEEK $A536
  LD ($A4ED),HL           ; POKE $A4ED,L; POKE $A4EE,H
  LD A,$01                ; A=$01
  CALL $6330              ; CALL 6330
  LD A,$10                ; A=$10
  LD ($A4E7),A            ; POKE $A4E7,A
  CALL $7334              ; CALL 7334
  CALL $72AE              ; CALL 72AE
  CALL $7660              ; CALL 7660
  RET                     ; Return

; Routine at 7B79
;
; Used by the routine at 7C3F.
  LD BC,($A4ED)           ; C=PEEK $A4ED; B=PEEK $A4EE
  LD HL,($A525)           ; L=PEEK $A525; H=PEEK $A526
  CALL $8A3F              ; CALL 8A3F
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  JR NC,$7B8B             ; Jump to 7B8B if the carry flag is not set
  CALL $7FC8              ; CALL 7FC8
  INC B                   ; B=B+1
  LD A,($A4E3)            ; A=PEEK $A4E3
  LD B,A                  ; B=A
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET Z                   ; Return if A=0
  CP B                    ; Set the zero flag if A=B, or the carry flag if A<B
  INC HL                  ; HL=HL+1
  JR Z,$7B9A              ; Jump to 7B9A if the zero flag is set
  INC HL                  ; HL=HL+1
  INC HL                  ; HL=HL+1
  JR $7B8F                ; Jump to 7B8F
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  EX DE,HL                ; Exchange DE and HL
  CALL $7808              ; CALL 7808
  XOR A                   ; A=0
  INC A                   ; A=A+1
  RET                     ; Return

; Routine at 7BA4
;
; Used by the routine at 7C0A.
  LD A,($A4E6)            ; A=PEEK $A4E6
  LD HL,($A481)           ; L=PEEK $A481; H=PEEK $A482
  INC HL                  ; HL=HL+1
  LD ($A481),HL           ; POKE $A481,L; POKE $A482,H
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7BB9              ; Jump to 7BB9 if A=0
  LD HL,($A4E5)           ; L=PEEK $A4E5; H=PEEK $A4E6
  LD ($A4F1),HL           ; POKE $A4F1,L; POKE $A4F2,H
  JR $7BC2                ; Jump to 7BC2
  LD A,($A4E5)            ; A=PEEK $A4E5
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7BC2              ; Jump to 7BC2 if A=0
  LD ($A4F2),A            ; POKE $A4F2,A
  LD HL,$0000             ; HL=$0000
  LD ($A4E3),HL           ; POKE $A4E3,L; POKE $A4E4,H
  LD ($A4E5),HL           ; POKE $A4E5,L; POKE $A4E6,H
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $10                 ; Keep only bit 4 of A
  JR Z,$7BF2              ; Jump to 7BF2 if A=0
  LD C,$F0                ; C=$F0
  CALL $77B8              ; CALL 77B8
  LD HL,$5B00             ; HL=$5B00
  LD ($A4F4),HL           ; POKE $A4F4,L; POKE $A4F5,H
  LD (HL),$00             ; POKE HL,$00
  CALL $85DC              ; CALL 85DC
  JR NC,$7BD2             ; Jump to 7BD2 if the carry flag is not set
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $EF                 ; Reset bit 4 of A
  LD ($A4E7),A            ; POKE $A4E7,A
  LD A,($5B00)            ; A=PEEK $5B00
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7BD2              ; Jump to 7BD2 if A=0
  LD DE,($A4F4)           ; E=PEEK $A4F4; D=PEEK $A4F5
  CALL $7A53              ; CALL 7A53
  CALL $7A64              ; CALL 7A64
  JR NZ,$7BF2             ; Jump to 7BF2 if the zero flag is not set
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$7C09             ; Jump to 7C09 if A>0
  LD A,($A4E7)            ; A=PEEK $A4E7
  OR $10                  ; Set bit 4 of A
  LD ($A4E7),A            ; POKE $A4E7,A
  RET                     ; Return

; Routine at 7C0A
;
; Used by the routine at 7C3F.
  LD A,($A4E3)            ; A=PEEK $A4E3
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$7C13              ; Jump to 7C13 if A=0
  LD ($A4F3),A            ; POKE $A4F3,A
  CALL $7BA4              ; CALL 7BA4
  LD A,($A4E5)            ; A=PEEK $A4E5
  INC A                   ; A=A+1
  JR NZ,$7C22             ; Jump to 7C22 if A>0
  LD A,($A4F2)            ; A=PEEK $A4F2
  LD ($A4E5),A            ; POKE $A4E5,A
  LD A,($A4E6)            ; A=PEEK $A4E6
  INC A                   ; A=A+1
  JR NZ,$7C2E             ; Jump to 7C2E if A>0
  LD A,($A4F2)            ; A=PEEK $A4F2
  LD ($A4E6),A            ; POKE $A4E6,A
  RET                     ; Return

; Routine at 7C2F
;
; Used by the routine at 8538.
  LD HL,($A54D)           ; L=PEEK $A54D; H=PEEK $A54E
  LD ($A535),HL           ; POKE $A535,L; POKE $A536,H
  CALL $7C3F              ; CALL 7C3F
  LD HL,$631E             ; HL=$631E
  LD ($8872),HL           ; POKE $8872,L; POKE $8873,H
  RET                     ; Return

; Routine at 7C3F
;
; Used by the routine at 7C2F.
  CALL $72C7              ; CALL 72C7
  LD HL,$778A             ; HL=$778A
  LD ($8872),HL           ; POKE $8872,L; POKE $8873,H
  LD A,$01                ; A=$01
  CALL $6330              ; CALL 6330
  LD A,$80                ; A=$80
  LD ($A541),A            ; POKE $A541,A
  LD A,$01                ; A=$01
  CALL $6330              ; CALL 6330
  CALL $6327              ; CALL 6327
  CALL $7B3F              ; CALL 7B3F
  LD HL,($A527)           ; L=PEEK $A527; H=PEEK $A528
  CALL $7967              ; CALL 7967
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $20                 ; Keep only bit 5 of A
  JR NZ,$7C82             ; Jump to 7C82 if A>0
  CALL $7C0A              ; CALL 7C0A
  LD HL,$96B1             ; HL=$96B1
  CALL $886C              ; CALL 886C
  CALL $7B79              ; CALL 7B79
  JR NZ,$7C5D             ; Jump to 7C5D if the zero flag is not set
  CALL $7B03              ; CALL 7B03
  LD A,($A4E7)            ; A=PEEK $A4E7
  AND $20                 ; Keep only bit 5 of A
  JR Z,$7C5D              ; Jump to 7C5D if A=0
  LD C,$F3                ; C=$F3
  CALL $7538              ; CALL 7538
  CALL $6324              ; CALL 6324
  CALL $6318              ; CALL 6318
  JR $7C42                ; Jump to 7C42

; Data block at 7C8F
  DEFB $21,$DE,$96,$CD,$6C,$88,$C9,$06
  DEFB $00,$3A,$F8,$A4,$4F,$7E,$23,$A7
  DEFB $28,$0B,$CD,$49,$81,$04,$78,$B9
  DEFB $CC,$AC,$7C,$18,$F0,$3A,$F9,$A4
  DEFB $CD,$49,$81,$D0,$3A,$FA,$A4,$CD
  DEFB $49,$81,$D0,$06,$00,$C9,$21,$18
  DEFB $5E,$11,$19,$5E,$01,$FF,$04,$36
  DEFB $20,$ED,$B0,$C9,$21,$11,$97,$CD
  DEFB $96,$7C,$2A,$2D,$A5,$CD,$FD,$7C
  DEFB $7E,$A7,$C8,$23,$11,$18,$5E,$E5
  DEFB $6F,$26,$00,$CD,$71,$8C,$E1,$11
  DEFB $1C,$5E,$4E,$06,$00,$23,$C5,$E5
  DEFB $CD,$4F,$87,$21,$18,$5E,$CD,$96
  DEFB $7C,$E1,$C1,$09,$18,$D7,$F5,$E5
  DEFB $D5,$C5,$CD,$BD,$7C,$C1,$D1,$E1
  DEFB $F1,$C9,$21,$1A,$97,$CD,$96,$7C
  DEFB $21,$22,$97,$CD,$96,$7C,$2A,$23
  DEFB $A5,$7E,$A7,$C8,$CD,$FD,$7C,$23
  DEFB $11,$18,$5E,$4E,$06,$00,$23,$C5
  DEFB $E5,$E5,$6F,$26,$00,$CD,$71,$8C
  DEFB $E1,$7E,$23,$11,$1C,$5E,$E5,$6F
  DEFB $26,$00,$CD,$71,$8C,$E1,$11,$20
  DEFB $5E,$4E,$23,$46,$23,$E5,$60,$69
  DEFB $CD,$71,$8C,$E1,$11,$26,$5E,$CD
  DEFB $4F,$87,$21,$18,$5E,$CD,$96,$7C
  DEFB $E1,$C1,$09,$18,$BC,$7E,$A7,$C8
  DEFB $E5,$CD,$3A,$8F,$21,$00,$5B,$CD
  DEFB $96,$7C,$E1,$23,$23,$23,$18,$ED
  DEFB $21,$3C,$97,$CD,$96,$7C,$21,$4F
  DEFB $A5,$C3,$5C,$7D,$21,$42,$97,$CD
  DEFB $96,$7C,$2A,$1F,$A5,$C3,$5C,$7D
  DEFB $21,$48,$97,$CD,$96,$7C,$2A,$21
  DEFB $A5,$C3,$5C,$7D,$CD,$DC,$7D,$21
  DEFB $50,$97,$CD,$6C,$88,$CD,$24,$63
  DEFB $CD,$18,$63,$CD,$D7,$91,$FE,$FC
  DEFB $C8,$21,$96,$7D,$E5,$E6,$DF,$FE
  DEFB $41,$CA,$87,$7D,$FE,$43,$CA,$31
  DEFB $80,$FE,$48,$CA,$ED,$72,$FE,$4C
  DEFB $CA,$25,$80,$FE,$4D,$CA,$CB,$7C
  DEFB $FE,$4E,$CA,$7B,$7D,$FE,$4F,$CA
  DEFB $09,$7D,$FE,$52,$CA,$B2,$95,$FE
  DEFB $56,$CA,$6F,$7D,$C9,$CD,$8F,$7C

; Message at 7DDF
  DEFM ">P2"

; Data block at 7DE2
  DEFB $F8,$A4,$21,$0D,$0A,$22,$F9,$A4
  DEFB $C9,$7E,$FE,$20,$20,$03,$23,$18
  DEFB $F8,$FE,$28,$20,$08,$DD,$34,$2D
  DEFB $23,$CD,$44,$7E,$C9,$FE,$3A,$30
  DEFB $12,$D5,$CD,$D9,$8B,$2B,$06,$10
  DEFB $4B,$7A,$F6,$80,$D1,$12,$13,$79
  DEFB $12,$13,$C9,$D5,$CD,$DF,$8B,$F5
  DEFB $7E,$E6,$DF,$28,$03,$23,$18,$F8
  DEFB $F1,$D1,$D8,$4F,$06,$00,$E5,$21
  DEFB $A6,$A0,$09,$46,$E1,$78,$E6,$0F
  DEFB $28,$0C,$FE,$01,$28,$02,$37,$C9
  DEFB $C5,$CD,$EB,$7D,$C1,$D8,$79,$12
  DEFB $13,$C9,$CD,$EB,$7D,$D8,$7E,$FE
  DEFB $20,$20,$03,$23,$18,$F8,$A7,$20
  DEFB $07,$DD,$7E,$2D,$A7,$C8,$37,$C9
  DEFB $FE,$29,$20,$07,$23,$DD,$35,$2D
  DEFB $F0,$37,$C9,$78,$E6,$F0,$CA,$44
  DEFB $7E,$D5,$CD,$DF,$8B,$F5,$7E,$E6
  DEFB $DF,$28,$03,$23,$18,$F8,$F1,$D1
  DEFB $D8,$4F,$06,$00,$E5,$21,$A6,$A0
  DEFB $09,$46,$E1,$78,$E6,$0F,$FE,$02
  DEFB $28,$02,$37,$C9,$C5,$CD,$EB,$7D
  DEFB $C1,$D8,$79,$12,$13,$18,$AF,$F5
  DEFB $E5,$ED,$4B,$FB,$A4,$E1,$E5,$A7
  DEFB $ED,$42,$28,$18,$0A,$E6,$80,$03
  DEFB $28,$F3,$E1,$E5,$A7,$ED,$42,$28
  DEFB $03,$03,$18,$E9,$E1,$2B,$C1,$CB
  DEFB $B1,$C5,$F1,$C9,$E1,$2B,$C1,$CB
  DEFB $F1,$18,$F6,$7E,$FE,$20,$C3,$EE
  DEFB $7D,$7E,$A7,$C8,$12,$1B,$2B,$18
  DEFB $F8

; Message at 7ED3
  DEFM "))&"

; Data block at 7ED6
  DEFB $00,$01,$A8,$9F,$09,$3E,$20,$12
  DEFB $1B,$06,$04,$7E,$FE,$2A,$28,$06
  DEFB $FE,$20,$28,$02,$12,$1B,$2B,$10
  DEFB $F2,$C9,$FE,$01,$20,$08,$3E,$20
  DEFB $12,$1B,$3E,$29,$12,$1B,$79,$C3
  DEFB $00,$7F,$E5,$2A,$03,$A5,$77,$23
  DEFB $22,$03,$A5,$E1,$C9,$E5,$2A,$03
  DEFB $A5,$2B,$7E,$22,$03,$A5,$E1,$C9
  DEFB $22,$FB,$A4,$11,$17,$62,$ED,$53
  DEFB $FD,$A4,$01,$FD,$A2,$ED,$43,$03
  DEFB $A5,$7E,$FE,$3F,$28,$0C,$A7,$28
  DEFB $08,$E6,$80,$28,$01,$23,$23,$18
  DEFB $F0,$2B,$E5,$ED,$4B,$FB,$A4,$A7
  DEFB $ED,$42,$E1,$D8,$7E,$CD,$99,$7E
  DEFB $20,$5A,$E5,$4F,$06,$00,$21,$A6
  DEFB $A0,$09,$7E,$E6,$0F,$E1,$20,$58
  DEFB $E5,$69,$26,$00,$CD,$D3,$7E,$E1
  DEFB $E5,$D5,$11,$FD,$A2,$2A,$03,$A5
  DEFB $A7,$ED,$52,$D1,$E1,$20,$06,$ED
  DEFB $53,$FD,$A4,$18,$C5,$CD,$0B,$7F
  DEFB $E5,$4F,$06,$00,$21,$A6,$A0,$09
  DEFB $7E,$E6,$0F,$E1,$FE,$01,$20,$12
  DEFB $3E,$20,$12,$1B,$3E,$28,$12,$1B
  DEFB $E5,$69,$26,$00,$CD,$D3,$7E,$E1
  DEFB $18,$C6,$E5,$69,$26,$00,$CD,$D3
  DEFB $7E,$E1,$18,$CF,$E5,$66,$6F,$CB
  DEFB $BC,$CD,$CA,$95,$E1,$2B,$18,$E8
  DEFB $CD,$F0,$7E,$18,$ED,$18,$D5,$D5
  DEFB $AF,$32,$18,$62,$CD,$16,$7F,$13
  DEFB $EB,$D1,$7E,$12,$A7,$C8,$23,$13
  DEFB $18,$F8,$21,$54,$97,$CD,$6C,$88
  DEFB $E1,$4E,$0C,$ED,$7B,$01,$A5,$21
  DEFB $E6,$A0,$CD,$75,$8A,$7E,$FE,$2A
  DEFB $28,$09,$A7,$28,$0C,$CD,$1E,$63
  DEFB $23,$18,$F2,$21,$5F,$97,$CD,$6C
  DEFB $88,$21,$6A,$97,$CD,$6C,$88,$C3
  DEFB $BE,$82,$2B,$7E,$A7,$28,$04,$FE
  DEFB $3F,$20,$F7,$2B,$CB,$7E,$20,$F2
  DEFB $11,$18,$5E,$23,$23,$CD,$93,$8C
  DEFB $3D,$12,$21,$18,$5E,$CD,$6C,$88
  DEFB $21,$6E,$97,$CD,$6C,$88,$CD,$24
  DEFB $63,$CD,$18,$63,$C3

; Message at 8023
  DEFM "'c!"

; Data block at 8026
  DEFB $81,$97,$CD,$96,$7C,$2A,$2B,$A5
  DEFB $C3,$CD,$72,$21,$99,$97,$CD,$96
  DEFB $7C,$2A,$29,$A5,$5E,$23,$56,$23
  DEFB $7A,$B3,$C8,$E5

; Message at 8042
  DEFM "!Ro"

; Data block at 8045
  DEFB $CD,$A4

; Message at 8047
  DEFM "r!om\""

; Data block at 804C
  DEFB $1A,$5E

; Message at 804E
  DEFM "> 2"

; Data block at 8051
  DEFB $1C,$5E,$EB,$11,$1D,$5E,$CD,$71
  DEFB $8C,$AF,$12,$21,$18,$5E,$CD,$96
  DEFB $7C,$E1,$CD,$CD,$72,$23,$18,$D1
  DEFB $21,$C4,$97,$CD,$6C,$88,$CD,$24
  DEFB $63,$CD,$18,$63,$CD,$27,$63,$E6
  DEFB $DF,$FE,$44,$CA,$AC,$8E,$FE,$52
  DEFB $20,$EC,$21,$F3,$97,$CD,$6C,$88
  DEFB $CD,$8F,$8E,$CD,$E4,$85,$CD,$95
  DEFB $80,$C3,$04,$86,$CD,$E0,$8E,$DD
  DEFB $21,$00,$5B,$AF,$DD,$77,$00,$32
  DEFB $74,$5C,$DD,$36,$0B,$36,$DD,$77
  DEFB $0C,$DD,$36,$0D,$01,$DD,$77,$0E
  DEFB $DD,$36,$0F,$36,$DD,$77,$10,$21
  DEFB $D6,$80,$01,$5A,$07,$CD,$53,$85
  DEFB $11,$C0,$5D,$D5,$DD,$E1,$2A,$33
  DEFB $A5,$A7,$ED

; Message at 80CC
  DEFM "RT]="

; Data block at 80D0
  DEFB $01,$C2,$04,$C3,$53,$85,$00,$0A
  DEFB $0E,$00,$F9,$C0

; Message at 80DC
  DEFM "23778"

; Data block at 80E1
  DEFB $0E,$00,$00,$E2,$5C,$00,$0D,$00
  DEFB $14,$FF,$FF,$EA,$F3,$31,$BF,$5D
  DEFB $21,$E2,$5C,$E5,$ED,$73,$3D,$5C
  DEFB $21,$38,$85,$E5,$11,$40,$A2,$DD
  DEFB $21,$C0,$5D,$3E,$FF,$37,$C3,$56
  DEFB $05,$0D,$54,$22,$1A,$5E,$21,$3A
  DEFB $98,$CD,$2E,$81,$E1,$C3,$85,$8A
  DEFB $21,$43,$98,$CD,$2E,$81,$AF,$32
  DEFB $45,$A5,$37,$E1,$C9,$3E,$08,$CD
  DEFB $1E,$63,$C3,$82,$81,$E5,$3E,$05
  DEFB $CD,$2A,$63,$E1,$F5,$CD,$6C,$88
  DEFB $F1,$CD,$2A,$63,$C9,$22,$35,$A5
  DEFB $7E,$A7,$CA,$78,$90,$C3,$2A,$90
  DEFB $F5,$E5,$3E,$42,$CD,$1B,$63,$E1
  DEFB $28,$03,$F1,$A7,$C9,$F1,$CD,$36
  DEFB $72,$C9

; Routine at 815B
;
; Used by the routines at 817C, 81E1 and 838F.
  PUSH HL                 ; Push HL onto the stack
  LD B,$00                ; B=$00
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$816F              ; Jump to 816F if A=0
  LD A,$01                ; A=$01
  CALL $631E              ; CALL 631E
  LD A,(HL)               ; A=PEEK HL
  CALL $631E              ; CALL 631E
  INC HL                  ; HL=HL+1
  INC B                   ; B=B+1
  JR $815E                ; Jump to 815E
  POP HL                  ; Pop last item from stack into HL
  RET                     ; Return

; Routine at 8171
;
; Used by the routine at 817C.
  LD A,B                  ; A=B
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET Z                   ; Return if A=0
  LD A,$08                ; A=$08
  CALL $631E              ; CALL 631E
  DJNZ $8176              ; Decrement B and jump to 8176 if B>0
  RET                     ; Return

; Routine at 817C
;
; Used by the routines at 81BE and 81E1.
  CALL $815B              ; CALL 815B
  JP $8171                ; Jump to 8171

; Data block at 8182
  DEFB $CD,$5B,$81,$3E,$20,$CD,$1E,$63
  DEFB $04,$C3,$71,$81,$79,$A7,$20,$05
  DEFB $3E,$07,$C3,$1E,$63,$E5,$7E,$2B
  DEFB $77,$23,$23,$A7,$20,$F8,$E1,$2B
  DEFB $0D,$15,$C3,$26,$81,$7E,$A7,$20
  DEFB $05,$3E,$07,$C3,$1E,$63,$E5,$23
  DEFB $7E,$2B,$77,$23,$A7,$20,$F8,$E1
  DEFB $15,$C3,$82,$81

; Routine at 81BE
;
; Used by the routine at 82A4.
  LD B,A                  ; B=A
  LD A,D                  ; A=D
  CP E                    ; Set the zero flag if A=E, or the carry flag if A<E
  JR C,$81C8              ; Jump to 81C8 if A<E
  LD A,$07                ; A=$07
  JP $631E                ; Jump to 631E
  LD A,$01                ; A=$01
  CALL $631E              ; CALL 631E
  LD A,B                  ; A=B
  CALL $631E              ; CALL 631E
  PUSH HL                 ; Push HL onto the stack
  LD A,(HL)               ; A=PEEK HL
  LD (HL),B               ; POKE HL,B
  INC HL                  ; HL=HL+1
  LD B,A                  ; B=A
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$81D2             ; Jump to 81D2 if A>0
  LD (HL),B               ; POKE HL,B
  POP HL                  ; Pop last item from stack into HL
  INC HL                  ; HL=HL+1
  INC C                   ; C=C+1
  INC D                   ; D=D+1
  JP $817C                ; Jump to 817C

; Routine at 81E1
;
; Used by the routine at 828A.
  PUSH HL                 ; Push HL onto the stack
  PUSH DE                 ; Push DE onto the stack
  PUSH BC                 ; Push BC onto the stack
  PUSH HL                 ; Push HL onto the stack
  LD D,$00                ; D=$00
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$81EF              ; Jump to 81EF if A=0
  INC HL                  ; HL=HL+1
  INC D                   ; D=D+1
  JR $81E7                ; Jump to 81E7
  POP HL                  ; Pop last item from stack into HL
  CALL $817C              ; CALL 817C
  CALL $6324              ; CALL 6324
  CALL $6318              ; CALL 6318
  CALL $6327              ; CALL 6327
  PUSH AF                 ; Push AF onto the stack
  PUSH BC                 ; Push BC onto the stack
  PUSH DE                 ; Push DE onto the stack
  PUSH HL                 ; Push HL onto the stack
  PUSH IX                 ; Push IX onto the stack
  LD D,$00                ; D=$00
  LD A,($5C39)            ; A=PEEK $5C39
  LD E,A                  ; E=A
  LD HL,$00FF             ; HL=$00FF
  CALL $03B5              ; CALL 03B5
  POP IX                  ; Pop last item from stack into IX
  POP HL                  ; Pop last item from stack into HL
  POP DE                  ; Pop last item from stack into DE
  POP BC                  ; Pop last item from stack into BC
  POP AF                  ; Pop last item from stack into AF
  CP $FC                  ; Set the zero flag if A=$FC, or the carry flag if
                          ; A<$FC
  JR NZ,$8234             ; Jump to 8234 if A<>$FC
  CALL $815B              ; CALL 815B
  LD A,($5C48)            ; A=PEEK $5C48
  AND $07                 ; Keep only bits 0, 1 and 2 of A
  PUSH AF                 ; Push AF onto the stack
  LD HL,$9884             ; HL=$9884
  CALL $886C              ; CALL 886C
  LD A,$0F                ; A=$0F
  CALL $631E              ; CALL 631E
  POP AF                  ; Pop last item from stack into AF
  CALL $631E              ; CALL 631E
; This entry point is used by the routine at 838F.
  POP BC                  ; Pop last item from stack into BC
  POP DE                  ; Pop last item from stack into DE
  POP HL                  ; Pop last item from stack into HL
  RET                     ; Return
  CP $FD                  ; Set the zero flag if A=$FD, or the carry flag if
                          ; A<$FD
  JR NZ,$8242             ; Jump to 8242 if A<>$FD
  LD A,($5C6A)            ; A=PEEK $5C6A
  XOR $08                 ; Flip bit 3 of A
  LD ($5C6A),A            ; POKE $5C6A,A
  JR $81F3                ; Jump to 81F3
  CP $0D                  ; Set the zero flag if A=$0D, or the carry flag if
                          ; A<$0D
  JR NZ,$8249             ; Jump to 8249 if A<>$0D
  JP $838F                ; Jump to 838F
  CP $7F                  ; Set the zero flag if A=$7F, or the carry flag if
                          ; A<$7F
  JR NZ,$8252             ; Jump to 8252 if A<>$7F
  CALL $818E              ; CALL 818E
  JR $81F3                ; Jump to 81F3
  CP $10                  ; Set the zero flag if A=$10, or the carry flag if
                          ; A<$10
  JR NZ,$825B             ; Jump to 825B if A<>$10
  CALL $81A7              ; CALL 81A7
  JR $8250                ; Jump to 8250
  CP $F2                  ; Set the zero flag if A=$F2, or the carry flag if
                          ; A<$F2
  JR NZ,$8270             ; Jump to 8270 if A<>$F2
  LD A,C                  ; A=C
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$826A             ; Jump to 826A if A>0
  LD A,$07                ; A=$07
  CALL $631E              ; CALL 631E
  JR $8259                ; Jump to 8259
  DEC HL                  ; HL=HL-1
  DEC C                   ; C=C-1
  LD A,$08                ; A=$08
  JR $8265                ; Jump to 8265
  CP $F3                  ; Set the zero flag if A=$F3, or the carry flag if
                          ; A<$F3
  JR NZ,$8285             ; Jump to 8285 if A<>$F3
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$827F             ; Jump to 827F if A>0
  LD A,$07                ; A=$07
  CALL $631E              ; CALL 631E
  JR $8268                ; Jump to 8268
  INC HL                  ; HL=HL+1
  INC C                   ; C=C+1
  LD A,$09                ; A=$09
  JR $827A                ; Jump to 827A
  CALL $82A4              ; CALL 82A4
  JR $827D                ; Jump to 827D

; Routine at 828A
;
; Used by the routine at 829B.
  LD C,$00                ; C=$00
  JP $81E1                ; Jump to 81E1

; Data block at 828F
  DEFB $1E,$03,$18,$0A,$1E,$04,$18,$06
  DEFB $1E,$1C,$18,$02

; Routine at 829B
;
; Used by the routine at 85DC.
  LD E,$FF                ; E=$FF
  JP $828A                ; Jump to 828A

; Data block at 82A0
  DEFB $1E,$0A,$18,$F9

; Routine at 82A4
;
; Used by the routine at 81E1.
  CP $FC                  ; Set the zero flag if A=$FC, or the carry flag if
                          ; A<$FC
  RET Z                   ; Return if A=$FC
  CP $80                  ; Set the zero flag if A=$80, or the carry flag if
                          ; A<$80
  RET NC                  ; Return if A>=$80
  CP $20                  ; Set the zero flag if A=$20, or the carry flag if
                          ; A<$20
  RET C                   ; Return if A<$20
  JP $81BE                ; Jump to 81BE

; Routine at 82B0
;
; Used by the routine at 7967.
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JP NZ,$797B             ; Jump to 797B if A>0
  PUSH HL                 ; Push HL onto the stack
  LD HL,$0000             ; HL=$0000
  LD ($A4E8),HL           ; POKE $A4E8,L; POKE $A4E9,H
  POP HL                  ; Pop last item from stack into HL
  RET                     ; Return

; Data block at 82BE
  DEFB $2A,$E8,$A4,$7C,$B5,$C2,$F8,$7F
  DEFB $C3,$16,$80,$C5,$E5,$CD,$0E,$74
  DEFB $7E,$A3,$3E,$99,$28,$01,$3C,$CD
  DEFB $1E,$63,$E1,$C1,$C9,$C5,$E5,$01
  DEFB $03,$A4,$09,$6E,$26,$00,$11,$00
  DEFB $5B,$CD,$71,$8C,$3E,$20,$12,$13
  DEFB $12,$13,$12,$13,$12,$3E,$FF,$32
  DEFB $04,$5B,$21,$00,$5B,$CD,$6C,$88
  DEFB $E1,$C1,$C9,$C5,$E5,$18,$DF,$21
  DEFB $8C,$98,$CD,$6C,$88,$21,$00,$00
  DEFB $06,$14,$CD,$01,$83,$CD,$C9,$82
  DEFB $23,$7C,$A7,$C0,$10,$F7,$E5,$21
  DEFB $B1,$96,$CD,$6C,$88,$E1,$18,$E8
  DEFB $21,$AB,$98,$CD,$6C,$88,$21,$00
  DEFB $00,$06,$07,$CD,$01,$83,$CD,$DB
  DEFB $82,$23,$CB,$7D,$C0,$10,$F7,$E5
  DEFB $21,$B1,$96,$CD,$6C,$88,$E1,$18
  DEFB $E8,$21,$CF,$98,$CD,$6C,$88,$CD
  DEFB $24,$63,$CD,$18,$63,$CD,$27,$63
  DEFB $FE,$FC,$20,$04,$CD,$C8,$7F,$07
  DEFB $CD,$16,$86,$21,$FD,$98,$CD,$D5
  DEFB $95,$CD,$24,$63,$CD,$18,$63,$CD

; Message at 836E
  DEFM "'c>"

; Data block at 8371
  DEFB $01,$CD,$30,$63,$C3,$60,$76

; Routine at 8378
  CALL $738D              ; CALL 738D
  JP $749C                ; Jump to 749C

; Data block at 837E
  DEFB $2A,$81,$A4,$C3,$15,$73,$3A,$E6
  DEFB $A4,$2A,$81,$A4,$23,$22,$81,$A4
  DEFB $C9

; Routine at 838F
;
; Used by the routine at 81E1.
  CALL $815B              ; CALL 815B
  SCF                     ; Set the carry flag
  JP $8230                ; Jump to 8230

; Data block at 8396
  DEFB $CD,$3A,$8C,$3E,$01,$CD

; Message at 839C
  DEFM "*c!"

; Data block at 839F
  DEFB $13,$99,$CD,$6C,$88,$AF,$C3

; Message at 83A6
  DEFM "*c!"

; Data block at 83A9
  DEFB $16,$99,$CD,$6C,$88,$2A,$11,$A5
  DEFB $C9,$AF,$CD,$2A,$63,$CD,$18,$63
  DEFB $2A,$11,$A5,$C9,$01,$E5,$FF,$09
  DEFB $1B,$1B,$1B,$1B,$1B,$1B,$1B,$C9
  DEFB $3E,$01,$CD

; Message at 83CC
  DEFM "*c*"

; Data block at 83CF
  DEFB $13,$A5,$01,$F7,$FF,$09,$CB,$7C
  DEFB $28,$10,$CD,$EE,$95,$21,$16,$99
  DEFB $CD,$6C,$88,$AF,$CD,$2A,$63,$C3
  DEFB $9F,$8F,$2A,$11,$A5,$01,$E5,$FF
  DEFB $09,$CD,$3A,$8F,$36,$FF,$CD,$EE
  DEFB $95,$21,$16,$99,$CD,$6C,$88,$21
  DEFB $00,$5B,$CD,$6C,$88,$18,$DC,$3E
  DEFB $01,$CD,$2A,$63,$CD,$DF,$95,$21
  DEFB $1A,$99,$CD,$6C,$88,$06,$08,$2A
  DEFB $11,$A5,$23,$23,$23,$7E,$A7,$28
  DEFB $0A,$10,$F7,$CD,$3A,$8F,$36,$FF
  DEFB $C3,$FE,$83,$3E,$20,$CD,$1E,$63
  DEFB $C3,$E2,$83,$21,$FD,$A1,$CD,$6C
  DEFB $88,$CD

; Message at 8439
  DEFM "$c!"

; Data block at 843C
  DEFB $23,$7B,$CD,$27,$8A,$CD,$27,$63
  DEFB $C3,$77,$94,$2A,$1D,$A5,$ED,$4B
  DEFB $33,$A5,$A7,$ED,$42,$7C,$FE,$08
  DEFB $D0

; Message at 8455
  DEFM "DM!F"

; Data block at 8459
  DEFB $99,$CD,$6C,$88,$78,$FE,$02,$30
  DEFB $08,$21,$54,$99,$CD,$6C,$88,$18
  DEFB $0B,$78,$FE,$04,$30,$06,$21,$5B
  DEFB $99,$CD,$6C,$88,$21,$60,$99,$CD
  DEFB $6C,$88,$60,$69,$CD,$92,$88,$21
  DEFB $84,$99,$CD,$6C,$88,$CD,$24,$63
  DEFB $CD,$18,$63,$CD

; Message at 848D
  DEFM "'c!"

; Data block at 8490
  DEFB $9D,$99,$CD,$6C,$88,$C9,$C5,$2A
  DEFB $33,$A5,$ED,$4B,$37,$A5,$A7,$ED
  DEFB $42,$C1,$09,$38,$07,$C5,$2A,$35
  DEFB $A5,$C3,$DC,$8A,$21,$A6,$99,$CD
  DEFB $6C,$88,$CD,$24,$63,$CD,$18,$63
  DEFB $C3,$27,$63,$D5,$E5,$11,$FA,$FF
  DEFB $EB,$A7,$ED,$52,$38,$06,$E1,$D1
  DEFB $1A,$77,$23,$C9,$21,$FE,$99,$CD
  DEFB $6C,$88,$3E,$FF,$E1,$D1,$C9,$78
  DEFB $B1,$C8,$C3,$59,$8A,$FE,$02,$28
  DEFB $04,$F1,$C3,$9A,$94,$21,$45,$9F
  DEFB $CD,$6C,$88,$21,$C8,$00,$C3,$27
  DEFB $8A,$11,$18,$5E,$CD,$FD,$7C,$2A
  DEFB $E3,$A4,$23,$22,$E3,$A4,$CD,$71
  DEFB $8C,$11,$1D,$5E,$C9,$D1,$E1,$2A
  DEFB $3D,$A5,$ED,$5B,$3B,$A5,$C3,$09
  DEFB $72,$CD,$3C,$63,$C3,$18,$90,$CD
  DEFB $D9,$8B,$D8,$2B,$7E,$FE,$20,$20
  DEFB $03,$23,$18,$F8,$A7,$C9,$21,$4F
  DEFB $85,$22,$3D,$5C,$31,$BF,$5D,$21
  DEFB $FF,$FF,$22,$1D,$A5,$C3,$32,$84

; Routine at 8538
  LD HL,$8551             ; HL=$8551
  LD ($5C3D),HL           ; POKE $5C3D,L; POKE $5C3E,H
  LD SP,$5DBF             ; SP=$5DBF
  LD A,$18                ; A=$18
  LD ($8216),A            ; POKE $8216,A
  LD HL,$FFFF             ; HL=$FFFF
  LD ($A51D),HL           ; POKE $A51D,L; POKE $A51E,H
  JP $7C2F                ; Jump to 7C2F

; Data block at 854F
  DEFB $26,$85,$38,$85,$D9,$2A,$3D,$5C
  DEFB $E5,$ED,$73,$B0,$5C,$21,$71,$85
  DEFB $E5,$ED,$73,$3D,$5C,$D9,$CD,$7C
  DEFB $85,$ED,$7B,$B0,$5C,$E1,$22,$3D
  DEFB $5C,$C9,$21,$1F,$9F,$CD,$6C,$88
  DEFB $CD,$18,$63,$18,$EC,$C5,$C9,$AF
  DEFB $32,$E3,$A4,$EB,$CD,$15,$7A,$EB
  DEFB $3A,$E3,$A4,$5F,$16,$00,$7E,$E6
  DEFB $DF,$CA,$1C,$85,$23,$18,$F7,$F5
  DEFB $C5

; Message at 8598
  DEFM "M!O"

; Data block at 859B
  DEFB $A5,$7E,$A7,$28,$13,$B9,$28,$05
  DEFB $23,$23,$23,$18,$F4,$23,$CD,$4F
  DEFB $87,$1B,$3E,$20,$12,$C1,$F1,$C9
  DEFB $3E,$2A,$12,$13,$18,$F4,$21,$1E
  DEFB $5E,$22,$43,$A5,$21,$00,$5B,$AF
  DEFB $32,$1E,$5E,$C9,$E5,$2A,$43,$A5
  DEFB $77,$23,$22,$43,$A5,$E1,$C9,$E5
  DEFB $2A,$43,$A5,$73,$23,$72,$23,$18
  DEFB $F1

; Routine at 85DC
;
; Used by the routine at 7BA4.
  CALL $829B              ; CALL 829B
  RET C                   ; Return if the carry flag is set
  JP $8347                ; Jump to 8347

; Data block at 85E3
  DEFB $07,$21,$9B,$82,$22,$FF,$A4,$21
  DEFB $77,$94,$11,$11,$5B,$01,$EF,$00
  DEFB $ED,$B0,$21,$77,$94,$11,$78,$94
  DEFB $01,$EE,$00,$ED,$B0,$21,$00,$5B
  DEFB $C9,$21,$11,$5B,$11,$77,$94,$01
  DEFB $EF,$00,$ED,$B0,$21,$DC,$85,$22
  DEFB $FF,$A4,$C9,$21,$1E

; Message at 8618
  DEFM "c\"r"

; Data block at 861B
  DEFB $88,$CD,$05,$83,$CD,$2A,$86,$CD
  DEFB $26,$83,$CD,$2A,$86,$18,$F2,$21
  DEFB $FB,$9E,$CD,$6C,$88,$CD,$18,$63
  DEFB $FE,$FC,$C0,$21,$8A

; Message at 8638
  DEFM "w\"r"

; Data block at 863B
  DEFB $88,$F1,$C9,$2A,$0B,$A5,$7C,$FE
  DEFB $27,$D8,$7D,$FE,$0F,$D8,$2B,$C9

; Routine at 864B
;
; Used by the routines at 778A, 79E3 and 7A64.
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  RET Z                   ; Return if A=0
  CP $20                  ; Set the zero flag if A=$20, or the carry flag if
                          ; A<$20
  RET Z                   ; Return if A=$20
  CP $2E                  ; Set the zero flag if A=$2E, or the carry flag if
                          ; A<$2E
  RET Z                   ; Return if A=$2E
  CP $2C                  ; Set the zero flag if A=$2C, or the carry flag if
                          ; A<$2C
  RET Z                   ; Return if A=$2C
  CP $2D                  ; Set the zero flag if A=$2D, or the carry flag if
                          ; A<$2D
  RET Z                   ; Return if A=$2D
  CP $21                  ; Set the zero flag if A=$21, or the carry flag if
                          ; A<$21
  RET Z                   ; Return if A=$21
  CP $3F                  ; Set the zero flag if A=$3F, or the carry flag if
                          ; A<$3F
  RET Z                   ; Return if A=$3F
  CP $3A                  ; Set the zero flag if A=$3A, or the carry flag if
                          ; A<$3A
  RET                     ; Return

; Data block at 8662
  DEFB $0E,$00,$A7,$C8,$0C,$FE,$20,$C8
  DEFB $0C,$FE,$2E,$C8,$0C,$FE,$2C,$C8
  DEFB $0C,$FE,$2D,$C8,$0C,$FE,$21,$C8
  DEFB $0C,$FE,$3F,$C8,$0C,$C9,$06,$00
  DEFB $E5,$7E,$CD,$4B,$86,$28,$25,$E6
  DEFB $60,$FE,$60,$20,$04,$06,$40,$18
  DEFB $1B,$7E,$E6,$60,$FE,$40,$28,$03
  DEFB $23,$18,$E6,$06,$80,$23,$7E,$CD
  DEFB $4B,$86,$28,$08,$E6,$60,$FE,$60
  DEFB $20,$F3,$06,$00,$E1,$E5,$7E,$CD
  DEFB $4B,$86,$28,$0B,$E6,$60,$FE,$60
  DEFB $20,$02,$CB,$AE,$23,$18,$EF,$7E
  DEFB $A7,$CD,$62,$86,$79,$07,$07,$07
  DEFB $B0,$47,$2B,$CB,$FE,$23,$E1,$C9
  DEFB $E5,$CD,$80,$86

; Message at 86D6
  DEFM "x29"

; Data block at 86D9
  DEFB $A5,$2A,$31,$A5,$D1,$01,$00,$00
  DEFB $C5,$D5,$7E,$23,$A7,$28,$20,$E5
  DEFB $4F,$1A,$BE,$20,$08,$E6,$80,$20
  DEFB $0D,$23,$13,$18,$F4,$E1,$D1,$06
  DEFB $00,$09,$C1,$03,$18,$E2,$E1,$C1
  DEFB $C1,$3A,$39,$A5,$B0,$47,$C9,$D1
  DEFB $C1,$2B,$DD,$E5,$E5,$DD,$E1,$23
  DEFB $CD,$BB,$84,$13,$DD,$34,$00,$E6
  DEFB $80,$28,$F5,$DD,$E1,$36,$00,$22
  DEFB $33,$A5,$1B,$18,$DC,$D5,$7E,$CD
  DEFB $4B,$86,$28,$07,$CD,$D2,$86,$EB
  DEFB $D1,$23,$C9,$01,$00,$C0,$D1,$CD
  DEFB $62,$86,$79,$07,$07,$07,$B0,$47
  DEFB $FE,$C0,$C8,$0E,$01,$7E,$23,$BE
  DEFB $2B,$C0,$03,$23,$18,$F7

; Routine at 874F
;
; Used by the routines at 7508 and 752C.
  PUSH BC                 ; Push BC onto the stack
  LD C,(HL)               ; C=PEEK HL
  INC HL                  ; HL=HL+1
  LD A,(HL)               ; A=PEEK HL
  INC HL                  ; HL=HL+1
  LD B,A                  ; B=A
  AND $C0                 ; Keep only bits 6 and 7 of A
  CP $C0                  ; Set the zero flag if A=$C0, or the carry flag if
                          ; A<$C0
  JP Z,$87B5              ; Jump to 87B5 if A=$C0
  PUSH HL                 ; Push HL onto the stack
  PUSH DE                 ; Push DE onto the stack
  PUSH BC                 ; Push BC onto the stack
  LD A,B                  ; A=B
  AND $07                 ; Keep only bits 0, 1 and 2 of A
  LD B,A                  ; B=A
  LD HL,($A531)           ; L=PEEK $A531; H=PEEK $A532
  LD A,B                  ; A=B
  OR C                    ; A=A|C
  JR Z,$8772              ; Jump to 8772 if A=0
  LD E,(HL)               ; E=PEEK HL
  LD D,$00                ; D=$00
  INC HL                  ; HL=HL+1
  DEC BC                  ; BC=BC-1
  ADD HL,DE               ; HL=HL+DE
  JR $8766                ; Jump to 8766
  INC HL                  ; HL=HL+1
  POP BC                  ; Pop last item from stack into BC
  POP DE                  ; Pop last item from stack into DE
  LD A,B                  ; A=B
  AND $C0                 ; Keep only bits 6 and 7 of A
  CP $40                  ; Set the zero flag if A=$40, or the carry flag if
                          ; A<$40
  JR NZ,$8788             ; Jump to 8788 if A<>$40
  LD A,(HL)               ; A=PEEK HL
  AND $40                 ; Keep only bit 6 of A
  CP $40                  ; Set the zero flag if A=$40, or the carry flag if
                          ; A<$40
  LD A,(HL)               ; A=PEEK HL
  JR NZ,$8792             ; Jump to 8792 if the zero flag is not set
  OR $20                  ; Set bit 5 of A
  JR $8792                ; Jump to 8792
  CP $80                  ; Set the zero flag if A=$80, or the carry flag if
                          ; A<$80
  JR NZ,$878F             ; Jump to 878F if A<>$80
  LD A,(HL)               ; A=PEEK HL
  JR $8792                ; Jump to 8792
  LD A,(HL)               ; A=PEEK HL
  SET 6,B                 ; Set bit 6 of B
  AND $7F                 ; Reset bit 7 of A
  LD (DE),A               ; POKE DE,A
  LD A,(HL)               ; A=PEEK HL
  INC HL                  ; HL=HL+1
  INC DE                  ; DE=DE+1
  AND $80                 ; Keep only bit 7 of A
  JR Z,$8775              ; Jump to 8775 if A=0
  LD A,B                  ; A=B
  AND $38                 ; Keep only bits 3, 4 and 5 of A
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  PUSH HL                 ; Push HL onto the stack
  LD HL,$A1E5             ; HL=$A1E5
  LD C,A                  ; C=A
  LD B,$00                ; B=$00
  ADD HL,BC               ; HL=HL+BC
  LD A,(HL)               ; A=PEEK HL
  POP HL                  ; Pop last item from stack into HL
  LD (DE),A               ; POKE DE,A
  INC DE                  ; DE=DE+1
  POP HL                  ; Pop last item from stack into HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JP NZ,$8750             ; Jump to 8750 if A>0
  POP BC                  ; Pop last item from stack into BC
  RET                     ; Return
  LD A,B                  ; A=B
  AND $38                 ; Keep only bits 3, 4 and 5 of A
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  RRCA                    ; Rotate A right circular (copying bit 0 into bit 7
                          ; and into the carry flag)
  PUSH BC                 ; Push BC onto the stack
  PUSH HL                 ; Push HL onto the stack
  LD HL,$A1E5             ; HL=$A1E5
  LD C,A                  ; C=A
  LD B,$00                ; B=$00
  ADD HL,BC               ; HL=HL+BC
  LD A,(HL)               ; A=PEEK HL
  POP HL                  ; Pop last item from stack into HL
  POP BC                  ; Pop last item from stack into BC
  LD B,C                  ; B=C
  LD (DE),A               ; POKE DE,A
  INC DE                  ; DE=DE+1
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR Z,$87B3              ; Jump to 87B3 if A=0
  DJNZ $87C8              ; Decrement B and jump to 87C8 if B>0
  JP $8750                ; Jump to 8750

; Data block at 87D2
  DEFB $C5,$D5,$E5,$C5,$E1,$ED,$4B,$37
  DEFB $A5,$A7,$ED

; Message at 87DD
  DEFM "B(>8 "

; Data block at 87E2
  DEFB $ED,$5B,$33,$A5,$19,$EB,$E1,$E5
  DEFB $ED,$4B,$37,$A5,$09,$D5,$EB,$2A
  DEFB $33,$A5,$A7,$ED,$52,$D1,$44,$4D
  DEFB $03,$2A,$33,$A5,$ED,$B8,$18,$1C
  DEFB $D1,$D5,$EB,$19,$ED,$4B,$37,$A5
  DEFB $09,$E5,$A7,$ED,$52,$E5,$EB,$2A
  DEFB $33,$A5,$A7,$ED,$52,$23,$44,$4D
  DEFB $E1,$D1,$ED,$B0,$E1,$D1,$C1,$78
  DEFB $B1,$C8,$EB,$ED,$B0,$EB,$C9,$DD
  DEFB $E5,$C5,$06,$0B,$C5,$DD,$46,$15
  DEFB $DD,$4E,$14,$E5,$A7,$ED,$42,$E1
  DEFB $30,$1A,$E5,$C5,$E1,$C1,$19,$E5
  DEFB $C5,$E1,$C1,$DD,$70,$15,$DD,$71
  DEFB $14,$C1,$DD,$2B,$DD,$2B,$10,$DC
  DEFB $C1,$DD,$E1,$C9,$C1,$18,$F9,$21
  DEFB $00,$00,$D5,$C5,$16,$00,$06,$08
  DEFB $29,$07,$30,$01,$19,$10,$F9,$C1
  DEFB $D1,$C9

; Routine at 886C
;
; Used by the routines at 7508, 752C, 754F, 7649, 7C3F and 81E1.
  LD A,(HL)               ; A=PEEK HL
  INC HL                  ; HL=HL+1
  CP $FF                  ; Set the zero flag if A=$FF, or the carry flag if
                          ; A<$FF
  RET Z                   ; Return if A=$FF
  CALL $631E              ; CALL 631E
  JR $886C                ; Jump to 886C

; Data block at 8876
  DEFB $3E,$30,$A7,$ED,$42,$38,$03,$3C
  DEFB $18,$F8,$09,$FE,$30,$28,$06,$32
  DEFB $3A,$A5,$C3,$1E,$63,$DD,$CB,$1B
  DEFB $66,$20,$F7,$C9,$AF,$32,$3A,$A5
  DEFB $01,$10,$27,$CD,$76,$88,$01,$E8
  DEFB $03,$CD,$76,$88,$01,$64,$00,$CD
  DEFB $76,$88,$01,$0A,$00,$CD,$76,$88
  DEFB $7D,$C6,$30,$C3,$1E,$63,$C5,$EB
  DEFB $1A,$13,$A7,$28,$1B,$FE,$20,$28
  DEFB $17,$FE,$30,$38,$13,$FE,$3A,$30
  DEFB $0E,$E6,$0F

; Message at 88C9
  DEFM "DM))"

; Data block at 88CD
  DEFB $09,$29,$4F,$06,$00,$09,$18,$E1
  DEFB $37,$EB,$C1,$C9,$DD,$E5,$E5,$D5
  DEFB $DD,$21,$ED,$A1,$06,$00,$DD,$09
  DEFB $DD,$5E,$00,$3A,$3F,$A5,$CD,$59
  DEFB $88,$44,$DD,$5E,$08,$3A,$40,$A5
  DEFB $CD,$59,$88,$4C,$D1,$E1,$DD,$E1
  DEFB $C9,$E5,$D5,$ED,$4B,$3D,$A5,$A7
  DEFB $ED,$42,$30,$09,$09,$E5,$2A,$3D
  DEFB $A5,$C1,$A7,$ED,$42,$7D,$32,$40
  DEFB $A5,$2A,$3B,$A5,$A7,$ED,$52,$30
  DEFB $09,$D5,$ED,$5B,$3B,$A5,$E1,$A7
  DEFB $ED,$52,$7D,$32,$3F,$A5,$16,$00
  DEFB $3A,$3F,$A5,$5F,$2A,$3B,$A5,$19
  DEFB $EB,$2A,$3D,$A5,$CD,$09,$72,$0E
  DEFB $00,$C5,$CD,$D9,$88,$2A,$3D,$A5
  DEFB $C5,$06,$00,$09,$C1,$EB,$48,$06
  DEFB $00,$2A,$3B,$A5,$09,$EB,$CD,$02
  DEFB $72,$C1,$0C,$79,$FE,$08,$20,$E1
  DEFB $16,$00,$3A,$3F,$A5,$5F,$2A,$3B
  DEFB $A5,$19,$EB,$2A,$3D,$A5,$CD,$09
  DEFB $72,$0E,$00,$C5,$CD,$D9,$88,$2A
  DEFB $3D,$A5,$C5,$06,$00,$A7,$ED,$42
  DEFB $C1,$EB,$48,$06,$00,$2A,$3B,$A5
  DEFB $09,$EB,$CD,$02,$72,$C1,$0C,$79
  DEFB $FE,$08,$20,$DF,$16,$00,$3A,$3F
  DEFB $A5,$5F,$2A,$3B,$A5,$A7,$ED,$52
  DEFB $EB,$2A,$3D,$A5,$CD,$09,$72,$0E
  DEFB $00,$C5,$CD,$D9,$88,$2A,$3D,$A5
  DEFB $C5,$06,$00,$A7,$ED,$42,$C1,$EB
  DEFB $48,$06,$00,$2A,$3B,$A5,$A7,$ED
  DEFB $42,$EB,$CD,$02,$72,$C1,$0C,$79
  DEFB $FE,$08,$20,$DD,$16,$00,$3A,$3F
  DEFB $A5,$5F,$2A,$3B,$A5,$A7,$ED,$52
  DEFB $EB,$2A,$3D,$A5,$CD,$09,$72,$0E
  DEFB $00,$C5,$CD,$D9,$88,$2A,$3D,$A5
  DEFB $C5,$06,$00,$09,$C1,$EB,$48,$06
  DEFB $00,$2A,$3B,$A5,$A7,$ED,$42,$EB
  DEFB $CD,$02,$72,$C1,$0C,$79,$FE,$08
  DEFB $20,$DF,$C3,$05,$85,$B9,$84,$21
  DEFB $00,$5B,$36,$00,$CD,$93,$82,$D0
  DEFB $21,$00,$5B,$CD,$D9,$8B,$EB,$3F
  DEFB $30,$04,$7C,$B5,$37,$C0,$21,$69
  DEFB $98,$CD,$6C,$88,$C3,$04,$8A

; Routine at 8A24
  CALL $72F9              ; CALL 72F9
  CALL $8A32              ; CALL 8A32
  JR NZ,$8A27             ; Jump to 8A27 if the zero flag is not set
  CALL $8A32              ; CALL 8A32
  JR Z,$8A2C              ; Jump to 8A2C if the zero flag is set
  RET                     ; Return

; Routine at 8A32
;
; Used by the routine at 8A24.
  LD A,H                  ; A=H
  OR L                    ; A=A|L
  JR Z,$8A3D              ; Jump to 8A3D if A=0
  HALT                    ; Wait for the next interrupt
  DEC HL                  ; HL=HL-1
  LD A,($5C04)            ; A=PEEK $5C04
  INC A                   ; A=A+1
  RET                     ; Return
  POP HL                  ; Pop last item from stack into HL
  RET                     ; Return

; Routine at 8A3F
;
; Used by the routines at 75B6, 7B79 and 8A59.
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  INC HL                  ; HL=HL+1
  LD A,D                  ; A=D
  OR E                    ; A=A|E
  JR NZ,$8A49             ; Jump to 8A49 if A>0
  SCF                     ; Set the carry flag
  RET                     ; Return
  LD A,E                  ; A=E
  CP C                    ; Set the zero flag if A=C, or the carry flag if A<C
  JR NZ,$8A4F             ; Jump to 8A4F if A<>C
  LD A,D                  ; A=D
  CP B                    ; Set the zero flag if A=B, or the carry flag if A<B
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  LD D,(HL)               ; D=PEEK HL
  INC HL                  ; HL=HL+1
  NOP                     ; Do nothing
  NOP                     ; Do nothing
  RET Z                   ; Return if the zero flag is set
  ADD HL,DE               ; HL=HL+DE
  JR $8A3F                ; Jump to 8A3F

; Routine at 8A59
;
; Used by the routine at 75B6.
  LD A,$2B                ; A=$2B
  LD ($8A52),A            ; POKE $8A52,A
  LD ($8A53),A            ; POKE $8A53,A
  LD ($8A54),A            ; POKE $8A54,A
  CALL $8A3F              ; CALL 8A3F
  LD A,$23                ; A=$23
  LD ($8A52),A            ; POKE $8A52,A
  LD A,$00                ; A=$00
  LD ($8A53),A            ; POKE $8A53,A
  LD ($8A54),A            ; POKE $8A54,A
  RET                     ; Return

; Routine at 8A75
;
; Used by the routines at 7508, 752C and 76F6.
  LD D,$00                ; D=$00
  LD A,(HL)               ; A=PEEK HL
  AND A                   ; Clear the carry flag and set the zero flag if A=0
  JR NZ,$8A7D             ; Jump to 8A7D if A>0
  SCF                     ; Set the carry flag
  RET                     ; Return
  INC HL                  ; HL=HL+1
  LD E,(HL)               ; E=PEEK HL
  INC HL                  ; HL=HL+1
  CP C                    ; Set the zero flag if A=C, or the carry flag if A<C
  RET Z                   ; Return if A=C
  ADD HL,DE               ; HL=HL+DE
  JR $8A77                ; Jump to 8A77

; Data block at 8A85
  DEFB $78,$B1,$C8,$AF,$32,$45,$A5,$78
  DEFB $E6,$80,$20,$1A,$E5,$D5,$21,$18
  DEFB $62,$E5,$09,$EB,$21,$19,$62,$ED
  DEFB $4B,$06,$A5,$A7,$ED

; Message at 8AA2
  DEFM "BDM"

; Data block at 8AA5
  DEFB $E1,$ED,$B8,$D1,$E1,$C9,$E5,$D5
  DEFB $2A,$06,$A5,$E5,$A7,$ED,$42,$EB
  DEFB $21,$18,$62,$ED,$4B,$06,$A5,$A7
  DEFB $ED

; Message at 8ABE
  DEFM "BDM"

; Data block at 8AC1
  DEFB $E1,$EB,$ED,$B0,$D1,$E1,$C9,$5E
  DEFB $23,$EB,$26,$00,$29,$EB,$C9,$7B
  DEFB $32,$1A,$5E,$ED,$4B,$19,$5E,$C9
  DEFB $C3,$96,$84,$11,$18,$5E,$CD,$D2
  DEFB $87,$E1,$ED,$4B,$37,$A5,$A7,$ED
  DEFB $42,$EB,$2A,$35,$A5,$CD,$29,$88
  DEFB $C3,$47,$84,$D5,$CD,$26,$87,$D1
  DEFB $79,$12,$13,$78,$12,$13,$E6,$38
  DEFB $C8,$23,$18,$EF,$3E,$01,$CD

; Message at 8B08
  DEFM "0c!5"

; Data block at 8B0C
  DEFB $9A,$CD,$6C,$88,$21,$00,$5B,$36
  DEFB $00,$CD,$93,$82,$D0,$3A,$00,$5B
  DEFB $A7,$20,$09,$2A,$0B,$A5,$23,$CD
  DEFB $B3,$8C,$18,$19,$21,$00,$5B,$CD
  DEFB $D9,$8B,$7A,$A7,$20,$03,$B3,$20
  DEFB $08,$21,$52,$9A,$CD,$6C,$88,$18
  DEFB $D3,$ED,$53,$0B,$A5,$ED,$4B,$0B
  DEFB $A5,$2A,$2D,$A5,$CD,$75,$8A,$30
  DEFB $1B,$22,$35,$A5,$21,$00,$00,$22
  DEFB $37,$A5,$3A,$0B,$A5,$21,$18,$5E
  DEFB $77,$23,$AF,$77,$23,$77,$23,$36
  DEFB $C0,$2B,$18,$15,$2B,$2B,$13,$13
  DEFB $22,$35,$A5,$ED,$53,$37,$A5,$42
  DEFB $4B,$11,$18,$5E,$ED,$B0,$21,$1A
  DEFB $5E,$11,$00,$5B,$CD,$4F,$87,$21
  DEFB $71,$9A,$CD,$6C,$88,$2A,$0B,$A5
  DEFB $CD,$92,$88,$21,$82,$9A,$CD,$6C
  DEFB $88,$21,$00,$5B,$CD,$9B,$82,$D2
  DEFB $0A,$8B,$21,$00,$5B,$11,$1A,$5E
  DEFB $CD,$F4,$8A,$01,$02,$00,$21,$1B
  DEFB $5E,$7E,$E6,$38,$28,$06,$23,$23
  DEFB $03,$03,$18,$F5,$78,$A7,$28,$08
  DEFB $21,$8C,$9A,$CD,$6C,$88,$18,$D1
  DEFB $79,$32,$19,$5E,$03,$03,$3A,$1B
  DEFB $5E,$FE,$C0,$20,$02,$0E,$00,$CD
  DEFB $D9,$8A,$C3,$0A,$8B,$11,$00,$00
  DEFB $C3,$B4,$88,$C5,$D5,$11,$A5,$9F
  DEFB $E5,$01,$00,$04,$1A,$FE,$2A,$28
  DEFB $18,$FE,$20,$20,$05,$7E,$A7,$28
  DEFB $10,$1A,$C5,$7E,$FE,$61,$38,$02
  DEFB $E6,$DF,$47,$1A,$B8,$C1,$28,$01
  DEFB $0C,$13,$23,$10,$DF,$79,$A7,$28
  DEFB $0A,$E1,$1A,$FE,$FF,$20,$D1,$37
  DEFB $D1,$C1,$C9,$E1,$1B,$D5,$E5,$EB
  DEFB $11,$A5,$9F,$A7,$ED,$52,$7D,$E1
  DEFB $D1,$E6,$FC,$0F,$0F,$A7,$D1,$C1
  DEFB $C9,$7E,$A7,$20,$02,$12,$C9,$DD
  DEFB $36,$2D,$00,$C3,$44,$7E,$22,$11
  DEFB $A5,$22,$0F,$A5,$C9,$11,$18,$60
  DEFB $21,$19,$5E,$D5,$CD,$4F,$87,$D1
  DEFB $2A,$0F,$A5,$01,$00,$00,$C3,$2E
  DEFB $95,$3E,$30,$A7,$ED,$42,$38,$03
  DEFB $3C,$18,$F8,$09,$FE,$30,$28,$06
  DEFB $32,$3A,$A5,$12,$13,$C9,$DD,$CB
  DEFB $1B,$66,$20,$F7,$C9,$AF,$32,$3A
  DEFB $A5,$01,$10,$27,$CD,$55,$8C,$01
  DEFB $E8,$03,$CD,$55,$8C,$01,$64,$00
  DEFB $CD,$55,$8C,$01,$0A,$00,$CD,$55
  DEFB $8C,$7D,$C6,$30,$12,$13,$C9,$7E
  DEFB $A7,$C2,$B5,$7F,$12,$C9,$02,$E5
  DEFB $D5,$11,$17,$5F,$23,$CD,$4F,$87
  DEFB $4B,$D1,$D5,$21,$17,$5F,$1A,$BE
  DEFB $23,$13,$28,$FA,$D1,$E1,$C9,$7C
  DEFB $A7,$C0,$22,$0B,$A5,$C9,$C9,$21
  DEFB $18,$5E,$11,$00,$5B,$CD,$93,$8C
  DEFB $21,$00,$5B,$CD,$9B,$82,$3F,$D8
  DEFB $21,$00,$5B,$11,$18,$5E,$CD,$2D
  DEFB $8C,$3E,$00,$12,$D0,$E5,$21,$A0
  DEFB $9A,$CD,$6C,$88,$E1,$7E,$AF,$28
  DEFB $0A,$FE,$20,$28,$06,$CD,$1E,$63
  DEFB $23,$18,$F2,$21,$6A,$97,$CD,$6C
  DEFB $88,$18,$CD,$7E,$A7,$C8,$23,$FE
  DEFB $3F,$20,$02,$A7,$C9,$E6,$80,$28
  DEFB $F2,$23,$18,$EF,$3E,$01,$CD

; Message at 8D0B
  DEFM "0c!"

; Data block at 8D0E
  DEFB $B6,$9A,$CD,$6C,$88,$21,$00,$5B
  DEFB $36,$00,$CD,$93,$82,$D0,$21,$00
  DEFB $5B,$7E,$A7,$20,$09,$CD,$3E,$86
  DEFB $23,$22,$0B,$A5,$18,$15,$CD,$D9
  DEFB $8B,$38,$04,$7A,$B3,$20,$08,$21
  DEFB $15,$9A,$CD,$6C,$88,$18,$D6,$ED
  DEFB $53,$0B,$A5,$ED,$4B,$0B,$A5,$2A
  DEFB $0D,$A5,$0B,$78,$B1,$28,$05,$CD
  DEFB $F7,$8C,$20,$F6,$22,$35,$A5,$11
  DEFB $18,$5E,$01,$00,$00,$7E,$12,$A7
  DEFB $28,$11,$23,$13,$03,$CB,$7F,$28
  DEFB $06,$7E,$12,$23,$13,$03,$AF,$FE
  DEFB $3F,$20,$EA,$AF,$12,$ED,$43,$37
  DEFB $A5,$21,$D1,$9A,$CD,$6C,$88,$2A
  DEFB $0B,$A5,$CD,$92,$88,$21,$82,$9A
  DEFB $CD,$6C,$88,$CD,$BB,$8C,$DA,$0D
  DEFB $8D,$21,$18,$5E,$EB,$ED

; Message at 8D94
  DEFM "RDM"

; Data block at 8D97
  DEFB $CD,$D9,$8A,$C3,$0D,$8D,$2A,$27
  DEFB $A5,$18,$03,$2A,$2B,$A5,$22,$0D
  DEFB $A5,$C3,$08,$8D,$3E,$01,$CD

; Message at 8DAE
  DEFM "0c!"

; Data block at 8DB1
  DEFB $96,$9E,$CD,$6C,$88,$21,$00,$5B
  DEFB $36,$00,$CD,$93,$82,$D2,$37,$8E
  DEFB $21,$00,$5B,$7E,$A7,$20,$09,$CD
  DEFB $3E,$86,$23,$22,$0B,$A5,$18,$15
  DEFB $CD,$D9,$8B,$38,$04,$7A,$B3,$20
  DEFB $08,$21,$69,$98,$CD,$6C,$88,$18
  DEFB $D4,$ED,$53,$0B,$A5,$ED,$4B,$0B
  DEFB $A5,$2A,$29,$A5,$5E,$23,$56,$23
  DEFB $7A,$B3,$28,$0F,$EB,$A7,$ED,$42
  DEFB $EB,$28,$32,$CD,$F7,$8C,$20,$FB
  DEFB $23,$18,$E9,$22,$0D,$A5

; Message at 8E07
  DEFM "++\"5"

; Data block at 8E0B
  DEFB $A5,$21,$00,$00,$22,$1A,$5E,$22
  DEFB $37,$A5,$2A,$0B,$A5,$22,$18,$5E
  DEFB $22,$18,$5E,$ED,$5B,$35,$A5,$01
  DEFB $03,$00,$CD,$D9,$8A,$2A,$0D,$A5
  DEFB $22,$35,$A5,$22,$0D,$A5,$CD,$08
  DEFB $8D,$C3,$B0,$8D,$2A,$29,$A5,$5E
  DEFB $23,$56,$23,$7A,$B3,$C8,$7E,$23
  DEFB $A7,$28,$08,$CD,$F7,$8C,$20,$FB
  DEFB $23,$18,$EC

; Message at 8E4E
  DEFM "+++"

; Data block at 8E51
  DEFB $E5,$22,$35,$A5,$EB,$21,$03,$00
  DEFB $22,$37,$A5,$01,$00,$00,$CD,$D9
  DEFB $8A,$E1,$18,$D5,$11,$51,$A5,$21
  DEFB $1F,$A5,$06,$0C,$73,$23,$72,$23
  DEFB $13,$13,$10,$F8,$3E,$80,$32,$41
  DEFB $A5,$32,$4B,$A5,$21,$4F,$A5,$11
  DEFB $50,$A5,$01,$FF,$00,$36,$00,$ED
  DEFB $B0,$DD,$21,$1F,$A5,$C9,$21,$00
  DEFB $5B,$06

; Message at 8E93
  DEFM "\"6 "

; Data block at 8E96
  DEFB $23,$10,$FB,$21,$00,$5B,$36,$00
  DEFB $CD,$A0,$82,$30,$07,$21,$F6,$9E
  DEFB $CD,$6C,$88,$C9,$F1,$C9,$21,$DF
  DEFB $9A,$CD,$6C,$88,$CD,$8F,$8E,$CD
  DEFB $E0,$8E,$2A,$33,$A5,$11,$1F,$A5
  DEFB $A7,$ED,$52,$DD,$21,$00,$5B,$DD
  DEFB $36,$00,$03,$DD,$75,$0B,$DD,$74
  DEFB $0C,$DD,$73,$0D,$DD,$72,$0E,$AF
  DEFB $32,$74,$5C,$EB,$01,$5A,$07,$C3
  DEFB $53,$85,$11,$0A,$5B,$21,$09,$5B
  DEFB $06,$0A,$7E,$A7,$20,$02,$3E,$20
  DEFB $12,$1B,$2B,$10,$F5,$C9,$AF,$12
  DEFB $13,$CD,$71,$8C,$AF,$12,$D1,$21
  DEFB $98,$62,$7E,$A7,$CA,$D0,$7E,$23
  DEFB $18,$F8,$CD,$CA,$74,$C9,$D5,$21
  DEFB $00,$5B,$36,$00,$CD,$8F,$82,$D1
  DEFB $D0,$D5,$21,$00,$5B,$7E,$A7,$20
  DEFB $03,$E1,$37,$C9,$CD,$D9,$8B,$38
  DEFB $07,$7A,$A7,$20,$03,$B3,$20,$08
  DEFB $21,$52,$9A,$CD,$6C,$88,$18,$D7
  DEFB $EB,$D1,$37,$C9,$D5,$E5,$6E,$26
  DEFB $00,$11,$00,$5B,$CD,$71,$8C,$CD
  DEFB $EC,$76,$E1,$23,$CD,$4F,$87,$EB
  DEFB $D1,$C9,$CD

; Message at 8F51
  DEFM "Gs!"

; Data block at 8F54
  DEFB $0E,$9B,$CD,$6C,$88,$21,$00,$00
  DEFB $22,$13,$A5,$3E,$01,$CD,$2A,$63
  DEFB $ED,$5B,$13,$A5,$1B,$1B,$CD,$A8
  DEFB $83,$CD,$BD,$83,$06,$12,$CB,$7A
  DEFB $20,$11,$D5,$C5,$E5,$CD,$3A,$8F
  DEFB $36,$FF,$21,$00,$5B,$CD,$6C,$88
  DEFB $E1,$C1,$D1,$E5,$C5,$D5,$21,$36
  DEFB $9B,$CD,$6C,$88,$D1,$C1,$E1,$23
  DEFB $23,$23,$13,$7E,$A7,$20,$02,$CB
  DEFB $FA,$10,$D3,$CD,$B2,$83,$FE,$F0
  DEFB $28,$19,$FE,$F1,$28,$2D,$FE,$FC
  DEFB $C8,$FE,$0D,$28,$76,$FE,$10,$28
  DEFB $58,$FE,$7F,$28,$36,$CD,$3C,$63
  DEFB $C3,$18,$90,$2A,$13,$A5,$2B,$CB
  DEFB $7C,$C2,$9F,$8F,$22,$13,$A5,$2A
  DEFB $11,$A5

; Message at 8FCE
  DEFM "+++\""

; Data block at 8FD2
  DEFB $11,$A5,$C3,$C9,$83,$2A,$11,$A5
  DEFB $23,$23,$23,$7E,$A7,$CA,$9F,$8F
  DEFB $22,$11,$A5,$2A,$13,$A5,$23,$22
  DEFB $13,$A5,$C3,$06,$84,$7E,$A7,$C3
  DEFB $FA,$77,$E5,$11,$18,$5E,$01,$03
  DEFB $00,$ED,$B0,$21,$03,$00,$22,$37
  DEFB $A5,$E1,$22,$35,$A5,$CD,$D9,$8A
  DEFB $C3,$5F,$8F,$C3,$EC,$77,$21,$00
  DEFB $00,$22,$37,$A5,$18

; Message at 9017
  DEFM "Z\"5"

; Data block at 901A
  DEFB $A5,$21,$00,$00,$22,$37,$A5,$AF
  DEFB $32,$00,$5B,$18,$0C,$C3,$3E,$81
  DEFB $CD,$44,$94,$21,$00,$00,$22,$37
  DEFB $A5,$21,$3B,$9B,$CD,$6C,$88,$21
  DEFB $00,$5B,$CD,$97,$82

; Message at 903F
  DEFM "07:"

; Data block at 9042
  DEFB $00,$5B,$A7,$CA,$9F,$8F,$CD,$95
  DEFB $75,$CD,$D9,$8B,$38,$07,$7A,$A7
  DEFB $20,$03,$B3,$20,$08,$21,$3F,$9B
  DEFB $CD,$6C,$88,$18,$D4,$32,$18,$5E
  DEFB $CD,$90,$75,$CD,$F4,$8A,$3A,$1A
  DEFB $5E,$E6,$07,$F6,$80,$32,$1A,$5E
  DEFB $CD,$41,$8C,$CD,$D9,$8A,$21,$44
  DEFB $9B,$CD,$6C,$88,$C3,$5F,$8F,$3E
  DEFB $01,$CD

; Message at 9084
  DEFM "0c!I"

; Data block at 9088
  DEFB $9B,$CD,$6C,$88,$21,$4F,$A5,$C3
  DEFB $50,$8F,$3E,$01,$CD

; Message at 9095
  DEFM "0c!"

; Data block at 9098
  DEFB $5F,$9B,$CD,$6C,$88,$2A,$1F,$A5
  DEFB $C3,$50,$8F,$3E,$01,$CD

; Message at 90A6
  DEFM "0c!u"

; Data block at 90AA
  DEFB $9B,$CD,$6C,$88,$2A,$21,$A5,$C3
  DEFB $50,$8F,$C9,$CD,$CA,$74,$C9,$3E
  DEFB $01,$CD

; Message at 90BC
  DEFM "0c!"

; Data block at 90BF
  DEFB $8D,$9B,$CD,$6C,$88,$2A,$4D,$A5
  DEFB $11,$00,$5B,$CD,$71,$8C,$AF,$12
  DEFB $21,$00,$5B,$CD,$93,$82,$D0,$21
  DEFB $00,$5B,$CD,$D9,$8B,$38,$09,$7A
  DEFB $B3,$28,$05,$ED,$53,$4D,$A5,$C9
  DEFB $21,$69,$98,$CD,$6C,$88,$18,$E0
  DEFB $21,$00,$5B,$CD,$93,$82,$D0,$21
  DEFB $00,$5B,$CD,$D9,$8B,$EB,$3F,$D8
  DEFB $21,$69,$98,$CD,$6C,$88,$C3,$EF
  DEFB $90,$3E,$01,$CD

; Message at 910B
  DEFM "0c!"

; Data block at 910E
  DEFB $00,$00,$22,$0B,$A5,$21,$C3,$9B
  DEFB $CD,$6C,$88,$ED,$5B,$0B,$A5,$13
  DEFB $CD,$0C,$8F,$D0,$CD,$B3,$8C,$E5
  DEFB $21,$DF,$9B,$CD,$6C,$88,$E1,$E5
  DEFB $CD,$92,$88,$E1,$4D,$2A,$23,$A5
  DEFB $CD,$75,$8A,$DA,$EE,$91

; Message at 913C
  DEFM "++\"5"

; Data block at 9140
  DEFB $A5,$23,$4E,$06,$00,$2B,$03,$03
  DEFB $ED,$43,$37,$A5,$11,$18,$5E,$ED
  DEFB $B0,$21,$1D,$5E,$11,$00,$5B,$CD
  DEFB $4F,$87,$21,$82,$9A,$CD,$6C,$88
  DEFB $21,$00,$5B,$CD,$9B,$82,$D2,$13
  DEFB $91,$3A,$00,$5B,$A7,$20,$09,$01
  DEFB $00,$00,$CD,$D9,$8A,$C3,$13,$91
  DEFB $11,$1D,$5E,$21,$00,$5B,$CD,$F4
  DEFB $8A,$7B,$3D,$32,$19,$5E,$21,$E9
  DEFB $9B,$CD,$6C,$88,$2A,$1B,$5E,$11
  DEFB $00,$5B,$CD,$71,$8C,$AF,$12,$CD
  DEFB $EF,$90,$22,$1B,$5E,$D2,$13,$91
  DEFB $21,$FD,$9B,$CD,$6C,$88,$3A,$1A
  DEFB $5E,$6F,$26,$00,$11,$00,$5B,$CD
  DEFB $71,$8C,$AF,$12,$21,$00,$5B,$CD
  DEFB $BF,$91,$D2,$13,$91,$18,$21,$D5
  DEFB $C3,$12,$8F,$78,$B1,$28,$0B,$E5
  DEFB $2A,$0B,$A5,$A7,$ED,$42,$E1,$C2
  DEFB $59,$8A,$37,$C9,$C3,$3F,$8A,$CD
  DEFB $27,$63,$F5,$CD,$AC,$7C,$F1,$C9
  DEFB $EB,$CD,$D0,$8A,$06,$00,$03,$03
  DEFB $CD,$D9,$8A,$C3,$13,$91,$22,$35
  DEFB $A5,$21,$00,$00,$22,$37,$A5,$21
  DEFB $DF,$9B,$CD,$6C,$88,$2A,$0B,$A5
  DEFB $7D,$32,$18,$5E,$CD,$92,$88,$21
  DEFB $82,$9A,$CD,$6C,$88,$21,$00,$5B
  DEFB $36,$00,$CD,$9B,$82,$D2,$13,$91
  DEFB $3A,$00,$5B,$A7,$CA,$13,$91,$21
  DEFB $00,$5B,$11,$1D,$5E,$CD,$F4,$8A
  DEFB $7B,$3D,$32,$19,$5E,$21,$E9,$9B
  DEFB $CD,$6C,$88,$AF,$32,$00,$5B,$CD
  DEFB $EF,$90,$D2,$13,$91,$22,$1B,$5E
  DEFB $21,$FD,$9B,$CD,$6C,$88,$CD,$0C
  DEFB $8F,$D2,$13,$91,$7D,$32,$1A,$5E
  DEFB $ED,$4B,$19,$5E,$06,$00,$03,$03
  DEFB $CD,$D9,$8A,$C3,$13,$91,$3E,$01
  DEFB $CD

; Message at 9261
  DEFM "0c!"

; Data block at 9264
  DEFB $00,$00,$22,$0B,$A5,$21,$0C,$9C
  DEFB $CD,$6C,$88,$AF,$32,$00,$5B,$CD
  DEFB $04,$8A,$D0,$3A,$00,$5B,$A7,$20
  DEFB $04,$CD,$3E,$86,$23,$22,$0B,$A5

; Message at 9284
  DEFM "DM*%"

; Data block at 9288
  DEFB $A5,$CD,$3F,$8A,$DA,$E4,$93

; Message at 928F
  DEFM "++++"

; Data block at 9293
  DEFB $13,$13,$13,$13,$22,$35,$A5,$ED
  DEFB $53,$37,$A5,$42,$4B,$11,$18,$60
  DEFB $ED,$B0,$21,$26,$9C,$CD,$6C,$88
  DEFB $2A,$0B,$A5,$CD,$92,$88,$21,$82
  DEFB $9A,$CD,$6C,$88,$2A,$18,$60,$22
  DEFB $18,$5E,$2A,$1C,$60,$22,$1C,$5E
  DEFB $21,$00,$00,$22,$1A,$5E,$22,$1E
  DEFB $5E,$21,$1E,$60,$7E,$A7,$23,$28
  DEFB $04,$23,$23,$18,$F7,$11,$00,$5B
  DEFB $CD,$4F,$87,$21,$00,$5B,$CD,$9B
  DEFB $82,$D2,$69,$92,$21,$00,$5B,$7E
  DEFB $A7,$20,$09,$01,$00,$00,$CD,$D9
  DEFB $8A,$C3,$69,$92,$11,$1F,$5E,$CD
  DEFB $F4,$8A,$EB,$11,$E4,$A1,$19,$22
  DEFB $1A,$5E,$21,$1E,$60,$11,$00,$5B
  DEFB $7E,$A7,$28,$1E,$E5,$6F,$26,$00
  DEFB $CD,$96,$85,$3E,$20,$12,$13,$E1
  DEFB $23,$4E,$23,$46,$23,$E5,$60,$69
  DEFB $CD,$71,$8C,$3E,$20,$12,$13,$E1
  DEFB $18,$DE,$AF,$12,$21,$2E,$9C,$CD
  DEFB $6C,$88,$21,$00,$5B,$CD,$9B,$82
  DEFB $D2,$69,$92,$21,$00,$5B,$7E,$A7
  DEFB $28,$23,$CD,$7E,$85,$38,$07,$7A
  DEFB $A7,$20,$03,$B3,$20,$08,$21,$47
  DEFB $9C,$CD,$6C,$88,$18,$DC,$CD,$17
  DEFB $85,$7A,$B3,$20,$E1,$21,$5E,$9C
  DEFB $CD,$6C,$88,$18,$CD,$CD,$B9,$85
  DEFB $7E,$A7,$28,$26,$E5,$2A,$43,$A5
  DEFB $22,$06,$A5,$01,$03,$00,$CD,$85
  DEFB $8A,$2A,$1A,$5E,$23,$23,$23,$22
  DEFB $1A,$5E,$E1,$CD,$7E,$85,$7B,$CD
  DEFB $C7,$85,$CD,$17,$85,$CD,$D2,$85
  DEFB $18,$D6,$21,$7F,$9C,$CD,$6C,$88
  DEFB $11,$00

; Message at 939D
  DEFM "[*7"

; Data block at 93A0
  DEFB $A5,$7C,$B5,$28,$06,$2A,$1C,$5E
  DEFB $CD,$71,$8C,$AF,$12,$21,$00,$5B
  DEFB $CD,$93,$82,$D2,$69,$92,$21,$00
  DEFB $5B,$CD,$D9,$8B,$38,$14,$ED,$53
  DEFB $1C,$5E

; Message at 93C2
  DEFM "BK*/"

; Data block at 93C6
  DEFB $A5,$CD,$D7,$84,$38,$06,$ED,$4B
  DEFB $1A,$5E,$18,$08,$21,$B3,$9C,$CD
  DEFB $6C,$88,$18,$D3,$03,$03,$03,$03
  DEFB $CD,$D9,$8A,$C3,$69,$92

; Message at 93E4
  DEFM "++\"5"

; Data block at 93E8
  DEFB $A5,$21,$00,$00,$22,$37,$A5,$21
  DEFB $26,$9C,$CD,$6C,$88,$2A,$0B,$A5
  DEFB $22,$18,$5E,$CD,$92,$88,$21,$82
  DEFB $9A,$CD,$6C,$88,$21,$00,$5B,$36
  DEFB $00,$CD,$9B,$82,$21,$00,$5B,$D2
  DEFB $69,$92,$7E,$A7,$CA,$69,$92,$7E
  DEFB $A7,$CA,$69,$92,$11,$1F,$5E,$CD
  DEFB $F4,$8A,$EB,$11,$E4,$A1,$19,$22
  DEFB $1A,$5E,$21,$2E,$9C,$CD,$6C,$88
  DEFB $AF,$32,$00,$5B,$C3,$35,$93,$3E
  DEFB $01,$CD

; Message at 943A
  DEFM "0c!"

; Data block at 943D
  DEFB $EA,$9C,$CD,$6C,$88,$18,$14,$E5
  DEFB $CD,$3A,$8F,$21,$03,$00,$22,$37
  DEFB $A5,$E1,$22,$35,$A5,$01,$00,$00
  DEFB $C3,$D9,$8A,$CD,$24,$63,$CD,$18
  DEFB $63,$E6,$5F,$FE,$4E,$C8,$CD

; Message at 9464
  DEFM "'c!"

; Data block at 9467
  DEFB $15,$9D,$CD,$6C,$88,$CD,$24,$63
  DEFB $CD,$18,$63,$E6,$5F,$FE,$4E,$C8
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$CD
  DEFB $CD,$CD,$CD,$CD,$CD,$CD,$CD,$23
  DEFB $E5,$C5,$5E,$23,$56,$23,$EB,$D5
  DEFB $11,$18,$60,$CD,$71,$8C,$E1,$3E
  DEFB $2C,$12,$13,$7E,$A7,$23,$28,$19
  DEFB $E5,$6F,$26,$00,$CD,$96,$85,$E1
  DEFB $4E,$23,$46,$23,$E5,$69,$60,$CD
  DEFB $71,$8C,$3E,$20,$12,$13,$E1,$18
  DEFB $E2,$AF,$12,$11,$1D,$5E,$CD,$4F
  DEFB $87,$21,$18,$5E,$CD,$96,$7C,$21
  DEFB $18,$60,$CD,$96,$7C,$C1,$E1,$09
  DEFB $C3,$50,$95,$21,$BD,$9E,$CD,$96
  DEFB $7C,$21,$CF,$9E,$CD,$96,$7C,$21
  DEFB $E1,$9E,$CD,$96,$7C,$CD,$AC,$7C
  DEFB $C3,$4D,$95,$3E,$20,$12,$1B,$D5
  DEFB $11,$97,$62,$C3,$F4,$8E

; Routine at 95D5
;
; Used by the routines at 72B4 and 72BB.
  LD A,(HL)               ; A=PEEK HL
  INC HL                  ; HL=HL+1
  CP $FF                  ; Set the zero flag if A=$FF, or the carry flag if
                          ; A<$FF
  RET Z                   ; Return if A=$FF
  CALL $631E              ; CALL 631E
  JR $95D5                ; Jump to 95D5

; Data block at 95DF
  DEFB $01,$03,$02,$CD,$FD,$95,$04,$0C
  DEFB $78,$FE,$13,$20,$F6,$18,$31,$01
  DEFB $12,$13,$CD,$FD,$95,$05,$0D,$78
  DEFB $FE,$01,$20,$F6,$18,$22,$C5,$78
  DEFB $CD,$9E,$0E,$E5,$79,$CD,$9E,$0E
  DEFB $D1,$3E,$08,$01,$1F,$00,$2C,$1C
  DEFB $C5,$D5,$E5,$ED,$B0,$E1,$D1,$C1
  DEFB $24,$14,$3D,$C2,$0F,$96,$C1,$C9
  DEFB $78,$CD,$9E,$0E,$E5,$54,$5D,$13
  DEFB $01,$1F,$00,$36,$00,$ED,$B0,$E1
  DEFB $24,$7C,$E6,$07,$20,$EE,$C9,$1A
  DEFB $00,$0C,$1A,$01,$1F,$01,$07,$FF
  DEFB $1A,$02,$1F,$01,$16,$FF,$1A,$00
  DEFB $1F,$01,$01,$12,$1A,$02,$FF

; Message at 964E
  DEFM "High priority conditions"

; Data block at 9666
  DEFB $00,$0C,$0A,$0A

; Message at 966A
  DEFM "Which adventure data file do you want to load?..."

; Data block at 969B
  DEFB $FF,$0D,$0A,$0A,$07

; Message at 96A0
  DEFM "Memory full ... "

; Data block at 96B0
  DEFB $FF,$0D,$0A,$FF

; Message at 96B4
  DEFM "nada   "

; Data block at 96BB
  DEFB $FF,$0D,$0A

; Message at 96BE
  DEFM "Nombre Clave?"

; Data block at 96CB
  DEFB $0D,$0A

; Message at 96CD
  DEFM "                "

; Data block at 96DD
  DEFB $FF,$1E

; Message at 96DF
  DEFM "          PRINTER MENU"

; Data block at 96F5
  DEFB $12,$0D,$0A,$0A,$0A,$12,$0A,$0A
  DEFB $12,$0A,$0A,$0A,$0A,$0A,$0A,$12
  DEFB $0A,$0A,$12,$0A,$12,$0A,$0A,$12
  DEFB $0A,$0A,$12,$FF

; Message at 9711
  DEFM "Messages"

; Unused
  DEFS $01

; Message at 971A
  DEFM "Objects"

; Unused
  DEFS $01

; Message at 9722
  DEFM "No. Wt. Start Description"

; Unused
  DEFS $01

; Message at 973C
  DEFM "Verbs"

; Unused
  DEFS $01

; Message at 9742
  DEFM "Nouns"

; Unused
  DEFS $01

; Message at 9748
  DEFM "Adverbs"

; Data block at 974F
  DEFB $00,$1F,$1C,$14,$FF,$0D,$0A,$0A
  DEFB $07

; Message at 9758
  DEFM "ERROR:"

; Data block at 975E
  DEFB $FF

; Message at 975F
  DEFM " not found"

; Data block at 9769
  DEFB $FF,$0D,$0A,$0A,$FF,$0D,$0A,$0A

; Message at 9771
  DEFM "Press a key ..."

; Data block at 9780
  DEFB $FF

; Message at 9781
  DEFM "Low priority conditions"

; Unused
  DEFS $01

; Message at 9799
  DEFM "Local conditions"

; Data block at 97A9
  DEFB $00,$0D,$0A,$0F,$32,$44,$0F

; Message at 97B0
  DEFM "1isc or "

; Data block at 97B8
  DEFB $0F,$32,$54,$0F

; Message at 97BC
  DEFM "1ape..."

; Data block at 97C3
  DEFB $FF,$0C,$0F,$32,$0A,$44,$0F

; Message at 97CA
  DEFM "1ata file or "

; Data block at 97D7
  DEFB $0D,$0A,$0F,$32,$52,$0F

; Message at 97DD
  DEFM "1unnable adventure..."

; Data block at 97F2
  DEFB $FF,$0C

; Message at 97F4
  DEFM "What name do you want to give"

; Data block at 9811
  DEFB $0A,$0D

; Message at 9813
  DEFM "this adventure ?..."

; Data block at 9826
  DEFB $FF,$1F,$1E,$0C

; Message at 982A
  DEFM "MEM"

; Data block at 982D
  DEFB $08,$08,$08,$0A

; Message at 9831
  DEFM "LOW"

; Data block at 9834
  DEFB $08,$08,$08,$0A,$12,$FF,$1F,$1E
  DEFB $0C,$12,$0A,$12,$0A,$12,$FF,$1F
  DEFB $1E,$0C

; Message at 9846
  DEFM "OUT"

; Data block at 9849
  DEFB $08,$08,$08,$0A

; Message at 984D
  DEFM "OF "

; Data block at 9850
  DEFB $08,$08,$08,$0A

; Message at 9854
  DEFM "MEM"

; Data block at 9857
  DEFB $FF,$1F,$1F,$05,$FE,$08,$0A,$FF
  DEFB $0F,$31,$08,$08,$0A,$0A,$D0,$D0
  DEFB $D0,$FF,$0D,$12

; Message at 986B
  DEFM "Number 1..9999 please..."

; Data block at 9883
  DEFB $FF,$0F,$02

; Message at 9886
  DEFM "BRK"

; Data block at 9889
  DEFB $0F,$00,$FF,$1A,$02,$0C

; Message at 988F
  DEFM "Mkr 01234567890123456789"

; Data block at 98A7
  DEFB $0D,$0A,$0A,$FF,$1A,$02,$0C

; Message at 98AE
  DEFM "Ctr +0  +1  +2  +3  +4  +5  +6"

; Data block at 98CC
  DEFB $0D,$0A,$FF,$0D,$0A

; Message at 98D1
  DEFM "Press D for diagnostics or"

; Data block at 98EB
  DEFB $0D,$0A

; Message at 98ED
  DEFM "BRK to break..."

; Data block at 98FC
  DEFB $FF,$1A,$02,$1F,$01,$16

; Message at 9902
  DEFM "Press a key ..."

; Data block at 9911
  DEFB $12,$FF,$1A,$02,$FF,$1F,$02,$01
  DEFB $FF,$1F,$02,$12,$FF,$1F,$06,$15

; Message at 9921
  DEFM "Which picture number ?..."

; Data block at 993A
  DEFB $FF,$1F,$01,$15,$12,$FF,$1F,$01
  DEFB $15,$12,$07,$FF,$1F,$01,$14,$07
  DEFB $12

; Message at 994B
  DEFM "You are "

; Data block at 9953
  DEFB $FF,$18

; Message at 9955
  DEFM "VERY"

; Data block at 9959
  DEFB $18,$FF

; Message at 995B
  DEFM "very"

; Data block at 995F
  DEFB $FF

; Message at 9960
  DEFM " short of memory"

; Data block at 9970
  DEFB $0D,$0A,$12

; Message at 9973
  DEFM "Free memory now "

; Data block at 9983
  DEFB $FF

; Message at 9984
  DEFM " bytes"

; Data block at 998A
  DEFB $0D,$0A,$12

; Message at 998D
  DEFM "PRESS A KEY ..."

; Data block at 999C
  DEFB $FF,$1F,$01,$14,$12,$0A,$12,$0A
  DEFB $12,$FF,$1F,$01,$14,$07,$12

; Message at 99AB
  DEFM "You have run out of memory."

; Data block at 99C6
  DEFB $0D,$0A,$12

; Message at 99C9
  DEFM "This last edit was IGNORED."

; Data block at 99E4
  DEFB $0D,$0A,$12

; Message at 99E7
  DEFM "Please press a key ..."

; Data block at 99FD
  DEFB $FF,$1F,$01,$14,$12,$07,$18

; Message at 9A04
  DEFM " OUT OF MEMORY "

; Data block at 9A13
  DEFB $18,$FF,$1F,$01,$15,$12

; Message at 9A19
  DEFM "  Number 1..9999 please ..."

; Data block at 9A34
  DEFB $FF,$1F,$01,$15

; Message at 9A38
  DEFM "Which message number ?..."

; Data block at 9A51
  DEFB $FF,$0D,$12

; Message at 9A54
  DEFM "Please give a number 1..255 "

; Data block at 9A70
  DEFB $FF,$0C

; Message at 9A72
  DEFM "Message number "

; Data block at 9A81
  DEFB $FF

; Message at 9A82
  DEFM " is..."

; Data block at 9A88
  DEFB $0D,$0A,$0A,$FF,$0D,$0A

; Message at 9A8E
  DEFM "Message too long!"

; Data block at 9A9F
  DEFB $FF,$0D,$0A,$07

; Message at 9AA3
  DEFM "I don't understand"

; Data block at 9AB5
  DEFB $FF,$1F,$01,$15,$12

; Message at 9ABA
  DEFM "Which line number ?..."

; Data block at 9AD0
  DEFB $FF,$0C

; Message at 9AD2
  DEFM "Line number "

; Data block at 9ADE
  DEFB $FF,$0C

; Message at 9AE0
  DEFM "What do you want to call"

; Data block at 9AF8
  DEFB $0D,$0A

; Message at 9AFA
  DEFM "this data file ?..."

; Data block at 9B0D
  DEFB $FF,$1F,$01,$0A,$96,$1F,$01,$16
  DEFB $97,$20,$98

; Message at 9B18
  DEFM " DEL ENTER-edit C/S 1-restore"

; Data block at 9B35
  DEFB $FF,$12,$0D,$0A,$09,$FF,$1F,$01
  DEFB $14,$FF,$1F,$01,$14,$07,$FF,$1F
  DEFB $01,$14,$12,$FF,$1A,$00,$1F,$0A
  DEFB $01

; Message at 9B4E
  DEFM "* EDIT VERBS *"

; Data block at 9B5C
  DEFB $1A,$02,$FF,$1A,$00,$1F,$0A,$01

; Message at 9B64
  DEFM "* EDIT NOUNS *"

; Data block at 9B72
  DEFB $1A,$02,$FF,$1A,$00,$1F,$09,$01

; Message at 9B7A
  DEFM "* EDIT ADVERBS *"

; Data block at 9B8A
  DEFB $1A,$02,$FF

; Message at 9B8D
  DEFM "The room in which you will start"

; Data block at 9BAD
  DEFB $0D,$0A

; Message at 9BAF
  DEFM "the adventure is..."

; Data block at 9BC2
  DEFB $FF,$1F,$01,$16

; Message at 9BC6
  DEFM "Which object number ?..."

; Data block at 9BDE
  DEFB $FF,$0C

; Message at 9BE0
  DEFM "Object "

; Data block at 9BE7
  DEFB $23,$FF,$0D,$0A,$0A

; Message at 9BEC
  DEFM "Starts in room "

; Data block at 9BFB
  DEFB $23,$FF,$0A,$0A,$0D

; Message at 9C00
  DEFM "and weighs "

; Data block at 9C0B
  DEFB $FF,$1F,$01,$16

; Message at 9C0F
  DEFM "Which room number ?..."

; Data block at 9C25
  DEFB $FF,$0C

; Message at 9C27
  DEFM "Room "

; Data block at 9C2C
  DEFB $23,$FF,$0D,$0A,$0A

; Message at 9C31
  DEFM "Connections are..."

; Data block at 9C43
  DEFB $0D,$0A,$0A,$FF,$0D,$12

; Message at 9C49
  DEFM "Error:no such verb"

; Data block at 9C5B
  DEFB $0D,$0A,$FF,$0D,$12

; Message at 9C60
  DEFM "Error:cannot move to this room"

; Data block at 9C7E
  DEFB $FF,$0D,$0A,$0A

; Message at 9C82
  DEFM "Which picture number goes"

; Data block at 9C9B
  DEFB $0D,$0A,$0A

; Message at 9C9E
  DEFM "with this room ?... "

; Data block at 9CB2
  DEFB $FF,$0D,$0B,$12,$07

; Message at 9CB7
  DEFM "This picture does not exist."

; Data block at 9CD3
  DEFB $0D,$0A,$12

; Message at 9CD6
  DEFM "Please try again..."

; Data block at 9CE9
  DEFB $FF

; Message at 9CEA
  DEFM "This will destroy all your data"

; Data block at 9D09
  DEFB $0D,$0A

; Message at 9D0B
  DEFM "Sure ?..."

; Data block at 9D14
  DEFB $FF,$0D,$0A

; Message at 9D17
  DEFM "Really sure ?..."

; Data block at 9D27
  DEFB $FF,$0E,$07,$0F,$00,$0C,$1F,$0C
  DEFB $01

; Message at 9D30
  DEFM "MAIN MENU"

; Data block at 9D39
  DEFB $0D,$0A,$0A,$0F,$32,$41,$0F

; Message at 9D40
  DEFM "1dverbs"

; Data block at 9D47
  DEFB $0A,$0D,$0F,$32,$42,$0F

; Message at 9D4D
  DEFM "1egin where ?"

; Data block at 9D5A
  DEFB $0A,$0D,$0F,$32,$43,$0F

; Message at 9D60
  DEFM "1onditions (LOCAL)"

; Data block at 9D72
  DEFB $0A,$0D,$0F,$32,$47,$0F

; Message at 9D78
  DEFM "1raphics"

; Data block at 9D80
  DEFB $0A,$0D,$0F,$32,$48,$0F

; Message at 9D86
  DEFM "1igh priority conditions"

; Data block at 9D9E
  DEFB $0A,$0D,$0F,$32,$4C,$0F

; Message at 9DA4
  DEFM "1ow priority conditions"

; Data block at 9DBB
  DEFB $0A,$0D,$0F,$32,$4D,$0F

; Message at 9DC1
  DEFM "1essages"

; Data block at 9DC9
  DEFB $0A,$0D,$0F,$32,$4E,$0F

; Message at 9DCF
  DEFM "1ouns"

; Data block at 9DD4
  DEFB $0A,$0D,$0F,$32,$4F,$0F

; Message at 9DDA
  DEFM "1bjects"

; Data block at 9DE1
  DEFB $0A,$0D,$0F,$32,$50,$0F

; Message at 9DE7
  DEFM "1rinter menu"

; Data block at 9DF3
  DEFB $0A,$0D,$0F,$32,$52,$0F

; Message at 9DF9
  DEFM "1oom descriptions"

; Data block at 9E0A
  DEFB $0A,$0D,$0F,$32,$53,$0F

; Message at 9E10
  DEFM "1ave adventure"

; Data block at 9E1E
  DEFB $0A,$0D,$0F,$32,$54,$0F

; Message at 9E24
  DEFM "1-load adventure"

; Data block at 9E34
  DEFB $0A,$0D,$0F,$32,$56,$0F

; Message at 9E3A
  DEFM "1erbs"

; Data block at 9E3F
  DEFB $0A,$0D,$0F,$32,$58,$0F

; Message at 9E45
  DEFM "1-erase adventure"

; Data block at 9E56
  DEFB $0D,$0A,$0A,$0F

; Message at 9E5A
  DEFM "2ENTER"

; Data block at 9E60
  DEFB $0F

; Message at 9E61
  DEFM "1-enter adventure"

; Data block at 9E72
  DEFB $0D,$0A,$0A,$0A

; Message at 9E76
  DEFM "HORUSOFT -Madrid 1987-        ."

; Data block at 9E95
  DEFB $FF,$1F,$01,$14

; Message at 9E99
  DEFM "Which room number ?..."

; Data block at 9EAF
  DEFB $FF,$1F,$14,$03

; Message at 9EB3
  DEFM "FREE:"

; Data block at 9EB8
  DEFB $FF,$1F,$20,$16,$FF

; Message at 9EBD
  DEFM "Room descriptions"

; Unused
  DEFS $01

; Message at 9ECF
  DEFM "No.   Description"

; Unused
  DEFS $01

; Message at 9EE1
  DEFM "Picture"

; Data block at 9EE8
  DEFB $23

; Message at 9EE9
  DEFM " Connections"

; Data block at 9EF5
  DEFB $00,$0C,$1F,$01,$0C,$FF,$1F,$01
  DEFB $16

; Message at 9EFE
  DEFM "BRK to end,other key to continue"

; Data block at 9F1E
  DEFB $FF,$0D,$0A

; Message at 9F21
  DEFM "ERROR... Pulse"

; Data block at 9F2F
  DEFB $0D,$0A

; Message at 9F31
  DEFM "una tecla."

; Data block at 9F3B
  DEFB $0D,$0A,$FF,$1A,$02,$0C,$1F,$01
  DEFB $16,$FF,$0C,$1F,$01,$08,$7F

; Message at 9F4A
  DEFM "1986 INCENTIVE SOFTWARE LTD."

; Data block at 9F66
  DEFB $0D,$0A,$0A

; Message at 9F69
  DEFM "Design by Sean Ellis"

; Data block at 9F7D
  DEFB $0D,$0A

; Message at 9F7F
  DEFM "Programmed by Brendan Kelly."

; Data block at 9F9B
  DEFB $FF,$FF

; Message at 9F9D
  DEFM "DIS"

; Data block at 9FA0
  DEFB $C3

; Message at 9FA1
  DEFM "TAP"

; Data block at 9FA4
  DEFB $C5

; Message at 9FA5
  DEFM "OP00AND OR *NOT XOR HOLDGET DROPSWAPTO *OBJ SET RESESET?RES?CSETC"
  DEFM "TR DECRINCREQU?DESCLOOKMESSPRINRAND< **> **= **SAVELOADHEREAVAICA"
  DEFM "RR+ **- **TURNAT *BRINFINDIN *OP28OP29OKAYWAITQUITEXITROOMNOUNVER"
  DEFM "BADVEGOTONO1 NO2 VBNOLISTPICTTEXTCONNWEIGWITHSTRELF *IF *END "

; Data block at A0A5
  DEFB $FF,$00,$12,$12,$11,$12,$01,$01
  DEFB $01,$02,$02,$01,$01,$01,$11,$11
  DEFB $02,$11,$01,$01,$12,$01,$00,$01
  DEFB $01,$11,$12,$12,$12,$00,$00,$11
  DEFB $11,$11,$12,$12,$10,$11,$01,$01
  DEFB $12,$01,$22,$00,$00,$00,$00,$10
  DEFB $11,$11,$11,$01,$10,$10,$10,$01
  DEFB $00,$00,$11,$11,$10,$01,$00,$01
  DEFB $00,$01,$0E

; Message at A0E8
  DEFM "Stack empty"

; Data block at A0F3
  DEFB $0A,$0D,$00,$02,$0D

; Message at A0F8
  DEFM "Stack full"

; Data block at A102
  DEFB $0A,$0D,$00,$03,$07

; Message at A107
  DEFM "Marker*"

; Data block at A10E
  DEFB $04,$08

; Message at A110
  DEFM "Counter*"

; Data block at A118
  DEFB $05,$05

; Message at A11A
  DEFM "Room*"

; Data block at A11F
  DEFB $06,$07

; Message at A121
  DEFM "Object*"

; Data block at A128
  DEFB $07,$08

; Message at A12A
  DEFM "Message*"

; Data block at A132
  DEFB $08,$0E,$0F

; Message at A135
  DEFM "3STOPPED"

; Data block at A13D
  DEFB $0F,$31,$0A,$0D,$00,$09,$10

; Message at A144
  DEFM "Illegal value"

; Data block at A151
  DEFB $0D,$0A,$00,$00,$66,$79,$93,$73
  DEFB $A3

; Message at A15A
  DEFM "sXs"

; Data block at A15D
  DEFB $B3,$73,$24,$8A,$B3

; Message at A162
  DEFM "vVu"

; Data block at A165
  DEFB $9F,$75,$AC,$77,$05

; Message at A16A
  DEFM "u(t/t6tDtwt"

; Data block at A175
  DEFB $81

; Message at A176
  DEFM "totht"

; Data block at A17B
  DEFB $8A,$74,$B6,$75,$60

; Message at A180
  DEFM "v,uAs"

; Data block at A185
  DEFB $C3,$73,$A2,$74,$B3,$74,$9C,$74
  DEFB $8F,$78,$B3

; Message at A190
  DEFM "xawowQwfsqs"

; Data block at A19B
  DEFB $7E,$83,$78,$83,$BE

; Message at A1A0
  DEFM "w'x"

; Data block at A1A3
  DEFB $7C

; Message at A1A4
  DEFM "wfyfy"

; Data block at A1A9
  DEFB $ED,$78,$F8,$78,$02,$79,$18,$79
  DEFB $8D

; Message at A1B2
  DEFM "sCy$y)y"

; Data block at A1B9
  DEFB $05,$78,$13,$78,$18,$78,$0E,$78
  DEFB $A8,$76,$AE,$72,$BB

; Message at A1C6
  DEFM "rVx;x;sXyOu"

; Data block at A1D1
  DEFB $E1

; Message at A1D2
  DEFM "sfy"

; Data block at A1D5
  DEFB $7C

; Message at A1D6
  DEFM "TTTTTTTT"

; Data block at A1DE
  DEFB $7C

; Message at A1DF
  DEFM "DD88"

; Data block at A1E3
  DEFB $10,$10,$00

; Message at A1E6
  DEFM " .,-!?:"

; Data block at A1ED
  DEFB $FB,$ED,$D5,$B5,$8E,$62,$32,$00
  DEFB $32,$62,$8E,$B5,$D5,$ED,$FB,$FF
  DEFB $00,$00,$FF,$7F,$02,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $1A,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$0E,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$0A
  DEFB $03,$04,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$01,$00,$DB,$87
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$10,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $01,$00,$01,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$18,$00,$00,$14,$00,$29
  DEFB $01,$00,$01,$00,$00,$00,$00,$00
  DEFB $5B,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$9B,$82,$BB,$5D,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $FF,$FF,$D2,$A5,$79,$A6,$7E,$A6
  DEFB $94,$A7,$21,$AB,$E3,$AB,$A0,$B2
  DEFB $E8,$B3,$5E,$BF,$9F,$E5,$DF,$FC
  DEFB $E9,$03,$A3,$A4,$10,$38,$54,$00
  DEFB $8E,$00,$03,$07,$80,$00,$21,$5E
  DEFB $00,$00,$00,$00,$00,$00,$80,$00
  DEFB $E9,$03,$18,$37,$82,$0C,$B6,$80
  DEFB $0B,$B7,$80,$17,$38,$82,$11,$73
  DEFB $81,$18,$CF,$81,$16,$CA,$81,$1A
  DEFB $76,$82,$05,$67,$80,$11,$74,$81
  DEFB $07,$69,$80,$06,$11,$83,$06,$68
  DEFB $80,$07,$6A,$80,$0C,$13,$83,$0F
  DEFB $59,$80,$03,$04,$80,$0E,$CA,$80
  DEFB $03,$05,$80,$09,$AE,$80,$0A,$5D
  DEFB $80,$08,$6B,$80,$08,$6C,$80,$09
  DEFB $12,$83,$12,$BF,$81,$19,$1D,$82
  DEFB $0E,$FC,$81,$01,$00,$80,$01,$01
  DEFB $80,$04,$06,$80,$04,$07,$80,$0B
  DEFB $B5,$80,$10,$E4,$80,$10,$E5,$80
  DEFB $14,$C1,$81,$02,$03,$80,$0D,$C1
  DEFB $80,$13,$C0,$81,$17,$CE,$81,$16
  DEFB $CB,$81,$02,$02,$80,$06,$3E,$82
  DEFB $0D,$FD,$81,$00,$00,$19,$91,$82
  DEFB $1B,$D4,$82,$0F,$2E,$81,$1A,$C8
  DEFB $82,$11,$E8,$80,$1A,$C7,$82,$1A
  DEFB $D3,$82,$10,$84,$81,$07,$0E,$80
  DEFB $11,$37,$80,$1D,$DA,$82,$03,$8C
  DEFB $80,$06,$8D,$80,$08,$09,$80,$05
  DEFB $B0,$81,$05,$94,$81,$10,$83,$81
  DEFB $17,$6A,$82,$0A,$82,$82,$0A,$64
  DEFB $80,$04,$86,$80,$0A,$45,$80,$05
  DEFB $85,$80,$08,$77,$80,$01,$8A,$80
  DEFB $13,$04,$80,$0A,$EF,$80,$13,$05
  DEFB $80,$1D,$D6,$82,$19,$A7,$82,$16
  DEFB $11,$82,$0D,$3F,$80,$17,$77,$82
  DEFB $0C,$FE,$81,$09,$00,$80,$08,$0B
  DEFB $80,$09,$01,$80,$14,$06,$80,$14
  DEFB $07,$80,$18,$80,$82,$1B,$C6,$82
  DEFB $02,$8B,$80,$11,$B2,$81,$19,$90
  DEFB $82,$06,$AA,$80,$18,$81,$82,$0E
  DEFB $60,$80,$12,$03,$80,$0B,$47,$80
  DEFB $12,$02,$80,$1D,$D9,$82,$0A,$F3
  DEFB $80,$11,$39,$80,$0F,$62,$80,$15
  DEFB $15,$82,$00,$00,$01,$08,$80,$00
  DEFB $00,$01,$22,$01,$00,$00,$34,$48
  DEFB $8A,$48,$8E,$40

; Message at A689
  DEFM "e la nave. Salidas:Sur. W"

; Data block at A6A2
  DEFB $02,$20,$01,$02,$00,$16,$48,$8B
  DEFB $40,$8E,$40

; Message at A6AD
  DEFM "e la nave. Salidas:Sur."

; Data block at A6C4
  DEFB $03,$20,$01,$00,$00,$34,$48,$8C
  DEFB $40,$8E,$40

; Message at A6CF
  DEFM "e la nave. Salidas:Sur."

; Data block at A6E6
  DEFB $10,$20,$32,$00,$00,$16,$48,$83
  DEFB $41,$80,$6B,$16,$3D,$83,$E8,$05
  DEFB $3D,$37,$15,$2B,$3F,$00

; Message at A6FC
  DEFM "yHSH,I"

; Data block at A702
  DEFB $80,$49,$DE,$48,$81,$49,$15,$22
  DEFB $01,$0E,$00,$34,$48,$09,$0A,$1A
  DEFB $42,$0B,$80,$06,$3C,$80,$03,$80
  DEFB $03,$0F,$80,$03,$80,$02,$0F,$80
  DEFB $0A,$80,$01,$0F,$80,$01,$80,$01
  DEFB $65,$73,$18,$20,$01,$00,$00,$34
  DEFB $48,$80,$42,$48,$FE

; Message at A737
  DEFM "IyHyJ)HzJ"

; Data block at A740
  DEFB $BD,$48,$B1

; Message at A743
  DEFM "HJH"

; Data block at A746
  DEFB $7B,$4A,$0A,$48,$11,$48,$7C,$5A
  DEFB $1D,$20,$01,$00,$00,$34,$48,$D6
  DEFB $42,$0A,$48,$D7

; Message at A75A
  DEFM "B===="

; Data block at A75F
  DEFB $87,$D0,$05,$37,$80,$01,$32,$80
  DEFB $04,$0B,$80,$07,$0B,$80,$08,$0B
  DEFB $80,$0C,$20,$01,$1A,$00,$16,$48
  DEFB $FE,$41,$D1,$41,$51,$D3,$09,$0A
  DEFB $48,$D4,$49,$A3,$48,$D5,$49,$84
  DEFB $69,$00,$C0,$C9,$69,$00,$C0,$17
  DEFB $49,$62,$10,$00,$00,$01,$00,$18
  DEFB $00,$01,$00,$02,$02,$00,$00,$08
  DEFB $08,$09,$48,$0A,$48,$08,$48,$0B
  DEFB $50,$01,$C8,$0C,$38,$02,$10,$0D
  DEFB $00,$02,$00,$1C,$00,$02,$00,$01
  DEFB $01,$00,$00,$08,$08,$0E,$48,$0A
  DEFB $48,$0F,$48,$0A,$48,$08,$48,$0B
  DEFB $50,$01,$C8,$0C,$38,$01,$10,$0D
  DEFB $00,$03,$00,$28,$00,$03,$00,$01
  DEFB $0A,$00,$02,$05,$00,$03,$06,$00
  DEFB $00,$34,$08

; Message at A7E2
  DEFM "5H6H7P0"

; Data block at A7E9
  DEFB $08,$31,$48,$08,$48,$0B,$50,$01
  DEFB $C8,$0C,$38,$01,$18,$02,$18,$05
  DEFB $10,$0D,$00,$05,$00,$23,$00,$05
  DEFB $00,$01,$03,$00,$03,$0C,$00,$00
  DEFB $38,$08,$37,$50,$08,$08

; Message at A80F
  DEFM "9H:H;H<P"

; Data block at A817
  DEFB $01,$C8,$0C,$38,$01,$18,$05,$18
  DEFB $07,$10,$0D,$00,$06,$00,$34,$00
  DEFB $06,$00,$01,$09,$00,$02,$0C,$00
  DEFB $04,$03,$00,$00,$38,$08,$37,$50
  DEFB $08,$08

; Message at A839
  DEFM "9H:H;H<P"

; Data block at A841
  DEFB $ED,$08,$05,$08,$57,$48,$B6

; Message at A848
  DEFM "H4HGP"

; Data block at A84D
  DEFB $01,$C8,$0C,$38,$01,$18,$02,$18
  DEFB $05,$18,$07,$10,$0D,$00,$09,$00
  DEFB $19,$00,$09,$00,$00,$08,$08,$3D
  DEFB $48,$0A

; Message at A867
  DEFM "H4H>H?P"

; Data block at A86E
  DEFB $01,$C8,$0C,$38,$02,$18,$07,$10
  DEFB $0D,$00,$0A,$00,$29,$00,$0A,$00
  DEFB $02,$03,$00,$03,$09,$00,$00,$38
  DEFB $08,$37,$50,$40,$08

; Message at A88B
  DEFM "AHBH"

; Data block at A88F
  DEFB $0A

; Message at A890
  DEFM "HCHDH,H4H"

; Data block at A899
  DEFB $EF,$50,$01,$C8,$0C,$38,$02,$18
  DEFB $05,$10,$0D,$00,$0B,$00,$28,$00
  DEFB $0E,$00,$03,$05,$00,$00,$38,$08
  DEFB $37,$50,$08,$08

; Message at A8B5
  DEFM "9H:H;H<P"

; Data block at A8BD
  DEFB $82,$08,$16,$48,$14,$4A,$0A,$48
  DEFB $15

; Message at A8C6
  DEFM "JIP"

; Data block at A8C9
  DEFB $01,$C8,$0C,$38,$05,$10,$0D,$00
  DEFB $0C,$00,$21,$00,$0C,$00,$01,$06
  DEFB $00,$04,$05,$00,$00,$38,$08,$37
  DEFB $50,$08,$08

; Message at A8E4
  DEFM "9H:H;H<P"

; Data block at A8EC
  DEFB $01,$C8,$0C,$38,$01,$18,$07,$10
  DEFB $0D,$00,$0D,$00,$1F,$00,$0D,$00
  DEFB $04,$06,$00,$03,$12,$00,$00,$38
  DEFB $08

; Message at A905
  DEFM "7P,"

; Data block at A908
  DEFB $08

; Message at A909
  DEFM "4HFHGP"

; Data block at A90F
  DEFB $01,$C8,$0C,$38,$05,$18,$07,$10
  DEFB $0D,$00,$12,$00,$24,$00,$12,$00
  DEFB $01,$14,$00,$03,$15,$00,$04,$0D
  DEFB $00,$00,$38,$08

; Message at A92B
  DEFM "7P8"

; Data block at A92E
  DEFB $08

; Message at A92F
  DEFM "GHHHIP"

; Data block at A935
  DEFB $01,$C8,$0C,$38,$01,$18,$05,$18
  DEFB $07,$10,$0D,$00,$14,$00,$14,$00
  DEFB $14,$00,$02,$12,$00,$00,$16,$08

; Message at A94D
  DEFM "aHb"

; Data block at A950
  DEFB $10,$01,$C8,$0C,$38,$02,$10,$0D
  DEFB $00,$16,$00,$20,$00,$16,$00,$02
  DEFB $14,$00,$00,$63,$08,$0A,$48,$08

; Message at A968
  DEFM "HdP"

; Data block at A96B
  DEFB $82,$08

; Message at A96D
  DEFM "4Hb"

; Data block at A970
  DEFB $08

; Message at A971
  DEFM "IHcP"

; Data block at A975
  DEFB $01,$C8,$0C,$38,$02,$10,$0D,$00
  DEFB $15,$00,$1A,$00,$15,$00,$04,$12
  DEFB $00,$00,$08,$08,$3D,$48,$0A

; Message at A98C
  DEFM "H4H"

; Data block at A98F
  DEFB $5F,$48,$60,$50,$01,$C8,$0C,$38
  DEFB $07,$10,$0D,$00,$17,$00,$15,$00
  DEFB $17,$00,$00,$4D,$08

; Message at A9A4
  DEFM "8H$I"

; Data block at A9A8
  DEFB $0A

; Message at A9A9
  DEFM "H4H;I?P"

; Data block at A9B0
  DEFB $01,$C8,$0D,$00,$18,$00,$18,$00
  DEFB $18,$00,$17,$0F,$00,$00,$38,$08
  DEFB $C3,$49,$0A,$48,$08,$48,$40,$11
  DEFB $01,$C8,$0C,$38,$38,$12,$0D,$00
  DEFB $1A,$00,$15,$00,$1A,$00,$00,$4D
  DEFB $08,$38,$48,$CC

; Message at A9DC
  DEFM "I6H?P"

; Data block at A9E1
  DEFB $01,$C8,$0C,$38,$38,$12,$0D,$00
  DEFB $04,$00,$23,$00,$04,$00,$00,$08
  DEFB $08,$3D,$48,$0A

; Message at A9F5
  DEFM "H4H"

; Data block at A9F8
  DEFB $5F,$48,$60,$50,$ED,$08,$02,$08

; Message at AA00
  DEFM ",H4H>H"

; Data block at AA06
  DEFB $EF,$50,$01,$C8,$0C,$38,$02,$10
  DEFB $0D,$00,$07,$00,$25,$00,$4D,$00
  DEFB $01,$04,$00,$0E,$11,$00,$00,$4D
  DEFB $08

; Message at AA1F
  DEFM "4H5H"

; Data block at AA23
  DEFB $0A

; Message at AA24
  DEFM "H7X"

; Data block at AA27
  DEFB $FB,$49,$A3

; Message at AA2A
  DEFM "H4H>H"

; Data block at AA2F
  DEFB $F3,$50,$01,$C8,$0C,$38,$01,$10
  DEFB $0D,$00,$08,$00,$36,$00,$08,$00
  DEFB $04,$06,$00,$00,$4A,$08

; Message at AA45
  DEFM ".HMH4HGH"

; Data block at AA4D
  DEFB $B1,$48,$0F

; Message at AA50
  DEFM "J8H7P"

; Data block at AA55
  DEFB $FB,$09,$A3

; Message at AA58
  DEFM "HiI"

; Data block at AA5B
  DEFB $82,$48,$93,$48,$10,$4A,$11,$12
  DEFB $12,$0A,$13,$6A,$01,$E8,$01,$C8
  DEFB $0C,$38,$05,$18,$07,$10,$0D,$00
  DEFB $0E,$00,$1A,$00,$0B,$00,$03,$05
  DEFB $00,$00,$38,$08,$37,$50,$08,$08

; Message at AA83
  DEFM "9H:H<P"

; Data block at AA89
  DEFB $01,$C8,$0C,$38,$05,$10,$0D,$00
  DEFB $E9,$03,$07,$00,$E9,$03,$00,$03
  DEFB $C8,$00,$C0,$0F,$00,$20,$00,$EB
  DEFB $05,$18,$18,$00,$00,$38,$08

; Message at AAA8
  DEFM "FJ6H"

; Data block at AAAC
  DEFB $C3,$51,$82,$08

; Message at AAB0
  DEFM "4Hb"

; Data block at AAB3
  DEFB $08,$49,$50,$01,$C8,$0C,$38,$05
  DEFB $18,$37,$12,$0D,$00,$11,$00,$18
  DEFB $00,$11,$00,$03,$07,$00,$00,$38
  DEFB $08

; Message at AACC
  DEFM ")I6H"

; Data block at AAD0
  DEFB $F2,$48,$F3,$10,$01,$C8,$0C,$38
  DEFB $05,$10,$0D,$00,$10,$00,$22,$00
  DEFB $10,$00,$04,$0F,$00,$00,$08,$08
  DEFB $8A,$4A,$A3,$48,$08,$48,$40,$51
  DEFB $82,$08,$34,$48,$8C,$4A,$8D,$52
  DEFB $01,$C8,$0C,$38,$01,$18,$07,$10
  DEFB $0D,$00,$13,$00,$19,$00,$00,$00
  DEFB $00,$10,$8B,$0F,$08,$08,$48,$0B
  DEFB $4B,$DB,$50,$08,$08,$0C,$4B,$1B

; Message at AB18
  DEFM "HMH"

; Data block at AB1B
  DEFB $0D,$93,$00,$C0,$00,$00,$80,$00
  DEFB $80,$7E,$13,$3E,$80,$14,$3C,$38
  DEFB $80,$79,$16

; Message at AB2E
  DEFM "======="

; Data block at AB35
  DEFB $A7,$0F,$05,$37,$80,$01,$32,$80
  DEFB $03,$0B,$80,$64,$0B,$80,$04,$0B
  DEFB $80,$06,$0B,$80,$07,$0B,$80,$08
  DEFB $0B,$80,$09,$0B,$80,$0A,$0B,$80
  DEFB $0F,$0B,$80,$04,$80,$03,$0F,$80
  DEFB $03,$80,$02,$0F,$80,$0A,$80,$01
  DEFB $0F,$80,$01,$80,$01,$09,$80,$01
  DEFB $06,$3F,$80,$16,$24,$80,$14,$24
  DEFB $02,$80,$04,$0D,$01,$3E,$80,$01
  DEFB $11,$3F,$80,$00,$80,$01,$13

; Message at AB84
  DEFM ">=8"

; Data block at AB87
  DEFB $80,$70,$16,$3D,$83,$E8,$05

; Message at AB8E
  DEFM "=-?"

; Data block at AB91
  DEFB $80,$1A,$24,$3E,$80,$02,$11,$3F
  DEFB $80,$08,$24,$3E,$80,$03,$11,$3F
  DEFB $80,$00,$80,$03,$13,$3E,$3D,$80
  DEFB $77,$16,$80,$64,$05

; Message at ABAE
  DEFM "=-?"

; Data block at ABB1
  DEFB $80,$00,$80,$02,$13,$3E,$3D,$80
  DEFB $74,$16,$80,$C8,$05

; Message at ABBE
  DEFM "=-?"

; Data block at ABC1
  DEFB $80,$1A,$24,$80,$08,$0D,$01

; Message at ABC8
  DEFM ">=="

; Data block at ABCB
  DEFB $80,$92,$16,$80,$FA,$05

; Message at ABD1
  DEFM "=-?"

; Data block at ABD4
  DEFB $80,$13

; Message at ABD6
  DEFM "$>=======-?"

; Data block at ABE1
  DEFB $00,$00,$01,$00,$80,$07,$30,$3E
  DEFB $80,$64,$16,$2B,$3F,$80,$09,$30
  DEFB $80,$08,$2F,$01,$3E,$3D,$80,$08
  DEFB $16,$2B,$3F,$80,$0F,$30,$80,$02
  DEFB $2F,$01,$80,$02,$20,$01,$3E,$80
  DEFB $62,$16,$83,$E8,$05

; Message at AC0E
  DEFM "=-?"

; Data block at AC11
  DEFB $00,$02,$00,$80,$07,$30,$3E,$80
  DEFB $65,$16,$2B,$3F,$80,$09,$30,$80
  DEFB $07,$2F,$01,$3E,$3D,$80,$07,$16
  DEFB $2B,$3F,$80,$09,$30,$80,$06,$2F
  DEFB $01,$3E,$3D,$80,$06,$16,$2B,$3F
  DEFB $80,$09,$30,$80,$04,$2F,$01,$3E
  DEFB $3D,$80,$04,$16,$2B,$3F,$80,$09
  DEFB $30,$80,$05,$2F,$01,$3E,$3D,$80
  DEFB $05,$16,$2B,$3F,$80,$0C,$30,$80
  DEFB $05,$2F,$01,$80,$0A,$0D,$01,$3E
  DEFB $80,$EC,$16,$80,$0A,$0C,$80,$03
  DEFB $80,$02,$09,$2B,$3F,$80,$0D,$30
  DEFB $80,$08,$2F,$01,$80,$04,$0D,$01
  DEFB $3E,$80,$EB,$16,$2B,$3F,$80,$0D
  DEFB $30,$80,$04,$0E,$01,$3E,$80,$03
  DEFB $32,$80,$04,$0B,$2B,$3F,$80,$0B
  DEFB $30,$80,$06,$2F,$01,$80,$04,$0D
  DEFB $01,$3E,$80,$04,$0C,$80,$63,$16
  DEFB $2B,$3F,$80,$0F,$30,$80,$02,$2F
  DEFB $01,$80,$02,$20,$01,$3E,$80,$62
  DEFB $16,$83,$E8,$05

; Message at ACB5
  DEFM "=-?"

; Data block at ACB8
  DEFB $00,$03,$00,$80,$0E,$30,$3E,$80
  DEFB $02,$32,$80,$04,$0C,$2B,$3F,$00
  DEFB $0A,$00,$80,$07,$30,$3E,$80,$66
  DEFB $16,$2B,$3F,$80,$09,$30,$80,$0A
  DEFB $2F,$01,$3E,$80,$0A,$16,$2B,$3F
  DEFB $80,$04,$30,$80,$01,$30,$02,$3E
  DEFB $80,$61,$16,$2B,$3F,$00,$0D,$00
  DEFB $80,$07,$30,$3E,$80,$5A,$16,$2B
  DEFB $3F,$00,$12,$00,$80,$07,$30,$3E
  DEFB $80,$5B,$16,$2B,$3F,$00,$14,$00
  DEFB $80,$07,$30,$3E,$80,$67,$16,$2B
  DEFB $3F,$80,$0E,$30,$80,$0A,$2F,$01
  DEFB $3E,$80,$16

; Message at AD1B
  DEFM "2+?"

; Data block at AD1E
  DEFB $80,$09,$30,$80,$0A,$2F,$01,$3E
  DEFB $80,$6F,$16,$2B,$3F,$00,$15,$00
  DEFB $80,$07,$30,$3E,$80,$6A,$16,$2B
  DEFB $3F,$80,$09,$30,$80,$0E,$2F,$01
  DEFB $3E,$80,$58,$16,$2B,$3F,$80,$09
  DEFB $30,$80,$11,$2F,$01,$80,$06,$0D
  DEFB $01,$3E,$80,$06,$0C,$80,$EC,$16
  DEFB $80,$10,$80,$15,$09,$2B,$3F,$80
  DEFB $05,$30,$80,$10,$2F,$01,$80,$04
  DEFB $0D,$01,$3E,$80,$6C,$16,$2B,$3F
  DEFB $80,$05,$30,$80,$10,$2F,$01,$80
  DEFB $04,$0E,$01,$80,$10,$1E,$01,$80
  DEFB $14,$0E,$01,$3E,$80,$6D,$16,$80
  DEFB $14,$0B,$3F,$80,$0E,$30,$80,$10
  DEFB $2F,$01,$80,$10,$1E,$01,$80,$14
  DEFB $0D,$01,$3E,$80,$05,$0B,$80,$14
  DEFB $0C,$80,$71,$16,$3D,$80,$C8,$05
  DEFB $3D,$80,$17

; Message at ADA9
  DEFM "2+?"

; Data block at ADAC
  DEFB $80,$0E,$30,$80,$10,$2F,$01,$80
  DEFB $14,$0E,$01,$3E,$80,$EB,$16,$2B
  DEFB $3F,$00,$16,$00,$80,$07,$30,$80
  DEFB $04,$0D,$01,$3E,$80,$68,$16,$2B
  DEFB $3F,$80,$0F,$30,$80,$02,$2F,$01
  DEFB $80,$02,$20,$01,$3E,$38,$80,$57
  DEFB $16,$83,$E8,$05

; Message at ADE0
  DEFM "=-?"

; Data block at ADE3
  DEFB $80,$11,$30,$80,$0F,$2F,$01,$80
  DEFB $03,$20,$01,$80,$04,$0D,$01,$3E
  DEFB $80,$56,$16,$80,$04,$0C,$2B,$3F
  DEFB $80,$07,$30,$80,$04,$0E,$01,$3E
  DEFB $80,$6B,$16,$2B,$3F,$80,$11,$30
  DEFB $80,$0F,$2F,$01,$80,$03,$20,$03
  DEFB $01,$3E,$80,$E9,$16,$2B,$3F,$00
  DEFB $09,$00,$80,$07,$30,$3E,$80,$69
  DEFB $16,$2B,$3F,$80,$09,$30,$80,$0D
  DEFB $2F,$01,$3E,$80,$59,$16,$2B,$3F
  DEFB $80,$14,$30,$80,$09,$2F,$01,$80
  DEFB $05,$0D,$01,$3E,$80,$17

; Message at AE41
  DEFM "2+?"

; Data block at AE44
  DEFB $80,$0D,$30,$80,$10,$2F,$01,$80
  DEFB $05,$0D,$01,$3E,$80,$05,$0C,$80
  DEFB $10,$80,$09,$09,$2A,$3F,$80,$0E
  DEFB $30,$80,$10,$2F,$01,$80,$05,$0E
  DEFB $01,$80,$10,$1E,$01,$3E,$80,$05
  DEFB $0B,$2A,$3F,$80,$02,$30,$80,$05
  DEFB $0E,$01,$3E,$80,$06

; Message at AE79
  DEFM "2+?"

; Data block at AE7C
  DEFB $80,$04,$30,$80,$05,$0E,$01,$3E
  DEFB $80,$0A

; Message at AE86
  DEFM "2+?"

; Data block at AE89
  DEFB $80,$01,$30,$80,$05,$0D,$01,$3E
  DEFB $80,$0D,$16,$2B,$3F,$00,$13,$00
  DEFB $80,$09,$30,$80,$0E,$2F,$01,$3E
  DEFB $80,$58,$16,$2B,$3F,$00,$17,$00
  DEFB $80,$01,$30,$80,$02,$30,$02,$80
  DEFB $04,$30,$02,$3E,$80,$0D,$16,$2B
  DEFB $3F,$80,$14,$30,$80,$12,$2F,$01
  DEFB $80,$05,$0D,$01,$3E,$80,$09

; Message at AEC8
  DEFM "2+?"

; Data block at AECB
  DEFB $80,$0D,$30,$80,$10,$2F,$01,$80
  DEFB $05,$0D,$01,$3E,$80,$05,$0C,$80
  DEFB $10,$80,$17,$09,$80,$0E,$16,$2B
  DEFB $3F,$80,$0E,$30,$80,$10,$2F,$01
  DEFB $80,$05,$0E,$01,$80,$10,$1E,$01
  DEFB $3E,$80,$05,$0B,$80,$10,$80,$00
  DEFB $09,$2A,$3F,$80,$14,$30,$80,$09
  DEFB $2F,$01,$80,$05,$0D,$01,$3E,$80
  DEFB $18

; Message at AF0C
  DEFM "2+?"

; Data block at AF0F
  DEFB $80,$16,$30,$80,$05,$0E,$01,$80
  DEFB $10,$1E,$01,$3E,$80,$1A

; Message at AF1D
  DEFM "2+?"

; Data block at AF20
  DEFB $80,$07,$30,$3E,$80,$72,$16,$2B
  DEFB $3F,$80,$09,$30,$80,$0D,$2F,$01
  DEFB $80,$64,$0D,$01,$3E,$80,$73,$16
  DEFB $2B,$3F,$80,$14,$30,$80,$14,$2F
  DEFB $01,$80,$05,$0D,$01,$3E,$80,$04

; Message at AF48
  DEFM "2+?"

; Data block at AF4B
  DEFB $80,$06,$30,$80,$05,$0E,$01,$80
  DEFB $0C,$2F,$01,$80,$0C,$20,$01,$3E
  DEFB $80,$0C,$80,$1A,$09,$80,$64,$0B
  DEFB $80,$8D,$16,$2B,$3F,$80,$16,$30
  DEFB $80,$05,$0D,$01,$3E,$80,$EB,$16
  DEFB $2B,$3F,$80,$0C,$30,$80,$1D,$2F
  DEFB $01,$80,$1D,$20,$01,$3E,$80,$08
  DEFB $0C,$80,$1D,$80,$00,$09,$80,$93
  DEFB $16,$2B,$3F,$80,$09,$30,$80,$0D
  DEFB $2F,$01,$80,$64,$0E,$01,$3E,$80
  DEFB $95,$16,$2B,$3F,$80,$06

; Message at AFA1
  DEFM "03/"

; Data block at AFA4
  DEFB $01,$33,$20,$01,$80,$05,$0E,$01
  DEFB $3E,$33,$80,$1A,$09,$80,$8D,$16
  DEFB $2B,$3F,$80,$05,$30,$80,$10,$2F
  DEFB $01,$3E,$80,$E9,$16,$2B,$3F,$00
  DEFB $04,$00,$80,$0D,$30,$80,$10,$2F
  DEFB $01,$80,$05,$0D,$01,$3E,$80,$05
  DEFB $0C,$80,$10,$80,$04,$09,$2A,$3F
  DEFB $80,$0E,$30,$80,$10,$2F,$01,$80
  DEFB $05,$0E,$01,$80,$10,$1E,$01,$3E
  DEFB $80,$05,$0B,$80,$10,$80,$00,$09
  DEFB $2A,$3F,$80,$02,$30,$80,$05,$0E
  DEFB $01,$3E,$80,$07

; Message at B000
  DEFM "2+?"

; Data block at B003
  DEFB $80,$14,$30,$80,$13,$2F,$01,$80
  DEFB $05,$0D,$01,$3E,$80,$17

; Message at B011
  DEFM "2+?"

; Data block at B014
  DEFB $80,$03,$30,$80,$05,$0D,$01,$3E
  DEFB $80,$0D,$16,$2B,$3F,$80,$07,$30
  DEFB $3E,$80,$7B,$16,$2B,$3F,$80,$09
  DEFB $30,$80,$0E,$2F,$01,$3E,$80,$7C
  DEFB $16,$2B,$3F,$00,$18,$00,$80,$02
  DEFB $30,$80,$05,$0D,$01,$3E,$80,$0D
  DEFB $16,$2B,$3F,$80,$14,$30,$80,$12
  DEFB $2F,$01,$80,$05,$0D,$01,$3E,$80
  DEFB $17

; Message at B055
  DEFM "2+?"

; Data block at B058
  DEFB $80,$07,$30,$3E,$80,$7F,$16,$2B
  DEFB $3F,$00,$06,$00,$80,$03,$30,$80
  DEFB $0F,$0D,$01,$3E,$80,$08

; Message at B06E
  DEFM "2+?"

; Data block at B071
  DEFB $80,$03,$30,$80,$0F,$0E,$01,$3E
  DEFB $80,$0D

; Message at B07B
  DEFM "2+?"

; Data block at B07E
  DEFB $00,$08,$00,$80,$03,$30,$3E,$80
  DEFB $EB,$16,$2B,$3F,$80,$06,$30,$80
  DEFB $15,$2F,$01,$80,$15,$20,$01,$3E
  DEFB $80,$15,$80,$00,$09,$80,$0F,$0C
  DEFB $80,$75,$16,$80,$C8,$05,$3D,$80
  DEFB $0D

; Message at B0A7
  DEFM "2+?"

; Data block at B0AA
  DEFB $80,$0F,$30,$80,$02,$2F,$01,$80
  DEFB $02,$20,$01,$3E,$3D,$80,$78,$16
  DEFB $80,$64,$05

; Message at B0BD
  DEFM "=-?"

; Data block at B0C0
  DEFB $80,$09,$30,$80,$16,$2F,$01,$3E
  DEFB $80,$7A,$16,$2B,$3F,$00,$0B,$00
  DEFB $80,$0F,$30,$80,$02,$2F,$01,$80
  DEFB $02,$20,$01,$3E,$80,$07,$0C,$80
  DEFB $76,$16,$80,$64,$05,$3D,$80,$0E

; Message at B0E8
  DEFM "2+?"

; Data block at B0EB
  DEFB $80,$05,$30,$80,$15,$2F,$01,$3E
  DEFB $80,$EB,$16,$2B,$3F,$80,$09,$30
  DEFB $80,$15,$2F,$01,$3E,$80,$15,$16
  DEFB $2B,$3F,$00,$05,$00,$80,$04,$30
  DEFB $80,$07,$0D,$01,$3E,$80,$0B

; Message at B112
  DEFM "2+?"

; Data block at B115
  DEFB $80,$04,$30,$80,$07,$0E,$01,$3E
  DEFB $80,$0E

; Message at B11F
  DEFM "2+?"

; Data block at B122
  DEFB $00,$07,$00,$80,$07,$30,$3E,$80
  DEFB $7D,$16,$2B,$3F,$80,$09,$30,$80
  DEFB $0A,$2F,$01,$3E,$80,$7E,$16,$2B
  DEFB $3F,$00,$0F,$00,$80,$07,$30,$3E
  DEFB $80,$80,$16,$2B,$3F,$80,$09,$30
  DEFB $80,$0F,$2F,$01,$80,$0C,$0E,$01
  DEFB $3E,$80,$81,$16,$2B,$3F,$80,$09
  DEFB $30,$80,$17,$2F,$01,$3E,$80,$82
  DEFB $16,$2B,$3F,$80,$03,$30,$80,$0C
  DEFB $0E,$01,$3E,$80,$83,$16,$2B,$3F
  DEFB $80,$06,$30,$80,$0C,$2F,$01,$80
  DEFB $0C,$20,$01,$3E,$80,$0C,$80,$00
  DEFB $09,$80,$18,$80,$0F,$09,$80,$0C
  DEFB $0B,$80,$84,$16,$2B,$3F,$80,$09
  DEFB $30,$80,$0F,$2F,$01,$80,$0C,$0D
  DEFB $01,$3E,$80,$85,$16,$2B,$3F,$80
  DEFB $03,$30,$80,$0C,$0D,$01,$3E,$80
  DEFB $10

; Message at B1AB
  DEFM "2+?"

; Data block at B1AE
  DEFB $80,$0F,$30,$80,$02,$2F,$01,$80
  DEFB $02,$20,$01,$3E,$80,$8C,$16,$81
  DEFB $F4,$05

; Message at B1C0
  DEFM "==-?"

; Data block at B1C4
  DEFB $00,$10,$00,$80,$07,$30,$3E,$80
  DEFB $86,$16,$2B,$3F,$80,$09,$30,$80
  DEFB $19,$2F,$01,$3E,$80,$87,$16,$2B
  DEFB $3F,$80,$09,$30,$80,$17,$2F,$01
  DEFB $3E,$80,$88,$16,$2B,$3F,$80,$01
  DEFB $30,$80,$02,$20,$01,$3E,$80,$89
  DEFB $16,$2B,$3F,$80,$06,$30,$80,$02
  DEFB $2F,$01,$80,$02,$20,$01,$3E,$80
  DEFB $02,$80,$00,$09,$80,$8A,$16,$2B
  DEFB $3F,$80,$0F,$30,$80,$02,$2F,$01
  DEFB $80,$02,$20,$01,$3E,$80,$8B,$16
  DEFB $81,$F4,$05

; Message at B21F
  DEFM "==-?"

; Data block at B223
  DEFB $80,$01,$30,$80,$02,$20,$03,$01

; Message at B22B
  DEFM ">========"

; Data block at B234
  DEFB $80,$13,$32,$3F,$00,$1A,$00,$80
  DEFB $17,$30,$3E,$80,$03,$80,$02,$0F
  DEFB $80,$17

; Message at B246
  DEFM "2+?"

; Data block at B249
  DEFB $80,$05,$30,$80,$0C,$2F,$01,$80
  DEFB $0C,$1E,$01,$3E,$80,$0C,$06,$80
  DEFB $64,$0C,$2A,$3F,$00,$11,$00,$80
  DEFB $07,$30,$3E,$80,$8E,$16,$2B,$3F
  DEFB $80,$09,$30,$80,$1A,$2F,$01,$3E
  DEFB $80,$8F,$16,$2B,$3F,$80,$09,$30
  DEFB $80,$1B,$2F,$01,$80,$09,$0D,$01
  DEFB $3E,$80,$EC,$16,$80,$1D,$80,$11
  DEFB $09,$80,$09,$0C

; Message at B28D
  DEFM "+?5"

; Data block at B290
  DEFB $80,$1A,$19,$80,$1A,$2F,$01,$3E
  DEFB $80,$96,$16,$2B,$3F,$00,$00,$00
  DEFB $80,$08,$30,$3E,$80,$EF,$16

; Message at B2A7
  DEFM ";6+?3"

; Data block at B2AC
  DEFB $80,$00,$1B,$80,$09,$30,$01,$3E
  DEFB $80,$EE,$16

; Message at B2B7
  DEFM "+?3"

; Data block at B2BA
  DEFB $80,$1E,$19,$80,$09,$30,$01,$33
  DEFB $20,$01

; Message at B2C4
  DEFM ">=3"

; Data block at B2C7
  DEFB $16

; Message at B2C8
  DEFM "+?3"

; Data block at B2CB
  DEFB $80,$00,$1B,$80,$05,$30,$01,$3E
  DEFB $80,$EE,$16

; Message at B2D6
  DEFM "+?3"

; Data block at B2D9
  DEFB $80,$1E,$19,$80,$05,$30,$01,$33
  DEFB $1E,$01,$3E,$33,$06

; Message at B2E6
  DEFM "*?3"

; Data block at B2E9
  DEFB $80,$00,$1B,$80,$06,$30,$01,$3E
  DEFB $80,$EE,$16

; Message at B2F4
  DEFM "+?3"

; Data block at B2F7
  DEFB $80,$1E,$19,$80,$06,$30,$01,$33
  DEFB $20,$01,$3E,$33,$07,$2A,$3F,$80
  DEFB $0A

; Message at B308
  DEFM "0>,?"

; Data block at B30C
  DEFB $80,$03,$24,$80,$05,$24,$02,$80
  DEFB $06,$24,$02,$80,$0B,$24,$02,$80
  DEFB $0C,$24,$02,$80,$0E,$24,$02,$80
  DEFB $07,$30,$01,$3E,$80,$09,$16,$2B
  DEFB $3F,$80,$10,$30,$3E,$15,$2B,$3F
  DEFB $80,$0F,$30,$80,$02,$2F,$01,$80
  DEFB $02,$20,$01,$3E,$80,$60,$16,$2B
  DEFB $3F,$80,$08,$24,$80,$0D,$24,$02
  DEFB $80,$12,$24,$02,$80,$09,$30,$01
  DEFB $80,$0B,$2F,$01,$3E,$80,$0B,$16
  DEFB $2B,$3F,$80,$09,$30,$80,$10,$2F
  DEFB $01,$80,$10,$1E,$01,$3E,$80,$6E
  DEFB $16,$2B,$3F,$80,$09,$30,$33,$01
  DEFB $80,$1E,$19,$33,$1E,$01,$3E,$80
  DEFB $FC,$16,$2B,$3F,$80,$12,$30,$3E
  DEFB $1D,$15,$2B,$3F,$80,$13,$30,$3E
  DEFB $1C,$15

; Message at B38E
  DEFM "=*?"

; Data block at B391
  DEFB $80,$19,$30,$3E,$80,$ED,$16,$2B
  DEFB $3F,$80,$05

; Message at B39C
  DEFM "03/"

; Data block at B39F
  DEFB $01,$33,$20,$01,$3E,$80,$F5,$16
  DEFB $2B,$3F,$80,$09,$30,$3E,$80,$EA
  DEFB $16,$2B,$3F,$80,$00,$80,$06

; Message at B3B6
  DEFM "03/"

; Data block at B3B9
  DEFB $01,$33,$20,$03,$01,$3E,$80,$F6
  DEFB $16,$2B,$3F,$80,$0C,$30,$80,$1D
  DEFB $2F,$01,$80,$1D,$20,$01,$3E,$80
  DEFB $1D,$80,$00,$09,$80,$91,$16,$3F
  DEFB $80,$05,$30,$80,$10,$2F,$01,$3E
  DEFB $80,$F8,$16,$2B,$3F,$00,$00,$F0
  DEFB $02,$10,$00,$F1,$0A,$11,$08,$30
  DEFB $48,$B2,$48,$B3,$50,$00,$C0,$F2
  DEFB $08,$13,$08,$08,$48,$14,$50,$00
  DEFB $C0,$F3,$18,$08,$88,$D6,$89,$AA
  DEFB $8A,$BE,$92,$15,$08,$16,$48,$17
  DEFB $48,$18,$48,$19,$48,$0A,$48,$1A
  DEFB $50,$00,$C0,$F4,$08,$1B,$08,$1C
  DEFB $70,$01,$C8,$1D,$80,$F5,$0A,$1E
  DEFB $08,$1F

; Message at B42B
  DEFM "Heh"

; Data block at B42E
  DEFB $01,$D0,$00,$C0,$F6,$0A,$11,$08
  DEFB $1F

; Message at B437
  DEFM "Heh"

; Data block at B43A
  DEFB $01,$D0,$00,$C0,$F7,$08,$11,$08
  DEFB $1B

; Message at B443
  DEFM "HIh"

; Data block at B446
  DEFB $00,$C0,$F8,$06,$24,$08,$25,$68
  DEFB $00,$C0,$FB,$0C,$1B,$08,$2B,$58
  DEFB $11

; Message at B457
  DEFM "H,H-P"

; Data block at B45C
  DEFB $00,$C0,$FC,$0A,$4B,$08,$0A,$48
  DEFB $02,$4A,$03,$6A,$00,$C0,$FD,$08
  DEFB $2F,$08

; Message at B46E
  DEFM "0H1x"

; Data block at B472
  DEFB $00,$C0,$FE,$04,$32,$28,$00,$C0
  DEFB $64,$1C,$02,$C8,$16,$08,$72,$48
  DEFB $09,$50,$43,$08

; Message at B486
  DEFM "wHxHyH4HzH"

; Data block at B490
  DEFB $7B,$48,$7C,$50,$04,$C8,$00,$C0
  DEFB $63,$12,$79,$08,$34,$48,$C2,$48
  DEFB $C3

; Message at B4A1
  DEFM "XAH"

; Data block at B4A4
  DEFB $C4

; Message at B4A5
  DEFM "HWH"

; Data block at B4A8
  DEFB $C5,$50,$00,$C0,$65,$2A,$02,$C8
  DEFB $08,$08,$0E,$50,$4D,$08,$08,$48
  DEFB $81,$48,$07,$08,$82,$48,$84,$48
  DEFB $85,$48,$18,$48,$0F,$50,$4D,$08
  DEFB $08,$48,$81,$48,$05,$08

; Message at B4CE
  DEFM "0H1H"

; Data block at B4D2
  DEFB $16,$48,$86,$50,$00,$C0,$EF,$06
  DEFB $66,$08,$87,$78,$00,$C0,$01,$20
  DEFB $3A,$08,$34,$48,$8A,$48,$8E

; Message at B4E9
  DEFM "HyH8H"

; Data block at B4EE
  DEFB $90,$48,$0A,$48,$91,$08,$92,$50
  DEFB $D8,$09,$D9,$49,$A3

; Message at B4FB
  DEFM "HiI"

; Data block at B4FE
  DEFB $DA,$69,$00,$C0,$02,$14,$3A,$08
  DEFB $16,$48,$8B,$48,$0A,$48,$95,$48
  DEFB $96,$08,$B4,$10,$3B,$08,$98,$50
  DEFB $00,$C0,$03,$16,$34,$08,$8C,$48
  DEFB $0A,$48,$99,$48,$9A,$50,$9B,$08
  DEFB $9C,$58,$01,$C8,$9D,$58,$EB,$51
  DEFB $00,$C0,$04,$1C,$3A,$08,$16,$48
  DEFB $86,$48,$9E,$58,$0A,$48,$9F,$48
  DEFB $A0,$50,$A2,$08,$A3,$48,$A4,$48
  DEFB $82

; Message at B547
  DEFM "H4H"

; Data block at B54A
  DEFB $8D,$50,$00,$C0,$05,$22,$55,$08
  DEFB $84,$48,$93,$49,$94,$49,$95,$49
  DEFB $18,$48,$97,$49,$0F

; Message at B55F
  DEFM "H)H"

; Data block at B562
  DEFB $98,$49,$7F

; Message at B565
  DEFM "H4H=I"

; Data block at B56A
  DEFB $0A,$48,$08,$48,$0E,$50,$00,$C0
  DEFB $06,$0E,$3A,$08,$34,$48,$AA,$48
  DEFB $0A,$48,$7B,$48,$7C,$50,$00,$C0
  DEFB $07,$08,$1B,$08,$AC,$48,$AD,$50
  DEFB $00,$C0,$EE,$08,$38,$08,$B1,$70
  DEFB $03,$D0,$00,$C0,$EC,$08,$49,$08
  DEFB $82,$48,$BD,$68,$00,$C0,$08,$2E
  DEFB $43,$08,$B3,$49,$B4,$49,$08,$48
  DEFB $09

; Message at B5AB
  DEFM "HyH4H"

; Data block at B5B0
  DEFB $B5,$49,$7B,$48,$7C,$58,$1F,$48
  DEFB $B1,$48,$B6,$49,$B7,$49,$B1,$48
  DEFB $7F,$48,$B8,$49,$B9,$51,$02,$D0
  DEFB $0A

; Message at B5C9
  DEFM "Hei"

; Data block at B5CC
  DEFB $01,$E8,$00,$C0,$EB,$06,$BE,$08
  DEFB $11,$68,$00,$C0,$09,$1E,$CB,$08
  DEFB $CC,$48,$CD,$48,$CE,$48,$CF

; Message at B5E3
  DEFM "HAH"

; Data block at B5E6
  DEFB $D0,$48,$DB,$49,$D2,$48,$0A,$48
  DEFB $D3

; Message at B5EF
  DEFM "HMH"

; Data block at B5F2
  DEFB $D3,$50,$02,$D0,$00,$C0

; Message at B5F8
  DEFM "b,4"

; Data block at B5FB
  DEFB $08,$D7,$48,$0A,$48,$95,$48,$D8

; Message at B603
  DEFM "H6H"

; Data block at B606
  DEFB $D9,$58,$01,$C8,$DA,$48,$DB,$48
  DEFB $0A

; Message at B60F
  DEFM "HCH"

; Data block at B612
  DEFB $DC,$48,$DD,$48,$0A,$48,$08,$48
  DEFB $0B,$50,$41,$08,$E6

; Message at B61F
  DEFM "HJH"

; Data block at B622
  DEFB $E7,$68,$00,$C0

; Message at B626
  DEFM "f.C"

; Data block at B629
  DEFB $08,$E8

; Message at B62B
  DEFM "HWH"

; Data block at B62E
  DEFB $E9

; Message at B62F
  DEFM "HIP)"

; Data block at B633
  DEFB $88,$EC,$68,$01,$C8,$40,$08

; Message at B63A
  DEFM "AHBH"

; Data block at B63E
  DEFB $0A

; Message at B63F
  DEFM "HCHDX"

; Data block at B644
  DEFB $ED,$48,$07,$18

; Message at B648
  DEFM "0H1H"

; Data block at B64C
  DEFB $EE

; Message at B64D
  DEFM "H4H>H"

; Data block at B652
  DEFB $EF,$50,$00,$C0,$0A,$20,$3A,$08
  DEFB $16

; Message at B65B
  DEFM "H>HEH"

; Data block at B660
  DEFB $0A,$48,$F0,$58,$0A,$48,$F1

; Message at B667
  DEFM "H;H"

; Data block at B66A
  DEFB $F2,$50,$16,$08,$A5,$48,$0A,$48
  DEFB $F3,$58,$F4,$50,$00,$C0,$61,$14
  DEFB $43,$08,$E8,$48,$F5

; Message at B67F
  DEFM "HJH"

; Data block at B682
  DEFB $F6,$48,$F7

; Message at B685
  DEFM "HMH"

; Data block at B688
  DEFB $F8,$48,$F9,$50,$00,$C0,$60,$18
  DEFB $FA,$A8,$02,$E8,$01,$C8,$38,$08
  DEFB $95,$48,$D8,$68,$03,$D0,$01,$09
  DEFB $11,$48,$00

; Message at B6A3
  DEFM "K-P"

; Data block at B6A6
  DEFB $00,$C0,$0B,$1C,$3A,$08,$34,$48
  DEFB $10,$49,$11,$49,$12,$49,$CF

; Message at B6B5
  DEFM "HCH"

; Data block at B6B8
  DEFB $13,$51,$82,$08,$16,$49,$0A,$48
  DEFB $17,$49,$62,$10,$00,$C0,$5B,$1A
  DEFB $02,$09

; Message at B6CA
  DEFM "MH4H"

; Data block at B6CE
  DEFB $18

; Message at B6CF
  DEFM "I6HGX"

; Data block at B6D4
  DEFB $B1,$48,$19,$49,$ED,$48,$01,$08
  DEFB $29,$48,$ED,$48,$07,$00,$5A,$16
  DEFB $02,$09

; Message at B6E6
  DEFM "MH8HGX"

; Data block at B6EC
  DEFB $B1,$48,$1D,$49,$0A,$48,$07,$08
  DEFB $A3,$48,$05,$10,$00,$C0,$67,$2E
  DEFB $08,$08

; Message at B6FE
  DEFM "aHb"

; Data block at B701
  DEFB $10,$4D,$08

; Message at B704
  DEFM "8H$I"

; Data block at B708
  DEFB $82,$48,$16

; Message at B70B
  DEFM "HdH'I(I"

; Data block at B712
  DEFB $B1

; Message at B713
  DEFM "HAH"

; Data block at B716
  DEFB $80,$50,$42,$09,$7F,$48,$14

; Message at B71D
  DEFM "ICYDI"

; Data block at B722
  DEFB $B1

; Message at B723
  DEFM "HJH"

; Data block at B726
  DEFB $A7,$51,$00,$C0

; Message at B72A
  DEFM "hBM"

; Data block at B72D
  DEFB $08

; Message at B72E
  DEFM "8H)I"

; Data block at B732
  DEFB $0A,$48,$08

; Message at B735
  DEFM "HdH"

; Data block at B738
  DEFB $82

; Message at B739
  DEFM "H4Hb"

; Data block at B73D
  DEFB $08

; Message at B73E
  DEFM "+IMH"

; Data block at B742
  DEFB $16,$48,$EF,$51,$2D,$09,$26,$48
  DEFB $F1,$48,$14

; Message at B74D
  DEFM "I;H.QS"

; Data block at B753
  DEFB $08

; Message at B754
  DEFM "/IJH0IyH1I2I3I"

; Data block at B762
  DEFB $BD,$50,$44,$09,$B1

; Message at B767
  DEFM "HJH"

; Data block at B76A
  DEFB $A7,$51,$00,$C0

; Message at B76E
  DEFM "i2J"

; Data block at B771
  DEFB $08,$2E,$48,$A3,$48,$08

; Message at B777
  DEFM "H=H"

; Data block at B77A
  DEFB $0A

; Message at B77B
  DEFM "H4H;I?P"

; Data block at B782
  DEFB $ED,$08

; Message at B784
  DEFM "<I=Y"

; Data block at B788
  DEFB $1A

; Message at B789
  DEFM "I8H"

; Data block at B78C
  DEFB $01,$18

; Message at B78E
  DEFM ",HAH>I?I"

; Data block at B796
  DEFB $0A,$48,$08,$48,$40,$49,$0A,$48
  DEFB $E7,$11,$00,$C0

; Message at B7A2
  DEFM "Y,8"

; Data block at B7A5
  DEFB $08,$3F,$48,$14

; Message at B7A9
  DEFM "I;HGI)HSHHIUHII)HJQ"

; Data block at B7BC
  DEFB $AF,$08,$1B

; Message at B7BF
  DEFM "HPI"

; Data block at B7C2
  DEFB $B1,$48,$1F

; Message at B7C5
  DEFM "HQIRY9"

; Data block at B7CB
  DEFB $89,$53,$A9,$00,$C0,$6A,$26,$A3
  DEFB $88,$08

; Message at B7D5
  DEFM "H=H"

; Data block at B7D8
  DEFB $0A

; Message at B7D9
  DEFM "H4H"

; Data block at B7DC
  DEFB $60,$48,$B1

; Message at B7DF
  DEFM "HTIyHUI"

; Data block at B7E6
  DEFB $1A

; Message at B7E7
  DEFM "I8H"

; Data block at B7EA
  DEFB $01,$10,$82,$08,$16

; Message at B7EF
  DEFM "H<H9HIP"

; Data block at B7F6
  DEFB $00,$C0,$58,$1A,$54,$09

; Message at B7FC
  DEFM "yH>HUQ"

; Data block at B802
  DEFB $AF,$08,$57,$49,$B1

; Message at B807
  DEFM "HXIMH8X9"

; Data block at B80F
  DEFB $89,$53,$A9,$00,$C0

; Message at B814
  DEFM "W48"

; Data block at B817
  DEFB $08,$5A,$49,$F1

; Message at B81B
  DEFM "I8H"

; Data block at B81E
  DEFB $F3

; Message at B81F
  DEFM "I6H.Y"

; Data block at B824
  DEFB $B1,$48,$F4,$49,$ED,$48,$F5,$51
  DEFB $0A,$08,$08

; Message at B82F
  DEFM "H-HaIbIqIb"

; Data block at B839
  DEFB $08,$B1

; Message at B83B
  DEFM "HJH"

; Data block at B83E
  DEFB $F8

; Message at B83F
  DEFM "IMHSH"

; Data block at B844
  DEFB $F9,$69,$01,$E8,$00,$C0

; Message at B84A
  DEFM "V2D"

; Data block at B84D
  DEFB $0A,$08,$48,$ED,$49,$0A,$48,$08
  DEFB $48,$EF,$51,$38,$08

; Message at B85A
  DEFM ".IJHzIyH/IEZ"

; Data block at B866
  DEFB $F0,$49,$B1

; Message at B869
  DEFM "HCHqI"

; Data block at B86E
  DEFB $B1,$58,$BE,$49,$0A,$48,$08

; Message at B875
  DEFM "H-XJH"

; Data block at B87A
  DEFB $7F,$51,$00,$C0

; Message at B87E
  DEFM "k&M"

; Data block at B881
  DEFB $08

; Message at B882
  DEFM "8H)I"

; Data block at B886
  DEFB $0A,$48,$08

; Message at B889
  DEFM "HdH6H.Ib"

; Data block at B891
  DEFB $10,$05,$18

; Message at B894
  DEFM "yH&H"

; Data block at B898
  DEFB $EF,$49,$FA

; Message at B89B
  DEFM "IJH"

; Data block at B89E
  DEFB $81

; Message at B89F
  DEFM "IyH"

; Data block at B8A2
  DEFB $82,$51,$00,$C0,$6C,$10,$1F,$08
  DEFB $86,$69,$01,$C8,$01,$49,$1B,$48
  DEFB $87,$49,$88,$51,$00,$C0,$6D,$2C
  DEFB $ED,$08,$31,$48,$B1,$48,$04,$4B
  DEFB $0A,$49,$08,$48,$83

; Message at B8C7
  DEFM "Y4Hb"

; Data block at B8CB
  DEFB $08,$57,$48,$8B,$59,$8C,$49,$08
  DEFB $48,$8D

; Message at B8D5
  DEFM "I)H"

; Data block at B8D8
  DEFB $A8,$4A,$08,$48,$83

; Message at B8DD
  DEFM "IMH8H"

; Data block at B8E2
  DEFB $60,$50,$00,$C0,$6E,$18,$3A,$08
  DEFB $16,$48,$83,$49,$62,$08,$3B,$48
  DEFB $90

; Message at B8F3
  DEFM "YyH"

; Data block at B8F6
  DEFB $91,$49,$18

; Message at B8F9
  DEFM "H4H"

; Data block at B8FC
  DEFB $92,$51,$00,$C0,$6F,$1C,$08,$08

; Message at B904
  DEFM "dH:H"

; Data block at B908
  DEFB $AC

; Message at B909
  DEFM "H(I)X-I&H"

; Data block at B912
  DEFB $F1,$58,$9C,$49,$0A,$48,$9D,$49
  DEFB $9E,$51,$00,$C0,$70,$2C,$A8,$09
  DEFB $2D,$49,$A9,$49,$0A

; Message at B927
  DEFM "HSH"

; Data block at B92A
  DEFB $AA,$59,$AB

; Message at B92D
  DEFM "IqIb"

; Data block at B931
  DEFB $08,$57,$48,$AC,$49,$40

; Message at B937
  DEFM "HiQU"

; Data block at B93B
  DEFB $08,$AD,$69,$01,$E8,$01,$C8,$11
  DEFB $08,$65,$48,$AE,$49,$AF,$69,$00
  DEFB $C0,$EA,$0A,$11,$08

; Message at B950
  DEFM ",H-H"

; Data block at B954
  DEFB $B1,$51,$00,$C0,$71,$1C,$BA,$09
  DEFB $A3,$48,$08,$48,$83,$51,$BB,$19
  DEFB $08,$48,$BC

; Message at B967
  DEFM "IJH"

; Data block at B96A
  DEFB $BD,$49,$1A

; Message at B96D
  DEFM "I4H>H?h"

; Data block at B974
  DEFB $00,$C0,$0D,$06,$DC,$09,$DD,$69
  DEFB $00,$C0,$0E,$1C,$C6,$29,$01,$E8
  DEFB $01,$C8,$02,$09

; Message at B988
  DEFM "LHMH8H"

; Data block at B98E
  DEFB $C7,$51,$C8,$29,$01,$C8,$1B,$08
  DEFB $3B,$48,$C9,$69,$00,$C0,$0C,$0E
  DEFB $3A,$08,$16,$48,$FE,$49,$0A,$48
  DEFB $FF,$09,$00,$52,$00,$C0

; Message at B9AC
  DEFM "r48"

; Data block at B9AF
  DEFB $08

; Message at B9B0
  DEFM "?H:H;HGQ"

; Data block at B9B8
  DEFB $ED,$08,$02,$08

; Message at B9BC
  DEFM ",H8H7H)H"

; Data block at B9C4
  DEFB $ED,$48,$01,$08,$08,$48,$40

; Message at B9CB
  DEFM "YiI"

; Data block at B9CE
  DEFB $E1,$69,$1A,$09,$38,$48,$07,$08
  DEFB $38,$48,$60,$48,$E2

; Message at B9DB
  DEFM "I&H"

; Data block at B9DE
  DEFB $E3,$51,$00,$C0

; Message at B9E2
  DEFM "s68"

; Data block at B9E5
  DEFB $08,$C7

; Message at B9E7
  DEFM "I:H;H"

; Data block at B9EC
  DEFB $E8

; Message at B9ED
  DEFM "I)H0H1H8H"

; Data block at B9F6
  DEFB $CC

; Message at B9F7
  DEFM "I6H?X"

; Data block at B9FC
  DEFB $11

; Message at B9FD
  DEFM "H;H"

; Data block at BA00
  DEFB $E9,$51,$A4,$09,$ED,$4A,$15

; Message at BA07
  DEFM "KMH8H"

; Data block at BA0C
  DEFB $C7,$51,$BD,$08,$EA

; Message at BA11
  DEFM "IMH8H"

; Data block at BA16
  DEFB $CC,$69,$00,$C0,$74,$1A,$89,$09
  DEFB $04,$4A,$11,$48,$05

; Message at BA23
  DEFM "J'i"

; Data block at BA26
  DEFB $01,$E8,$01,$C8,$06,$0A,$04,$58
  DEFB $07

; Message at BA2F
  DEFM "ZJH"

; Data block at BA32
  DEFB $08,$52,$00,$C0,$15,$2C,$3A,$08
  DEFB $34,$48,$0A,$4A,$0B,$4A,$A3,$50
  DEFB $01,$D0,$01,$D8,$A3,$50,$02,$D0
  DEFB $01,$D8,$3A,$5A,$01,$C8

; Message at BA50
  DEFM ":HsH4P"

; Data block at BA56
  DEFB $02,$D0,$01,$D8

; Message at BA5A
  DEFM "sH4H"

; Data block at BA5E
  DEFB $09,$1A,$3B,$6A,$00,$C0

; Message at BA64
  DEFM "u C"

; Data block at BA67
  DEFB $08,$11,$0A,$16,$4A,$ED,$48,$09
  DEFB $0A,$CF

; Message at BA71
  DEFM "HSH"

; Data block at BA74
  DEFB $17

; Message at BA75
  DEFM "J)HWH"

; Data block at BA7A
  DEFB $18

; Message at BA7B
  DEFM "JMH8H7P"

; Data block at BA82
  DEFB $19,$2A,$00,$C0

; Message at BA86
  DEFM "v 8"

; Data block at BA89
  DEFB $08,$1B,$4A,$1C,$4A,$1D,$4A,$A3
  DEFB $48,$A9,$49,$0A

; Message at BA95
  DEFM "HCH"

; Data block at BA98
  DEFB $DB,$69,$38,$08,$1E,$4A,$0A,$48
  DEFB $08,$48,$14,$4A,$1F,$52,$00,$C0

; Message at BAA8
  DEFM "w$C"

; Data block at BAAB
  DEFB $08,$13,$4A,$11,$0A,$20,$4A,$B1
  DEFB $48,$1E

; Message at BAB5
  DEFM "H:H!J"

; Data block at BABA
  DEFB $0A

; Message at BABB
  DEFM "H\"j"

; Data block at BABE
  DEFB $01,$C8,$29,$88,$23

; Message at BAC3
  DEFM "JEI&H$j"

; Data block at BACA
  DEFB $01,$E8,$00,$C0

; Message at BACE
  DEFM "x&8"

; Data block at BAD1
  DEFB $08,$1C,$4A,$1D,$4A,$A3,$48,$A9
  DEFB $49,$0A

; Message at BADB
  DEFM "HCH"

; Data block at BADE
  DEFB $11,$1A,$01

; Message at BAE1
  DEFM "I8H<IWH%J"

; Data block at BAEA
  DEFB $40

; Message at BAEB
  DEFM "Hii:"

; Data block at BAEF
  DEFB $08

; Message at BAF0
  DEFM "$H&j"

; Data block at BAF4
  DEFB $00,$C0,$79,$34,$0A,$C8,$01,$E0
  DEFB $3C,$8A,$3D,$A2,$2A,$C8,$47,$0A
  DEFB $03,$C8,$2D,$49,$00,$90,$2B,$0A

; Message at BB0C
  DEFM ")H,"

; Data block at BB0F
  DEFB $92,$2D,$0A,$07,$C8,$03,$E0,$01
  DEFB $C8,$15,$88,$16,$88,$17,$88,$03
  DEFB $E0,$29,$C8,$17,$8B,$18,$8B,$30
  DEFB $0A,$25,$C8,$00,$C0,$ED,$04,$73
  DEFB $30,$00,$C0,$7A,$10,$55,$08,$3F
  DEFB $6A,$01,$C8,$29,$88,$9A,$49,$13
  DEFB $AA,$02,$E8,$00,$C0,$7B,$2C,$08
  DEFB $08

; Message at BB48
  DEFM "=H6H"

; Data block at BB4C
  DEFB $60,$58,$B1

; Message at BB4F
  DEFM "HIJ&H"

; Data block at BB54
  DEFB $E3,$51,$ED,$08,$02,$08

; Message at BB5A
  DEFM "WHJJ4HKJ"

; Data block at BB62
  DEFB $F3,$08,$F2,$50,$ED,$08,$05,$08

; Message at BB6A
  DEFM ",H8H?P"

; Data block at BB70
  DEFB $00,$C0,$7C,$22,$38,$08,$60,$48
  DEFB $E2,$49,$ED,$48,$07,$18,$01

; Message at BB7F
  DEFM "ILJMJNJ"

; Data block at BB86
  DEFB $F6,$48,$F7

; Message at BB89
  DEFM "H-IOJyH"

; Data block at BB90
  DEFB $08,$48,$83,$51,$00,$C0,$7D,$22
  DEFB $50,$0A

; Message at BB9A
  DEFM "iIWHJJ4H"

; Data block at BBA2
  DEFB $F2,$48,$F3,$18,$60

; Message at BBA7
  DEFM "IRR"

; Data block at BBAA
  DEFB $7F,$08

; Message at BBAC
  DEFM "WHSJMHTR"

; Data block at BBB4
  DEFB $02,$D0,$01,$C8,$00,$C0,$7E,$24
  DEFB $55,$0A

; Message at BBBE
  DEFM "yHVJWZSH[J"

; Data block at BBC8
  DEFB $9A,$49,$5C,$4A,$0A

; Message at BBCD
  DEFM "H]J"

; Data block at BBD0
  DEFB $B1,$48,$11,$48,$A6,$51,$08,$08
  DEFB $5E,$4A,$1B,$48,$5F,$52,$00,$C0
  DEFB $7F,$22,$4A,$08

; Message at BBE4
  DEFM ".HMH"

; Data block at BBE8
  DEFB $08,$48,$83,$59,$01,$C8

; Message at BBEE
  DEFM "aJ8HFJ6H"

; Data block at BBF6
  DEFB $C3,$51,$16,$08,$62,$4A,$CE,$49
  DEFB $ED

; Message at BBFF
  DEFM "HFR"

; Data block at BC02
  DEFB $00,$C0,$80,$32,$38,$08

; Message at BC08
  DEFM "FJ:HcJ)HeJ"

; Data block at BC12
  DEFB $82

; Message at BC13
  DEFM "HKIfJ"

; Data block at BC18
  DEFB $0A

; Message at BC19
  DEFM "HgRa"

; Data block at BC1D
  DEFB $0A

; Message at BC1E
  DEFM "8HFJ,HiI"

; Data block at BC26
  DEFB $83,$51,$82,$08

; Message at BC2A
  DEFM "4Hb"

; Data block at BC2D
  DEFB $08,$A2,$48,$A3

; Message at BC31
  DEFM "H4HjR"

; Data block at BC36
  DEFB $00,$C0,$81,$1E,$20,$08,$6B,$4A
  DEFB $F1

; Message at BC3F
  DEFM "H)HlJmRn"

; Data block at BC47
  DEFB $0A,$16,$48,$D0,$49,$B1,$48,$14

; Message at BC4F
  DEFM "IoJpJqR"

; Data block at BC56
  DEFB $00,$C0,$82,$16,$38,$08

; Message at BC5C
  DEFM "jJ3ys"

; Data block at BC61
  DEFB $8A,$FF,$09,$19,$93,$01,$C8,$75
  DEFB $32,$01,$E8,$C9,$10,$00,$C0,$83
  DEFB $18,$38,$08,$62,$08

; Message at BC76
  DEFM "JHvJ8H"

; Data block at BC7C
  DEFB $DF,$69,$01,$C8,$89,$1A

; Message at BC82
  DEFM "iJ4HwR"

; Data block at BC88
  DEFB $00,$C0,$84,$2A,$38,$08,$62,$08
  DEFB $67,$48,$08,$48,$FE

; Message at BC95
  DEFM "I)X"

; Data block at BC98
  DEFB $01,$C8,$7A,$4A,$BD,$48,$B1

; Message at BC9F
  DEFM "HJH"

; Data block at BCA2
  DEFB $7B,$4A,$0A,$48,$11,$48,$7C,$5A
  DEFB $01,$C8,$4A,$48,$7F

; Message at BCAF
  DEFM "J4H"

; Data block at BCB2
  DEFB $80,$52,$00,$C0,$18,$14,$3A,$08
  DEFB $34,$48,$80

; Message at BCBD
  DEFM "JyH"

; Data block at BCC0
  DEFB $BD,$48,$83,$52,$01,$C8,$34,$08
  DEFB $81,$72,$00,$C0,$85,$1A,$38,$08
  DEFB $62,$08,$4A,$48,$84,$4A,$16,$48
  DEFB $85,$4A,$0A,$48,$86,$52,$01,$C8
  DEFB $87,$2A,$01,$C8,$88,$2A,$00,$C0
  DEFB $86,$2E,$02,$09

; Message at BCEC
  DEFM "PJ4H"

; Data block at BCF0
  DEFB $8E,$4A,$A3,$48,$08,$48,$40,$49
  DEFB $8F

; Message at BCF9
  DEFM "J-I"

; Data block at BCFC
  DEFB $08,$48,$90,$12,$34,$08,$91,$4A
  DEFB $93,$4A,$89

; Message at BD07
  DEFM "I3P"

; Data block at BD0A
  DEFB $40,$08,$38,$48,$8E,$4A,$82

; Message at BD11
  DEFM "H4HwR"

; Data block at BD16
  DEFB $00,$C0,$87,$2C,$3A,$08,$34,$48
  DEFB $94,$4A,$95

; Message at BD21
  DEFM "J)H"

; Data block at BD24
  DEFB $96,$4A,$B1,$48,$11,$48,$97

; Message at BD2B
  DEFM "J9I"

; Data block at BD2E
  DEFB $A9,$49,$0A,$48,$89

; Message at BD33
  DEFM "I3P&"

; Data block at BD37
  DEFB $08,$98,$4A,$99,$4A,$9A,$4A,$0A

; Message at BD3F
  DEFM "H&H"

; Data block at BD42
  DEFB $D9,$50,$00,$C0,$88,$12,$38,$08

; Message at BD4A
  DEFM "wJ3y"

; Data block at BD4E
  DEFB $9B,$8A,$9C,$8A,$9D,$8A,$9E,$8A
  DEFB $9F,$92,$00,$C0,$89,$26,$79,$08

; Message at BD5E
  DEFM "4H&J"

; Data block at BD62
  DEFB $A0

; Message at BD63
  DEFM "Z8H"

; Data block at BD66
  DEFB $90

; Message at BD67
  DEFM "JJH"

; Data block at BD6A
  DEFB $A1

; Message at BD6B
  DEFM "J8H"

; Data block at BD6E
  DEFB $DF,$69,$01,$C8,$A2,$0A,$B7,$49
  DEFB $A3

; Message at BD77
  DEFM "JJHiJ8HjR"

; Data block at BD80
  DEFB $00,$C0,$8A,$26,$38,$08,$A7

; Message at BD87
  DEFM "JxJ"

; Data block at BD8A
  DEFB $08,$48,$8B

; Message at BD8D
  DEFM "H)H"

; Data block at BD90
  DEFB $08,$48,$A8,$4A,$A2,$48,$A3,$48
  DEFB $A9,$52,$59,$0A,$7B,$49,$0A,$48
  DEFB $B1,$48,$1E

; Message at BDA3
  DEFM "H0H"

; Data block at BDA6
  DEFB $AC,$52,$00,$C0,$8B,$30,$03,$0A
  DEFB $0A,$48,$AD,$4A,$AE

; Message at BDB3
  DEFM "J8H"

; Data block at BDB6
  DEFB $AF

; Message at BDB7
  DEFM "Z8H"

; Data block at BDBA
  DEFB $90,$4A,$FC

; Message at BDBD
  DEFM "J&H"

; Data block at BDC0
  DEFB $D9

; Message at BDC1
  DEFM "H)H"

; Data block at BDC4
  DEFB $B6,$48,$B1,$6A,$01,$E8,$01,$C8
  DEFB $38,$08,$1C,$4A,$0A,$48,$B3,$4A
  DEFB $B4

; Message at BDD5
  DEFM "JiI"

; Data block at BDD8
  DEFB $B5,$52,$00,$C0,$8C,$44,$38,$08
  DEFB $95,$48,$D8

; Message at BDE3
  DEFM "H)H"

; Data block at BDE6
  DEFB $FD,$4A,$ED,$48,$62,$10,$02,$D0
  DEFB $29,$48,$11,$48,$00

; Message at BDF3
  DEFM "K-h"

; Data block at BDF6
  DEFB $02,$E8,$01,$C8,$B6,$0A,$97

; Message at BDFD
  DEFM "I4H"

; Data block at BE00
  DEFB $B7,$4A,$B8,$52,$BA,$0A,$BB,$4A
  DEFB $08,$48,$BC

; Message at BE0B
  DEFM "J)HEIcJ-I"

; Data block at BE14
  DEFB $08,$48,$90,$52,$02,$D0,$A3,$48
  DEFB $BD,$6A,$02,$E8,$00,$C0,$8D,$08
  DEFB $57,$08,$BF,$6A,$01,$E8,$00,$C0
  DEFB $8E,$28,$16,$08,$3E,$48,$C0

; Message at BE33
  DEFM "JMH"

; Data block at BE36
  DEFB $C1,$5A,$C2,$4A,$C3,$4A,$C4

; Message at BE3D
  DEFM "JCH"

; Data block at BE40
  DEFB $C5,$52,$4D,$08

; Message at BE44
  DEFM "8H$Y"

; Data block at BE48
  DEFB $40

; Message at BE49
  DEFM "H4H"

; Data block at BE4C
  DEFB $C6,$5A,$82,$48,$16,$48,$C7,$52
  DEFB $00,$C0,$8F,$1E,$3A,$08,$16,$48
  DEFB $C8,$4A,$0A,$48,$C9,$4A,$F5

; Message at BE63
  DEFM "JMH"

; Data block at BE66
  DEFB $08,$48,$CB

; Message at BE69
  DEFM "J6H"

; Data block at BE6C
  DEFB $C6,$52,$20,$08,$CC

; Message at BE71
  DEFM "J]R"

; Data block at BE74
  DEFB $00,$C0,$1D,$1C,$3A,$08,$34,$48
  DEFB $D6,$4A,$0A,$48,$D7,$4A,$DB,$4A
  DEFB $B1,$48,$9B

; Message at BE87
  DEFM "H4H"

; Data block at BE8A
  DEFB $DC,$4A,$DD,$52,$1B,$08,$DF,$52
  DEFB $00,$C0,$1E,$10,$3A,$08,$34,$48
  DEFB $D6,$4A,$0A,$48,$D7,$4A,$DB,$5A
  DEFB $DE,$52,$00,$C0,$91

; Message at BEA7
  DEFM "\"2("

; Data block at BEAA
  DEFB $01,$C8,$34,$08,$E0,$4A,$E1,$4A
  DEFB $D8

; Message at BEB3
  DEFM "H)H8H"

; Data block at BEB8
  DEFB $D6

; Message at BEB9
  DEFM "JWH"

; Data block at BEBC
  DEFB $EA,$52,$38,$08,$DC,$4A,$F7,$4A
  DEFB $ED,$48,$F8,$52,$00,$C0,$92,$28
  DEFB $38,$08,$3F,$48,$1B,$48,$EC,$4A
  DEFB $0A,$48,$ED,$4A,$EE,$6A,$02,$E8
  DEFB $01,$C8,$4D,$08,$EF,$4A,$11,$48
  DEFB $F0,$4A,$0A

; Message at BEE7
  DEFM "HiI9ICH"

; Data block at BEEE
  DEFB $F1,$6A,$03,$E8,$00,$C0,$93,$32
  DEFB $ED,$08,$F2

; Message at BEF9
  DEFM "Z8H"

; Data block at BEFC
  DEFB $DC,$4A,$B1,$48,$9B,$48,$EA

; Message at BF03
  DEFM "J8H"

; Data block at BF06
  DEFB $D6

; Message at BF07
  DEFM "J)HWH"

; Data block at BF0C
  DEFB $F3

; Message at BF0D
  DEFM "JyH8H"

; Data block at BF12
  DEFB $C7,$51,$B1,$08,$6B,$4A,$F4,$6A
  DEFB $01,$D0,$43,$08,$ED

; Message at BF1F
  DEFM "J6H?H"

; Data block at BF24
  DEFB $16,$6B,$00,$C0,$95,$20,$38,$08
  DEFB $C7

; Message at BF2D
  DEFM "I:H;H"

; Data block at BF32
  DEFB $E8

; Message at BF33
  DEFM "I)H0H1H8H"

; Data block at BF3C
  DEFB $CC

; Message at BF3D
  DEFM "I6H?X"

; Data block at BF42
  DEFB $11

; Message at BF43
  DEFM "H;H"

; Data block at BF46
  DEFB $E9,$51,$00,$C0,$E9,$06,$49,$08
  DEFB $11,$68,$00,$C0,$96,$08,$11,$08
  DEFB $03

; Message at BF57
  DEFM "K-P"

; Data block at BF5A
  DEFB $00,$C0,$00,$00,$21,$05,$DF,$02
  DEFB $96,$09,$81,$75,$85,$74,$09,$85
  DEFB $74,$88,$76,$09,$88,$76,$8B,$74
  DEFB $09,$8C,$74,$8E,$75,$09,$8E,$75
  DEFB $90,$72,$09,$90,$72,$8E,$71,$09
  DEFB $8E,$71,$8B,$6E,$09,$8A,$6D,$87
  DEFB $6C,$09,$87,$6C,$85,$6D,$09,$85
  DEFB $6D,$82,$6F,$09,$82,$6F,$80,$71
  DEFB $09,$80,$70,$7F,$71,$09,$7F,$71
  DEFB $80,$74,$09,$83,$74,$84,$70,$09
  DEFB $84,$70,$86,$73,$09,$8A,$74,$8C
  DEFB $70,$09,$8C,$70,$8D,$74,$09,$86
  DEFB $6E,$88,$71,$09,$88,$71,$8A,$6E
  DEFB $09,$88,$6D,$88,$70,$09,$86,$74
  DEFB $88,$72,$09,$88,$72,$8A,$75,$04
  DEFB $82,$73,$04,$8B,$71,$04,$86,$70
  DEFB $09,$85,$77,$87,$7D,$09,$87,$7D
  DEFB $8A,$77,$09,$86,$78,$88,$78,$09
  DEFB $85,$7B,$81,$85,$09,$81,$85,$7D
  DEFB $86,$09,$7D,$86,$7C,$81,$09,$7C
  DEFB $81,$7F,$7A,$09,$7F,$7A,$82,$77
  DEFB $09,$7E,$84,$82,$7F,$09,$82,$7F
  DEFB $85,$78,$09,$82,$7C,$82,$76,$09
  DEFB $83,$77,$85,$77,$04,$83,$79,$09
  DEFB $8A,$7A,$8E,$84,$09,$8E,$84,$92
  DEFB $86,$09,$92,$86,$94,$7F,$09,$94
  DEFB $7F,$8D,$78,$09,$89,$78,$92,$84
  DEFB $09,$92,$73,$96,$7A,$09,$96,$7A
  DEFB $9C,$6B,$09,$9C,$6B,$A0,$67,$09
  DEFB $A0,$67,$9E,$5F,$09,$9E,$5F,$9A
  DEFB $5E,$09,$9A,$5E,$9C,$66,$09,$9C
  DEFB $66,$96,$71,$09,$96,$71,$90,$68
  DEFB $09,$90,$68,$8D,$6A,$09,$8D,$6A
  DEFB $8D,$6D,$09,$90,$68,$90,$68,$09
  DEFB $91,$68,$92,$62,$09,$92,$62,$8D
  DEFB $60,$09,$8D,$60,$88,$5E,$09,$88
  DEFB $5E,$81,$5F,$09,$81,$5F,$7E,$63
  DEFB $09,$7E,$63,$7F,$69,$09,$7F,$69
  DEFB $82,$6C,$09,$80,$5F,$7E,$58,$09
  DEFB $7E,$58,$80,$4F,$09,$80,$4F,$7D
  DEFB $4B,$09,$7D,$4B,$82,$4A,$09,$82
  DEFB $4A,$83,$50,$09,$83,$50,$81,$58
  DEFB $09,$81,$58,$86,$5D,$09,$8A,$5E
  DEFB $8D,$57,$09,$8D,$57,$8A,$4E,$09
  DEFB $8A,$4E,$8D,$4A,$09,$8D,$4A,$90
  DEFB $4A,$09,$90,$4A,$8E,$4E,$09,$8E
  DEFB $4E,$90,$57,$09,$90,$57,$90,$60
  DEFB $09,$80

; Message at C0D4
  DEFM "pzs"

; Data block at C0D7
  DEFB $09

; Message at C0D8
  DEFM "ytvy"

; Data block at C0DC
  DEFB $09

; Message at C0DD
  DEFM "vynk"

; Data block at C0E1
  DEFB $09

; Message at C0E2
  DEFM "nkqe"

; Data block at C0E6
  DEFB $09

; Message at C0E7
  DEFM "qeug"

; Data block at C0EB
  DEFB $09

; Message at C0EC
  DEFM "ugrj"

; Data block at C0F0
  DEFB $09

; Message at C0F1
  DEFM "rjvs"

; Data block at C0F5
  DEFB $09,$76,$72,$7E,$6A,$09,$8E,$78
  DEFB $8F,$75,$09

; Message at C100
  DEFM "qiud"

; Data block at C104
  DEFB $09

; Message at C105
  DEFM "udvd"

; Data block at C109
  DEFB $09

; Message at C10A
  DEFM "vgwg"

; Data block at C10E
  DEFB $09

; Message at C10F
  DEFM "rerb"

; Data block at C113
  DEFB $09

; Message at C114
  DEFM "rbtb"

; Data block at C118
  DEFB $09,$9A,$62,$98,$62,$09,$98,$62
  DEFB $98,$63,$09,$9A,$5F,$98,$5F,$09
  DEFB $9C,$5E,$9B,$5B,$09,$9B,$5B,$9A
  DEFB $5B,$09,$83,$4E,$84,$4E,$09,$85
  DEFB $4D,$85,$4C,$09,$8A,$50,$88,$50
  DEFB $09,$98,$76,$9C,$78,$09,$9C,$78
  DEFB $A1,$78,$09,$A1,$78,$A5,$75,$09
  DEFB $A5,$75,$A2,$7F,$09,$A2,$7F,$A4
  DEFB $85,$09,$A4,$85,$A9,$83,$09,$A9
  DEFB $83,$A8,$76,$09,$A8,$76,$AC,$7A
  DEFB $09,$AD,$7A,$AF,$7A,$09,$AF,$7A
  DEFB $AB,$74,$09,$AB,$74,$B1,$75,$09
  DEFB $B1,$75,$B2,$70,$09,$B2,$70,$A9
  DEFB $71,$09,$A9,$71,$AA,$6A,$09,$AA
  DEFB $6A,$AF,$6A,$09,$AF,$6A,$AE,$66
  DEFB $09,$AE,$66,$A7,$68,$09,$A7,$68
  DEFB $A7,$6B,$09,$A7,$6B,$A4,$69,$09
  DEFB $A9,$80,$AC,$83,$09,$AC,$83,$AF
  DEFB $82,$09,$AF,$82,$AD,$7A,$09,$A9
  DEFB $75,$AB,$75,$09,$A8,$74,$AB,$74
  DEFB $09,$AC,$71,$AC,$6D,$09,$AC,$6D
  DEFB $AE,$70,$09,$AF,$6F,$AF,$6C,$09
  DEFB $AF,$6C,$B1,$6F,$09,$AF,$6B,$AB
  DEFB $6C,$09,$AC,$6A,$AC,$6B,$04,$AA
  DEFB $6F,$04,$AE,$6E,$09,$A4,$83,$A8
  DEFB $76,$04,$AC,$7C,$09,$9F,$69,$AB
  DEFB $5F,$09,$AB,$5F,$AC,$5A,$09,$AC
  DEFB $5A,$A9,$58,$09,$A9,$58,$A9,$5D
  DEFB $09,$A9,$5D,$A0,$63,$09,$A8,$58
  DEFB $A7,$58,$09,$AB,$58,$AB,$55,$09
  DEFB $AA,$55,$A9,$55,$09,$9C,$65,$96
  DEFB $64,$09,$96,$64,$93,$66,$09,$96
  DEFB $63,$93,$55,$09,$93,$55,$96,$4D
  DEFB $09,$97,$4D,$9A,$4B,$09,$9A,$4B
  DEFB $95,$4B,$09,$95,$4B,$8F,$51,$09
  DEFB $94,$66,$97,$6E,$04,$95,$6E,$04
  DEFB $92,$5F,$04,$95,$4D,$57,$04,$38
  DEFB $01,$3F,$09,$5C

; Message at C244
  DEFM "gaf"

; Data block at C247
  DEFB $09

; Message at C248
  DEFM "afda"

; Data block at C24C
  DEFB $09

; Message at C24D
  DEFM "dahZ"

; Data block at C251
  DEFB $09

; Message at C252
  DEFM "hZpY"

; Data block at C256
  DEFB $09

; Message at C257
  DEFM "pYsT"

; Data block at C25B
  DEFB $09

; Message at C25C
  DEFM "sTtQ"

; Data block at C260
  DEFB $09

; Message at C261
  DEFM "sQoU"

; Data block at C265
  DEFB $09

; Message at C266
  DEFM "oUgW"

; Data block at C26A
  DEFB $09

; Message at C26B
  DEFM "gWc]"

; Data block at C26F
  DEFB $09,$63,$60,$62,$55,$09

; Message at C275
  DEFM "aTcL"

; Data block at C279
  DEFB $09

; Message at C27A
  DEFM "cLeK"

; Data block at C27E
  DEFB $09

; Message at C27F
  DEFM "eKaJ"

; Data block at C283
  DEFB $09,$61,$4A,$5F,$54,$09,$5F,$54
  DEFB $5E,$56,$09,$5E,$56,$5F,$5B,$09
  DEFB $5F,$5B,$5C,$60,$09,$5B,$60,$56
  DEFB $54,$09

; Message at C29D
  DEFM "VTPS"

; Data block at C2A1
  DEFB $09

; Message at C2A2
  DEFM "PSMO"

; Data block at C2A6
  DEFB $09

; Message at C2A7
  DEFM "MOOU"

; Data block at C2AB
  DEFB $09

; Message at C2AC
  DEFM "OUSU"

; Data block at C2B0
  DEFB $09

; Message at C2B1
  DEFM "SUX"

; Data block at C2B4
  DEFB $5F,$09,$58,$5F,$58,$63,$09

; Message at C2BB
  DEFM "[fWe"

; Data block at C2BF
  DEFB $09

; Message at C2C0
  DEFM "WeVa"

; Data block at C2C4
  DEFB $09

; Message at C2C5
  DEFM "VaW"

; Data block at C2C8
  DEFB $5E,$09,$5A,$5B,$5C,$5B,$09

; Message at C2CF
  DEFM "ZZVQ"

; Data block at C2D3
  DEFB $09

; Message at C2D4
  DEFM "VQVM"

; Data block at C2D8
  DEFB $09

; Message at C2D9
  DEFM "VMYK"

; Data block at C2DD
  DEFB $09

; Message at C2DE
  DEFM "YKTK"

; Data block at C2E2
  DEFB $09

; Message at C2E3
  DEFM "TKTR"

; Data block at C2E7
  DEFB $02,$70,$57,$09

; Message at C2EB
  DEFM "fknn"

; Data block at C2EF
  DEFB $09

; Message at C2F0
  DEFM "nnrh"

; Data block at C2F4
  DEFB $09

; Message at C2F5
  DEFM "rhsa"

; Data block at C2F9
  DEFB $09

; Message at C2FA
  DEFM "savb"

; Data block at C2FE
  DEFB $09

; Message at C2FF
  DEFM "vbze"

; Data block at C303
  DEFB $09,$7A,$65,$7F,$63,$09,$7F,$62
  DEFB $83,$5E,$09,$83,$5E,$8B,$5C,$09
  DEFB $8B,$5C,$8E,$5F,$09,$8E,$5F,$8C
  DEFB $5A,$09,$8C,$5A,$84,$5B,$09,$84
  DEFB $5B,$81,$5C,$09,$81,$5C,$7D,$58
  DEFB $09,$7D,$58,$7C,$53,$09,$7B

; Message at C332
  DEFM "RyN"

; Data block at C335
  DEFB $09

; Message at C336
  DEFM "yNtN"

; Data block at C33A
  DEFB $09

; Message at C33B
  DEFM "tNxP"

; Data block at C33F
  DEFB $09

; Message at C340
  DEFM "xPzV"

; Data block at C344
  DEFB $09

; Message at C345
  DEFM "zVy]"

; Data block at C349
  DEFB $09

; Message at C34A
  DEFM "yZs"

; Data block at C34D
  DEFB $5E,$09,$73,$5E,$6F,$65,$09

; Message at C354
  DEFM "ofnj"

; Data block at C358
  DEFB $09

; Message at C359
  DEFM "mjgj"

; Data block at C35D
  DEFB $02,$6C,$6C,$09,$7E,$59,$81,$4F
  DEFB $09,$80,$4E,$7D,$4E,$09,$7D,$4E
  DEFB $7E,$55,$04,$7F,$4F,$04,$5C,$5E
  DEFB $3C,$00,$23,$00,$06,$09,$57,$40
  DEFB $57,$58,$09

; Message at C380
  DEFM "VPVp"

; Data block at C384
  DEFB $09

; Message at C385
  DEFM "WhW"

; Data block at C388
  DEFB $9F,$09,$4F,$9F,$52,$67,$09

; Message at C38F
  DEFM "RgP"

; Data block at C392
  DEFB $40,$09,$44,$40,$47,$9F,$46,$00
  DEFB $41,$00,$0C,$09,$60,$9F,$60,$67
  DEFB $09

; Message at C3A3
  DEFM "aoaW"

; Data block at C3A7
  DEFB $09,$60,$5F,$60,$47,$09

; Message at C3AD
  DEFM "oGog"

; Data block at C3B1
  DEFB $09,$6E,$5F,$6E,$7F,$09

; Message at C3B7
  DEFM "owo"

; Data block at C3BA
  DEFB $9F,$09

; Message at C3BC
  DEFM "wGgH"

; Data block at C3C0
  DEFB $09

; Message at C3C1
  DEFM "gHWF"

; Data block at C3C5
  DEFB $09,$64,$9E,$63,$76,$09

; Message at C3CB
  DEFM "cveI"

; Data block at C3CF
  DEFB $09

; Message at C3D0
  DEFM "jHk"

; Data block at C3D3
  DEFB $88,$09,$6B,$88,$69,$9F,$50,$00
  DEFB $3C,$00,$0B,$09,$90,$9F,$90,$6F
  DEFB $09,$91,$77,$91,$57,$09,$90,$5F
  DEFB $90,$4F,$09,$9F,$4F,$9F,$77,$09
  DEFB $9E,$6F,$9E,$87,$09,$9F,$7F,$9F
  DEFB $9F,$09,$97,$51,$87,$4C,$09,$95
  DEFB $50,$A7,$4E,$09,$9A,$4F,$98,$9F
  DEFB $09,$94,$9F,$96,$7F,$09,$96,$7F
  DEFB $94,$51,$5A,$00,$28,$00,$07,$09
  DEFB $A8,$9F,$A8,$7F,$09,$A9,$87,$A9
  DEFB $67,$09,$A8,$68,$A8,$40,$09,$AD
  DEFB $40,$B0,$9F,$09,$B5,$9F,$B3,$67
  DEFB $09,$B3,$67,$B5,$40,$09,$BD,$40
  DEFB $BA,$9F,$06,$00,$3A,$01,$51,$07
  DEFB $E8,$03,$11,$04,$05,$B7,$97,$07
  DEFB $3C,$00,$07,$46,$00,$07,$50,$00
  DEFB $07,$5A,$00,$09

; Message at C457
  DEFM "VpQ"

; Data block at C45A
  DEFB $82,$09

; Message at C45C
  DEFM "VQPB"

; Data block at C460
  DEFB $06,$43,$42,$06,$4B,$42,$09,$4B
  DEFB $40,$49,$70,$09,$49,$9F,$4C,$70
  DEFB $06,$56,$74,$06,$56,$4C,$06,$62
  DEFB $74,$06,$67,$78,$09,$67,$83,$66
  DEFB $5B,$06,$6D,$6E,$09,$91,$76,$94
  DEFB $8E,$06,$91,$7C,$06,$97,$7C,$06
  DEFB $9B,$7C,$06,$AB,$7C,$06,$B1,$7C
  DEFB $09,$B4,$77,$B7,$5F,$09,$B7,$5F
  DEFB $B6,$4A,$04,$B5,$5D,$04,$B5,$5D
  DEFB $04,$B5,$5D,$04,$B5,$5D,$04,$B5
  DEFB $5D,$04,$B5,$5D,$04,$B5,$5D,$04
  DEFB $B5,$5D,$06,$B9,$5D,$04,$BE,$45
  DEFB $04,$B4,$6E,$09,$57,$7E,$5B,$92
  DEFB $09,$5B,$92,$60,$7F,$09,$6F,$7F
  DEFB $75,$95,$09,$75,$95,$82,$65,$09
  DEFB $7B,$7E,$7E,$8F,$09,$7E,$8F,$83
  DEFB $76,$09,$80,$6D,$89,$98,$09,$89
  DEFB $98,$90,$81,$09,$6F,$51,$90,$53
  DEFB $09,$9F,$88,$A3,$96,$09,$A3,$96
  DEFB $A8,$82,$09,$82

; Message at C4FC
  DEFM "ewi"

; Data block at C4FF
  DEFB $09

; Message at C500
  DEFM "wiwQ"

; Data block at C504
  DEFB $09

; Message at C505
  DEFM "tQsi"

; Data block at C509
  DEFB $09,$81,$69,$8A,$6B,$09,$87,$6C
  DEFB $91,$6A,$09,$87,$6A,$87,$52,$09
  DEFB $8A,$53,$8B,$69,$04,$78,$68,$04
  DEFB $86,$69,$06,$88,$69,$09,$71,$69
  DEFB $7B,$6B,$06,$76,$68,$09,$8E,$6A
  DEFB $8F,$52,$09,$9F,$6A,$A5,$6E,$09
  DEFB $A2,$6C,$A2,$4D,$04,$A0,$50,$09
  DEFB $A5,$4E,$A6,$6D,$06,$A4,$6A,$09
  DEFB $60,$5F,$59,$63,$09

; Message at C54E
  DEFM "[bZG"

; Data block at C552
  DEFB $09,$5D,$47,$5C,$61,$06,$5B,$50
  DEFB $04,$5F,$5E,$10,$01,$04,$58,$87
  DEFB $04,$5F,$86,$04,$70,$86,$04,$7B
  DEFB $83,$04,$82,$7E,$04,$8F,$86,$04
  DEFB $A0,$8E,$04,$A7,$8A,$0C,$00,$26
  DEFB $01,$49,$07,$E8,$03,$11,$04,$05
  DEFB $B7,$97,$07,$3C,$00,$07,$46,$00
  DEFB $07,$5A,$00,$09,$57,$7E,$5B,$99
  DEFB $09,$5B,$99,$60,$78,$09,$6F,$7F
  DEFB $76,$97,$09,$76,$97,$7C,$83,$09
  DEFB $84,$9B,$77,$71,$09,$84,$9B,$97
  DEFB $6B,$09,$91,$7B,$98,$94,$09,$98
  DEFB $94,$9B,$83,$09,$9B,$82,$9F,$9A
  DEFB $09,$9F,$9A,$A4,$86,$09,$A4,$86
  DEFB $A7,$96,$09,$A8

; Message at C5C6
  DEFM "NpL"

; Data block at C5C9
  DEFB $09,$50,$85,$4E,$5D,$09

; Message at C5CF
  DEFM "N]OE"

; Data block at C5D3
  DEFB $09,$97,$6B,$8B,$6E,$09,$8B,$6E
  DEFB $94,$69,$09,$94,$69,$82,$6D,$09
  DEFB $82,$6D,$82,$4D,$09,$8A,$4D,$8A
  DEFB $6C,$09,$85,$6C,$86,$4E,$09,$88
  DEFB $4E,$89,$6C,$06,$83,$6B,$06,$87
  DEFB $6A,$09,$8A,$64,$9A,$6A,$09,$96
  DEFB $68,$96,$4D,$09,$9A,$4D,$9A,$64
  DEFB $09,$96,$67,$A3,$62,$09,$A3,$62
  DEFB $A0,$6A,$09,$98,$66,$99,$4D,$06
  DEFB $97,$4E,$04,$95,$66,$09,$9A,$5E
  DEFB $A8,$63,$04,$A7,$60,$09,$82

; Message at C62A
  DEFM "hrb"

; Data block at C62D
  DEFB $09

; Message at C62E
  DEFM "pby"

; Data block at C631
  DEFB $60,$09

; Message at C633
  DEFM "uauL"

; Data block at C637
  DEFB $09

; Message at C638
  DEFM "zLze"

; Data block at C63C
  DEFB $09,$77,$60,$78,$4D,$06,$76,$4D
  DEFB $04,$71,$4D,$04,$81,$66,$09,$60

; Message at C64C
  DEFM "YWW"

; Data block at C64F
  DEFB $04,$5F,$58,$04,$5F,$58,$04,$5F
  DEFB $58,$04,$50,$4C,$04,$43,$4C,$06
  DEFB $49,$4C,$06,$53,$4C,$06,$62,$4C
  DEFB $06,$67,$4C,$06,$6D,$4C,$09,$A9
  DEFB $84,$AC,$9F,$09,$A9,$67,$AC,$4F
  DEFB $06,$A9,$61,$06,$A9,$91,$06,$B2
  DEFB $97,$06,$B7,$97,$06,$BE,$47,$10
  DEFB $01,$04,$58,$8A,$04,$5F,$83,$04
  DEFB $70,$86,$04,$7C,$86,$04,$91,$86
  DEFB $04,$9B,$87,$04,$A4,$8A,$E7,$00
  DEFB $17,$01,$3B,$08,$BF,$9F,$58,$7F
  DEFB $11,$06,$05,$78,$87,$09,$BF,$8F
  DEFB $AF,$8F,$09,$AF,$8F,$AD,$8C,$09
  DEFB $AD,$8C,$A9,$8C,$09,$A9,$8C,$A9
  DEFB $83,$09,$A9,$83,$A6,$83,$09,$A6
  DEFB $83,$A6,$91,$09,$A6,$91,$A2,$96
  DEFB $09,$A2,$96,$A2,$9A,$09,$A2,$9A
  DEFB $A0,$9A,$09,$A0,$9A,$A0,$96,$09
  DEFB $A0,$96,$9D,$92,$09,$9D,$92,$9D
  DEFB $8A,$09,$9D,$8A,$9A,$8A,$09,$9A
  DEFB $8A,$9A,$8F,$09,$9A,$8F,$98,$90
  DEFB $09,$98,$90,$98,$9A,$09,$98,$9A
  DEFB $95,$9A,$09,$95,$9A,$91,$95,$09
  DEFB $91,$95,$91,$85,$09,$91,$85,$8F
  DEFB $85,$09,$8F,$85,$8F,$8E,$09,$8F
  DEFB $8E,$8D,$8E,$09,$8D,$8E,$8B,$92
  DEFB $09,$8B,$92,$89,$92,$09,$89,$92
  DEFB $89,$95,$09,$89,$95,$85,$95,$09
  DEFB $85,$95,$85,$92,$09,$85,$92,$83
  DEFB $92,$09,$83,$92,$83,$8F,$09,$83
  DEFB $8F,$82,$8F,$09,$82,$8F,$82,$96
  DEFB $09,$82,$96,$7F,$99,$09,$7F,$99
  DEFB $7F,$85,$09,$7F,$85,$7C,$85,$09
  DEFB $7C,$85,$7C,$85,$09,$7C,$85,$7C
  DEFB $82,$09,$7C,$82,$7A,$82,$09,$7A
  DEFB $82,$7A,$8A,$09,$7A,$8A,$77,$8D
  DEFB $09,$77,$8D,$77,$90,$09,$77,$90
  DEFB $75,$90,$09,$75,$90,$75,$8D,$09
  DEFB $75,$8D,$72,$8A,$09,$72,$8A,$72
  DEFB $80,$04,$76,$8F,$04,$7E,$84,$04
  DEFB $80,$96,$04,$86,$94,$04,$97,$99
  DEFB $04,$A1,$99,$04,$AF,$8E,$09,$6F
  DEFB $80,$6F,$83,$09,$6F,$83,$67,$83
  DEFB $09,$67,$83,$66,$86,$09,$66,$86
  DEFB $58,$86,$04,$59,$85,$08,$00,$0D
  DEFB $00,$03,$07,$0D,$00,$10,$00,$07
  DEFB $21,$05,$01,$00,$C1,$02,$A0,$07
  DEFB $E8,$03,$11,$07,$05,$B0,$90,$08
  DEFB $B8,$98,$A0,$78,$08,$A0,$70,$60
  DEFB $90,$08,$60,$98,$48,$78,$11,$01
  DEFB $05,$50,$8F,$05,$78,$77,$05,$A8
  DEFB $93,$09,$78,$73,$88,$73,$09,$88
  DEFB $73,$8B,$89,$09

; Message at C7F3
  DEFM "xsu"

; Data block at C7F6
  DEFB $89,$09,$75,$89,$8B,$89,$09,$91
  DEFB $89,$8D,$74,$09,$8D,$74,$9F,$72
  DEFB $09,$91,$89,$AF,$94,$09,$AF,$94
  DEFB $B7,$78,$09,$6F,$89,$73,$73,$09
  DEFB $73,$73,$60,$71,$09,$6F,$89,$50
  DEFB $94,$09,$50,$94,$48,$78,$04,$49
  DEFB $96,$04,$5F,$90,$04,$81,$8E,$04
  DEFB $74,$89,$04,$8C,$88,$04,$A1,$96
  DEFB $04,$B7,$94,$11,$07,$09,$90,$90
  DEFB $A8,$9C,$09,$A8,$9C,$BF,$96,$09
  DEFB $BF,$96,$B8,$77,$09,$72,$90,$57
  DEFB $9C,$09,$57,$9C,$40,$96,$09,$40
  DEFB $96,$47,$77,$04,$47,$97,$04,$58
  DEFB $9B,$04,$61,$97,$04,$9F,$97,$04
  DEFB $A9,$9B,$04,$B9,$97,$09,$A3,$77
  DEFB $A6,$6F,$09,$A6,$6F,$A3,$67,$09
  DEFB $A6,$6F,$BB,$6F,$09,$5C

; Message at C87C
  DEFM "wYo"

; Data block at C87F
  DEFB $09,$59,$6F,$5C,$67,$09

; Message at C885
  DEFM "YoDo"

; Data block at C889
  DEFB $09,$60,$6F,$60,$67,$09,$60

; Message at C890
  DEFM "gHg"

; Data block at C893
  DEFB $09

; Message at C894
  DEFM "HgDo"

; Data block at C898
  DEFB $09

; Message at C899
  DEFM "DoGw"

; Data block at C89D
  DEFB $09,$A1,$6F,$A1,$67,$09,$A1,$67
  DEFB $B9,$67,$09,$B9,$67,$BB,$6F,$09
  DEFB $BB,$6F,$B9,$77,$09,$A9,$66,$B1
  DEFB $66,$09,$A9,$65,$B1,$65,$09

; Message at C8BC
  DEFM "XfPf"

; Data block at C8C0
  DEFB $09

; Message at C8C1
  DEFM "PeXe"

; Data block at C8C5
  DEFB $09,$A2,$64,$BA,$64,$09,$BA,$64
  DEFB $BC,$61,$09,$BC,$61,$BC,$44,$09
  DEFB $BC,$44,$A1,$44,$09,$A1,$44,$A1
  DEFB $5F,$09,$A1,$5F,$A2,$63,$09,$A2
  DEFB $64,$A0,$64,$09,$A0,$64,$9E,$62
  DEFB $09,$9E,$62,$9E,$54,$09,$9E,$54
  DEFB $97,$5B,$09,$97,$5B,$93,$5B,$09
  DEFB $93,$5B,$93,$55,$09,$93,$55,$9E
  DEFB $44,$09,$9E,$44,$9E,$4F,$09,$9E
  DEFB $4F,$94,$59,$09,$9D,$43,$BC,$43
  DEFB $09,$9E,$4F,$A0,$4F,$09,$A0,$4F
  DEFB $9F,$53,$06,$B5,$6B,$06,$B5,$5B
  DEFB $09,$9D,$43,$92,$4E,$09,$92,$4E
  DEFB $8F,$4C,$09,$8F,$4C,$91,$45,$09
  DEFB $91,$45,$99,$41,$09,$9F,$43,$9F
  DEFB $40,$09,$92,$4E,$96,$4E,$09,$60

; Message at C945
  DEFM "dFd"

; Data block at C948
  DEFB $09,$60

; Message at C94A
  DEFM "dba"

; Data block at C94D
  DEFB $09

; Message at C94E
  DEFM "FdDa"

; Data block at C952
  DEFB $09

; Message at C953
  DEFM "DaDD"

; Data block at C957
  DEFB $09,$44,$44,$60,$44,$09

; Message at C95D
  DEFM "babU"

; Data block at C961
  DEFB $09

; Message at C962
  DEFM "bUi"

; Data block at C965
  DEFB $5C,$09,$69,$5C,$6D,$5C,$09,$6D
  DEFB $5C,$6D,$56,$09

; Message at C971
  DEFM "mVcF"

; Data block at C975
  DEFB $09

; Message at C976
  DEFM "bEbQ"

; Data block at C97A
  DEFB $09

; Message at C97B
  DEFM "bQl["

; Data block at C97F
  DEFB $09,$5F,$63,$5F,$44,$09,$62,$51
  DEFB $60,$51,$09

; Message at C98A
  DEFM "bQbU"

; Data block at C98E
  DEFB $09,$44,$43,$60,$43,$09

; Message at C994
  DEFM "aClN"

; Data block at C998
  DEFB $09

; Message at C999
  DEFM "lNnK"

; Data block at C99D
  DEFB $09

; Message at C99E
  DEFM "nKlD"

; Data block at C9A2
  DEFB $09

; Message at C9A3
  DEFM "lDdA"

; Data block at C9A7
  DEFB $09,$61,$40,$61,$42,$09

; Message at C9AD
  DEFM "lNiN"

; Data block at C9B1
  DEFB $06,$55,$6B,$06,$55,$5B,$09,$60
  DEFB $69,$A0,$69,$09,$78,$59,$88,$59
  DEFB $09,$88,$59,$90,$61,$09,$90,$61
  DEFB $9E,$61,$09

; Message at C9CC
  DEFM "xYpa"

; Data block at C9D0
  DEFB $09

; Message at C9D1
  DEFM "paca"

; Data block at C9D5
  DEFB $09

; Message at C9D6
  DEFM "yYyA"

; Data block at C9DA
  DEFB $09,$89,$41,$89,$59,$09,$58,$9C
  DEFB $50,$9E,$09,$A8,$9C,$B0,$9F,$09
  DEFB $73,$90,$6B,$9F,$09,$90,$90,$98
  DEFB $9F,$08

; Message at C9F4
  DEFM "dntk"

; Data block at C9F8
  DEFB $08,$9E,$6E,$8E,$6B,$08,$78,$67
  DEFB $88,$5F,$08,$76,$92,$8E,$96,$08
  DEFB $8D,$9C,$85,$98,$08,$77,$98,$80
  DEFB $9C,$06,$42,$9E,$09

; Message at CA15
  DEFM "FCFA"

; Data block at CA19
  DEFB $09

; Message at CA1A
  DEFM "MfMd"

; Data block at CA1E
  DEFB $09,$46,$73,$40,$88,$04,$41,$81
  DEFB $09,$B9,$75,$BF,$89,$06,$BE,$9E
  DEFB $09,$BA,$40,$BA,$43,$09,$B5,$64
  DEFB $B5,$67,$04,$BE,$83,$04,$70,$60
  DEFB $04,$70,$60,$04,$70,$60,$04,$70
  DEFB $60,$04,$70,$60,$04,$63,$5C,$04
  DEFB $8B,$5A,$04,$9D,$60,$08,$7D,$56
  DEFB $85,$43,$08,$80,$45,$82,$55,$02
  DEFB $64,$65,$02,$69,$65,$02,$6F,$65
  DEFB $02,$92,$65,$02,$97,$65,$02,$9D
  DEFB $65,$08,$A7,$61,$B6,$48,$08

; Message at CA75
  DEFM "YHK"

; Data block at CA78
  DEFB $60,$11,$00,$10,$04,$12,$01,$05
  DEFB $82,$65,$02,$00,$35,$01,$49,$07
  DEFB $E8,$03,$11,$06,$05,$AF,$97,$09
  DEFB $6F,$5F,$8F,$5F,$09,$8F,$5F,$97
  DEFB $77,$09,$97,$77,$8F,$8F,$09,$8F
  DEFB $8F,$6F,$8F,$09,$6F,$8F,$67,$77
  DEFB $09

; Message at CAA9
  DEFM "gwo"

; Data block at CAAC
  DEFB $5F,$09,$40,$9F,$57,$9A,$09,$57
  DEFB $9A,$57,$68,$09,$57,$68,$5E,$68
  DEFB $09,$5E

; Message at CABE
  DEFM "hab"

; Data block at CAC1
  DEFB $09

; Message at CAC2
  DEFM "abaI"

; Data block at CAC6
  DEFB $09

; Message at CAC7
  DEFM "aI]"

; Data block at CACA
  DEFB $40,$09

; Message at CACC
  DEFM "fwXw"

; Data block at CAD0
  DEFB $09,$70,$8F,$57,$9F,$09,$57,$68
  DEFB $40,$59,$09,$5E,$68,$40,$4A,$09

; Message at CAE0
  DEFM "acFA"

; Data block at CAE4
  DEFB $09,$6F,$5F,$61,$4D,$09,$8F,$5F
  DEFB $A9,$40,$09,$8F,$8F,$AB,$9F,$09
  DEFB $A0,$99,$AC,$78,$09,$A1,$4A,$AC
  DEFB $77,$09,$97,$77,$AB,$77,$09,$B0
  DEFB $49,$B0,$97,$09,$B0,$97,$BF,$9E
  DEFB $09,$A1,$98,$AF,$98,$09,$AF,$49
  DEFB $A2,$49,$09,$B0,$49,$BF,$41,$08
  DEFB $A9,$90,$AE,$87,$02,$AC,$8D,$06
  DEFB $BE,$9B,$09,$BF,$9A,$B4,$96,$09
  DEFB $B4,$96,$B4,$4B,$09,$B4,$4B,$BD
  DEFB $47,$08,$72,$8B,$8C,$63,$08,$77
  DEFB $87,$7F,$7F,$08,$78,$77,$80,$67
  DEFB $09,$84,$67,$84,$86,$11,$02,$05
  DEFB $7C,$84,$11,$05,$05,$7C,$84,$05
  DEFB $7C,$6C,$10,$02,$02,$7B,$6A,$02
  DEFB $7B,$6E,$02,$7B,$72,$10,$01,$02
  DEFB $7B,$85,$02,$7B,$81,$11,$06,$09
  DEFB $72,$56,$8D,$56,$09,$8D,$56,$98
  DEFB $40,$09

; Message at CB76
  DEFM "rVf"

; Data block at CB79
  DEFB $40,$06,$76,$50,$04,$75,$63,$04
  DEFB $8B,$63,$08,$4F,$97,$47,$67,$09
  DEFB $4F,$97,$41,$9A,$09,$47,$97,$42
  DEFB $98,$09,$47,$67,$40,$63,$09,$4F
  DEFB $67,$40,$5E,$09,$4F,$80,$48,$80
  DEFB $09

; Message at CBA2
  DEFM "HwNw"

; Data block at CBA6
  DEFB $11,$05,$05,$4B,$7D,$02,$4A,$7D
  DEFB $02,$4C,$7D,$04,$4C,$8A,$04,$4C
  DEFB $6A,$03,$00,$F5,$02,$B3,$07,$E8
  DEFB $03,$11,$07,$05,$A7,$87,$09,$40
  DEFB $77,$88,$77,$09,$88,$77,$88,$5F
  DEFB $09,$88,$5F,$BF,$5F,$09,$BF,$4F
  DEFB $40,$4F,$09

; Message at CBD9
  DEFM "AwDl"

; Data block at CBDD
  DEFB $09

; Message at CBDE
  DEFM "DlFs"

; Data block at CBE2
  DEFB $09

; Message at CBE3
  DEFM "FsHj"

; Data block at CBE7
  DEFB $09

; Message at CBE8
  DEFM "HjKv"

; Data block at CBEC
  DEFB $09

; Message at CBED
  DEFM "KvMl"

; Data block at CBF1
  DEFB $09

; Message at CBF2
  DEFM "MlPt"

; Data block at CBF6
  DEFB $09

; Message at CBF7
  DEFM "PtSj"

; Data block at CBFB
  DEFB $09

; Message at CBFC
  DEFM "SjVv"

; Data block at CC00
  DEFB $09

; Message at CC01
  DEFM "VvXo"

; Data block at CC05
  DEFB $09

; Message at CC06
  DEFM "XoZt"

; Data block at CC0A
  DEFB $09,$5A,$74,$5C,$6C,$09,$5C,$6C
  DEFB $5F,$75,$09,$5F

; Message at CC16
  DEFM "ubj"

; Data block at CC19
  DEFB $09

; Message at CC1A
  DEFM "bjfv"

; Data block at CC1E
  DEFB $09

; Message at CC1F
  DEFM "fvhi"

; Data block at CC23
  DEFB $09

; Message at CC24
  DEFM "hikt"

; Data block at CC28
  DEFB $09

; Message at CC29
  DEFM "ktmm"

; Data block at CC2D
  DEFB $09

; Message at CC2E
  DEFM "mmqw"

; Data block at CC32
  DEFB $09

; Message at CC33
  DEFM "qwtk"

; Data block at CC37
  DEFB $09

; Message at CC38
  DEFM "tkwt"

; Data block at CC3C
  DEFB $09

; Message at CC3D
  DEFM "wtzm"

; Data block at CC41
  DEFB $09,$7A,$6D,$7C,$76,$09,$7C,$76
  DEFB $7E,$6A,$09,$7E,$6A,$82,$77,$09
  DEFB $82,$77,$88,$60,$09,$88,$60,$8B
  DEFB $66,$09,$8B,$66,$91,$6E,$09,$91
  DEFB $6E,$9B,$74,$09,$9B,$74,$A5,$77
  DEFB $09,$A5,$77,$B3,$77,$09,$B3,$77
  DEFB $B8,$74,$09,$B8,$74,$BA,$66,$09
  DEFB $BA,$66,$B5,$64,$09,$B5,$64,$BA
  DEFB $64,$09,$BA,$64,$BC,$5F,$09,$B7
  DEFB $75,$BF,$73,$09,$AF,$5F,$BE,$50
  DEFB $09,$B5,$76,$AE,$74,$09,$AE,$74
  DEFB $A3,$71,$09,$A3,$71,$9A,$6D,$09
  DEFB $9A,$6D,$95,$69,$09,$95,$69,$8E
  DEFB $63,$09,$8E,$63,$8A,$5F,$09,$B3
  DEFB $78,$B7,$7D,$09,$B7,$7D,$BF,$7C
  DEFB $09,$B7,$7E,$B0,$78,$09,$88,$6F
  DEFB $90,$6F,$09,$90,$6F,$90,$77,$09
  DEFB $90,$77,$A8,$77,$09,$BF,$7F,$AF
  DEFB $7F,$09,$AF,$7F,$AF,$77,$09

; Message at CCD8
  DEFM "BwD"

; Data block at CCDB
  DEFB $83,$09,$44,$83,$46,$7A,$09

; Message at CCE2
  DEFM "FzH"

; Data block at CCE5
  DEFB $7F,$09,$48,$7F,$4A,$78,$09

; Message at CCEC
  DEFM "OxR"

; Data block at CCEF
  DEFB $7F,$09,$52,$7F,$54,$78,$09

; Message at CCF6
  DEFM "[x[x"

; Data block at CCFA
  DEFB $09

; Message at CCFB
  DEFM "[x]"

; Data block at CCFE
  DEFB $7C,$09,$5D,$7C,$5F,$78,$09,$5F
  DEFB $78,$61,$82,$09,$61,$82,$64,$77
  DEFB $09

; Message at CD0F
  DEFM "jwl"

; Data block at CD12
  DEFB $81,$09,$6C,$80,$6E,$79,$09

; Message at CD19
  DEFM "nyp"

; Data block at CD1C
  DEFB $7F,$09,$70,$7F,$73,$79,$09

; Message at CD23
  DEFM "syu"

; Data block at CD26
  DEFB $80,$09,$75,$7F,$77,$78,$09,$7E
  DEFB $78,$80,$7E,$09,$80,$7E,$81,$79
  DEFB $09,$81,$78,$85,$82,$09,$85,$82
  DEFB $88,$77,$09,$88,$77,$8A,$73,$09
  DEFB $8A,$73,$8D,$7E,$09,$8D,$7E,$8F
  DEFB $78,$09,$8F,$78,$91,$84,$09,$91
  DEFB $84,$94,$78,$09,$99,$77,$9B,$82
  DEFB $09,$9B,$82,$9D,$78,$09,$9D,$78
  DEFB $9F,$7F,$09,$9F,$7F,$A1,$78,$09
  DEFB $AB,$77,$B0,$85,$09,$B0,$85,$B2
  DEFB $7F,$09,$B2,$7F,$B4,$89,$09,$B4
  DEFB $89,$B6,$80,$09,$BA,$7F,$BC,$8A
  DEFB $09,$BC,$8A,$BE,$80,$09,$8B,$65
  DEFB $8F,$65,$09,$8F,$65,$91,$60,$09
  DEFB $92,$6C,$A1,$6C,$09,$A1,$6C,$A2
  DEFB $67,$09,$A2,$67,$97,$67,$09,$97
  DEFB $67,$9A,$6B,$09,$93,$67,$8F,$67
  DEFB $09,$8F,$67,$92,$6C,$04,$44,$6F
  DEFB $04,$48,$6F,$04,$4D,$70,$04,$53
  DEFB $70,$04,$58,$72,$04,$5C,$72,$04
  DEFB $62,$72,$04,$68,$72,$04,$6E,$72
  DEFB $04,$74,$72,$04,$7A,$72,$04,$7F
  DEFB $72,$04,$87,$69,$04,$89,$64,$04
  DEFB $90,$76,$04,$92,$68,$04,$9F,$6B
  DEFB $04,$BE,$5D,$06,$A5,$75,$06,$9A
  DEFB $71,$06,$8B,$61,$06,$8E,$60,$06
  DEFB $94,$61,$06,$B5,$74,$06,$BE,$7A
  DEFB $06,$B2,$78,$06,$BE,$71,$09,$9D
  DEFB $74,$AD,$74,$09,$AD,$74,$B1,$6B
  DEFB $09,$B1,$6B,$AB,$6B,$09,$AB,$6B
  DEFB $A7,$71,$09,$96,$60,$BB,$60,$08
  DEFB $A8,$66,$AF,$62,$11,$04,$06,$42
  DEFB $70,$06,$4B,$70,$06,$50,$70,$06
  DEFB $56,$70,$06,$5A,$70,$06,$5F,$70
  DEFB $06,$66,$70,$06,$6B,$70,$06,$71
  DEFB $70,$06,$78,$70,$06,$7C,$70,$06
  DEFB $83,$70,$09,$5E,$50,$8E,$50,$09
  DEFB $7E,$52,$AE,$51,$11,$01,$04,$44
  DEFB $7E,$04,$48,$7C,$04,$52,$7D,$04
  DEFB $5D,$7A,$04,$61,$7F,$04,$6C,$7E
  DEFB $04,$70,$7D,$04,$75,$7D,$04,$80
  DEFB $7B,$04,$85,$80,$04,$8D,$7C,$04
  DEFB $91,$80,$04,$9B,$7F,$04,$9F,$7D
  DEFB $04,$AE,$7C,$04,$B0,$83,$04,$B4
  DEFB $86,$04,$BC,$86,$05,$AC,$9C,$11
  DEFB $07,$04,$91,$6F,$04,$B0,$79,$04
  DEFB $BE,$7D,$11,$06,$06,$9E,$4D,$09
  DEFB $66,$4E,$96,$4E,$09

; Message at CEA3
  DEFM "oMGM"

; Data block at CEA7
  DEFB $09,$57,$4D,$A7,$49,$4D,$00,$47
  DEFB $02,$85,$07,$E8,$03,$11,$07,$05
  DEFB $7F,$7F,$09

; Message at CEBA
  DEFM "pHh"

; Data block at CEBD
  DEFB $60,$09,$68,$60,$70,$78,$09,$70
  DEFB $78,$88,$78,$09,$88,$78,$90,$60
  DEFB $09,$90,$60,$88,$48,$09

; Message at CED3
  DEFM "lHd"

; Data block at CED6
  DEFB $5E,$09,$64,$5E,$68,$5F,$09,$67
  DEFB $5F,$6F,$78,$09,$88,$78,$91,$61
  DEFB $09,$91,$60,$94,$5E,$09,$94,$5E
  DEFB $8C,$48,$09,$71,$48,$86,$48,$09
  DEFB $8C,$48,$8C,$40,$09

; Message at CEFB
  DEFM "lGl"

; Data block at CEFE
  DEFB $40,$09

; Message at CF00
  DEFM "qHmA"

; Data block at CF04
  DEFB $09,$88,$47,$8B,$41,$09,$89

; Message at CF0B
  DEFM "EqE"

; Data block at CF0E
  DEFB $09,$6E,$42,$89,$42,$09,$90,$61
  DEFB $BF,$61,$09,$94,$5E,$BC,$5E,$09
  DEFB $68,$60,$40,$60,$09,$40,$5C,$63
  DEFB $5C,$09,$40,$7D,$BF,$7D,$09,$BF
  DEFB $81,$40,$81,$08

; Message at CF32
  DEFM "Oyec"

; Data block at CF36
  DEFB $08,$94,$63,$AA,$78,$09,$98,$73
  DEFB $9C,$75,$09,$9C,$75,$9F,$74,$09
  DEFB $9F,$74,$9E,$70,$09,$9E,$70,$98
  DEFB $72,$09,$9D,$70,$9F,$6B,$09,$9F
  DEFB $6B,$A4,$6A,$09,$A1,$6B,$A3,$6E
  DEFB $09,$A3,$6D,$A5,$66,$09,$9F,$6B
  DEFB $A0,$6F,$09,$A0,$6F,$A2,$66,$09
  DEFB $9F,$6C,$9B,$6B,$09,$9B,$6B,$99
  DEFB $6D,$09,$9B,$74,$9D,$73,$04,$9D
  DEFB $74,$09,$5B,$75,$5F,$74,$09,$5F
  DEFB $74,$60,$71,$09,$60

; Message at CF8B
  DEFM "qZq"

; Data block at CF8E
  DEFB $09

; Message at CF8F
  DEFM "Zq[t"

; Data block at CF93
  DEFB $09

; Message at CF94
  DEFM "ZqYl"

; Data block at CF98
  DEFB $09

; Message at CF99
  DEFM "YlTj"

; Data block at CF9D
  DEFB $09

; Message at CF9E
  DEFM "WlUo"

; Data block at CFA2
  DEFB $09

; Message at CFA3
  DEFM "UoTf"

; Data block at CFA7
  DEFB $09

; Message at CFA8
  DEFM "UjSn"

; Data block at CFAC
  DEFB $09

; Message at CFAD
  DEFM "SnRg"

; Data block at CFB1
  DEFB $09

; Message at CFB2
  DEFM "Ym]k"

; Data block at CFB6
  DEFB $09,$5D,$6B,$60,$6D,$09,$5C,$73
  DEFB $5E,$73,$02,$5C,$74,$02,$97,$68
  DEFB $02,$99,$68,$02,$99,$68,$02,$9A
  DEFB $68,$02,$98,$67,$02,$9B,$67,$02
  DEFB $9B,$65,$02,$52,$75,$02,$56,$75
  DEFB $02,$58,$73,$02,$56,$74,$02,$5B
  DEFB $66,$02,$5E,$68,$02,$60,$68,$04
  DEFB $79,$68,$09,$89,$81,$89,$9F,$09
  DEFB $70,$81,$70,$9F,$09,$51,$87,$5A
  DEFB $87,$09,$5A,$87,$59,$96,$09,$59
  DEFB $96,$5D,$94,$09,$51,$87,$57,$89
  DEFB $09,$57,$89,$57,$9A,$09,$57,$9A
  DEFB $5E,$96,$09,$5F,$97,$61,$9E,$09
  DEFB $67,$9E,$62,$90,$09,$62,$90,$5B
  DEFB $92,$09,$56,$97,$53,$99,$09,$53
  DEFB $99,$53,$8A,$09,$53,$8A,$4E,$87
  DEFB $09,$51,$87,$4F,$87,$09,$4A,$81
  DEFB $4A,$9F,$09,$68,$9F,$62,$8E,$09
  DEFB $5B,$92,$5C,$87,$09,$73,$81,$73
  DEFB $9F,$09,$86,$9F,$86,$81,$08,$78
  DEFB $9C,$81,$94,$08,$81,$90,$78,$85
  DEFB $02,$7A,$8D,$02,$7D,$8D,$02,$7D
  DEFB $8C,$02,$7D,$8A,$02,$7B,$88,$02
  DEFB $7E,$88,$02,$7A,$9A,$02,$7D,$9A
  DEFB $02,$7D,$99,$02,$7C,$98,$02,$7E
  DEFB $96,$02,$7F,$96,$02,$7F,$97,$09
  DEFB $65,$89,$65,$8D,$09,$65,$8D,$68
  DEFB $8D,$09,$68,$8B,$6A,$8B,$09,$69
  DEFB $88,$6D,$86,$09,$92,$9E,$99,$8C
  DEFB $09,$99,$8C,$A5,$90,$09,$A5,$90
  DEFB $9C,$93,$09,$9C,$93,$98,$9E,$09
  DEFB $96,$9A,$92,$8D,$09,$92,$8D,$8F
  DEFB $99,$09,$8F,$99,$8D,$96,$09,$9B
  DEFB $8D,$9F,$99,$09,$9F,$99,$9F,$88
  DEFB $09,$9F,$88,$A3,$88,$09,$AB,$81
  DEFB $AB,$9F,$06,$AB,$4F,$06,$5B,$4F
  DEFB $06,$43,$67,$06,$BB,$67,$06,$BB
  DEFB $87,$06,$83,$87,$06,$43,$87,$06
  DEFB $75,$44,$06,$68,$6D,$06,$90,$6D
  DEFB $08,$A4,$45,$BF,$51,$09,$00,$9E
  DEFB $00,$25,$07,$E8,$03,$07,$E7,$00
  DEFB $09,$57,$9E,$57,$40,$11,$04,$05
  DEFB $51,$45,$07,$3C,$00,$04,$43,$47
  DEFB $06,$4B,$47,$09,$4B,$40,$4E,$80
  DEFB $09,$49,$9E,$4B,$66,$09,$54,$9F
  DEFB $55,$40,$06,$53,$68,$11,$06,$05
  DEFB $73,$68,$09,$58,$58,$BF,$52,$10
  DEFB $01,$06,$BD,$54,$09,$BF,$7E,$58
  DEFB $7C,$09,$58,$7C,$BF,$7A,$09,$A6
  DEFB $79,$8F,$79,$09,$90,$78,$A3,$76
  DEFB $09,$9F,$76,$99,$75,$09,$99,$75
  DEFB $9F,$73,$09,$8F,$76,$95,$75,$09
  DEFB $95,$75,$8A,$74,$09,$8C

; Message at D15C
  DEFM "zwy"

; Data block at D15F
  DEFB $09,$77,$79,$7E,$77,$09,$7E

; Message at D166
  DEFM "wwv"

; Data block at D169
  DEFB $09,$76,$75,$7C,$73,$09,$83,$79
  DEFB $89,$78,$09,$89,$78,$84,$77,$09
  DEFB $84,$76,$87,$75,$09

; Message at D17E
  DEFM "ozYy"

; Data block at D182
  DEFB $09

; Message at D183
  DEFM "Yynx"

; Data block at D187
  DEFB $10,$00,$09,$58,$51,$BF,$4C,$06
  DEFB $5B,$50,$0A,$00,$8D,$01,$62,$07
  DEFB $E8,$03,$11,$07,$05,$B7,$97,$08
  DEFB $80,$7E,$98,$97,$09,$98,$86,$90
  DEFB $96,$09,$88,$96,$80,$86,$09,$88
  DEFB $7E,$8C,$86,$09,$8C,$86,$90,$7E
  DEFB $09,$90,$7E,$94,$84,$09,$94,$84
  DEFB $97,$7F,$09,$88,$7E,$84,$84,$09
  DEFB $84,$84,$81,$7F,$04,$84,$82,$04
  DEFB $94,$82,$09,$8A,$96,$85,$83,$09
  DEFB $89,$91,$8D,$91,$09,$88,$8D,$8D
  DEFB $8D,$09,$87,$89,$93,$87,$10,$01
  DEFB $04,$81,$8B,$04,$97,$8B,$10,$04
  DEFB $04,$8C,$80,$10,$09,$11,$04,$05
  DEFB $5F,$97,$05,$AF,$97,$07,$46,$00
  DEFB $07,$5A,$00,$09,$87,$7E,$7C,$65
  DEFB $09,$90,$7E,$98,$67,$09,$95,$71
  DEFB $9E,$92,$09,$9E,$92,$A5,$74,$09
  DEFB $A2,$7F,$A7,$90,$09,$80,$6F,$7C
  DEFB $99,$09,$7C,$99,$75,$78,$09

; Message at D226
  DEFM "wmr"

; Data block at D229
  DEFB $95,$09,$72,$95,$6F,$88,$09,$60
  DEFB $80,$5A,$9F,$09,$4C,$9F,$41,$7A
  DEFB $09

; Message at D23A
  DEFM "OpW"

; Data block at D23D
  DEFB $90,$09,$57,$90,$60,$69,$09,$60
  DEFB $51,$40,$4F,$09,$6F,$53,$A6,$51
  DEFB $09

; Message at D24E
  DEFM "wmy"

; Data block at D251
  DEFB $5F,$09,$79,$5F,$73,$63,$09

; Message at D258
  DEFM "scsS"

; Data block at D25C
  DEFB $09

; Message at D25D
  DEFM "rcpT"

; Data block at D261
  DEFB $06,$72,$5F,$09,$79,$61,$89,$65
  DEFB $09,$89,$65,$89,$52,$09,$8E,$52
  DEFB $8E,$67,$09,$8D,$67,$8B,$53,$06
  DEFB $8D,$5F,$04,$88,$63,$04,$74,$61
  DEFB $09,$98,$66,$8A,$6A,$09,$99,$6A
  DEFB $99,$52,$09,$9D,$51,$9B,$6B,$09
  DEFB $9B,$6B,$A7,$66,$09,$9F,$69,$9F
  DEFB $51,$06,$9E,$52,$04,$90,$67,$04
  DEFB $A0,$67,$09

; Message at D2A4
  DEFM "OoK"

; Data block at D2A7
  DEFB $60,$09,$4B,$60,$55,$65,$09

; Message at D2AE
  DEFM "UeUP"

; Data block at D2B2
  DEFB $09

; Message at D2B3
  DEFM "ZRZi"

; Data block at D2B7
  DEFB $09

; Message at D2B8
  DEFM "YiWQ"

; Data block at D2BC
  DEFB $06,$59,$60,$09,$5A,$65,$60,$63
  DEFB $04,$5B,$64,$09

; Message at D2C8
  DEFM "LdC"

; Data block at D2CB
  DEFB $60,$09

; Message at D2CD
  DEFM "HbHP"

; Data block at D2D1
  DEFB $09

; Message at D2D2
  DEFM "OPOc"

; Data block at D2D6
  DEFB $09,$4B,$5F,$4D,$50,$09

; Message at D2DC
  DEFM "JPJ"

; Data block at D2DF
  DEFB $60,$06,$4E,$52,$06,$4B,$59,$04
  DEFB $47,$60,$04,$54,$63,$04,$81,$74
  DEFB $04,$95,$74,$04,$BE,$47,$06,$B8
  DEFB $47,$06,$B2,$87,$06,$AB,$87,$06
  DEFB $62,$87,$06,$67,$87,$06,$6D,$87
  DEFB $10,$01,$04,$41,$7E,$04,$5F,$88
  DEFB $04,$70,$8F,$04,$75,$81,$04,$7F
  DEFB $83,$04,$99,$84,$04,$A2,$84,$0B
  DEFB $00,$EE,$00,$39,$07,$E8,$03,$11
  DEFB $04,$05,$B7,$97,$07,$5A,$00,$07
  DEFB $50,$00,$09,$64,$97,$5C,$6F,$09
  DEFB $64,$97,$6C,$77,$09,$6A,$7F,$72
  DEFB $9F,$09,$82,$9F,$8A,$87,$09,$87
  DEFB $77,$8F,$9D,$09,$5E,$77,$55,$9F
  DEFB $09,$45,$9F,$41,$8F,$09

; Message at D355
  DEFM "]sNx"

; Data block at D359
  DEFB $09,$51,$7B,$43,$72,$09

; Message at D35F
  DEFM "KwJ"

; Data block at D362
  DEFB $5F,$09,$4A,$5E,$47,$75,$04,$49
  DEFB $6C,$09

; Message at D36C
  DEFM "PwO"

; Data block at D36F
  DEFB $5F,$09

; Message at D371
  DEFM "MaMq"

; Data block at D375
  DEFB $09,$5C

; Message at D377
  DEFM "rQs"

; Data block at D37A
  DEFB $04,$51,$76,$09

; Message at D37E
  DEFM "hytp"

; Data block at D382
  DEFB $09,$6F,$73,$7C,$7B,$09

; Message at D388
  DEFM "vwyo"

; Data block at D38C
  DEFB $09

; Message at D38D
  DEFM "yoyx"

; Data block at D391
  DEFB $04,$78,$74,$09,$7F,$77,$7E,$67
  DEFB $09,$40

; Message at D39B
  DEFM "KTL"

; Data block at D39E
  DEFB $09,$59,$4C,$5F,$4D,$09

; Message at D3A4
  DEFM "dMuP"

; Data block at D3A8
  DEFB $09,$80,$53,$8F,$52,$09,$9F,$52
  DEFB $A7,$54,$09,$9F,$84,$A3,$98,$09
  DEFB $A3,$98,$A8,$80,$06,$93,$68,$06
  DEFB $97,$68,$09,$9E,$70,$9C,$50,$04
  DEFB $9E,$65,$06,$9B,$59,$06,$AC,$59
  DEFB $06,$B1,$59,$09,$B1,$71,$AF,$41
  DEFB $06,$B8,$41,$09,$B8,$41,$B6,$79
  DEFB $06,$BE,$79,$09,$4A,$5E,$4C,$4D
  DEFB $06,$45,$6D,$09,$40,$45,$90,$49
  DEFB $09,$90,$49,$A7,$47,$06,$8E,$48
  DEFB $10,$01,$04,$A7,$88,$04,$A0,$8D
  DEFB $04,$8A,$8A,$04,$6A,$83,$04,$5E
  DEFB $7D,$04,$41,$94,$0E,$00,$0D,$00
  DEFB $03,$07,$0B,$00,$10,$00,$07,$57
  DEFB $04,$EB,$05,$51,$01,$4B,$07,$E8
  DEFB $03,$11,$07,$05,$87,$77,$03,$8D
  DEFB $7E,$88,$84,$03,$7D,$7E,$82,$84
  DEFB $09,$82,$7F,$85,$80,$09,$85,$80
  DEFB $87,$7F,$09,$7C,$79,$7E,$6F,$09
  DEFB $7E,$6F,$83,$6B,$09,$83,$6B,$86
  DEFB $6B,$09,$86,$6B,$8B,$6F,$09,$8B
  DEFB $6F,$8D,$78,$09,$85,$7C,$85,$73
  DEFB $03,$7D,$7C,$7B,$7F,$04,$7A,$80
  DEFB $04,$80,$7D,$03,$8D,$7C,$8B,$7F
  DEFB $04,$8E,$82,$04,$8A,$7D,$04,$90
  DEFB $7D,$04,$7E,$82,$09,$83,$6A,$82
  DEFB $5C,$09,$82,$5C,$80,$54,$09,$80
  DEFB $54,$84,$4E,$09,$84,$4E,$88,$54
  DEFB $09,$88,$55,$86,$5B,$09,$86,$5B
  DEFB $85,$6A,$09,$83

; Message at D494
  DEFM "gyi"

; Data block at D497
  DEFB $09

; Message at D498
  DEFM "yiwt"

; Data block at D49C
  DEFB $09

; Message at D49D
  DEFM "wtsx"

; Data block at D4A1
  DEFB $09

; Message at D4A2
  DEFM "sxts"

; Data block at D4A6
  DEFB $09

; Message at D4A7
  DEFM "tsxh"

; Data block at D4AB
  DEFB $09,$78,$68,$82,$65,$09,$86,$66
  DEFB $8D,$60,$09,$8D,$60,$88,$5A,$09
  DEFB $88,$5A,$8A,$60,$09,$8A,$60,$86
  DEFB $64,$09,$81

; Message at D4C6
  DEFM "[xc"

; Data block at D4C9
  DEFB $09

; Message at D4CA
  DEFM "xcwL"

; Data block at D4CE
  DEFB $09

; Message at D4CF
  DEFM "wLrJ"

; Data block at D4D3
  DEFB $09

; Message at D4D4
  DEFM "rJyJ"

; Data block at D4D8
  DEFB $09

; Message at D4D9
  DEFM "yJz"

; Data block at D4DC
  DEFB $5F,$09,$7A,$5F,$80,$5A,$09,$87
  DEFB $59,$91,$61,$09,$91,$61,$92,$4B
  DEFB $09,$92,$4B,$96,$4A,$09,$96,$4A
  DEFB $8E,$4A,$09,$90,$4A,$8F,$5D,$09
  DEFB $8F,$5D,$88,$58,$09,$7D,$5C,$7B
  DEFB $4B,$09,$8C,$5B,$8E,$4B,$09,$40

; Message at D50C
  DEFM "PuP"

; Data block at D50F
  DEFB $09,$7D,$50,$81,$50,$09,$86,$50
  DEFB $8C,$50,$09,$93,$50,$BF,$50,$11
  DEFB $04,$06,$97,$53,$06,$47,$7B,$06
  DEFB $86,$82,$06,$7A,$75,$06,$7E,$61
  DEFB $06,$7E,$54,$06,$8A,$54,$05,$82
  DEFB $74,$08,$40,$84,$70,$9F,$08,$A0
  DEFB $9F,$BE,$67,$08,$40,$87,$6C,$9F
  DEFB $03,$4B,$97,$44,$92,$09,$82,$59
  DEFB $85,$59,$09,$84,$80,$7F,$8B,$09
  DEFB $7F,$8B,$7A,$84,$09,$85,$81,$8B
  DEFB $89,$09,$8B,$89,$8E,$85,$11,$06
  DEFB $05,$50,$47,$11,$00,$B3,$00,$2A
  DEFB $07,$E8,$03,$11,$07,$13,$01,$05
  DEFB $7F,$6F,$08,$6F,$47,$8F,$5F,$08
  DEFB $6C,$5F,$92,$67,$03,$7F

; Message at D585
  DEFM "quf"

; Data block at D588
  DEFB $03,$7F,$70,$7B,$75,$09,$7E,$6C
  DEFB $7E,$68,$09,$81,$68,$81,$6B,$08

; Message at D598
  DEFM "rfw"

; Data block at D59B
  DEFB $5F,$08,$75,$5F,$7A,$47,$09

; Message at D5A2
  DEFM "sGs"

; Data block at D5A5
  DEFB $5E,$09,$70,$5F,$70,$66,$04,$75
  DEFB $64,$04,$77,$5C,$09,$8D,$9F,$9D
  DEFB $47,$09,$75,$9F,$5D,$47,$09

; Message at D5BC
  DEFM "]GvB"

; Data block at D5C0
  DEFB $09,$76,$42,$89,$42,$09,$89,$42
  DEFB $9D,$47,$06,$51,$47,$06,$B1,$47
  DEFB $09,$70,$46,$8D,$46,$09,$8B

; Message at D5D7
  DEFM "EsE"

; Data block at D5DA
  DEFB $08,$40,$60,$60,$9F,$08,$BF,$60
  DEFB $9F,$9F,$08,$A7,$97,$B7,$77,$08
  DEFB $47,$97,$57,$77,$06,$7F,$77,$06
  DEFB $77,$6F,$06,$87,$6F,$06,$7A,$6B
  DEFB $06,$83,$6B,$06,$83,$5B,$06,$83
  DEFB $63,$06,$6D,$63,$06,$71,$59,$08
  DEFB $AA,$94,$B4,$7A,$09,$9F,$75,$BF
  DEFB $75,$08

; Message at D614
  DEFM "JzT"

; Data block at D617
  DEFB $94,$09

; Message at D619
  DEFM "atAt"

; Data block at D61D
  DEFB $12,$00,$3B,$01,$4E,$07,$E8,$03
  DEFB $11,$04,$05,$B7,$97,$07,$3C,$00
  DEFB $07,$50,$00,$07,$5A,$00,$09,$57
  DEFB $83,$5F,$9B,$09,$5F,$9B,$6F,$6B
  DEFB $09,$67,$84,$6C,$94,$09,$6C,$94
  DEFB $73,$74,$09,$6F,$67,$7E,$97,$09
  DEFB $7E,$97,$88,$6F,$09,$85,$7A,$8B
  DEFB $9A,$09,$8B,$9A,$90,$76,$09,$9F
  DEFB $8B,$A2,$9A,$09,$A2,$9A,$A8,$85
  DEFB $09,$57,$55,$8F,$59,$09,$9F,$59
  DEFB $A7,$5A,$06,$43,$72,$09

; Message at D673
  DEFM "FoIO"

; Data block at D677
  DEFB $09

; Message at D678
  DEFM "IOHA"

; Data block at D67C
  DEFB $04,$46,$67,$06,$4D,$67,$09,$4D
  DEFB $40,$4A,$88,$09,$4D,$88,$4F,$60
  DEFB $06,$55,$60,$09,$55,$40,$53,$58
  DEFB $09,$53,$9F,$54,$78,$06,$93,$6B
  DEFB $09,$95,$64,$98,$50,$04,$95,$5B
  DEFB $06,$97,$5E,$06,$99,$57,$06,$9C
  DEFB $57,$09,$A9,$67,$AD,$4E,$09,$A9
  DEFB $80,$AE,$70,$06,$AE,$74,$06,$A9
  DEFB $63,$06,$B2,$74,$06,$B7,$74,$06
  DEFB $BE,$44,$09,$6F,$66,$7E,$6B,$09
  DEFB $7E,$6B,$7E,$58,$09

; Message at D6D1
  DEFM "xWxh"

; Data block at D6D5
  DEFB $09,$7A,$69,$7B,$58,$06,$79,$66
  DEFB $06,$7C,$66,$09,$7E,$66,$8A,$69
  DEFB $09,$88,$69,$8F,$72,$09,$88,$69
  DEFB $88,$59,$09,$8D,$59,$8D,$71,$09
  DEFB $8B,$6D,$8A,$59,$06,$8C,$5C,$04
  DEFB $8F,$71,$04,$87,$67,$09,$5F

; Message at D704
  DEFM "img"

; Data block at D707
  DEFB $09

; Message at D708
  DEFM "[i[U"

; Data block at D70C
  DEFB $09

; Message at D70D
  DEFM "cVch"

; Data block at D711
  DEFB $09,$60,$69,$5F,$56,$09,$5D,$56
  DEFB $5E,$6A,$06,$61,$65,$09

; Message at D71F
  DEFM "Wicl"

; Data block at D723
  DEFB $04,$5A,$68,$04,$64,$67,$09,$9F
  DEFB $6C,$A8,$69,$09,$A2,$6B,$A2,$5A
  DEFB $09,$A6,$5A,$A6,$6A,$06,$A4,$69
  DEFB $04,$A1,$69,$04,$A7,$67,$10,$01
  DEFB $04,$A7,$8B,$04,$A0,$93,$04,$8F
  DEFB $82,$04,$85,$7F,$04,$73,$77,$04
  DEFB $67,$86,$04,$58,$89,$1A,$00,$43
  DEFB $00,$10,$07,$E8,$03,$11,$04,$05
  DEFB $8F,$87,$10,$01,$06,$8F,$87,$09
  DEFB $40,$61,$80,$63,$09,$80,$63,$BF
  DEFB $5E,$09,$B8

; Message at D776
  DEFM "YXW"

; Data block at D779
  DEFB $09,$4B,$51,$B3,$4F,$03,$AB,$8F
  DEFB $A8,$92,$03,$B5,$82,$B3,$85,$03
  DEFB $A5,$72,$A2,$76,$03,$B2,$68,$AF
  DEFB $6C,$02,$AC,$85,$02,$B0,$7D,$02
  DEFB $AA,$6D,$17,$00,$D0,$00,$2E,$07
  DEFB $E8,$03,$07,$E7,$00,$05,$41,$95
  DEFB $10,$06,$09,$58,$9F,$58,$88,$09
  DEFB $58,$7F,$40,$7F,$10,$04,$09,$40
  DEFB $8B,$44,$84,$09,$44,$84,$46,$8E
  DEFB $09,$46,$8E,$49,$86,$09,$49,$86
  DEFB $4B,$8D,$09,$4B,$8D,$4E,$82,$09
  DEFB $4E,$82,$50,$8C,$09,$50,$8C,$52
  DEFB $84,$09,$52,$84,$54,$8D,$09,$54
  DEFB $8D,$57,$7F,$04,$41,$87,$04,$46
  DEFB $8A,$04,$4B,$8A,$04,$50,$88,$04
  DEFB $54,$8A,$10,$01,$06,$8C,$4A,$09
  DEFB $BF,$7E,$40,$7C,$09,$40,$7C,$BF
  DEFB $7B,$09,$BF,$7B,$A7,$79,$09,$99
  DEFB $7A,$A0,$79,$09,$A0,$79,$99,$77
  DEFB $09,$94,$7A,$90,$79,$09,$90,$79
  DEFB $96,$78,$09,$96,$78,$90,$77,$09
  DEFB $8B,$7A,$80,$78,$09,$80,$78,$86
  DEFB $77,$09,$86,$77,$7B,$76,$09,$7B
  DEFB $76,$7D,$74,$09,$7D

; Message at D836
  DEFM "tys"

; Data block at D839
  DEFB $09,$78,$7B,$70,$7A,$09

; Message at D83F
  DEFM "pyvx"

; Data block at D843
  DEFB $09

; Message at D844
  DEFM "vxqv"

; Data block at D848
  DEFB $09,$6E,$7B,$56,$7A,$09

; Message at D84E
  DEFM "Vzkx"

; Data block at D852
  DEFB $09,$55,$7E,$42,$7E,$09,$42,$7B
  DEFB $52,$79,$09

; Message at D85D
  DEFM "RyOx"

; Data block at D861
  DEFB $09

; Message at D862
  DEFM "IyFw"

; Data block at D866
  DEFB $09,$7A,$79,$7E,$79,$15,$00,$0F
  DEFB $01,$42,$07,$E8,$03,$11,$04,$05
  DEFB $B7,$97,$07,$3C,$00,$09

; Message at D87C
  DEFM "XkXO"

; Data block at D880
  DEFB $07,$5A,$00,$09,$57,$8A,$5C,$9A
  DEFB $09,$5C,$9A,$61,$85,$09,$61,$85
  DEFB $65,$97,$09,$65,$97,$6C,$7D,$09
  DEFB $6A,$86,$6F,$96,$09,$6F,$96,$74
  DEFB $81,$09,$74,$81,$79,$99,$09,$79
  DEFB $99,$7F,$7A,$09,$7F,$7C,$85,$93
  DEFB $09,$85,$93,$88,$84,$09,$88,$84
  DEFB $8F,$95,$09,$8F,$95,$94,$7E,$09
  DEFB $94,$7E,$9A,$9B,$09,$9A,$9B,$A2
  DEFB $7D,$09,$A2,$7D,$A7,$95,$09,$A9

; Message at D8D0
  DEFM "oYo"

; Data block at D8D3
  DEFB $09,$57,$4B,$A7,$4D,$09

; Message at D8D9
  DEFM "Wydv"

; Data block at D8DD
  DEFB $09

; Message at D8DE
  DEFM "bwlz"

; Data block at D8E2
  DEFB $09,$6B,$78,$83,$76,$09,$81,$77
  DEFB $8A,$7B,$09,$88,$79,$A0,$77,$09
  DEFB $9F,$78,$A8,$7A,$09,$A8

; Message at D8F8
  DEFM "rXq"

; Data block at D8FB
  DEFB $09,$5C,$78,$5C,$71,$09,$5F,$71
  DEFB $5F,$77,$09

; Message at D906
  DEFM "qwqr"

; Data block at D90A
  DEFB $09

; Message at D90B
  DEFM "tqtv"

; Data block at D90F
  DEFB $09,$86,$79,$86,$72,$09,$89,$72
  DEFB $89,$79,$09,$A4,$79,$A4,$72,$09
  DEFB $A7,$72,$A7,$79,$04,$A8,$79,$06
  DEFB $A5,$78,$04,$A2,$77,$06,$88,$77
  DEFB $04,$84,$77,$06,$73,$75,$04,$6A
  DEFB $78,$06,$5D,$76,$04,$58,$78,$06
  DEFB $43,$7B,$06,$4A,$7B,$09,$57,$99
  DEFB $51,$83,$06,$51,$87,$09,$A7,$5F
  DEFB $AC,$4B,$06,$AA,$4A,$06,$B1,$72
  DEFB $06,$B7,$72,$06,$BE,$4A,$10,$01
  DEFB $04,$A2,$81,$04,$94,$81,$04,$88
  DEFB $87,$04,$7F,$7F,$04,$74,$84,$04
  DEFB $6A,$89,$04,$61,$89,$04,$58,$90
  DEFB $06,$59,$6B,$16,$00,$89,$02,$92
  DEFB $07,$E8,$03,$11,$04,$05,$B7,$97
  DEFB $03,$97,$77,$9C,$72,$03,$96,$76
  DEFB $98,$74,$04,$97,$7A,$04,$9A,$76
  DEFB $04,$98,$74,$09,$92,$78,$8F,$78
  DEFB $09,$8F,$78,$8B,$74,$09,$8B,$74
  DEFB $88,$6D,$09,$88,$6C,$89,$69,$09
  DEFB $89,$69,$8E,$68,$09,$8E,$68,$94
  DEFB $69,$09,$94,$69,$98,$6C,$09,$98
  DEFB $6C,$9A,$6F,$09,$9A,$70,$9B,$72
  DEFB $09,$8F,$78,$8E,$7A,$09,$8E,$7A
  DEFB $8B,$7A,$09,$8B,$7A,$89,$78,$09
  DEFB $89,$78,$89,$75,$09,$8A,$74,$8A
  DEFB $75,$09,$8A,$78,$8C,$77,$09,$8C
  DEFB $77,$8B,$75,$04,$8D,$79,$09,$92
  DEFB $75,$92,$72,$09,$92,$72,$95,$71
  DEFB $09,$92,$74,$92,$6F,$09,$93,$6F
  DEFB $94,$6F,$09,$91,$76,$8C,$70,$09
  DEFB $8C,$70,$8B,$6D,$09,$90,$79,$8E
  DEFB $7F,$09,$8E,$7F,$8A,$7E,$09,$93
  DEFB $79,$92,$80,$09,$92,$80,$8E,$81
  DEFB $09,$99,$6D,$9C,$63,$09,$9C,$63
  DEFB $9B,$5F,$09,$9B,$5F,$A3,$60,$09
  DEFB $A3,$60,$A6,$5D,$09,$A6,$5D,$A8
  DEFB $5E,$09,$A8,$5D,$A6,$5B,$09,$A6
  DEFB $5B,$A1,$5A,$09,$A0,$5B,$9A,$5D
  DEFB $09,$9A,$5D,$97,$64,$09,$97,$64
  DEFB $98,$6A,$09,$9A,$68,$96,$60,$09
  DEFB $96,$60,$90,$62,$09,$90,$61,$8E
  DEFB $5E,$09,$8F,$5E,$91,$5E,$09,$91
  DEFB $5E,$91,$61,$09,$97,$63,$8E,$64
  DEFB $09,$8E,$64,$8D,$60,$09,$8D,$60
  DEFB $8E,$60,$09,$8B,$60,$8A,$5D,$09
  DEFB $8A,$5D,$8E,$5C,$09,$8E,$5C,$8F
  DEFB $56,$09,$8F,$56,$8E,$50,$09,$8E
  DEFB $50,$8F,$50,$09,$8F,$50,$91,$59
  DEFB $09,$91,$59,$8F,$5E,$09,$9D,$5D
  DEFB $A2,$67,$09,$A2,$67,$A4,$50,$09
  DEFB $A4,$50,$A9,$4E,$09,$A9,$4E,$A2
  DEFB $4E,$09,$A2,$4E,$A1,$60,$09,$A3
  DEFB $62,$A6,$66,$09,$A6,$66,$A7,$50
  DEFB $09,$A7,$50,$AC,$4E,$09,$A6,$51
  DEFB $A5,$61,$09,$9A,$5C,$98,$50,$09
  DEFB $98,$50,$93,$50,$09,$93,$50,$9A
  DEFB $52,$09,$9A,$52,$9B,$5C,$09,$9F
  DEFB $5B,$9D,$50,$09,$9D,$50,$99,$50
  DEFB $09,$9C,$51,$9E,$5D,$09,$9B,$71
  DEFB $9D,$6E,$09,$9D,$6E,$9B,$6F,$09
  DEFB $9B,$6F,$9C,$6C,$09,$9C,$6C,$99
  DEFB $6D,$06,$9A,$63,$06,$8D,$5E,$06
  DEFB $8F,$5A,$08,$40,$98,$70,$70,$09
  DEFB $81,$56,$B1,$56,$09,$B1,$56,$B9
  DEFB $7E,$09,$B9,$7E,$A9,$96,$09,$A9
  DEFB $96,$89,$96,$09,$89,$96,$79,$76
  DEFB $09,$79,$76,$81,$56,$09,$81,$56
  DEFB $61,$40,$09,$B1,$56,$B9,$40,$09
  DEFB $81

; Message at DB38
  DEFM "VaV"

; Data block at DB3B
  DEFB $09

; Message at DB3C
  DEFM "aVpp"

; Data block at DB40
  DEFB $09,$70,$80,$7A,$9F,$09,$B2,$9F
  DEFB $BF,$87,$09,$B1,$56,$BF,$56,$09

; Message at DB50
  DEFM "bVAM"

; Data block at DB54
  DEFB $04,$71,$86,$04,$BE,$8A,$04,$42
  DEFB $4F,$06,$61,$42,$06,$74,$77,$06
  DEFB $74,$77,$06,$74,$77,$06,$74,$77
  DEFB $06,$74,$77,$06,$74,$77,$06,$7D
  DEFB $9D,$06,$B5,$96,$06,$BE,$84,$06
  DEFB $BE,$54,$09,$7E,$9C,$AE,$98,$09
  DEFB $BE,$68,$BA,$88,$09,$62,$60,$72
  DEFB $60,$09,$72,$80,$74,$60,$11,$01
  DEFB $05,$59,$7E,$09,$4C,$94,$64,$92
  DEFB $09,$64,$92,$69,$82,$09,$69,$82
  DEFB $5E,$76,$09,$5E

; Message at DBA8
  DEFM "vIx"

; Data block at DBAB
  DEFB $09

; Message at DBAC
  DEFM "IxF"

; Data block at DBAF
  DEFB $88,$09,$46,$88,$4C,$93,$04,$42
  DEFB $96,$04,$6C,$93,$09,$68,$84,$48
  DEFB $88,$09,$47,$85,$67,$81,$09,$55
  DEFB $92,$4C,$79,$09

; Message at DBCB
  DEFM "OxX"

; Data block at DBCE
  DEFB $93,$09,$5D,$92,$5D,$77,$09,$60
  DEFB $78,$60,$91,$04,$5F,$91,$04,$5F
  DEFB $84,$04,$5E,$78,$04,$63,$84,$04
  DEFB $5C,$83,$04,$52,$85,$04,$53,$88
  DEFB $04,$55,$8C,$04,$56,$92,$04,$47
  DEFB $87,$04,$4F,$85,$04,$51,$83,$04
  DEFB $4F,$7F,$04,$4E,$79,$0D,$00,$CD
  DEFB $00,$32,$07,$E8,$03,$11,$04,$05
  DEFB $B7,$97,$07,$3C,$00,$07,$46,$00
  DEFB $09,$6F,$8B,$79,$9F,$09,$8B,$9F
  DEFB $8F,$93,$09,$8D,$8D,$96,$9F,$09
  DEFB $A6,$9F,$AF,$8B,$09,$AF,$8B,$B3
  DEFB $9B,$09,$B3,$9B,$B9,$86,$09,$B9
  DEFB $86,$BF,$96,$09,$57,$8E,$5B,$9B
  DEFB $09,$5B,$9B,$60,$85,$09,$77,$47
  DEFB $BF,$49,$06,$BD,$47,$06,$55,$47
  DEFB $06,$4D,$47,$09,$4A,$40,$49,$88
  DEFB $09,$4D,$9F,$4B,$67,$04,$43,$67
  DEFB $06,$62,$67,$06,$67,$67,$09,$67
  DEFB $9F,$69,$5F,$06,$6D,$65,$09,$AF
  DEFB $8B,$B9,$74,$09,$B9,$86,$B6,$7F
  DEFB $09,$BF,$72,$BA,$6E,$09,$BA,$6E
  DEFB $BA,$52,$09,$BA,$52,$BF,$52,$09
  DEFB $BD,$52,$BC,$6F,$06,$BB,$6D,$06
  DEFB $BE,$6D,$09,$56,$65,$60,$6A,$09

; Message at DC96
  DEFM "YgYR"

; Data block at DC9A
  DEFB $09,$57,$51,$5E,$52,$09

; Message at DCA0
  DEFM "]R]i"

; Data block at DCA4
  DEFB $09,$5B,$67,$5C,$52,$06,$5A,$54
  DEFB $04,$5E,$54,$04,$58,$54,$09,$BA
  DEFB $52,$95,$53,$09,$7F

; Message at DCB9
  DEFM "SpR"

; Data block at DCBC
  DEFB $10,$01,$04,$58,$94,$04,$5F,$8E
  DEFB $04,$70,$8E,$04,$90,$95,$04,$AF
  DEFB $8E,$04,$B9,$89,$14,$00,$EF,$02
  DEFB $A9,$07,$E8,$03,$11,$07,$05,$97
  DEFB $87,$09,$40,$7F,$70,$7F,$09,$70
  DEFB $7F,$70,$77,$09,$70,$77,$88,$77
  DEFB $09,$88,$77,$88,$87,$09,$88,$87
  DEFB $BF,$87,$11,$06,$05,$4F,$77,$05
  DEFB $97,$7F,$09,$47,$5F,$58,$5F,$09
  DEFB $58,$5F,$5C,$6A,$09,$5C

; Message at DD0A
  DEFM "jYs"

; Data block at DD0D
  DEFB $09

; Message at DD0E
  DEFM "YsIs"

; Data block at DD12
  DEFB $09

; Message at DD13
  DEFM "IsFk"

; Data block at DD17
  DEFB $09

; Message at DD18
  DEFM "FkH"

; Data block at DD1B
  DEFB $5F,$09

; Message at DD1D
  DEFM "Zs]j"

; Data block at DD21
  DEFB $09

; Message at DD22
  DEFM "]jij"

; Data block at DD26
  DEFB $09

; Message at DD27
  DEFM "ijnr"

; Data block at DD2B
  DEFB $09

; Message at DD2C
  DEFM "nrl"

; Data block at DD2F
  DEFB $7D,$09,$6C,$7D,$5E,$7D,$09,$5E
  DEFB $7D,$5B,$74,$09

; Message at DD3B
  DEFM "ZtAt"

; Data block at DD3F
  DEFB $09

; Message at DD40
  DEFM "EjAj"

; Data block at DD44
  DEFB $09,$40,$5F,$47,$5F,$09

; Message at DD4A
  DEFM "]ihi"

; Data block at DD4E
  DEFB $09,$5D,$7D,$45,$7D,$09,$45,$7D
  DEFB $41,$75,$06,$46,$7B,$06,$43,$70
  DEFB $04,$43,$66,$08,$48,$7B,$5A,$79
  DEFB $09

; Message at DD67
  DEFM "fkhr"

; Data block at DD6B
  DEFB $09

; Message at DD6C
  DEFM "hrew"

; Data block at DD70
  DEFB $09

; Message at DD71
  DEFM "ewaw"

; Data block at DD75
  DEFB $09,$61,$77,$5F,$72,$09,$5F,$72
  DEFB $60,$6B,$09

; Message at DD80
  DEFM "ekdv"

; Data block at DD84
  DEFB $04,$62,$74,$09,$57,$60,$59,$69
  DEFB $09

; Message at DD8D
  DEFM "YiWm"

; Data block at DD91
  DEFB $09

; Message at DD92
  DEFM "WmSm"

; Data block at DD96
  DEFB $09

; Message at DD97
  DEFM "SmQg"

; Data block at DD9B
  DEFB $09

; Message at DD9C
  DEFM "QgS"

; Data block at DD9F
  DEFB $60,$09,$56,$60,$52,$68,$04,$55
  DEFB $66,$09

; Message at DDA9
  DEFM "KhNh"

; Data block at DDAD
  DEFB $09

; Message at DDAE
  DEFM "NhPk"

; Data block at DDB2
  DEFB $09

; Message at DDB3
  DEFM "PkOn"

; Data block at DDB7
  DEFB $09

; Message at DDB8
  DEFM "OnKn"

; Data block at DDBC
  DEFB $09

; Message at DDBD
  DEFM "KnIk"

; Data block at DDC1
  DEFB $09

; Message at DDC2
  DEFM "IkKi"

; Data block at DDC6
  DEFB $04,$4D,$6A,$09

; Message at DDCA
  DEFM "bjd"

; Data block at DDCD
  DEFB $5F,$09,$68,$5F,$66,$69,$09

; Message at DDD4
  DEFM "fgdg"

; Data block at DDD8
  DEFB $09

; Message at DDD9
  DEFM "ddfd"

; Data block at DDDD
  DEFB $09

; Message at DDDE
  DEFM "gaea"

; Data block at DDE2
  DEFB $09

; Message at DDE3
  DEFM "kmq"

; Data block at DDE6
  DEFB $60,$09

; Message at DDE8
  DEFM "kjo"

; Data block at DDEB
  DEFB $60,$09,$BF,$50,$B1,$4D,$09,$B1
  DEFB $4D,$8F,$4D,$09,$8F,$4D,$86,$67
  DEFB $09,$86,$67,$8F,$81,$09,$8F,$81
  DEFB $B0,$81,$09,$B0,$81,$BA,$65,$09
  DEFB $BA,$65,$B0,$4D,$09,$AF,$81,$BD
  DEFB $83,$09,$90,$81,$BD,$86,$09,$BA
  DEFB $65,$BD,$67,$09,$BE,$7F,$B9,$7E
  DEFB $09,$B9,$7E,$B8,$75,$09,$B8,$75
  DEFB $BC,$6E,$09,$BC,$6E,$BD,$6E,$04
  DEFB $BC,$7B,$06,$A9,$82,$06,$B7,$73
  DEFB $06,$BC,$6B,$04,$BC,$63,$04,$BC
  DEFB $63,$09,$B0,$75,$B4,$6B,$09,$B4
  DEFB $6B,$B0,$64,$09,$B0,$64,$A9,$64
  DEFB $09,$A9,$64,$A6,$6A,$09,$A6,$6A
  DEFB $AA,$74,$09,$AA,$74,$AE,$75,$09
  DEFB $AC,$74,$AB,$65,$09,$A8,$67,$A9
  DEFB $6B,$02,$AF,$75,$04,$AF,$6C,$09
  DEFB $91,$50,$8A,$68,$09,$8A,$68,$91
  DEFB $76,$09,$91,$76,$9D,$76,$09,$9D
  DEFB $76,$A4,$67,$09,$A4,$67,$A0,$50
  DEFB $09,$A0,$50,$92,$50,$09,$94,$50
  DEFB $8D,$68,$09,$8D,$68,$94,$76,$09
  DEFB $9A,$76,$9C,$50,$09,$9E,$73,$9E
  DEFB $51,$06,$9D,$56,$06,$A0,$56,$04
  DEFB $98,$56,$08,$94,$7D,$AA,$79,$08
  DEFB $A1,$79,$AA,$76,$09,$6C,$70,$88
  DEFB $72,$04,$42,$7F,$04,$6F,$77,$04
  DEFB $89,$86,$11,$01,$05,$79,$86,$09
  DEFB $40,$81,$44,$89,$09,$44,$89,$46
  DEFB $82,$09,$46,$82,$48,$86,$09,$48
  DEFB $86,$4A,$81,$09,$51,$80,$54,$8B
  DEFB $09,$54,$8B,$56,$83,$09,$56,$83
  DEFB $58,$88,$09,$58,$88,$5A,$80,$09
  DEFB $5A,$80,$5D,$8C,$09,$5D,$8C,$60
  DEFB $81,$09,$60,$81,$64,$86,$09,$64
  DEFB $86,$66,$81,$09,$66,$81,$69,$88
  DEFB $09,$69,$88,$6B,$81,$09,$6B,$81
  DEFB $6E,$8E,$09,$6E,$8C,$73,$7C,$09
  DEFB $73,$7C,$76,$86,$09,$76,$86,$79
  DEFB $79,$09,$7D,$79,$7E,$80,$09,$7E
  DEFB $80,$80,$79,$09,$80,$79,$82,$84
  DEFB $09,$82,$84,$85,$7C,$09,$85,$7C
  DEFB $89,$92,$09,$89,$92,$8C,$89,$09
  DEFB $8C,$89,$8E,$8F,$09,$8E,$8F,$90
  DEFB $89,$09,$97,$89,$9A,$93,$09,$9A
  DEFB $93,$9D,$8B,$09,$9D,$8B,$A0,$97
  DEFB $09,$A0,$97,$A3,$8B,$09,$A3,$8B
  DEFB $A5,$90,$09,$A5,$90,$A8,$89,$09
  DEFB $AE,$89,$B1,$92,$09,$B1,$92,$B3
  DEFB $89,$09,$B8,$89,$B9,$91,$09,$B9
  DEFB $91,$BB,$89,$09,$BB,$89,$BE,$94
  DEFB $04,$BE,$91,$04,$B9,$8C,$04,$B1
  DEFB $8E,$04,$A5,$8D,$04,$A0,$91,$04
  DEFB $9A,$8F,$04,$8E,$8C,$04,$89,$8D
  DEFB $04,$87,$82,$04,$82,$7F,$04,$7E
  DEFB $7B,$04,$76,$81,$04,$6E,$87,$04
  DEFB $69,$84,$04,$63,$83,$04,$5D,$87
  DEFB $04,$58,$84,$04,$54,$87,$04,$48
  DEFB $83,$04,$44,$86,$18,$00,$2F,$01
  DEFB $47,$07,$E8,$03,$11,$07,$05,$97
  DEFB $7F,$09,$BF

; Message at DFCE
  DEFM "WoW"

; Data block at DFD1
  DEFB $09

; Message at DFD2
  DEFM "oWo"

; Data block at DFD5
  DEFB $5F,$09,$6F,$5F,$41,$5F,$08,$6F
  DEFB $67,$8F,$57,$08,$AF,$57,$BF,$67
  DEFB $09,$AF

; Message at DFE7
  DEFM "gog"

; Data block at DFEA
  DEFB $09

; Message at DFEB
  DEFM "ogoo"

; Data block at DFEF
  DEFB $09,$6F,$6F,$BF,$6F,$08

; Message at DFF5
  DEFM "ojW"

; Data block at DFF8
  DEFB $5F,$08,$47,$5F,$40,$6A,$09,$6F
  DEFB $6C,$40,$6C,$08,$BF,$6F,$87,$8F
  DEFB $08,$85,$92,$BF,$8F,$09,$67,$9F
  DEFB $67,$8F,$09,$67,$8F,$6F,$8F,$09
  DEFB $6F,$8F,$6F,$97,$09,$6F,$97,$BF
  DEFB $97,$08,$48,$6C,$40,$88,$08,$40
  DEFB $8E,$4B,$88,$09,$46,$8E,$56,$9B
  DEFB $09,$56,$9B,$42,$8F,$09,$55,$99
  DEFB $55,$86,$03,$55,$83,$53,$85,$02
  DEFB $55,$85,$09,$48,$82,$41,$82,$06
  DEFB $42,$9D,$06,$59,$99,$06,$52,$85
  DEFB $06,$72,$95,$09

; Message at E054
  DEFM "GjVj"

; Data block at E058
  DEFB $06,$55,$68,$04,$5D,$68,$04,$45
  DEFB $68,$06,$75,$60,$06,$B5,$60,$08
  DEFB $72,$94,$80,$8F,$08,$80,$8C,$68
  DEFB $85,$08

; Message at E072
  DEFM "hqm"

; Data block at E075
  DEFB $7B,$08,$72,$7B,$77,$71,$08,$5C
  DEFB $6D,$40,$9D,$08,$43,$9A,$46,$96
  DEFB $08,$60,$9B,$64,$8A,$09

; Message at E08B
  DEFM "BnB"

; Data block at E08E
  DEFB $87,$08,$42,$8C,$48,$8A,$11,$06
  DEFB $05,$B5,$80,$08,$8D,$8A,$97,$7E
  DEFB $08,$99,$7E,$A4,$8A,$08,$B7,$71
  DEFB $BF,$88,$08,$B4,$70,$BF,$8B,$08
  DEFB $9B,$88,$A2,$80,$08,$95,$80,$8F
  DEFB $88,$04,$91,$86,$04,$9E,$86,$08
  DEFB $AA,$87,$AD,$77,$08,$AD,$77,$B1
  DEFB $70,$06,$89,$8E,$06,$A7,$88,$06
  DEFB $AF,$85,$04,$69,$9E,$11,$04,$10
  DEFB $01,$06,$41,$56,$11,$00,$05,$99
  DEFB $5E,$09,$90,$58,$AD,$58,$09,$AD
  DEFB $58,$90,$5A,$09,$90,$5A,$AC,$5B
  DEFB $04,$00,$05,$01,$41,$07,$E8,$03
  DEFB $11,$07,$05,$B7,$97,$08,$BF,$9F
  DEFB $7F,$5F,$05,$57,$8F,$09,$7F,$5F
  DEFB $8F,$97,$09,$8F,$97,$AF,$97,$09
  DEFB $AF,$97,$BF,$5F,$09,$87,$5F,$8B
  DEFB $77,$09,$8B,$77,$8E,$5F,$09,$B7
  DEFB $5F,$B4,$67,$09,$B4,$67,$B2,$5F
  DEFB $09,$AF,$5F,$AD,$6F,$09,$AD,$6F
  DEFB $AB,$5F,$09,$97,$97,$91,$5F,$10
  DEFB $01,$04,$80,$66,$04,$BE,$66,$10
  DEFB $00,$09,$90,$93,$AF,$93,$04,$B4
  DEFB $65,$04,$AD,$69,$04,$8B,$71,$09
  DEFB $9F,$93,$A5,$60,$09,$A7,$93,$AC
  DEFB $70,$06,$A6,$7F,$09,$96,$7F,$9E
  DEFB $7F,$09,$AC,$7F,$AF,$7F,$09,$98
  DEFB $87,$9D,$87,$09,$AC,$87,$AF,$87
  DEFB $09,$96,$76,$9F,$76,$09,$AD,$76
  DEFB $B3,$76,$09,$93,$8F,$8F,$79,$11
  DEFB $04,$05,$4F,$91,$07,$3C,$00,$07
  DEFB $46,$00,$09,$75,$93,$6F,$79,$09
  DEFB $60,$78,$5B,$8E,$09,$5B,$8E,$57
  DEFB $76,$09,$75,$91,$81,$56,$09,$81
  DEFB $56,$78,$5E,$09,$78,$5E,$78,$50
  DEFB $09

; Message at E1A7
  DEFM "xPtb"

; Data block at E1AB
  DEFB $09

; Message at E1AC
  DEFM "tbtP"

; Data block at E1B0
  DEFB $09,$6F,$50,$BE,$53,$06,$6D,$69
  DEFB $06,$68,$69,$06,$4B,$6D,$04,$42
  DEFB $45,$06,$62,$6F,$09,$80,$5B,$BF
  DEFB $57,$04,$BE,$5E,$06,$79,$5B,$06
  DEFB $82,$59,$09,$74,$60,$70,$5E,$04
  DEFB $73,$5E,$09,$57,$5A,$5F,$5C,$04
  DEFB $5F,$5B,$04,$5F,$5B,$10,$01,$04
  DEFB $7E,$69,$04,$70,$81,$04,$5F,$81
  DEFB $04,$58,$81,$05,$00,$50,$01,$51
  DEFB $07,$E8,$03,$11,$04,$05,$B7,$97
  DEFB $07,$46,$00,$07,$50,$00,$09,$68
  DEFB $40,$BF,$48,$06,$BE,$47,$09,$40
  DEFB $89,$46,$9F,$09,$54,$9F,$59,$7F
  DEFB $09,$57,$77,$5F,$9C,$09

; Message at E21E
  DEFM "jfh"

; Data block at E221
  DEFB $86,$09,$68,$86,$68,$9E,$04,$6A
  DEFB $86,$04,$69,$92,$06,$67,$6A,$06
  DEFB $6D,$6A,$09,$9E,$82,$99,$9E,$09
  DEFB $9A,$62,$9E,$73,$06,$9E,$6D,$06
  DEFB $9E,$8D,$06,$97,$81,$06,$93,$6E
  DEFB $09,$40,$52,$60,$54,$09,$6F,$8A
  DEFB $75,$9B,$09,$75,$9B,$80,$6F,$09
  DEFB $7D,$7A,$85,$95,$09,$85,$95,$90
  DEFB $70,$09,$9F,$85,$A7,$95,$09,$A7
  DEFB $95,$AF,$85,$09,$AD,$7F,$B5,$9F
  DEFB $09,$6F,$5A,$8F,$5C,$09,$9F,$5C
  DEFB $BF,$5F,$06,$62,$6C,$09

; Message at E27F
  DEFM "WwRg"

; Data block at E283
  DEFB $09,$52,$67,$5F,$6B,$09

; Message at E289
  DEFM "]j]T"

; Data block at E28D
  DEFB $09

; Message at E28E
  DEFM "TmGr"

; Data block at E292
  DEFB $09

; Message at E293
  DEFM "GrGR"

; Data block at E297
  DEFB $09

; Message at E298
  DEFM "MTMp"

; Data block at E29C
  DEFB $09

; Message at E29D
  DEFM "JpKS"

; Data block at E2A1
  DEFB $06,$4C,$56,$04,$4E,$6E,$06,$5C
  DEFB $69,$09,$80

; Message at E2AC
  DEFM "oss"

; Data block at E2AF
  DEFB $09

; Message at E2B0
  DEFM "sssZ"

; Data block at E2B4
  DEFB $09

; Message at E2B5
  DEFM "vZvr"

; Data block at E2B9
  DEFB $09

; Message at E2BA
  DEFM "urtZ"

; Data block at E2BE
  DEFB $06,$75,$5C,$09

; Message at E2C2
  DEFM "rspq"

; Data block at E2C6
  DEFB $04,$71,$71,$09,$76,$68,$81,$6D
  DEFB $09,$81,$6D,$81,$5B,$09,$84,$5B
  DEFB $82,$73,$09,$87,$71,$87,$5B,$06
  DEFB $82,$5C,$04,$80,$6B,$09,$9F,$86
  DEFB $AD,$6E,$09,$9F,$70,$A2,$5C,$04
  DEFB $A0,$64,$09,$A5,$5D,$A4,$75,$09
  DEFB $BC,$7E,$BC,$5F,$09,$BF,$81,$AB
  DEFB $6E,$09,$AC,$6F,$AC,$5D,$09,$AF
  DEFB $5F,$AF,$71,$06,$AE,$6F,$04,$BB
  DEFB $7B,$09,$A9,$73,$A9,$5D,$09,$A4
  DEFB $74,$AA,$71,$04,$A8,$71,$09,$87
  DEFB $6F,$91,$6C,$04,$88,$6E,$09,$4A
  DEFB $74,$40,$70,$04,$46,$71,$10,$01
  DEFB $04,$AE,$8A,$04,$A0,$8A,$04,$8F
  DEFB $76,$04,$7D,$80,$04,$70,$90,$04
  DEFB $59,$84,$04,$41,$90,$E9,$03,$0C
  DEFB $00,$03,$01,$00,$11,$00,$05,$80
  DEFB $70,$10,$00,$33,$02,$82,$07,$E8
  DEFB $03,$11,$07,$05,$B7,$97,$08,$90
  DEFB $90,$B0,$68,$11,$05,$05,$A0,$78
  DEFB $09,$97,$69,$A8,$69,$09,$A8,$69
  DEFB $AB,$6B,$09,$AB,$6B,$AC,$6E,$09
  DEFB $AC,$6E,$AA,$7B,$09,$AA,$7B,$96
  DEFB $7B,$09,$96,$7B,$94,$6F,$09,$94
  DEFB $6F,$95,$6C,$09,$95,$6C,$97,$6A
  DEFB $09,$93,$72,$92,$7C,$09,$92,$7C
  DEFB $93,$86,$09,$93,$86,$97,$8D,$09
  DEFB $97,$8D,$9B,$8E,$09,$9B,$8E,$A5
  DEFB $8E,$09,$A5,$8E,$A9,$8B,$09,$A9
  DEFB $8B,$AC,$85,$09,$AC,$85,$AE,$79
  DEFB $09,$AE,$79,$AD,$72,$09,$9B,$6E
  DEFB $A5,$6E,$09,$A5,$6E,$A8,$6C,$09
  DEFB $9A,$6D,$98,$6C,$09,$99,$6D,$99
  DEFB $72,$09,$99,$72,$9B,$6E,$09,$A5
  DEFB $6E,$A8,$71,$09,$A8,$71,$A8,$6C
  DEFB $09,$9C,$77,$98,$75,$09,$98,$75
  DEFB $97,$72,$09,$A4,$77,$A8,$75,$09
  DEFB $A8,$75,$AA,$72,$08,$96,$7D,$AB
  DEFB $83,$09,$9C,$83,$99,$7D,$09,$9B
  DEFB $7D,$9E,$82,$09,$A6,$82,$A4,$7E
  DEFB $09,$A6,$7E,$A8,$82,$04,$97,$82
  DEFB $04,$A0,$82,$04,$A9,$82,$06,$9F
  DEFB $8D,$06,$95,$83,$06,$94,$76,$06
  DEFB $AD,$79,$06,$AD,$79,$04,$AF,$8F
  DEFB $04,$91,$8D,$11,$02,$05,$51,$8D
  DEFB $05,$B8,$8D,$09,$82,$63,$90,$52
  DEFB $09,$90,$52,$97,$54,$09,$97,$67
  DEFB $82,$63,$09,$97,$67,$97,$55,$09
  DEFB $A9,$55,$B1,$52,$09,$B1,$52,$BD
  DEFB $60,$09,$A9,$67,$A9,$55,$09,$AA
  DEFB $67,$BD,$61,$09,$95,$48,$9C,$4D
  DEFB $09,$9C,$4D,$A3,$4F,$09,$A3,$4F
  DEFB $B2,$4B,$09,$90,$48,$88,$40,$09
  DEFB $8E,$47,$83,$47,$09,$8D,$54,$89
  DEFB $47,$09,$89,$47,$84,$4B,$09,$84
  DEFB $5F,$77,$45,$09

; Message at E482
  DEFM "wEv"

; Data block at E485
  DEFB $40,$09,$A8,$47,$AF,$40,$09,$B2
  DEFB $4A,$B8,$41,$09,$BB,$5C,$BF,$55
  DEFB $09,$B3,$49,$BC,$47,$09,$B8,$49
  DEFB $B3,$52,$09,$96,$48,$A3,$4A,$09
  DEFB $A3,$4A,$A8,$46,$09,$90,$48,$95
  DEFB $48,$09,$9E,$40,$A4,$44,$09,$A4
  DEFB $44,$AB,$43,$06,$AB,$65,$06,$96
  DEFB $65,$06,$90,$54,$06,$B0,$54,$09
  DEFB $87,$61,$93,$64,$09,$89,$5E,$93
  DEFB $61,$09,$AB,$64,$B7,$5F,$09,$AC
  DEFB $60,$B4,$5D,$09,$9A,$5B,$A0,$5E
  DEFB $09,$A0,$5E,$A6,$5B,$09,$A6,$5B
  DEFB $A4,$53,$09,$A4,$53,$A0,$50,$09
  DEFB $A0,$50,$9C,$52,$09,$9C,$52,$9A
  DEFB $5A,$09,$8E,$53,$8D,$48,$04,$8C
  DEFB $48,$09,$B2,$52,$B3,$4A,$04,$B4
  DEFB $4A,$04,$A6,$43,$09,$9D,$67,$9C
  DEFB $61,$09,$A2,$67,$A3,$5F,$09,$60
  DEFB $9F,$60,$40,$04,$68,$98,$04,$B8
  DEFB $88,$04,$BE,$5B,$06,$A3,$4E,$06
  DEFB $B0,$4A,$06,$A3,$48,$06,$8F,$43
  DEFB $06,$9E,$4A,$06,$98,$49,$11,$07
  DEFB $05,$4F,$53,$08,$40,$9B,$5D,$73
  DEFB $08,$59,$77,$40,$97,$09,$43,$93
  DEFB $43,$8A,$09,$43,$8A,$47,$8D,$09
  DEFB $48,$91,$4D,$8B,$09,$4D,$8B,$4D
  DEFB $92,$03,$54,$8E,$51,$95,$09,$55
  DEFB $82,$40,$82,$08,$43,$7E,$48,$7B
  DEFB $09,$4C,$7D,$53,$7D,$09,$53,$7D
  DEFB $4F,$7A,$11,$01,$10,$06,$04,$9F
  DEFB $5C,$04,$9F,$5C,$04,$9F,$5C,$04
  DEFB $9F,$5C,$04,$9F,$5C,$E8,$03,$1B
  DEFB $00,$06,$07,$E9,$03,$10,$07,$08
  DEFB $00,$30,$FF,$AF,$08,$38,$38,$C7
  DEFB $A7,$08,$40,$40,$BF,$9F,$10,$00
  DEFB $00,$00,$01,$CE,$05

; Message at E5A2
  DEFM "NORT"

; Data block at E5A6
  DEFB $C5,$03,$53,$55,$D2,$01,$D3,$01
  DEFB $C5,$04

; Message at E5B0
  DEFM "EST"

; Data block at E5B3
  DEFB $C5,$01,$CF,$05

; Message at E5B7
  DEFM "OEST"

; Data block at E5BB
  DEFB $C5,$02,$4C,$C1,$06

; Message at E5C0
  DEFM "CABIN"

; Data block at E5C5
  DEFB $C1,$02,$44,$C5,$04

; Message at E5CA
  DEFM "NAV"

; Data block at E5CD
  DEFB $C5,$07

; Message at E5CF
  DEFM "SALIDA"

; Data block at E5D5
  DEFB $D3

; Message at E5D6
  DEFM " *******************************"

; Data block at E5F6
  DEFB $AA,$06

; Message at E5F8
  DEFM "BODEG"

; Data block at E5FD
  DEFB $C1,$05

; Message at E5FF
  DEFM "CARG"

; Data block at E603
  DEFB $C1,$03,$3E,$3E,$BE,$02,$4E,$CF
  DEFB $05

; Message at E60C
  DEFM "PUED"

; Data block at E610
  DEFB $C5,$06

; Message at E612
  DEFM "REPIT"

; Data block at E617
  DEFB $C1,$05

; Message at E619
  DEFM "ORDE"

; Data block at E61D
  DEFB $CE,$05

; Message at E61F
  DEFM "PULS"

; Data block at E623
  DEFB $C5,$03,$55,$4E,$C1,$05

; Message at E629
  DEFM "TECL"

; Data block at E62D
  DEFB $C1,$04

; Message at E62F
  DEFM "PAR"

; Data block at E632
  DEFB $C1,$05

; Message at E634
  DEFM "JUGA"

; Data block at E638
  DEFB $D2,$05

; Message at E63A
  DEFM "NUEV"

; Data block at E63E
  DEFB $CF,$04

; Message at E640
  DEFM "EST"

; Data block at E643
  DEFB $C1,$06

; Message at E645
  DEFM "SEGUR"

; Data block at E64A
  DEFB $CF,$05

; Message at E64C
  DEFM "(S/N"

; Data block at E650
  DEFB $A9,$02,$59,$C1,$02,$4C,$CF,$05

; Message at E658
  DEFM "TIEN"

; Data block at E65C
  DEFB $C5,$06

; Message at E65E
  DEFM "PUEDE"

; Data block at E663
  DEFB $D3,$05

; Message at E665
  DEFM "VERL"

; Data block at E669
  DEFB $CF,$06

; Message at E66B
  DEFM "LLEVA"

; Data block at E670
  DEFB $D3,$09

; Message at E672
  DEFM "DEMASIAD"

; Data block at E67A
  DEFB $CF,$04

; Message at E67C
  DEFM "PES"

; Data block at E67F
  DEFB $CF,$02,$53,$D5,$0A

; Message at E684
  DEFM "PUNTUACIO"

; Data block at E68D
  DEFB $CE,$03,$46,$55,$C5,$01,$D9,$07

; Message at E695
  DEFM "EFECTU"

; Data block at E69B
  DEFB $CF,$06

; Message at E69D
  DEFM "OSCUR"

; Data block at E6A2
  DEFB $CF,$03,$56,$45,$CF,$04

; Message at E6A8
  DEFM "NAD"

; Data block at E6AB
  DEFB $C1,$09

; Message at E6AD
  DEFM "ENCUENTR"

; Data block at E6B5
  DEFB $CF,$07

; Message at E6B7
  DEFM "TAMBIE"

; Data block at E6BD
  DEFB $CE,$05

; Message at E6BF
  DEFM "PUED"

; Data block at E6C3
  DEFB $CF,$03,$56,$45,$D2,$05

; Message at E6C9
  DEFM "HECH"

; Data block at E6CD
  DEFB $CF,$0B

; Message at E6CF
  DEFM "MOVIMIENTO"

; Data block at E6D9
  DEFB $D3,$02,$55,$CE,$05

; Message at E6DE
  DEFM "CLAR"

; Data block at E6E2
  DEFB $CF,$03,$44,$45,$CC,$06

; Message at E6E8
  DEFM "BOSQU"

; Data block at E6ED
  DEFB $C5,$02,$45,$CC,$0A

; Message at E6F2
  DEFM "VEGETACIO"

; Data block at E6FB
  DEFB $CE,$02,$45,$D3,$03,$4D,$55,$D9
  DEFB $06

; Message at E704
  DEFM "ESPES"

; Data block at E709
  DEFB $C1,$06

; Message at E70B
  DEFM "ORILL"

; Data block at E710
  DEFB $C1,$04

; Message at E712
  DEFM "GRA"

; Data block at E715
  DEFB $CE,$04

; Message at E717
  DEFM "LAG"

; Data block at E71A
  DEFB $CF,$05

; Message at E71C
  DEFM "SOBR"

; Data block at E720
  DEFB $C5,$03,$4C,$41,$D3,$05

; Message at E726
  DEFM "COPA"

; Data block at E72A
  DEFB $D3,$03,$4C,$4F,$D3,$07

; Message at E730
  DEFM "ARBOLE"

; Data block at E736
  DEFB $D3,$0C

; Message at E738
  DEFM "CONSTRUCCIO"

; Data block at E743
  DEFB $CE,$07

; Message at E745
  DEFM "GASTAD"

; Data block at E74B
  DEFB $CF,$07

; Message at E74D
  DEFM "SENDER"

; Data block at E753
  DEFB $CF,$06

; Message at E755
  DEFM "TUERC"

; Data block at E75A
  DEFB $C5,$04

; Message at E75C
  DEFM "AQU"

; Data block at E75F
  DEFB $C9,$02,$4D,$C5,$02,$48,$C5,$06

; Message at E767
  DEFM "METID"

; Data block at E76C
  DEFB $CF,$02,$45,$CE,$05

; Message at E771
  DEFM "MEDI"

; Data block at E775
  DEFB $CF,$08

; Message at E777
  DEFM "PATRULL"

; Data block at E77E
  DEFB $C1,$07

; Message at E780
  DEFM "CASTIG"

; Data block at E786
  DEFB $CF,$08

; Message at E788
  DEFM "EJERCIT"

; Data block at E78F
  DEFB $CF,$05

; Message at E791
  DEFM "GEAN"

; Data block at E795
  DEFB $CF,$03,$53,$55,$D3,$07

; Message at E79B
  DEFM "ORDENE"

; Data block at E7A1
  DEFB $D3,$03,$53,$4F,$CE,$03,$22,$53
  DEFB $C9,$02,$53,$C5,$05

; Message at E7AE
  DEFM "MUEV"

; Data block at E7B2
  DEFB $C5,$07

; Message at E7B4
  DEFM "DISPAR"

; Data block at E7BA
  DEFB $C1,$03,$22,$3B,$D9,$07

; Message at E7C0
  DEFM "SIEMPR"

; Data block at E7C6
  DEFB $C5,$07

; Message at E7C8
  DEFM "CUMPLE"

; Data block at E7CE
  DEFB $CE,$03,$46,$49,$CE,$06

; Message at E7D4
  DEFM "MISIO"

; Data block at E7D9
  DEFB $CE,$09

; Message at E7DB
  DEFM "CAUDALOS"

; Data block at E7E3
  DEFB $CF,$03,$52,$49,$CF,$05

; Message at E7E9
  DEFM "ALDE"

; Data block at E7ED
  DEFB $C1,$08

; Message at E7EF
  DEFM "YNNH'AR"

; Data block at E7F6
  DEFB $D2,$06

; Message at E7F8
  DEFM "DENTR"

; Data block at E7FD
  DEFB $CF,$05

; Message at E7FF
  DEFM "CHOZ"

; Data block at E803
  DEFB $C1,$05

; Message at E805
  DEFM "TENG"

; Data block at E809
  DEFB $CF,$05

; Message at E80B
  DEFM "LLEV"

; Data block at E80F
  DEFB $CF,$04

; Message at E811
  DEFM "COG"

; Data block at E814
  DEFB $C5,$04

; Message at E816
  DEFM "DEJ"

; Data block at E819
  DEFB $C1,$01,$C4,$04

; Message at E81D
  DEFM "DES"

; Data block at E820
  DEFB $C3,$01,$C9,$04

; Message at E824
  DEFM "INV"

; Data block at E827
  DEFB $C5,$0B

; Message at E829
  DEFM "CHOCOLATIN"

; Data block at E833
  DEFB $C1,$05

; Message at E835
  DEFM "PERR"

; Data block at E839
  DEFB $C1,$05

; Message at E83B
  DEFM "GORD"

; Data block at E83F
  DEFB $C1,$06

; Message at E841
  DEFM "BABOS"

; Data block at E846
  DEFB $C1,$07

; Message at E848
  DEFM "PEINET"

; Data block at E84E
  DEFB $C1,$07

; Message at E850
  DEFM "ANGOST"

; Data block at E856
  DEFB $C1,$04

; Message at E858
  DEFM "COM"

; Data block at E85B
  DEFB $CF,$06

; Message at E85D
  DEFM "LOGIC"

; Data block at E862
  DEFB $CF,$03,$54,$41,$CE,$08

; Message at E868
  DEFM "REDUCID"

; Data block at E86F
  DEFB $C1,$09

; Message at E871
  DEFM "CONTROLE"

; Data block at E879
  DEFB $D3,$07

; Message at E87B
  DEFM "BRILLA"

; Data block at E881
  DEFB $CE,$03,$43,$4F,$CE,$0E

; Message at E887
  DEFM "TRANQUILIZADO"

; Data block at E894
  DEFB $D2,$05

; Message at E896
  DEFM "COLO"

; Data block at E89A
  DEFB $D2,$05

; Message at E89C
  DEFM "VERD"

; Data block at E8A0
  DEFB $C5,$01,$AA,$40

; Message at E8A4
  DEFM "***************************************************************"

; Data block at E8E3
  DEFB $AA,$04

; Message at E8E5
  DEFM "TOD"

; Data block at E8E8
  DEFB $CF,$05

; Message at E8EA
  DEFM "DEMA"

; Data block at E8EE
  DEFB $D3,$05

; Message at E8F0
  DEFM "PARE"

; Data block at E8F4
  DEFB $C4,$03,$48,$41,$D9,$07

; Message at E8FA
  DEFM "FIJADO"

; Data block at E900
  DEFB $D3,$04

; Message at E902
  DEFM "UNO"

; Data block at E905
  DEFB $D3,$0C

; Message at E907
  DEFM "CONTENEDORE"

; Data block at E912
  DEFB $D3,$09

; Message at E914
  DEFM "COMPUERT"

; Data block at E91C
  DEFB $C1,$07

; Message at E91E
  DEFM "CONMIG"

; Data block at E924
  DEFB $CF,$09

; Message at E926
  DEFM "CUALQUIE"

; Data block at E92E
  DEFB $D2,$04

; Message at E930
  DEFM "COS"

; Data block at E933
  DEFB $C1,$05

; Message at E935
  DEFM "DISC"

; Data block at E939
  DEFB $CF,$07

; Message at E93B
  DEFM "PISTOL"

; Data block at E941
  DEFB $C1,$08

; Message at E943
  DEFM "BOTIQUI"

; Data block at E94A
  DEFB $CE,$05

; Message at E94C
  DEFM "BOTO"

; Data block at E950
  DEFB $CE,$08

; Message at E952
  DEFM "METALIC"

; Data block at E959
  DEFB $CF,$0A

; Message at E95B
  DEFM "RELUCIENT"

; Data block at E964
  DEFB $C5,$05

; Message at E966
  DEFM "SIGN"

; Data block at E96A
  DEFB $CF,$09

; Message at E96C
  DEFM "HORUSCOR"

; Data block at E974
  DEFB $D0,$07

; Message at E976
  DEFM "GRABAD"

; Data block at E97C
  DEFB $CF,$03,$44,$4F,$D3,$05

; Message at E982
  DEFM "CARA"

; Data block at E986
  DEFB $D3,$06

; Message at E988
  DEFM "PLASM"

; Data block at E98D
  DEFB $C1,$05

; Message at E98F
  DEFM "KRAY"

; Data block at E993
  DEFB $D4,$03,$4D,$4B,$C9,$07

; Message at E999
  DEFM "POTENT"

; Data block at E99F
  DEFB $C5,$08

; Message at E9A1
  DEFM "PRIMERO"

; Data block at E9A8
  DEFB $D3,$08

; Message at E9AA
  DEFM "AUXILIO"

; Data block at E9B1
  DEFB $D3,$08

; Message at E9B3
  DEFM "CONTIEN"

; Data block at E9BA
  DEFB $C5,$06

; Message at E9BC
  DEFM "VENDA"

; Data block at E9C1
  DEFB $D3,$0D

; Message at E9C3
  DEFM "DESINFECTANT"

; Data block at E9CF
  DEFB $C5,$05

; Message at E9D1
  DEFM "DOBL"

; Data block at E9D5
  DEFB $C5,$06

; Message at E9D7
  DEFM "CIERR"

; Data block at E9DC
  DEFB $C5,$09

; Message at E9DE
  DEFM "HERMETIC"

; Data block at E9E6
  DEFB $CF,$06

; Message at E9E8
  DEFM "SOLID"

; Data block at E9ED
  DEFB $C1,$05

; Message at E9EF
  DEFM "JUNT"

; Data block at E9F3
  DEFB $CF,$01,$C1,$04

; Message at E9F7
  DEFM "ELL"

; Data block at E9FA
  DEFB $C1,$07

; Message at E9FC
  DEFM "ESPECI"

; Data block at EA02
  DEFB $C5,$0A

; Message at EA04
  DEFM "CASILLERO"

; Data block at EA0D
  DEFB $D3,$07

; Message at EA0F
  DEFM "GUARDA"

; Data block at EA15
  DEFB $D2,$05

; Message at EA17
  DEFM "COSA"

; Data block at EA1B
  DEFB $D3,$0B

; Message at EA1D
  DEFM "TRIPULACIO"

; Data block at EA27
  DEFB $CE,$08

; Message at EA29
  DEFM "PULSADO"

; Data block at EA30
  DEFB $D2,$04

; Message at EA32
  DEFM "<AC"

; Data block at EA35
  DEFB $BE,$08

; Message at EA37
  DEFM "BASTANT"

; Data block at EA3E
  DEFB $C5,$05

; Message at EA40
  DEFM "SUCI"

; Data block at EA44
  DEFB $C1,$07

; Message at EA46
  DEFM "EXAMIN"

; Data block at EA4C
  DEFB $C1,$02,$53,$C9,$07

; Message at EA51
  DEFM "TUVIER"

; Data block at EA57
  DEFB $C1,$03,$51,$55,$C5,$05

; Message at EA5D
  DEFM "HACE"

; Data block at EA61
  DEFB $D2,$03,$45,$53,$CF,$03,$4D,$4B
  DEFB $B1,$05

; Message at EA6B
  DEFM "PULS"

; Data block at EA6F
  DEFB $C1,$04

; Message at EA71
  DEFM "ABR"

; Data block at EA74
  DEFB $C5,$07

; Message at EA76
  DEFM "APRIET"

; Data block at EA7C
  DEFB $C1,$04

; Message at EA7E
  DEFM "TIP"

; Data block at EA81
  DEFB $CF,$05

; Message at EA83
  DEFM "LIST"

; Data block at EA87
  DEFB $CF,$02,$45,$C8,$03,$41,$53,$C9
  DEFB $04

; Message at EA90
  DEFM "VAL"

; Data block at EA93
  DEFB $C5,$04

; Message at EA95
  DEFM "ALG"

; Data block at EA98
  DEFB $CF,$03,$41,$55,$CE,$01,$BB,$05

; Message at EAA0
  DEFM "DICH"

; Data block at EAA4
  DEFB $CF,$03,$53,$41,$CC,$0A

; Message at EAAA
  DEFM "HIDRAULIC"

; Data block at EAB3
  DEFB $CF,$07

; Message at EAB5
  DEFM "SUSPIR"

; Data block at EABB
  DEFB $CF,$0A

; Message at EABD
  DEFM "COMPUERTA"

; Data block at EAC6
  DEFB $D3,$05

; Message at EAC8
  DEFM "ABRE"

; Data block at EACC
  DEFB $CE,$03,$50,$41,$D2,$07

; Message at EAD2
  DEFM "(BONIT"

; Data block at EAD8
  DEFB $C1,$0B

; Message at EADA
  DEFM "DESCRIPCIO"

; Data block at EAE4
  DEFB $CE,$01,$A9,$05

; Message at EAE8
  DEFM "ENTR"

; Data block at EAEC
  DEFB $C1,$06

; Message at EAEE
  DEFM "MUCHO"

; Data block at EAF3
  DEFB $D3,$08

; Message at EAF5
  DEFM "ARBOLES"

; Data block at EAFC
  DEFB $BB,$07

; Message at EAFE
  DEFM "HIERBA"

; Data block at EB04
  DEFB $BB,$05

; Message at EB06
  DEFM "BRIS"

; Data block at EB0A
  DEFB $C1,$05

; Message at EB0C
  DEFM "ENTR"

; Data block at EB10
  DEFB $C5,$06

; Message at EB12
  DEFM "HOJAS"

; Data block at EB17
  DEFB $BB,$06

; Message at EB19
  DEFM "GNURR"

; Data block at EB1E
  DEFB $D3,$08

; Message at EB20
  DEFM "SALTAND"

; Data block at EB27
  DEFB $CF,$04

; Message at EB29
  DEFM "RAM"

; Data block at EB2C
  DEFB $C1,$08

; Message at EB2E
  DEFM "BUCOLIC"

; Data block at EB35
  DEFB $CF,$05

; Message at EB37
  DEFM "TOTA"

; Data block at EB3B
  DEFB $CC,$06

; Message at EB3D
  DEFM "ANIMA"

; Data block at EB42
  DEFB $CC,$06

; Message at EB44
  DEFM "CHORR"

; Data block at EB49
  DEFB $CF,$05

; Message at EB4B
  DEFM "SURG"

; Data block at EB4F
  DEFB $C5,$04

; Message at EB51
  DEFM "ARM"

; Data block at EB54
  DEFB $C1,$0B

; Message at EB56
  DEFM "DESTRUYEND"

; Data block at EB60
  DEFB $CF,$05

; Message at EB62
  DEFM "PART"

; Data block at EB66
  DEFB $C5,$08

; Message at EB68
  DEFM "SISTEMA"

; Data block at EB6F
  DEFB $D3,$0C

; Message at EB71
  DEFM "ELECTRONICO"

; Data block at EB7C
  DEFB $D3,$02,$54,$C5,$03,$48,$41,$D3
  DEFB $09

; Message at EB85
  DEFM "CONDENAD"

; Data block at EB8D
  DEFB $CF,$02,$54,$D5,$06

; Message at EB92
  DEFM "MISMO"

; Data block at EB97
  DEFB $BB,$07

; Message at EB99
  DEFM "MERECE"

; Data block at EB9F
  DEFB $D3,$01,$D2,$0A

; Message at EBA3
  DEFM "REDESCRIB"

; Data block at EBAC
  DEFB $C5,$06

; Message at EBAE
  DEFM "LLAMA"

; Data block at EBB3
  DEFB $D3,$09

; Message at EBB5
  DEFM "ENVUELVE"

; Data block at EBBD
  DEFB $CE,$08

; Message at EBBF
  DEFM "ARBUSTO"

; Data block at EBC6
  DEFB $D3,$07

; Message at EBC8
  DEFM "ESPESA"

; Data block at EBCE
  DEFB $CE,$11

; Message at EBD0
  DEFM "CONSIDERABLEMENT"

; Data block at EBE0
  DEFB $C5,$06

; Message at EBE2
  DEFM "ADEMA"

; Data block at EBE7
  DEFB $D3,$07

; Message at EBE9
  DEFM "PINCHA"

; Data block at EBEF
  DEFB $CE,$02,$41,$CC,$06

; Message at EBF4
  DEFM "ASOMA"

; Data block at EBF9
  DEFB $D2,$08

; Message at EBFB
  DEFM "EDIFICI"

; Data block at EC02
  DEFB $CF,$06

; Message at EC04
  DEFM "PIEDR"

; Data block at EC09
  DEFB $C1,$07

; Message at EC0B
  DEFM "ASPECT"

; Data block at EC11
  DEFB $CF,$07

; Message at EC13
  DEFM "ANTIGU"

; Data block at EC19
  DEFB $CF,$06

; Message at EC1B
  DEFM "TEMPL"

; Data block at EC20
  DEFB $CF,$05

; Message at EC22
  DEFM "QUIZ"

; Data block at EC26
  DEFB $C1,$09

; Message at EC28
  DEFM "ESPINOSO"

; Data block at EC30
  DEFB $D3,$07

; Message at EC32
  DEFM "IMPIDE"

; Data block at EC38
  DEFB $CE,$02,$49,$D2,$03,$45,$53,$C1
  DEFB $09

; Message at EC41
  DEFM "DIRECCIO"

; Data block at EC49
  DEFB $CE,$04

; Message at EC4B
  DEFM "ZZA"

; Data block at EC4E
  DEFB $D0,$07

; Message at EC50
  DEFM "PRODUC"

; Data block at EC56
  DEFB $C5,$07

; Message at EC58
  DEFM "SOCAVO"

; Data block at EC5E
  DEFB $CE,$02,$35,$B0,$02,$43,$CD,$0B

; Message at EC66
  DEFM "PROFUNDIDA"

; Data block at EC70
  DEFB $C4,$0D

; Message at EC72
  DEFM "IMPRESIONANT"

; Data block at EC7E
  DEFB $C5,$04

; Message at EC80
  DEFM "PER"

; Data block at EC83
  DEFB $CF,$05

; Message at EC85
  DEFM "ESTO"

; Data block at EC89
  DEFB $D9,$05

; Message at EC8B
  DEFM "VERL"

; Data block at EC8F
  DEFB $C5,$07

; Message at EC91
  DEFM "SENTID"

; Data block at EC97
  DEFB $CF,$04

; Message at EC99
  DEFM "EST"

; Data block at EC9C
  DEFB $CF,$08

; Message at EC9E
  DEFM "BICHITO"

; Data block at ECA5
  DEFB $D3,$07

; Message at ECA7
  DEFM "PELUDO"

; Data block at ECAD
  DEFB $D3,$06

; Message at ECAF
  DEFM "SALTA"

; Data block at ECB4
  DEFB $CE,$0A

; Message at ECB6
  DEFM "SIMPATICO"

; Data block at ECBF
  DEFB $D3,$05

; Message at ECC1
  DEFM "COGE"

; Data block at ECC5
  DEFB $D2,$05

; Message at ECC7
  DEFM "GNUR"

; Data block at ECCB
  DEFB $D2,$08

; Message at ECCD
  DEFM "BORRACH"

; Data block at ECD4
  DEFB $CF,$05

; Message at ECD6
  DEFM "MANO"

; Data block at ECDA
  DEFB $D3,$06

; Message at ECDC
  DEFM "CORRE"

; Data block at ECE1
  DEFB $CE,$01,$A5,$08

; Message at ECE5
  DEFM "ESTRECH"

; Data block at ECEC
  DEFB $CF,$06

; Message at ECEE
  DEFM "CAMIN"

; Data block at ECF3
  DEFB $CF,$07

; Message at ECF5
  DEFM "ABIERT"

; Data block at ECFB
  DEFB $CF,$0A

; Message at ECFD
  DEFM "MATORRALE"

; Data block at ED06
  DEFB $D3,$06

; Message at ED08
  DEFM "PAREC"

; Data block at ED0D
  DEFB $C5,$0A

; Message at ED0F
  DEFM "TRANSITAD"

; Data block at ED18
  DEFB $CF,$0A

; Message at ED1A
  DEFM "ABUNDANCI"

; Data block at ED23
  DEFB $C1,$07

; Message at ED25
  DEFM "HUELLA"

; Data block at ED2B
  DEFB $D3,$06

; Message at ED2D
  DEFM "RECOD"

; Data block at ED32
  DEFB $CF,$04

; Message at ED34
  DEFM "GIR"

; Data block at ED37
  DEFB $C1,$05

; Message at ED39
  DEFM "HACI"

; Data block at ED3D
  DEFB $C1,$07

; Message at ED3F
  DEFM "ESCUCH"

; Data block at ED45
  DEFB $CF,$05

; Message at ED47
  DEFM "VOCE"

; Data block at ED4B
  DEFB $D3,$08

; Message at ED4D
  DEFM "DISCURR"

; Data block at ED54
  DEFB $C5,$04

; Message at ED56
  DEFM "OIG"

; Data block at ED59
  DEFB $CF,$09

; Message at ED5B
  DEFM "ENCUENTR"

; Data block at ED63
  DEFB $C1,$0A

; Message at ED65
  DEFM "DESTROZAD"

; Data block at ED6E
  DEFB $C1,$06

; Message at ED70
  DEFM "ACABA"

; Data block at ED75
  DEFB $D2,$07

; Message at ED77
  DEFM "RECIBI"

; Data block at ED7D
  DEFB $D2,$06

; Message at ED7F
  DEFM "ATAQU"

; Data block at ED84
  DEFB $C5,$06

; Message at ED86
  DEFM "CENTR"

; Data block at ED8B
  DEFB $CF,$07

; Message at ED8D
  DEFM "POBLAD"

; Data block at ED93
  DEFB $CF,$03,$50,$49,$C5,$03,$4D,$41
  DEFB $D3,$06

; Message at ED9D
  DEFM "GRAND"

; Data block at EDA2
  DEFB $C5,$08

; Message at EDA4
  DEFM "INTERIO"

; Data block at EDAB
  DEFB $D2,$06

; Message at EDAD
  DEFM "JERGO"

; Data block at EDB2
  DEFB $CE,$06

; Message at EDB4
  DEFM "HERID"

; Data block at EDB9
  DEFB $CF,$05

; Message at EDBB
  DEFM "PATA"

; Data block at EDBF
  DEFB $D3,$03,$50,$4F,$D2,$07

; Message at EDC5
  DEFM "ANCIAN"

; Data block at EDCB
  DEFB $CF,$04

; Message at EDCD
  DEFM "OJO"

; Data block at EDD0
  DEFB $D3,$05

; Message at EDD2
  DEFM "MIRA"

; Data block at EDD6
  DEFB $CE,$05

; Message at EDD8
  DEFM "TEMO"

; Data block at EDDC
  DEFB $D2,$08

; Message at EDDE
  DEFM "MIENTRA"

; Data block at EDE5
  DEFB $D3,$04

; Message at EDE7
  DEFM "DIC"

; Data block at EDEA
  DEFB $C5,$05

; Message at EDEC
  DEFM "SUEN"

; Data block at EDF0
  DEFB $C1,$09

; Message at EDF2
  DEFM "\"FKFVIWY"

; Data block at EDFA
  DEFB $C7,$08

; Message at EDFC
  DEFM "MBR'NVB"

; Data block at EE03
  DEFB $C8,$07

; Message at EE05
  DEFM "NERBCH"

; Data block at EE0B
  DEFB $A2,$09

; Message at EE0D
  DEFM "ENTIENDE"

; Data block at EE15
  DEFB $D3,$02,$4E,$C9,$04

; Message at EE1A
  DEFM "JOT"

; Data block at EE1D
  DEFB $C1,$05

; Message at EE1F
  DEFM "ANCH"

; Data block at EE23
  DEFB $CF,$04

; Message at EE25
  DEFM "OTR"

; Data block at EE28
  DEFB $CF,$04

; Message at EE2A
  DEFM "LAD"

; Data block at EE2D
  DEFB $CF,$05

; Message at EE2F
  DEFM "ALTA"

; Data block at EE33
  DEFB $D3,$06

; Message at EE35
  DEFM "TORRE"

; Data block at EE3A
  DEFB $D3,$06

; Message at EE3C
  DEFM "CIUDA"

; Data block at EE41
  DEFB $C4,$07

; Message at EE43
  DEFM "N'MHYR"

; Data block at EE49
  DEFB $C8,$06

; Message at EE4B
  DEFM "AUNQU"

; Data block at EE50
  DEFB $C5,$08

; Message at EE52
  DEFM "DESIERT"

; Data block at EE59
  DEFB $CF,$06

; Message at EE5B
  DEFM "SIENT"

; Data block at EE60
  DEFB $CF,$03,$53,$4F,$D9,$09

; Message at EE66
  DEFM "OBSERVAD"

; Data block at EE6E
  DEFB $CF,$09

; Message at EE70
  DEFM "TRANQUIL"

; Data block at EE78
  DEFB $CF,$05

; Message at EE7A
  DEFM "AGUA"

; Data block at EE7E
  DEFB $D3,$07

; Message at EE80
  DEFM "LIMPIA"

; Data block at EE86
  DEFB $D3,$0B

; Message at EE88
  DEFM "CRISTALINA"

; Data block at EE92
  DEFB $D3,$07

; Message at EE94
  DEFM "ALGUNA"

; Data block at EE9A
  DEFB $D3,$06

; Message at EE9C
  DEFM "FORMA"

; Data block at EEA1
  DEFB $D3,$0A

; Message at EEA3
  DEFM "MOVIENDOS"

; Data block at EEAC
  DEFB $C5,$06

; Message at EEAE
  DEFM "(PECE"

; Data block at EEB3
  DEFB $D3,$08

; Message at EEB5
  DEFM "IMAGINO"

; Data block at EEBC
  DEFB $A9,$08

; Message at EEBE
  DEFM "PENSAND"

; Data block at EEC5
  DEFB $CF,$05

; Message at EEC7
  DEFM "CRUC"

; Data block at EECB
  DEFB $C5,$07

; Message at EECD
  DEFM "NADAND"

; Data block at EED3
  DEFB $CF,$06

; Message at EED5
  DEFM "HABLA"

; Data block at EEDA
  DEFB $D2,$05

; Message at EEDC
  DEFM "CORR"

; Data block at EEE0
  DEFB $C5,$06

; Message at EEE2
  DEFM "FUERZ"

; Data block at EEE7
  DEFB $C1,$0F

; Message at EEE9
  DEFM "PRESUMIBLEMENT"

; Data block at EEF7
  DEFB $C5,$08

; Message at EEF9
  DEFM "PRETEND"

; Data block at EF00
  DEFB $C5,$04

; Message at EF02
  DEFM "NAD"

; Data block at EF05
  DEFB $C5,$06

; Message at EF07
  DEFM "PIENS"

; Data block at EF0C
  DEFB $C5,$07

; Message at EF0E
  DEFM "DISPAR"

; Data block at EF14
  DEFB $CF,$07

; Message at EF16
  DEFM "ESPARC"

; Data block at EF1C
  DEFB $C5,$07

; Message at EF1E
  DEFM "PEDAZO"

; Data block at EF24
  DEFB $D3,$04

; Message at EF26
  DEFM "TOD"

; Data block at EF29
  DEFB $C1,$05

; Message at EF2B
  DEFM "QUED"

; Data block at EF2F
  DEFB $C1,$0A

; Message at EF31
  DEFM "REDECORAD"

; Data block at EF3A
  DEFB $C1,$0D

; Message at EF3C
  DEFM "APARENTEMENT"

; Data block at EF48
  DEFB $C5,$06

; Message at EF4A
  DEFM "SURGE"

; Data block at EF4F
  DEFB $CE,$04

; Message at EF51
  DEFM "DOC"

; Data block at EF54
  DEFB $C5,$11

; Message at EF56
  DEFM "GUERREROSYNNH'AR"

; Data block at EF66
  DEFB $D2,$04

; Message at EF68
  DEFM "TRA"

; Data block at EF6B
  DEFB $D3,$07

; Message at EF6D
  DEFM "MOMENT"

; Data block at EF73
  DEFB $CF,$08

; Message at EF75
  DEFM "SORPRES"

; Data block at EF7C
  DEFB $C1,$09

; Message at EF7E
  DEFM "ARREMETE"

; Data block at EF86
  DEFB $CE,$06

; Message at EF88
  DEFM "CONTR"

; Data block at EF8D
  DEFB $C1,$02,$4D,$C9,$09

; Message at EF92
  DEFM "EXPRESIO"

; Data block at EF9A
  DEFB $CE,$04

; Message at EF9C
  DEFM "ODI"

; Data block at EF9F
  DEFB $CF,$05

; Message at EFA1
  DEFM "NUNC"

; Data block at EFA5
  DEFB $C1,$04

; Message at EFA7
  DEFM "CRE"

; Data block at EFAA
  DEFB $C9,$07

; Message at EFAC
  DEFM "POSIBL"

; Data block at EFB2
  DEFB $C5,$0A

; Message at EFB4
  DEFM "INSECTOID"

; Data block at EFBD
  DEFB $C5,$08

; Message at EFBF
  DEFM "ENTIEND"

; Data block at EFC6
  DEFB $CF,$09

; Message at EFC8
  DEFM "GUERRERO"

; Data block at EFD0
  DEFB $D3,$05

; Message at EFD2
  DEFM "ACAB"

; Data block at EFD6
  DEFB $CF,$05

; Message at EFD8
  DEFM "AYUD"

; Data block at EFDC
  DEFB $C1,$04

; Message at EFDE
  DEFM "CUR"

; Data block at EFE1
  DEFB $C1,$07

; Message at EFE3
  DEFM "YNN'AR"

; Data block at EFE9
  DEFB $D2,$04

; Message at EFEB
  DEFM "CAS"

; Data block at EFEE
  DEFB $C9,$09

; Message at EFF0
  DEFM "DESTRUID"

; Data block at EFF8
  DEFB $C1,$09

; Message at EFFA
  DEFM "COMIENZA"

; Data block at F002
  DEFB $D3,$05

; Message at F004
  DEFM "CURA"

; Data block at F008
  DEFB $D2,$04

; Message at F00A
  DEFM "MIR"

; Data block at F00D
  DEFB $C1,$05

; Message at F00F
  DEFM "GEST"

; Data block at F013
  DEFB $CF,$0A

; Message at F015
  DEFM "AGRADECID"

; Data block at F01E
  DEFB $CF,$06

; Message at F020
  DEFM "DOCEN"

; Data block at F025
  DEFB $C1,$08

; Message at F027
  DEFM "SURGIDO"

; Data block at F02E
  DEFB $D3,$06

; Message at F030
  DEFM "RODEA"

; Data block at F035
  DEFB $CE,$08

; Message at F037
  DEFM "VENDADA"

; Data block at F03E
  DEFB $D3,$09

; Message at F040
  DEFM "CONTEMPL"

; Data block at F048
  DEFB $C1,$0E

; Message at F04A
  DEFM "AGRADECIMIEND"

; Data block at F057
  DEFB $CF,$05

; Message at F059
  DEFM "CANO"

; Data block at F05D
  DEFB $C1,$05

; Message at F05F
  DEFM "BARC"

; Data block at F063
  DEFB $C1,$05

; Message at F065
  DEFM "233N"

; Data block at F069
  DEFB $CF,$07

; Message at F06B
  DEFM "INTENT"

; Data block at F071
  DEFB $CF,$0B

; Message at F073
  DEFM "FUERTEMENT"

; Data block at F07D
  DEFB $C5,$06

; Message at F07F
  DEFM "SUJET"

; Data block at F084
  DEFB $C1,$03,$4D,$49,$D3,$09

; Message at F08A
  DEFM "ESFUERZO"

; Data block at F092
  DEFB $D3,$06

; Message at F094
  DEFM "ACERC"

; Data block at F099
  DEFB $C1,$06

; Message at F09B
  DEFM "LIBER"

; Data block at F0A0
  DEFB $C1,$09

; Message at F0A2
  DEFM "SUJECCIO"

; Data block at F0AA
  DEFB $CE,$07

; Message at F0AC
  DEFM "DESLIZ"

; Data block at F0B2
  DEFB $CF,$05

; Message at F0B4
  DEFM "HAST"

; Data block at F0B8
  DEFB $C1,$08

; Message at F0BA
  DEFM "SENCILL"

; Data block at F0C1
  DEFB $C1,$09

; Message at F0C3
  DEFM "CAPACIDA"

; Data block at F0CB
  DEFB $C4,$08

; Message at F0CD
  DEFM "PASAJER"

; Data block at F0D4
  DEFB $CF,$07

; Message at F0D6
  DEFM "GRANDE"

; Data block at F0DC
  DEFB $D3,$07

; Message at F0DE
  DEFM "CAJONE"

; Data block at F0E4
  DEFB $D3,$06

; Message at F0E6
  DEFM "USADO"

; Data block at F0EB
  DEFB $D3,$0B

; Message at F0ED
  DEFM "NORMALMENT"

; Data block at F0F7
  DEFB $C5,$06

; Message at F0F9
  DEFM "LLEVA"

; Data block at F0FE
  DEFB $D2,$06

; Message at F100
  DEFM "OCUPA"

; Data block at F105
  DEFB $CE,$0D

; Message at F107
  DEFM "PRACTICAMENT"

; Data block at F113
  DEFB $C5,$05

; Message at F115
  DEFM "ESTA"

; Data block at F119
  DEFB $CE,$08

; Message at F11B
  DEFM "CERRADO"

; Data block at F122
  DEFB $D3,$09

; Message at F124
  DEFM "PROPIEDA"

; Data block at F12C
  DEFB $C4,$07

; Message at F12E
  DEFM "ALGUIE"

; Data block at F134
  DEFB $CE,$0A

; Message at F136
  DEFM "IMPORTANT"

; Data block at F13F
  DEFB $C5,$07

; Message at F141
  DEFM "MUESTR"

; Data block at F147
  DEFB $C1,$06

; Message at F149
  DEFM "MARCA"

; Data block at F14E
  DEFB $D3,$08

; Message at F150
  DEFM "DISPARO"

; Data block at F157
  DEFB $D3,$0D

; Message at F159
  DEFM "PROBABLEMENT"

; Data block at F165
  DEFB $C5,$05

; Message at F167
  DEFM "ACAB"

; Data block at F16B
  DEFB $C1,$07

; Message at F16D
  DEFM "ALGUNO"

; Data block at F173
  DEFB $D3,$09

; Message at F175
  DEFM "CADAVERE"

; Data block at F17D
  DEFB $D3,$09

; Message at F17F
  DEFM "COMPREND"

; Data block at F187
  DEFB $CF,$08

; Message at F189
  DEFM "OBSERVA"

; Data block at F190
  DEFB $CE,$09

; Message at F192
  DEFM "TOMANDOM"

; Data block at F19A
  DEFB $C5,$03,$55,$4E,$CF,$08

; Message at F1A0
  DEFM "ENEMIGO"

; Data block at F1A7
  DEFB $D3,$06

; Message at F1A9
  DEFM "VARIO"

; Data block at F1AE
  DEFB $D3,$06

; Message at F1B0
  DEFM "LANZA"

; Data block at F1B5
  DEFB $CE,$0A

; Message at F1B7
  DEFM "DEMASIADO"

; Data block at F1C0
  DEFB $D3,$07

; Message at F1C2
  DEFM "NINGUN"

; Data block at F1C8
  DEFB $C1,$0B

; Message at F1CA
  DEFM "OPORTUNIDA"

; Data block at F1D4
  DEFB $C4,$05

; Message at F1D6
  DEFM "CAJA"

; Data block at F1DA
  DEFB $D3,$08

; Message at F1DC
  DEFM "ESPECIA"

; Data block at F1E3
  DEFB $CC,$07

; Message at F1E5
  DEFM "PLANTA"

; Data block at F1EB
  DEFB $D3,$0B

; Message at F1ED
  DEFM "INDICADORE"

; Data block at F1F7
  DEFB $D3,$08

; Message at F1F9
  DEFM "ILUMINA"

; Data block at F200
  DEFB $CE,$05

; Message at F202
  DEFM "TENU"

; Data block at F206
  DEFB $C5,$06

; Message at F208
  DEFM "QUIER"

; Data block at F20D
  DEFB $C5,$05

; Message at F20F
  DEFM "DECI"

; Data block at F213
  DEFB $D2,$06

; Message at F215
  DEFM "MARCH"

; Data block at F21A
  DEFB $C1,$04

; Message at F21C
  DEFM "BIE"

; Data block at F21F
  DEFB $CE,$04

; Message at F221
  DEFM "SUB"

; Data block at F224
  DEFB $CF,$0E

; Message at F226
  DEFM "INMEDIATAMENT"

; Data block at F233
  DEFB $C5,$09

; Message at F235
  DEFM "CORRIENT"

; Data block at F23D
  DEFB $C5,$07

; Message at F23F
  DEFM "IMPULS"

; Data block at F245
  DEFB $C1,$07

; Message at F247
  DEFM "SALIDO"

; Data block at F24D
  DEFB $D3,$04

; Message at F24F
  DEFM "LOA"

; Data block at F252
  DEFB $C4,$04

; Message at F254
  DEFM "SAV"

; Data block at F257
  DEFB $C5,$04

; Message at F259
  DEFM "REM"

; Data block at F25C
  DEFB $C1,$06

; Message at F25E
  DEFM "HOMBR"

; Data block at F263
  DEFB $C5,$0B

; Message at F265
  DEFM "EMBARCADER"

; Data block at F26F
  DEFB $CF,$03,$4D,$31,$B6,$03,$4D,$31
  DEFB $B0,$06

; Message at F279
  DEFM "SPLAS"

; Data block at F27E
  DEFB $C8,$04

; Message at F280
  DEFM "AGU"

; Data block at F283
  DEFB $C1,$04

; Message at F285
  DEFM "BRR"

; Data block at F288
  DEFB $D2,$04

; Message at F28A
  DEFM "FRI"

; Data block at F28D
  DEFB $C1,$05

; Message at F28F
  DEFM "BUCE"

; Data block at F293
  DEFB $C1,$09

; Message at F295
  DEFM "SUMERGET"

; Data block at F29D
  DEFB $C5,$05

; Message at F29F
  DEFM "FOND"

; Data block at F2A3
  DEFB $CF,$0A

; Message at F2A5
  DEFM "CRISTALIN"

; Data block at F2AE
  DEFB $C1,$04

; Message at F2B0
  DEFM "SUB"

; Data block at F2B3
  DEFB $C5,$04

; Message at F2B5
  DEFM "BAJ"

; Data block at F2B8
  DEFB $C1,$05

; Message at F2BA
  DEFM "PLAC"

; Data block at F2BE
  DEFB $C1,$08

; Message at F2C0
  DEFM "METALIC"

; Data block at F2C7
  DEFB $C1,$0E

; Message at F2C9
  DEFM "IDENTIFICACIO"

; Data block at F2D6
  DEFB $CE,$05

; Message at F2D8
  DEFM "DEBI"

; Data block at F2DC
  DEFB $CF,$08

; Message at F2DE
  DEFM "CAERSEL"

; Data block at F2E5
  DEFB $C5,$04

; Message at F2E7
  DEFM "OTR"

; Data block at F2EA
  DEFB $C1,$08

; Message at F2EC
  DEFM "AVENTUR"

; Data block at F2F3
  DEFB $C1,$05

; Message at F2F5
  DEFM "LLEG"

; Data block at F2F9
  DEFB $C1,$04

; Message at F2FB
  DEFM "DEB"

; Data block at F2FE
  DEFB $CF,$0A

; Message at F300
  DEFM "ENTREGARL"

; Data block at F309
  DEFB $CF,$08

; Message at F30B
  DEFM "CONTACT"

; Data block at F312
  DEFB $CF,$08

; Message at F314
  DEFM "ANIMALE"

; Data block at F31B
  DEFB $D3,$06

; Message at F31D
  DEFM "PRUEB"

; Data block at F322
  DEFB $C1,$07

; Message at F324
  DEFM "REMAND"

; Data block at F32A
  DEFB $CF,$0A

; Message at F32C
  DEFM "ARRASATOD"

; Data block at F335
  DEFB $CF,$04

; Message at F337
  DEFM "PAS"

; Data block at F33A
  DEFB $CF,$05

; Message at F33C
  DEFM "SIRV"

; Data block at F340
  DEFB $C1,$07

; Message at F342
  DEFM "DESTIN"

; Data block at F348
  DEFB $CF,$08

; Message at F34A
  DEFM "CONTINU"

; Data block at F351
  DEFB $C1,$05

; Message at F353
  DEFM "CURS"

; Data block at F357
  DEFB $CF,$07

; Message at F359
  DEFM "GRACIA"

; Data block at F35F
  DEFB $D3

; Message at F360
  DEFM "(ATENCION*******************************"

; Data block at F388
  DEFB $AA,$08

; Message at F38A
  DEFM "ATENCIO"

; Data block at F391
  DEFB $CE,$06

; Message at F393
  DEFM "NYHMI"

; Data block at F398
  DEFB $D2,$05

; Message at F39A
  DEFM "CLAR"

; Data block at F39E
  DEFB $C1,$08

; Message at F3A0
  DEFM "PROFUND"

; Data block at F3A7
  DEFB $CF,$06

; Message at F3A9
  DEFM "BRILL"

; Data block at F3AE
  DEFB $C1,$03,$45,$54,$C3,$0B

; Message at F3B4
  DEFM "DESINFECTA"

; Data block at F3BE
  DEFB $D3,$06

; Message at F3C0
  DEFM "HERID"

; Data block at F3C5
  DEFB $C1,$0B

; Message at F3C7
  DEFM "ENTABLILLA"

; Data block at F3D1
  DEFB $D3,$04

; Message at F3D3
  DEFM "PAT"

; Data block at F3D6
  DEFB $C1,$05

; Message at F3D8
  DEFM "IGUA"

; Data block at F3DC
  DEFB $CC,$09

; Message at F3DE
  DEFM "ATRAVIES"

; Data block at F3E6
  DEFB $C1,$0B

; Message at F3E8
  DEFM "LIMPIAMENT"

; Data block at F3F2
  DEFB $C5,$06

; Message at F3F4
  DEFM "CRANE"

; Data block at F3F9
  DEFB $CF,$05

; Message at F3FB
  DEFM "MUER"

; Data block at F3FF
  DEFB $C5,$08

; Message at F401
  DEFM "INSTANT"

; Data block at F408
  DEFB $C5,$0B

; Message at F40A
  DEFM "ENFURECIDO"

; Data block at F414
  DEFB $D3,$08

; Message at F416
  DEFM "YNN'AHR"

; Data block at F41D
  DEFB $D2,$08

; Message at F41F
  DEFM "ENSARTA"

; Data block at F426
  DEFB $CE,$06

; Message at F428
  DEFM "LANZA"

; Data block at F42D
  DEFB $D3,$07

; Message at F42F
  DEFM "VENDAD"

; Data block at F435
  DEFB $C1,$06

; Message at F437
  DEFM "FRENT"

; Data block at F43C
  DEFB $C5,$05

; Message at F43E
  DEFM "MONT"

; Data block at F442
  DEFB $C1,$04

; Message at F444
  DEFM "VET"

; Data block at F447
  DEFB $C5,$06

; Message at F449
  DEFM "MONED"

; Data block at F44E
  DEFB $C1,$01,$B5,$08

; Message at F452
  DEFM "CREDITO"

; Data block at F459
  DEFB $D3,$05

; Message at F45B
  DEFM "AHOR"

; Data block at F45F
  DEFB $C1,$07

; Message at F461
  DEFM "TENERL"

; Data block at F467
  DEFB $CF,$05

; Message at F469
  DEFM "ANTE"

; Data block at F46D
  DEFB $D3,$08

; Message at F46F
  DEFM "PULMONE"

; Data block at F476
  DEFB $D3,$08

; Message at F478
  DEFM "RESISTE"

; Data block at F47F
  DEFB $CE,$06

; Message at F481
  DEFM "BOQUE"

; Data block at F486
  DEFB $CF,$0F

; Message at F488
  DEFM "INEVITABLEMENT"

; Data block at F496
  DEFB $C5,$05

; Message at F498
  DEFM "AHOG"

; Data block at F49C
  DEFB $CF,$04

; Message at F49E
  DEFM "ZIT"

; Data block at F4A1
  DEFB $C8,$03,$53,$45,$D2,$08

; Message at F4A7
  DEFM "PARECID"

; Data block at F4AE
  DEFB $CF,$07

; Message at F4B0
  DEFM "VENADO"

; Data block at F4B6
  DEFB $D3,$06

; Message at F4B8
  DEFM "TIERR"

; Data block at F4BD
  DEFB $C1,$05

; Message at F4BF
  DEFM "RAMA"

; Data block at F4C3
  DEFB $D3,$05

; Message at F4C5
  DEFM "CRUZ"

; Data block at F4C9
  DEFB $C1,$07

; Message at F4CB
  DEFM "FEROCE"

; Data block at F4D1
  DEFB $D3,$05

; Message at F4D3
  DEFM "KRYY"

; Data block at F4D7
  DEFB $D8,$07

; Message at F4D9
  DEFM "PARECE"

; Data block at F4DF
  DEFB $CE,$0B

; Message at F4E1
  DEFM "HAMBRIENTO"

; Data block at F4EB
  DEFB $D3,$06

; Message at F4ED
  DEFM "MANAD"

; Data block at F4F2
  DEFB $C1,$05

; Message at F4F4
  DEFM "ZITH"

; Data block at F4F8
  DEFB $D3,$07

; Message at F4FA
  DEFM "AFERRA"

; Data block at F500
  DEFB $CE,$06

; Message at F502
  DEFM "FAUCE"

; Data block at F507
  DEFB $D3,$08

; Message at F509
  DEFM "INTERNA"

; Data block at F510
  DEFB $CE,$02,$55,$C6,$06

; Message at F515
  DEFM "MUERT"

; Data block at F51A
  DEFB $CF,$09

; Message at F51C
  DEFM "BRILLANT"

; Data block at F524
  DEFB $C5,$04

; Message at F526
  DEFM "RAY"

; Data block at F529
  DEFB $CF,$04

; Message at F52B
  DEFM "MAT"

; Data block at F52E
  DEFB $C1,$05

; Message at F530
  DEFM "REST"

; Data block at F534
  DEFB $CF,$04

; Message at F536
  DEFM "HUY"

; Data block at F539
  DEFB $C5,$07

; Message at F53B
  DEFM "DECIDE"

; Data block at F541
  DEFB $CE,$04

; Message at F543
  DEFM "HOR"

; Data block at F546
  DEFB $C1,$05

; Message at F548
  DEFM "COME"

; Data block at F54C
  DEFB $D2,$02,$59,$CF,$08

; Message at F551
  DEFM "ALMUERZ"

; Data block at F558
  DEFB $CF,$06

; Message at F55A
  DEFM "ARROJ"

; Data block at F55F
  DEFB $C1,$06

; Message at F561
  DEFM "RAPID"

; Data block at F566
  DEFB $CF,$05

; Message at F568
  DEFM "THET"

; Data block at F56C
  DEFB $C1,$07

; Message at F56E
  DEFM "ORIONI"

; Data block at F574
  DEFB $D3,$07

; Message at F576
  DEFM "GRAFIC"

; Data block at F57C
  DEFB $CF,$0E

; Message at F57E
  DEFM "CONVERSACIONA"

; Data block at F58B
  DEFB $CC,$07

; Message at F58D
  DEFM "LECUON"

; Data block at F593
  DEFB $C1,$01,$CC,$06

; Message at F597
  DEFM "FRANC"

; Data block at F59C
  DEFB $CF,$09

; Message at F59E
  DEFM "COPYRIGH"

; Data block at F5A6
  DEFB $D4,$08

; Message at F5A8
  DEFM "HORUSOF"

; Data block at F5AF
  DEFB $D4,$04

; Message at F5B1
  DEFM "198"

; Data block at F5B4
  DEFB $B7,$16

; Message at F5B6
  DEFM "GRAFICO/CONVERSACIONA"

; Data block at F5CB
  DEFB $CC,$1F

; Message at F5CD
  DEFM "AVENTURA=GRAFICO/CONVERSACIONA"

; Data block at F5EB
  DEFB $CC,$08

; Message at F5ED
  DEFM "STARRIO"

; Data block at F5F4
  DEFB $D2,$03,$4F,$4E,$C5,$06

; Message at F5FA
  DEFM "LLAME"

; Data block at F5FF
  DEFB $D3,$05

; Message at F601
  DEFM "LLAM"

; Data block at F605
  DEFB $C5,$05

; Message at F607
  DEFM "ABAJ"

; Data block at F60B
  DEFB $CF,$06

; Message at F60D
  DEFM "ARRIB"

; Data block at F612
  DEFB $C1,$06

; Message at F614
  DEFM "ARRAS"

; Data block at F619
  DEFB $C1,$05

; Message at F61B
  DEFM "BUEN"

; Data block at F61F
  DEFB $CF,$04

; Message at F621
  DEFM "VAY"

; Data block at F624
  DEFB $C1,$04

; Message at F626
  DEFM "MEG"

; Data block at F629
  DEFB $C1,$04

; Message at F62B
  DEFM "COR"

; Data block at F62E
  DEFB $D0,$04

; Message at F630
  DEFM "TIR"

; Data block at F633
  DEFB $C1,$0A

; Message at F635
  DEFM "ESPANTOSO"

; Data block at F63E
  DEFB $D3,$07

; Message at F640
  DEFM "ENORME"

; Data block at F646
  DEFB $D3,$07

; Message at F648
  DEFM "RELAME"

; Data block at F64E
  DEFB $CE,$02,$33,$B0,$0A

; Message at F653
  DEFM "DESINFECT"

; Data block at F65C
  DEFB $CF,$04

; Message at F65E
  DEFM "CUR"

; Data block at F661
  DEFB $CF,$0B

; Message at F663
  DEFM "AGRADECIDO"

; Data block at F66D
  DEFB $D3,$06

; Message at F66F
  DEFM "MUELL"

; Data block at F674
  DEFB $C5,$1F

; Message at F676
  DEFM "AVENTURA/GRAFICO/CONVERSACIONA"

; Data block at F694
  DEFB $CC,$04

; Message at F696
  DEFM "CUA"

; Data block at F699
  DEFB $CC,$05

; Message at F69B
  DEFM "SIGU"

; Data block at F69F
  DEFB $C5,$04

; Message at F6A1
  DEFM "ALZ"

; Data block at F6A4
  DEFB $C1,$09

; Message at F6A6
  DEFM "IMPONENT"

; Data block at F6AE
  DEFB $C5,$04

; Message at F6B0
  DEFM "UNA"

; Data block at F6B3
  DEFB $D3,$06

; Message at F6B5
  DEFM "AGUDA"

; Data block at F6BA
  DEFB $D3,$05

; Message at F6BC
  DEFM "ROCA"

; Data block at F6C0
  DEFB $D3,$03,$41,$48,$C9,$04

; Message at F6C6
  DEFM "ANT"

; Data block at F6C9
  DEFB $C5,$0A

; Message at F6CB
  DEFM "MAJESTUOS"

; Data block at F6D4
  DEFB $CF,$0A

; Message at F6D6
  DEFM "ABANDONAD"

; Data block at F6DF
  DEFB $CF,$05

; Message at F6E1
  DEFM "HALL"

; Data block at F6E5
  DEFB $C1,$08

; Message at F6E7
  DEFM "SILENCI"

; Data block at F6EE
  DEFB $CF,$0A

; Message at F6F0
  DEFM "CONSTRUID"

; Data block at F6F9
  DEFB $CF,$08

; Message at F6FB
  DEFM "INMENSA"

; Data block at F702
  DEFB $D3,$07

; Message at F704
  DEFM "PIEDRA"

; Data block at F70A
  DEFB $D3,$06

; Message at F70C
  DEFM "FUERT"

; Data block at F711
  DEFB $C5,$04

; Message at F713
  DEFM "HAC"

; Data block at F716
  DEFB $C5,$06

; Message at F718
  DEFM "SIGLO"

; Data block at F71D
  DEFB $D3,$07

; Message at F71F
  DEFM "PAREDE"

; Data block at F725
  DEFB $D3,$09

; Message at F727
  DEFM "CUBIERTA"

; Data block at F72F
  DEFB $D3,$08

; Message at F731
  DEFM "SIMBOLO"

; Data block at F738
  DEFB $D3,$06

; Message at F73A
  DEFM "PUERT"

; Data block at F73F
  DEFB $C1,$07

; Message at F741
  DEFM "ABIERT"

; Data block at F747
  DEFB $C1,$07

; Message at F749
  DEFM "INVITA"

; Data block at F74F
  DEFB $D2,$04

; Message at F751
  DEFM "BAJ"

; Data block at F754
  DEFB $CF,$0B

; Message at F756
  DEFM "ESCALERILL"

; Data block at F760
  DEFB $C1,$08

; Message at F762
  DEFM "REDUCID"

; Data block at F769
  DEFB $CF,$0D

; Message at F76B
  DEFM "EMBARCACIONE"

; Data block at F777
  DEFB $D3,$04

; Message at F779
  DEFM "SOL"

; Data block at F77C
  DEFB $CF,$06

; Message at F77E
  DEFM "BARCA"

; Data block at F783
  DEFB $D3,$05

; Message at F785
  DEFM "PESC"

; Data block at F789
  DEFB $C1,$0B

; Message at F78B
  DEFM "MALHUMORAD"

; Data block at F795
  DEFB $CF,$06

; Message at F797
  DEFM "INDIC"

; Data block at F79C
  DEFB $C1,$06

; Message at F79E
  DEFM "CARTE"

; Data block at F7A3
  DEFB $CC,$03,$4D,$41,$CC,$06

; Message at F7A9
  DEFM "PEORE"

; Data block at F7AE
  DEFB $D3,$07

; Message at F7B0
  DEFM "MODALE"

; Data block at F7B6
  DEFB $D3,$05

; Message at F7B8
  DEFM "LLEV"

; Data block at F7BC
  DEFB $C1,$05

; Message at F7BE
  DEFM "DARL"

; Data block at F7C2
  DEFB $C5,$06

; Message at F7C4
  DEFM "CIERT"

; Data block at F7C9
  DEFB $C1,$09

; Message at F7CB
  DEFM "AUTORIDA"

; Data block at F7D3
  DEFB $C4,$08

; Message at F7D5
  DEFM "GUSTABA"

; Data block at F7DC
  DEFB $CE,$07

; Message at F7DE
  DEFM "\"UBSJG"

; Data block at F7E4
  DEFB $C2,$09

; Message at F7E6
  DEFM "DSFEHSPT"

; Data block at F7EE
  DEFB $A2,$01,$A8,$06

; Message at F7F2
  DEFM "CIERR"

; Data block at F7F7
  DEFB $C1,$07

; Message at F7F9
  DEFM "LETRER"

; Data block at F7FF
  DEFB $CF,$04

; Message at F801
  DEFM "TOM"

; Data block at F804
  DEFB $C1,$0A

; Message at F806
  DEFM "BRUSQUEDA"

; Data block at F80F
  DEFB $C4,$0B

; Message at F811
  DEFM "FARFULLAND"

; Data block at F81B
  DEFB $CF,$06

; Message at F81D
  DEFM "ALEGR"

; Data block at F822
  DEFB $CF,$08

; Message at F824
  DEFM "ENTENDE"

; Data block at F82B
  DEFB $D2,$05

; Message at F82D
  DEFM "ALEJ"

; Data block at F831
  DEFB $C1,$06

; Message at F833
  DEFM "GUARD"

; Data block at F838
  DEFB $C1,$07

; Message at F83A
  DEFM "ENTREG"

; Data block at F840
  DEFB $C1,$05

; Message at F842
  DEFM "PAPE"

; Data block at F846
  DEFB $CC,$06

; Message at F848
  DEFM "RECIB"

; Data block at F84D
  DEFB $CF,$04

; Message at F84F
  DEFM "CAS"

; Data block at F852
  DEFB $C1,$07

; Message at F854
  DEFM "ESCRIT"

; Data block at F85A
  DEFB $CF,$06

; Message at F85C
  DEFM "DEDIC"

; Data block at F861
  DEFB $C1,$06

; Message at F863
  DEFM "MIRAD"

; Data block at F868
  DEFB $C1,$09

; Message at F86A
  DEFM "DESPRECI"

; Data block at F872
  DEFB $CF,$0C

; Message at F874
  DEFM "FUNCIONARIO"

; Data block at F87F
  DEFB $D3,$03,$42,$41,$C8,$09

; Message at F885
  DEFM "CHILLAND"

; Data block at F88D
  DEFB $CF,$07

; Message at F88F
  DEFM "ENTRAD"

; Data block at F895
  DEFB $C1,$06

; Message at F897
  DEFM "PUEST"

; Data block at F89C
  DEFB $CF,$07

; Message at F89E
  DEFM "CONTRO"

; Data block at F8A4
  DEFB $CC,$08

; Message at F8A6
  DEFM "POLICIA"

; Data block at F8AD
  DEFB $CC,$06

; Message at F8AF
  DEFM "ACCES"

; Data block at F8B4
  DEFB $CF,$08

; Message at F8B6
  DEFM "VIGILAD"

; Data block at F8BD
  DEFB $CF,$07

; Message at F8BF
  DEFM "POLICI"

; Data block at F8C5
  DEFB $C1,$06

; Message at F8C7
  DEFM "AGENT"

; Data block at F8CC
  DEFB $C5,$06

; Message at F8CE
  DEFM "SEVER"

; Data block at F8D3
  DEFB $C1,$06

; Message at F8D5
  DEFM "VIGIL"

; Data block at F8DA
  DEFB $C1,$09

; Message at F8DC
  DEFM "HUMANOID"

; Data block at F8E4
  DEFB $C5,$04

; Message at F8E6
  DEFM "ALT"

; Data block at F8E9
  DEFB $CF,$09

; Message at F8EB
  DEFM "MUSCULOS"

; Data block at F8F3
  DEFB $CF,$06

; Message at F8F5
  DEFM "PIERD"

; Data block at F8FA
  DEFB $C5,$04

; Message at F8FC
  DEFM "MAN"

; Data block at F8FF
  DEFB $CF,$09

; Message at F901
  DEFM "PERMANEC"

; Data block at F909
  DEFB $C5,$05

; Message at F90B
  DEFM "CERC"

; Data block at F90F
  DEFB $C1,$0A

; Message at F911
  DEFM "\"QSPIJCJE"

; Data block at F91A
  DEFB $D0,$02,$46,$CD,$04

; Message at F91F
  DEFM "QBT"

; Data block at F922
  DEFB $D0,$03,$44,$50,$CF,$06

; Message at F928
  DEFM "BSNBT"

; Data block at F92D
  DEFB $A2,$0A

; Message at F92F
  DEFM "MOVIMIENT"

; Data block at F938
  DEFB $CF,$07

; Message at F93A
  DEFM "BLOQUE"

; Data block at F940
  DEFB $C1,$03,$53,$49,$CE,$07

; Message at F946
  DEFM "PALABR"

; Data block at F94C
  DEFB $C1,$08

; Message at F94E
  DEFM "EXTIEND"

; Data block at F955
  DEFB $C5,$04

; Message at F957
  DEFM "DED"

; Data block at F95A
  DEFB $CF,$06

; Message at F95C
  DEFM "INDIC"

; Data block at F961
  DEFB $C5,$07

; Message at F963
  DEFM "GUARDI"

; Data block at F969
  DEFB $C1,$04

; Message at F96B
  DEFM "PON"

; Data block at F96E
  DEFB $C5,$05

; Message at F970
  DEFM "OTRA"

; Data block at F974
  DEFB $D3,$02,$48,$C1,$09

; Message at F979
  DEFM "REQUISAD"

; Data block at F981
  DEFB $CF,$05

; Message at F983
  DEFM "PASA"

; Data block at F987
  DEFB $D2,$05

; Message at F989
  DEFM "PODE"

; Data block at F98D
  DEFB $D2,$07

; Message at F98F
  DEFM "APRETA"

; Data block at F995
  DEFB $D2,$07

; Message at F997
  DEFM "GATILL"

; Data block at F99D
  DEFB $CF,$06

; Message at F99F
  DEFM "EXTRA"

; Data block at F9A4
  DEFB $C5,$05

; Message at F9A6
  DEFM "FUEG"

; Data block at F9AA
  DEFB $CF,$03,$48,$41,$DA,$07

; Message at F9B0
  DEFM "ENERGI"

; Data block at F9B6
  DEFB $C1,$07

; Message at F9B8
  DEFM "PERFOR"

; Data block at F9BE
  DEFB $C1,$05

; Message at F9C0
  DEFM "PECH"

; Data block at F9C4
  DEFB $CF,$04

; Message at F9C6
  DEFM "DEB"

; Data block at F9C9
  DEFB $C5,$05

; Message at F9CB
  DEFM "CAMP"

; Data block at F9CF
  DEFB $CF,$09

; Message at F9D1
  DEFM "DEFLECTO"

; Data block at F9D9
  DEFB $D2,$05

; Message at F9DB
  DEFM "TIPO"

; Data block at F9DF
  DEFB $D3,$0B

; Message at F9E1
  DEFM "RAPIDAMENT"

; Data block at F9EB
  DEFB $C5,$02,$44,$C1,$06

; Message at F9F0
  DEFM "ALARM"

; Data block at F9F5
  DEFB $C1,$05

; Message at F9F7
  DEFM "TIRO"

; Data block at F9FB
  DEFB $D3,$09

; Message at F9FD
  DEFM "TERMINAD"

; Data block at FA05
  DEFB $CF,$05

; Message at FA07
  DEFM "HUND"

; Data block at FA0B
  DEFB $C5,$04

; Message at FA0D
  DEFM "SAL"

; Data block at FA10
  DEFB $C1,$08

; Message at FA12
  DEFM "PENUMBR"

; Data block at FA19
  DEFB $C1,$05

; Message at FA1B
  DEFM "DOND"

; Data block at FA1F
  DEFB $C5,$06

; Message at FA21
  DEFM "DEBIA"

; Data block at FA26
  DEFB $CE,$0A

; Message at FA28
  DEFM "CELEBRARS"

; Data block at FA31
  DEFB $C5,$05

; Message at FA33
  DEFM "RITO"

; Data block at FA37
  DEFB $D3,$08

; Message at FA39
  DEFM "PEDESTA"

; Data block at FA40
  DEFB $CC,$07

; Message at FA42
  DEFM "ARGOLL"

; Data block at FA48
  DEFB $C1,$06

; Message at FA4A
  DEFM "ANILL"

; Data block at FA4F
  DEFB $C1,$05

; Message at FA51
  DEFM "PLAT"

; Data block at FA55
  DEFB $C1,$0A

; Message at FA57
  DEFM "ENCASTRAD"

; Data block at FA60
  DEFB $C1,$04

; Message at FA62
  DEFM "LOS"

; Data block at FA65
  DEFB $C1,$0E

; Message at FA67
  DEFM "INDESCIFRABLE"

; Data block at FA74
  DEFB $D3,$06

; Message at FA76
  DEFM "PULID"

; Data block at FA7B
  DEFB $C1,$04

; Message at FA7D
  DEFM "ROC"

; Data block at FA80
  DEFB $C1,$0C

; Message at FA82
  DEFM "JEROGLIFICO"

; Data block at FA8D
  DEFB $D3,$08

; Message at FA8F
  DEFM "GRABADO"

; Data block at FA96
  DEFB $D3,$07

; Message at FA98
  DEFM "COSTAD"

; Data block at FA9E
  DEFB $CF,$05

; Message at FAA0
  DEFM "HUEC"

; Data block at FAA4
  DEFB $CF,$03,$41,$52,$CF,$05

; Message at FAAA
  DEFM "ALTA"

; Data block at FAAE
  DEFB $D2,$07

; Message at FAB0
  DEFM "AGUJER"

; Data block at FAB6
  DEFB $CF,$06

; Message at FAB8
  DEFM "FRASC"

; Data block at FABD
  DEFB $CF,$08

; Message at FABF
  DEFM "CERAMIC"

; Data block at FAC6
  DEFB $C1,$07

; Message at FAC8
  DEFM "(VACIO"

; Data block at FACE
  DEFB $A9,$05

; Message at FAD0
  DEFM "TARR"

; Data block at FAD4
  DEFB $CF,$04

; Message at FAD6
  DEFM "BOT"

; Data block at FAD9
  DEFB $C5,$0A

; Message at FADB
  DEFM "TRASLUCID"

; Data block at FAE4
  DEFB $C1,$07

; Message at FAE6
  DEFM "LIQUID"

; Data block at FAEC
  DEFB $CF,$0B

; Message at FAEE
  DEFM "AMARILLENT"

; Data block at FAF8
  DEFB $CF,$05

; Message at FAFA
  DEFM "VACI"

; Data block at FAFE
  DEFB $CF,$06

; Message at FB00
  DEFM "TAPAD"

; Data block at FB05
  DEFB $CF,$0B

; Message at FB07
  DEFM "NAUSEABUND"

; Data block at FB11
  DEFB $CF,$04

; Message at FB13
  DEFM "OLO"

; Data block at FB16
  DEFB $D2,$07

; Message at FB18
  DEFM "EXPAND"

; Data block at FB1E
  DEFB $C5,$04

; Message at FB20
  DEFM "AIR"

; Data block at FB23
  DEFB $C5,$03,$42,$4F,$D4,$05

; Message at FB29
  DEFM "FRAS"

; Data block at FB2D
  DEFB $C3,$04

; Message at FB2F
  DEFM "TAR"

; Data block at FB32
  DEFB $D2,$06

; Message at FB34
  DEFM "ALGUN"

; Data block at FB39
  DEFB $C1,$08

; Message at FB3B
  DEFM "REACCIO"

; Data block at FB42
  DEFB $CE,$07

; Message at FB44
  DEFM "QUIMIC"

; Data block at FB4A
  DEFB $C1,$08

; Message at FB4C
  DEFM "DISUELV"

; Data block at FB53
  DEFB $C5,$07

; Message at FB55
  DEFM "MOVERS"

; Data block at FB5B
  DEFB $C5,$09

; Message at FB5D
  DEFM "INFESTAD"

; Data block at FB65
  DEFB $CF,$05

; Message at FB67
  DEFM "PECE"

; Data block at FB6B
  DEFB $D3,$0A

; Message at FB6D
  DEFM "CARNIVORO"

; Data block at FB76
  DEFB $D3,$07

; Message at FB78
  DEFM "MINUTO"

; Data block at FB7E
  DEFB $D3,$07

; Message at FB80
  DEFM "QUEDAR"

; Data block at FB86
  DEFB $C1,$06

; Message at FB88
  DEFM "HUESO"

; Data block at FB8D
  DEFB $D3,$07

; Message at FB8F
  DEFM "ABRIRL"

; Data block at FB95
  DEFB $CF,$06

; Message at FB97
  DEFM "MEZCL"

; Data block at FB9C
  DEFB $C1,$05

; Message at FB9E
  DEFM "HUEL"

; Data block at FBA2
  DEFB $C5,$06

; Message at FBA4
  DEFM "FIJAD"

; Data block at FBA9
  DEFB $C1,$09

; Message at FBAB
  DEFM "BASALTIC"

; Data block at FBB3
  DEFB $C1,$03,$43,$41,$C5,$05

; Message at FBB9
  DEFM "SUEL"

; Data block at FBBD
  DEFB $CF,$05

; Message at FBBF
  DEFM "LLEN"

; Data block at FBC3
  DEFB $CF,$07

; Message at FBC5
  DEFM "PLAGAD"

; Data block at FBCB
  DEFB $CF,$06

; Message at FBCD
  DEFM "HUMAN"

; Data block at FBD2
  DEFB $CF,$04

; Message at FBD4
  DEFM "SAC"

; Data block at FBD7
  DEFB $C1,$08

; Message at FBD9
  DEFM "ENVUELV"

; Data block at FBE0
  DEFB $C5,$07

; Message at FBE2
  DEFM "INSECT"

; Data block at FBE8
  DEFB $CF,$02,$4C,$C5,$04

; Message at FBED
  DEFM "PAS"

; Data block at FBF0
  DEFB $C1,$07

; Message at FBF2
  DEFM "AAARGH"

; Data block at FBF8
  DEFB $C8,$04

; Message at FBFA
  DEFM "TIR"

; Data block at FBFD
  DEFB $CF,$05

; Message at FBFF
  DEFM "LOGR"

; Data block at FC03
  DEFB $CF,$06

; Message at FC05
  DEFM "QUIER"

; Data block at FC0A
  DEFB $CF,$07

; Message at FC0C
  DEFM "TERMIN"

; Data block at FC12
  DEFB $C1,$07

; Message at FC14
  DEFM "PRIMER"

; Data block at FC1A
  DEFB $C1,$04

; Message at FC1C
  DEFM "***"

; Data block at FC1F
  DEFB $AA,$09

; Message at FC21
  DEFM "PARTE***"

; Data block at FC29
  DEFB $AA,$0A

; Message at FC2B
  DEFM "DESCONECT"

; Data block at FC34
  DEFB $C1,$09

; Message at FC36
  DEFM "ORDENADO"

; Data block at FC3E
  DEFB $D2,$07

; Message at FC40
  DEFM "SEGUND"

; Data block at FC46
  DEFB $C1,$05

; Message at FC48
  DEFM "CLAV"

; Data block at FC4C
  DEFB $C5,$06

; Message at FC4E
  DEFM "REBEC"

; Data block at FC53
  DEFB $C1,$0A

; Message at FC55
  DEFM "(SIMPATIC"

; Data block at FC5E
  DEFB $CF,$1B

; Message at FC60
  DEFM "FIN/DE/LA/PRIMERA/PARTE***"

; Data block at FC7A
  DEFB $AA,$1F

; Message at FC7C
  DEFM "****FIN/DE/LA/PRIMERA/PARTE***"

; Data block at FC9A
  DEFB $AA,$04

; Message at FC9C
  DEFM "DAL"

; Data block at FC9F
  DEFB $C5,$03,$4C,$45,$C5,$07

; Message at FCA5
  DEFM "DESTAP"

; Data block at FCAB
  DEFB $C1,$05

; Message at FCAD
  DEFM "PONG"

; Data block at FCB1
  DEFB $CF,$05

; Message at FCB3
  DEFM "NADA"

; Data block at FCB7
  DEFB $CE,$0B

; Message at FCB9
  DEFM "DESAPARECE"

; Data block at FCC3
  DEFB $CE,$07

; Message at FCC5
  DEFM "DINAMI"

; Data block at FCCB
  DEFB $C3,$08

; Message at FCCD
  DEFM "SOFTWAR"

; Data block at FCD4
  DEFB $C5,$09

; Message at FCD6
  DEFM "DSFEHUPT"

; Data block at FCDE
  DEFB $A2,$6E,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $00,$18,$18,$18,$18,$18,$00,$18
  DEFB $00,$36,$36,$00,$00,$00,$00,$00
  DEFB $00,$00,$24,$7E,$24,$24,$7E,$24
  DEFB $00,$08,$7F,$48,$7F,$09,$7F,$08
  DEFB $00,$00,$62,$64,$08,$10,$26,$46
  DEFB $00,$10,$28,$10

; Message at FD32
  DEFM "(EB="

; Data block at FD36
  DEFB $00,$18,$18,$10,$00,$00,$00,$00
  DEFB $00,$0C,$18,$18,$18,$18,$18,$0C
  DEFB $00,$18,$0C,$0C,$0C,$0C,$0C,$18
  DEFB $00,$00,$18,$7E,$3C,$7E,$18,$00
  DEFB $00,$0C,$0C,$3F,$3F,$0C,$0C,$00
  DEFB $00,$00,$00,$00,$00,$00,$18,$18
  DEFB $08,$00,$00,$3F,$3F,$00,$00,$00
  DEFB $00,$00,$00,$00,$00,$1C,$1C,$1C
  DEFB $00,$00,$00,$02,$04,$08,$10,$20
  DEFB $00,$3E,$7F

; Message at FD81
  DEFM "gks"

; Data block at FD84
  DEFB $7F,$3E,$00,$1C,$1C,$0C,$0C,$0C
  DEFB $3E,$3E,$00,$7E,$7F,$07,$1E,$38
  DEFB $7F,$7F,$00,$7E,$7F,$03,$7E,$03
  DEFB $7F,$7E,$00,$60,$66,$66,$7F,$7F
  DEFB $06,$06,$00,$7F,$7F,$60,$7E,$03
  DEFB $7F,$7E,$00,$3E,$7E,$60,$7E,$63
  DEFB $7F,$3E,$00,$7F,$7F,$07,$0E,$1C
  DEFB $38,$30,$00,$3E,$7F

; Message at FDC1
  DEFM "c>c"

; Data block at FDC4
  DEFB $7F,$3E,$00,$3E,$7F,$63,$3F,$03
  DEFB $3F,$3E,$00,$00,$00,$18,$18,$00
  DEFB $18,$18,$00,$00,$18,$18,$00,$18
  DEFB $18,$08,$00,$04,$0C,$1C,$3C,$1C
  DEFB $0C,$04,$00,$00,$7E,$7E,$00,$7E
  DEFB $7E,$00,$00

; Message at FDEF
  DEFM " 08<80 "

; Data block at FDF6
  DEFB $00,$7E,$7F,$03,$3F,$3E,$00,$30
  DEFB $30,$00

; Message at FE00
  DEFM ".TtTT"

; Data block at FE05
  DEFB $00,$00,$3E,$7F,$63,$7F,$7F,$63
  DEFB $63,$00,$7E,$7F,$03,$7E,$63,$7F
  DEFB $7E,$00,$3F,$7F,$60,$60,$60,$7F
  DEFB $3F,$00,$7E,$7F

; Message at FE21
  DEFM "ccc"

; Data block at FE24
  DEFB $7F,$7E,$00,$7F,$7F,$00,$7E,$60
  DEFB $7F,$3F,$00,$7F,$7F,$00,$7E,$60
  DEFB $60,$60,$00,$3F,$7F,$60,$6F,$63
  DEFB $7F,$3F,$00,$63,$63,$7B,$7B

; Message at FE43
  DEFM "ccc"

; Data block at FE46
  DEFB $00,$1C,$1C,$00,$1C,$1C,$1C,$1C
  DEFB $00,$7F,$7F,$00,$03,$03,$7F,$7E
  DEFB $00,$63,$67,$7E,$7C

; Message at FE5B
  DEFM "ngc"

; Data block at FE5E
  DEFB $00,$60,$60,$60,$60,$60,$7F,$7F
  DEFB $00,$7E,$7F

; Message at FE69
  DEFM "ckkkk"

; Data block at FE6E
  DEFB $00,$7E,$7F

; Message at FE71
  DEFM "ccccc"

; Data block at FE76
  DEFB $00,$3E,$7F

; Message at FE79
  DEFM "ccc"

; Data block at FE7C
  DEFB $7F,$3E,$00,$7E,$7F,$03,$7F,$7E
  DEFB $60,$60,$00,$3E,$7F

; Message at FE89
  DEFM "ccm"

; Data block at FE8C
  DEFB $7E,$3F,$03,$7E,$7F,$03,$7F,$7E
  DEFB $67,$63,$00,$38,$38,$1C,$0E,$07
  DEFB $7F,$7E,$00,$7F,$7F,$00,$60,$60
  DEFB $7F,$3F,$00

; Message at FEA7
  DEFM "ccccc"

; Data block at FEAC
  DEFB $7F,$3F,$00

; Message at FEAF
  DEFM "cccw>"

; Data block at FEB4
  DEFB $1C,$08,$00

; Message at FEB7
  DEFM "kkkkk"

; Data block at FEBC
  DEFB $7F,$3E,$00

; Message at FEBF
  DEFM "cw>"

; Data block at FEC2
  DEFB $1C

; Message at FEC3
  DEFM ">wc"

; Data block at FEC6
  DEFB $00,$63,$63,$7F,$3F,$03,$7F,$7E
  DEFB $00,$7F,$7F,$0E,$1C,$38,$7F,$7F
  DEFB $00,$00,$0E,$08,$08,$08,$08,$0E
  DEFB $00,$00,$00,$40,$20,$10,$08,$04
  DEFB $00,$00,$70,$10,$10,$10,$10,$70
  DEFB $00,$18,$3C,$7E,$18,$18,$18,$18
  DEFB $00,$00,$00,$00,$00,$00,$00,$00
  DEFB $FF,$00,$1C

; Message at FF01
  DEFM "\"x  "

; Data block at FF05
  DEFB $7E,$00,$00,$00,$3E,$63,$7F,$63
  DEFB $63,$00,$00,$00,$7E,$03,$7E,$63
  DEFB $7E,$00,$00,$00,$3F,$60,$60,$60
  DEFB $3F,$00,$00,$00,$7E

; Message at FF22
  DEFM "ccc"

; Data block at FF25
  DEFB $7E,$00,$00,$00,$7F,$00,$7E,$60
  DEFB $3F,$00,$00,$00,$7F,$00,$7E,$60
  DEFB $60,$00,$00,$00,$3F,$60

; Message at FF3B
  DEFM "gc?"

; Data block at FF3E
  DEFB $00,$00,$00,$63,$63,$7B,$63,$63
  DEFB $00,$00,$00,$18,$00,$18,$18,$18
  DEFB $00,$00,$00,$7F,$00,$06,$06,$7C
  DEFB $00,$00,$00,$63,$66,$7C,$66,$63
  DEFB $00,$00,$00,$60,$60,$60,$60,$7F
  DEFB $00,$00,$00,$7E

; Message at FF6A
  DEFM "ckkk"

; Data block at FF6E
  DEFB $00,$00,$00,$7E

; Message at FF72
  DEFM "cccc"

; Unused
  DEFS $03

; Message at FF79
  DEFM ">ccc>"

; Data block at FF7E
  DEFB $00,$00,$00,$7E,$03,$7E,$60,$60
  DEFB $00,$00,$00

; Message at FF89
  DEFM ">ccm6"

; Data block at FF8E
  DEFB $03,$00,$00,$7E,$03,$7E,$67,$63
  DEFB $00,$00,$00,$1C,$0C,$06,$03,$7E
  DEFB $00,$00,$00,$7F,$00,$30,$30,$1F
  DEFB $00,$00,$00

; Message at FFA9
  DEFM "cccc?"

; Unused
  DEFS $03

; Message at FFB1
  DEFM "cc6"

; Data block at FFB4
  DEFB $1C,$08,$00,$00,$00

; Message at FFB9
  DEFM "ckkk6"

; Data block at FFBE
  DEFB $00,$00,$00,$63,$36,$1C,$36,$63
  DEFB $00,$00,$00

; Message at FFC9
  DEFM "cc?"

; Data block at FFCC
  DEFB $03,$7E,$00,$00,$00,$7F,$0E,$1C
  DEFB $38,$7F,$00,$00,$0E,$08,$30,$08
  DEFB $08,$0E,$00,$00,$08,$08,$DB,$02
  DEFB $4D,$00,$C8,$3E,$00,$00,$28,$50
  DEFB $5C,$08,$CE,$0B,$2F,$50,$06,$03
  DEFB $CE,$0B,$DB,$02,$4D,$00,$FF,$FF
  DEFB $0E,$01,$00,$00

