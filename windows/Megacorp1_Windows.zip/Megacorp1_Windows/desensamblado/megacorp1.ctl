@ $5C00 start
@ $5C00 org
b $5C00
t $5CD0
b $5CD6
t $5CD7
b $5CDC
t $5CE2
b $5CE6
t $5CEF
b $5CF4
t $5D04
b $5D0A
t $5D20
b $5D25
t $5DA8
b $5DAC
t $5DC0
b $5DCE
t $5E18
b $5E1B
t $5E1C
b $5E5A
t $5E5B
b $5F15
c $6318
  $6318 Jump to #R29015
b $631B
c $631E
  $631E Jump to #R28277
c $6321
  $6321 Jump to #R28982
c $6324
  $6324 Jump to #R29126
c $6327
  $6327 Jump to #R29098
b $632A
c $6330
  $6330 Jump to #R29007
c $6333
  $6333 Jump to #R29076
c $6336
  $6336 Jump to #R26818
b $6339
c $6364
  $6364 #REGhl=#N(0,4,,1)($)
  $6367 Jump to #R25457
c $6369
  $6369 #REGhl=#N(65450,4,,1)($)
  $636C Jump to #R25457
c $636E
  $636E #REGhl=#N(255,4,,1)($)
  $6371 POKE #N(25411,4,,1)($),#REGl; POKE #N(25412,4,,1)($),#REGh
  $6374 #REGe=PEEK #N(25409,4,,1)($); #REGd=PEEK #N(25410,4,,1)($)
  $6378 Push #REGde onto the stack
  $6379 CALL #R25817
  $637C Pop last item from stack into #REGbc
  $637D Return if the zero flag is not set
  $637E Push #REGbc onto the stack
  $637F Jump to #R25480
c $6381
  $6381 Push #REGde onto the stack
  $6382 CALL #R25817
  $6385 Pop last item from stack into #REGbc
  $6386 Jump to #R25491 if the zero flag is not set
  $6388 Push #REGbc onto the stack
  $6389 CALL #R25509
  $638C Pop last item from stack into #REGde
  $638D #REGd=#REGd+1
  $638E #REGa=#REGd
  $638F Set the zero flag if #REGa=#N(176,2,,1)($), or the carry flag if #REGa<#N(176,2,,1)($)
  $6391 Jump to #R25473 if #REGa<#N(176,2,,1)($)
  $6393 Pop last item from stack into #REGde
  $6394 #REGd=#REGd-1
  $6395 #REGa=#REGd
  $6396 Set the zero flag if #REGa=#N(48,2,,1)($), or the carry flag if #REGa<#N(48,2,,1)($)
  $6398 Return if #REGa<#N(48,2,,1)($)
  $6399 Push #REGde onto the stack
  $639A CALL #R25817
  $639D Pop last item from stack into #REGbc
  $639E Return if the zero flag is not set
  $639F Push #REGbc onto the stack
  $63A0 CALL #R25509
  $63A3 Jump to #R25491
c $63A5
  $63A5 Push #REGbc onto the stack
  $63A6 #REGl=PEEK #N(25411,4,,1)($); #REGh=PEEK #N(25412,4,,1)($)
  $63A9 #REGa=#REGl
  $63AA Set the zero flag if bit 0 of #REGb is 0
  $63AC Jump to #R25519 if bit 0 of #REGb is reset
  $63AE #REGa=#REGa^#REGh
  $63AF POKE #N(25413,4,,1)($),#REGa
  $63B2 #REGc=#REGc-1
  $63B3 #REGa=#REGc
  $63B4 #REGa=#REGa+1
  $63B5 CALL #R25567 if #REGa>0
  $63B8 Pop last item from stack into #REGbc
  $63B9 Jump to #R25532
  $63BC CALL #R25835
  $63BF #REGb=#REGa
  $63C0 #REGa=0
  $63C1 #REGb=#REGb+1
  $63C2 Set the carry flag
  $63C3 Rotate #REGa left through the carry flag
  $63C4 Decrement #REGb and jump to #R25539 if #REGb>0
  $63C6 #REGb=#REGa
  $63C7 CALL #R25637
  $63CA Set the zero flag if bit 0 of #REGc is 0
  $63CC Return if bit 0 of #REGc is reset
  $63CD #REGhl=#REGhl+1
  $63CE #REGa=#REGl
  $63CF Reset bits 5, 6 and 7 of #REGa
  $63D1 Return if #REGa=0
  $63D2 #REGa=PEEK #REGhl
  $63D3 Clear the carry flag and set the zero flag if #REGa=0
  $63D4 Jump to #R25635 if #REGa>0
  $63D6 #REGa=PEEK #N(25413,4,,1)($)
  $63D9 POKE #REGhl,#REGa
  $63DA CALL #R25652
  $63DD Jump to #R25549
c $63DF
  $63DF CALL #R25835
  $63E2 #REGb=#REGa
  $63E3 #REGa=0
  $63E4 #REGb=#REGb+1
  $63E5 Set the carry flag
  $63E6 Rotate #REGa left through the carry flag
  $63E7 Decrement #REGb and jump to #R25574 if #REGb>0
  $63E9 #REGb=#REGa
  $63EA CALL #R25606
  $63ED Set the zero flag if bit 7 of #REGc is 0
  $63EF Return if bit 7 of #REGc is reset
  $63F0 #REGhl=#REGhl-1
  $63F1 #REGa=#REGl
  $63F2 Reset bits 5, 6 and 7 of #REGa
  $63F4 Set the zero flag if #REGa=#N(31,2,,1)($), or the carry flag if #REGa<#N(31,2,,1)($)
  $63F6 Return if #REGa=#N(31,2,,1)($)
  $63F7 #REGa=PEEK #REGhl
  $63F8 Clear the carry flag and set the zero flag if #REGa=0
  $63F9 Jump to #R25604 if #REGa>0
  $63FB #REGa=PEEK #N(25413,4,,1)($)
  $63FE POKE #REGhl,#REGa
  $63FF CALL #R25652
  $6402 Jump to #R25584
  $6404 #REGb=#N(1,2,,1)($)
  $6406 #REGc=#N(0,2,,1)($)
  $6408 #REGa=#REGb
  $6409 #REGa=#REGa&PEEK #REGhl
  $640A Jump to #R25619 if #REGa>0
  $640C #REGa=#REGb
  $640D #REGa=#REGa|#REGc
  $640E #REGc=#REGa
  $640F Shift #REGb left (copying bit 7 into the carry flag, and resetting bit 0)
  $6411 Jump to #R25608 if the carry flag is not set
  $6413 #REGa=PEEK #N(25413,4,,1)($)
  $6416 #REGa=#REGa&#REGc
  $6417 #REGb=#REGa
  $6418 #REGa=#REGc
  $6419 #REGa=#N($FF,2,,1)($)-#REGa
  $641A #REGa=#REGa&PEEK #REGhl
  $641B #REGa=#REGa|#REGb
  $641C POKE #REGhl,#REGa
  $641D #REGa=#REGc
  $641E Clear the carry flag and set the zero flag if #REGa=0
  $641F CALL #R25652 if #REGa>0
  $6422 Return
c $6423
  $6423 #REGb=#N(128,2,,1)($)
  $6425 #REGc=#N(0,2,,1)($)
  $6427 #REGa=#REGb
  $6428 #REGa=#REGa&PEEK #REGhl
  $6429 Jump to #R25619 if #REGa>0
  $642B #REGa=#REGb
  $642C #REGa=#REGa|#REGc
  $642D #REGc=#REGa
  $642E Shift #REGb right (copying bit 0 into the carry flag, and resetting bit 7)
  $6430 Jump to #R25619 if the carry flag is set
  $6432 Jump to #R25639
c $6434
  $6434 Push #REGhl onto the stack
  $6435 Push #REGbc onto the stack
  $6436 CALL #R25792
  $6439 Pop last item from stack into #REGbc
  $643A Pop last item from stack into #REGhl
  $643B Return
c $643C
  $643C Set the zero flag if bit 7 of #REGd is 0
  $643E Jump to #R25673 if bit 7 of #REGd is set
  $6440 #REGa=#REGd
  $6441 Clear the carry flag and set the zero flag if #REGa=0
  $6442 Jump to #R25676 if #REGa=0
  $6444 #REGde=#N(255,4,,1)($)
  $6447 Jump to #R25676
  $6449 #REGde=#N(0,4,,1)($)
  $644C Set the zero flag if bit 7 of #REGh is 0
  $644E Jump to #R25698 if bit 7 of #REGh is set
  $6450 #REGa=#REGh
  $6451 Clear the carry flag and set the zero flag if #REGa=0
  $6452 Jump to #R25689 if #REGa=0
  $6454 #REGhl=#N(175,4,,1)($)
  $6457 Jump to #R25701
  $6459 #REGa=#REGl
  $645A Set the zero flag if #REGa=#N(176,2,,1)($), or the carry flag if #REGa<#N(176,2,,1)($)
  $645C Jump to #R25684 if #REGa>=#N(176,2,,1)($)
  $645E Set the zero flag if #REGa=#N(48,2,,1)($), or the carry flag if #REGa<#N(48,2,,1)($)
  $6460 Jump to #R25701 if #REGa>=#N(48,2,,1)($)
  $6462 #REGhl=#N(48,4,,1)($)
  $6465 #REGc=PEEK #N(23677,4,,1)($); #REGb=PEEK #N(23678,4,,1)($)
  $6469 Push #REGbc onto the stack
  $646A #REGa=#REGe
  $646B #REGa=#REGa-#REGc
  $646C #REGe=#N(1,2,,1)($)
  $646E Jump to #R25717 if the zero flag is set
  $6470 Jump to #R25718 if the carry flag is not set
  $6472 #REGa=#N(256,2,,1)($)-#REGa
  $6474 #REGe=#REGe-1
  $6475 #REGe=#REGe-1
  $6476 #REGc=#REGa
  $6477 #REGa=#REGl
  $6478 #REGa=#REGa-#REGb
  $6479 #REGd=#N(1,2,,1)($)
  $647B Jump to #R25730 if the zero flag is set
  $647D Jump to #R25731 if the carry flag is not set
  $647F #REGa=#N(256,2,,1)($)-#REGa
  $6481 #REGd=#REGd-1
  $6482 #REGd=#REGd-1
  $6483 #REGb=#REGa
  $6484 CALL #R9402
  $6487 Pop last item from stack into #REGbc
  $6488 Jump to #R25759
c $648A
  $648A #REGl=PEEK #N(25407,4,,1)($); #REGh=PEEK #N(25408,4,,1)($)
  $648D POKE #N(23677,4,,1)($),#REGl; POKE #N(23678,4,,1)($),#REGh
  $6490 #REGl=PEEK #N(25409,4,,1)($); #REGh=PEEK #N(25410,4,,1)($)
  $6493 #REGa=0
  $6494 #REGd=#REGa
  $6495 #REGe=#REGl
  $6496 #REGl=#REGh
  $6497 #REGh=#REGa
  $6498 Jump to #R25660
c $649B
  $649B #REGc=PEEK #N(25409,4,,1)($); #REGb=PEEK #N(25410,4,,1)($)
  $649F #REGl=PEEK #N(23693,4,,1)($); #REGh=PEEK #N(23694,4,,1)($)
  $64A2 POKE #N(23695,4,,1)($),#REGl; POKE #N(23696,4,,1)($),#REGh
  $64A5 Jump to #R8933
c $64A8
  $64A8 #REGhl=#N(22528,4,,1)($)
  $64AB #REGde=#N(41469,4,,1)($)
  $64AE #REGbc=#N(512,4,,1)($)
  $64B1 POKE #REGde,PEEK #REGhl; #REGhl=#REGhl+1; #REGde=#REGde+1; #REGbc=#REGbc-1; repeat until #REGbc=0
  $64B3 Return
b $64B4
c $64C0
  $64C0 #REGa=#REGh
  $64C1 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $64C2 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $64C3 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $64C4 Keep only bits 0 and 1 of #REGa
  $64C6 #REGa=#REGa+#N(88,2,,1)($)
  $64C8 #REGh=#REGa
  $64C9 #REGa=PEEK #N(23694,4,,1)($)
  $64CC #REGb=#REGa
  $64CD #REGa=#N($FF,2,,1)($)-#REGa
  $64CE #REGc=#REGa
  $64CF #REGa=PEEK #N(23693,4,,1)($)
  $64D2 #REGa=#REGa&#REGc
  $64D3 #REGc=#REGa
  $64D4 #REGa=#REGb
  $64D5 #REGa=#REGa&PEEK #REGhl
  $64D6 #REGa=#REGa|#REGc
  $64D7 POKE #REGhl,#REGa
  $64D8 Return
c $64D9
  $64D9 #REGa=#N(175,2,,1)($)
  $64DB #REGa=#REGa-#REGd
  $64DC #REGc=#REGe
  $64DD CALL #R25838
  $64E0 Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $64E1 Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $64E2 Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $64E3 #REGa=#REGa+#N(70,2,,1)($)
  $64E5 POKE #N(25833,4,,1)($),#REGa
  $64E8 Set the zero flag if bit 5 of (#REGhl) is 0
  $64EA Return
c $64EB
  $64EB #REGa=#N(175,2,,1)($)
  $64ED #REGa=#REGa-#REGb
  $64EE CALL #R8880
  $64F1 #REGa=#REGa-#N(7,2,,1)($)
  $64F3 #REGa=#N(256,2,,1)($)-#REGa
  $64F5 Clear the carry flag and set the zero flag if #REGa=0
  $64F6 Return
c $64F7
  $64F7 #REGe=PEEK #N(25407,4,,1)($); #REGd=PEEK #N(25408,4,,1)($)
  $64FB #REGl=PEEK #N(25409,4,,1)($); #REGh=PEEK #N(25410,4,,1)($)
  $64FE Push #REGde onto the stack
  $64FF #REGc=#REGl
  $6500 #REGb=#REGd
  $6501 Push #REGbc onto the stack
  $6502 Push #REGbc onto the stack
  $6503 Push #REGhl onto the stack
  $6504 Push #REGhl onto the stack
  $6505 #REGc=#REGe
  $6506 #REGb=#REGh
  $6507 Push #REGbc onto the stack
  $6508 Push #REGbc onto the stack
  $6509 Push #REGde onto the stack
  $650A #REGb=#N(4,2,,1)($)
  $650C Pop last item from stack into #REGhl
  $650D Pop last item from stack into #REGde
  $650E Push #REGbc onto the stack
  $650F CALL #R25878
  $6512 Pop last item from stack into #REGbc
  $6513 Decrement #REGb and jump to #R25868 if #REGb>0
  $6515 Return
c $6516
  $6516 POKE #N(23677,4,,1)($),#REGe; POKE #N(23678,4,,1)($),#REGd
  $651A Jump to #R25747
b $651D
t $651E
b $6521
t $6522
b $6526
t $652C
b $6532
t $653C
b $653F
t $6556
b $655A
t $6560
b $6563
t $656B
b $656E
t $659D
b $65A1
t $65B1
b $65BD
t $65BE
b $65C3
t $65C7
b $65D5
t $65DC
b $65E4
t $65E8
b $65EC
t $65F1
b $65F5
t $6622
b $6625
t $663A
b $6644
t $6647
b $664A
c $664B
  $664B #REGa=#N(1,2,,1)($)
  $664D CALL #R27378
  $6650 #REGa=#N(15,2,,1)($)
  $6652 POKE #N(23624,4,,1)($),#REGa
  $6655 CALL #R28469
  $6658 #REGa=PEEK #N(25420,4,,1)($)
  $665B #REGa=#REGa+#N(2,2,,1)($)
  $665D POKE #N(28118,4,,1)($),#REGa
  $6660 CALL #R26232
  $6663 POKE #N(28050,4,,1)($),#REGa
  $6666 CALL #R26238
  $6669 POKE #N(28052,4,,1)($),#REGa
  $666C #REGhl=#N(28049,4,,1)($)
  $666F CALL #R26361
  $6672 CALL #R26381
  $6675 Jump to #R26261
c $6678
  $6678 #REGa=PEEK #N(23693,4,,1)($)
  $667B Keep only bits 0, 1 and 2 of #REGa
  $667D Return
c $667E
  $667E #REGa=PEEK #N(23693,4,,1)($)
  $6681 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $6682 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $6683 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $6684 Keep only bits 0, 1 and 2 of #REGa
  $6686 Return
b $6687
t $66A6
b $66AA
t $66AF
b $66B2
t $66C1
b $66C5
t $66D2
b $66E7
t $66EA
b $66F1
c $66F9
  $66F9 #REGa=PEEK #REGhl
  $66FA Set the zero flag if #REGa=#N(255,2,,1)($), or the carry flag if #REGa<#N(255,2,,1)($)
  $66FC Return if #REGa=#N(255,2,,1)($)
  $66FD Set the zero flag if #REGa=#N(10,2,,1)($), or the carry flag if #REGa<#N(10,2,,1)($)
  $66FF Jump to #R26374 if #REGa<>#N(10,2,,1)($)
  $6701 CALL #R28277
  $6704 Jump to #R26377
  $6706 CALL #R28842
  $6709 #REGhl=#REGhl+1
  $670A Jump to #R26361
b $670C
t $6717
b $671A
t $6737
b $673A
t $673C
b $6740
t $6755
b $6759
c $675D
  $675D #REGl=#N(56,2,,1)($)
  $675F #REGh=#N(0,2,,1)($)
  $6761 POKE #N(23693,4,,1)($),#REGl; POKE #N(23694,4,,1)($),#REGh
  $6764 POKE #N(23695,4,,1)($),#REGl; POKE #N(23696,4,,1)($),#REGh
  $6767 #REGhl=#N(23697,4,,1)($)
  $676A Reset bit 0 of (#REGhl)
  $676C Reset bit 2 of (#REGhl)
  $676E #REGhl=#N(28800,4,,1)($)
  $6771 POKE #N(25407,4,,1)($),#REGl; POKE #N(25408,4,,1)($),#REGh
  $6774 POKE #N(25409,4,,1)($),#REGl; POKE #N(25410,4,,1)($),#REGh
  $6777 #REGa=0
  $6778 Jump to #R29086
b $677B
t $678B
b $6790
t $67A2
b $67A5
t $67A7
b $67AB
t $67BF
b $67C2
t $67CF
b $67EC
t $67F0
b $6806
t $6817
b $681A
t $681E
b $6821
t $6831
b $6834
t $683A
b $683D
c $6850
  $6850 #REGixl=PEEK #N(42287,4,,1)($); #REGixh=PEEK #N(42288,4,,1)($)
  $6854 #REGl=PEEK (#REGix+#N(0,2,,1)($))
  $6857 #REGh=PEEK (#REGix+#N(1,2,,1)($))
  $685A #REGa=#REGh
  $685B #REGa=#REGa|#REGl
  $685C Return if #REGa=0
  $685D #REGc=PEEK (#REGix+#N(2,2,,1)($))
  $6860 #REGb=PEEK (#REGix+#N(3,2,,1)($))
  $6863 Clear the carry flag and set the zero flag if #REGa=0
  $6864 #REGhl=#REGhl-carry-#REGde
  $6866 Jump to #R26732 if #REGhl=0
  $6868 #REGix=#REGix+#REGbc
  $686A Jump to #R26708
  $686C #REGa=0
  $686D #REGa=#REGa+1
  $686E Return
b $686F
t $688A
b $688D
t $689F
b $68A3
t $68AF
b $68B2
t $68B8
b $68BB
c $68C2
  $68C2 #REGa=#N(201,2,,1)($)
  $68C4 POKE #N(25768,4,,1)($),#REGa
  $68C7 POKE #N(27560,4,,1)($),#REGa
  $68CA POKE #N(26187,4,,1)($),#REGa
  $68CD CALL #R26461
  $68D0 CALL #R28480
  $68D3 CALL #R27703
  $68D6 CALL #R26461
  $68D9 #REGa=#N(33,2,,1)($)
  $68DB POKE #N(25768,4,,1)($),#REGa
  $68DE #REGa=#N(62,2,,1)($)
  $68E0 POKE #N(27560,4,,1)($),#REGa
  $68E3 POKE #N(26187,4,,1)($),#REGa
  $68E6 Return
b $68E7
t $68F4
b $68F7
t $690B
b $690F
t $693B
b $693E
t $6940
b $6943
t $694D
b $6953
t $6956
b $695A
t $695B
b $6961
t $6962
b $6965
t $6972
b $6975
t $6983
b $6986
t $69AA
b $69B0
t $69D1
b $69D5
t $6A03
s $6A09
t $6A0A
b $6A11
t $6A19
b $6A1C
t $6A1F
b $6A22
t $6A23
b $6A26
t $6A32
b $6A36
t $6A4E
b $6A5F
t $6A63
b $6A76
t $6A7A
b $6A8B
t $6A8F
b $6AA1
t $6AA5
b $6AB9
t $6ABD
b $6AD6
t $6ADD
b $6AE0
t $6AE1
b $6AE4
t $6AE6
b $6AEA
c $6AF2
  $6AF2 #REGhl=#N(25426,4,,1)($)
  $6AF5 #REGd=PEEK #REGhl
  $6AF6 POKE #REGhl,#REGa
  $6AF7 Push #REGde onto the stack
  $6AF8 CALL #R5633
  $6AFB Pop last item from stack into #REGaf
  $6AFC Return
b $6AFD
t $6B14
b $6B17
t $6B30
b $6B33
t $6B3D
b $6B42
t $6B48
s $6B4B
t $6B4C
b $6B53
t $6B58
b $6B5B
t $6B61
b $6B65
t $6B6A
b $6B6D
t $6B6E
b $6B71
t $6B74
b $6B79
t $6B93
b $6B97
t $6B98
b $6B9D
t $6B9E
b $6BA2
c $6BA8
  $6BA8 #REGa=#N(1,2,,1)($)
  $6BAA CALL #R29086
  $6BAD Jump to #R25755
b $6BB0
c $6BC8
  $6BC8 #REGa=#N(1,2,,1)($)
  $6BCA POKE #N(25439,4,,1)($),#REGa
  $6BCD Jump to #R27560
b $6BD0
t $6BD2
b $6BD5
t $6BD8
b $6BDB
t $6BDC
b $6BDF
t $6C0E
b $6C11
t $6C17
b $6C1A
t $6C1B
b $6C21
c $6C37
  $6C37 #REGa=0
  $6C38 CALL #R29086
  $6C3B Push #REGix onto the stack
  $6C3D Pop last item from stack into #REGhl
  $6C3E #REGhl=#REGhl+1
  $6C3F #REGhl=#REGhl+1
  $6C40 #REGhl=#REGhl+1
  $6C41 #REGhl=#REGhl+1
  $6C42 #REGa=PEEK #REGhl
  $6C43 #REGhl=#REGhl+1
  $6C44 Exchange #REGde and #REGhl
  $6C45 #REGl=PEEK #N(25416,4,,1)($); #REGh=PEEK #N(25417,4,,1)($)
  $6C48 Push #REGhl onto the stack
  $6C49 #REGl=PEEK #N(25418,4,,1)($); #REGh=PEEK #N(25419,4,,1)($)
  $6C4C Push #REGhl onto the stack
  $6C4D POKE #N(25417,4,,1)($),#REGa
  $6C50 CALL #R27831
  $6C53 Pop last item from stack into #REGhl
  $6C54 POKE #N(25418,4,,1)($),#REGl; POKE #N(25419,4,,1)($),#REGh
  $6C57 Pop last item from stack into #REGhl
  $6C58 POKE #N(25416,4,,1)($),#REGl; POKE #N(25417,4,,1)($),#REGh
  $6C5B #REGa=#N(7,2,,1)($)
  $6C5D POKE #N(25443,4,,1)($),#REGa
  $6C60 Return
c $6C61
  $6C61 #REGa=#N(201,2,,1)($)
  $6C63 POKE #N(27871,4,,1)($),#REGa
  $6C66 Exchange #REGde and #REGhl
  $6C67 #REGe=PEEK #REGhl
  $6C68 #REGhl=#REGhl+1
  $6C69 #REGd=PEEK #REGhl
  $6C6A #REGhl=#REGhl+1
  $6C6B Push #REGhl onto the stack
  $6C6C #REGa=PEEK #N(25422,4,,1)($)
  $6C6F Push #REGaf onto the stack
  $6C70 CALL #R26704
  $6C73 CALL #R27703 if the zero flag is not set
  $6C76 Pop last item from stack into #REGaf
  $6C77 POKE #N(25422,4,,1)($),#REGa
  $6C7A #REGa=#N(205,2,,1)($)
  $6C7C POKE #N(27871,4,,1)($),#REGa
  $6C7F #REGa=0
  $6C80 CALL #R29086
  $6C83 Pop last item from stack into #REGde
  $6C84 Return
b $6C85
t $6C86
b $6C8B
t $6C9A
b $6C9D
t $6CA3
b $6CA6
t $6CAD
b $6CB0
c $6CB7
  $6CB7 POKE #N(25416,4,,1)($),#REGa
  $6CBA #REGa=#REGa+1
  $6CBB POKE #N(25422,4,,1)($),#REGa
  $6CBE #REGhl=#N(25422,4,,1)($)
  $6CC1 POKE #REGhl,(PEEK #REGhl)-1
  $6CC2 Jump to #R27867 if (PEEK #REGhl)=0
  $6CC4 #REGa=PEEK #REGde
  $6CC5 POKE #N(25443,4,,1)($),#REGa
  $6CC8 #REGde=#REGde+1
  $6CC9 Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $6CCA #REGhl=#N(28009,4,,1)($)
  $6CCD #REGa=#REGa+#REGl
  $6CCE Jump to #R27857 if the carry flag is not set
  $6CD0 #REGh=#REGh+1
  $6CD1 #REGl=#REGa
  $6CD2 #REGa=PEEK #REGhl
  $6CD3 #REGhl=#REGhl+1
  $6CD4 #REGh=PEEK #REGhl
  $6CD5 #REGl=#REGa
  $6CD6 #REGbc=#N(27838,4,,1)($)
  $6CD9 Push #REGbc onto the stack
  $6CDA Jump to #REGhl
  $6CDB POKE #N(25418,4,,1)($),#REGe; POKE #N(25419,4,,1)($),#REGd
  $6CDF CALL #R25768
  $6CE2 CALL #R26187
  $6CE5 Jump to #R27592
c $6CE8
  $6CE8 #REGa=PEEK #REGde
  $6CE9 #REGl=#REGa
  $6CEA #REGde=#REGde+1
  $6CEB #REGa=PEEK #REGde
  $6CEC #REGh=#REGa
  $6CED #REGde=#REGde+1
  $6CEE POKE #N(25407,4,,1)($),#REGl; POKE #N(25408,4,,1)($),#REGh
  $6CF1 #REGa=PEEK #REGde
  $6CF2 #REGl=#REGa
  $6CF3 #REGde=#REGde+1
  $6CF4 #REGa=PEEK #REGde
  $6CF5 #REGh=#REGa
  $6CF6 #REGde=#REGde+1
  $6CF7 POKE #N(25409,4,,1)($),#REGl; POKE #N(25410,4,,1)($),#REGh
  $6CFA Push #REGde onto the stack
  $6CFB CALL #R25444
  $6CFE Pop last item from stack into #REGde
  $6CFF Return
c $6D00
  $6D00 #REGhl=#N(25755,4,,1)($)
  $6D03 POKE #N(27900,4,,1)($),#REGl; POKE #N(27901,4,,1)($),#REGh
  $6D06 Jump to #R27889
b $6D08
c $6D0B
  $6D0B POKE #N(27900,4,,1)($),#REGl; POKE #N(27901,4,,1)($),#REGh
  $6D0E Jump to #R27880
c $6D10
  $6D10 #REGhl=#N(25454,4,,1)($)
  $6D13 Jump to #R27907
c $6D15
  $6D15 #REGhl=#N(25444,4,,1)($)
  $6D18 Jump to #R27907
c $6D1A
  $6D1A #REGhl=#N(25449,4,,1)($)
  $6D1D Jump to #R27907
c $6D1F
  $6D1F #REGhl=#N(25847,4,,1)($)
  $6D22 Jump to #R27915
c $6D24
  $6D24 #REGhl=#N(25738,4,,1)($)
  $6D27 Jump to #R27915
c $6D29
  $6D29 #REGde=#REGde-1
  $6D2A #REGa=PEEK #REGde
  $6D2B CALL #R16
  $6D2C #REGde=#REGde+1
  $6D2D #REGa=PEEK #REGde
  $6D2E CALL #R16
  $6D2F #REGde=#REGde+1
  $6D30 #REGl=PEEK #N(23695,4,,1)($); #REGh=PEEK #N(23696,4,,1)($)
  $6D33 POKE #N(23693,4,,1)($),#REGl; POKE #N(23694,4,,1)($),#REGh
  $6D36 Return
c $6D37
  $6D37 #REGa=PEEK #REGde
  $6D38 #REGde=#REGde+1
  $6D39 Push #REGde onto the stack
  $6D3A Keep only bits 0, 1 and 2 of #REGa
  $6D3C OUT #N(254,2,,1)($),#REGa
  $6D3E #REGb=#N(0,2,,1)($)
  $6D40 Set the zero flag if bit 2 of #REGa is 0
  $6D42 Jump to #R27974 if bit 2 of #REGa is set
  $6D44 #REGb=#N(7,2,,1)($)
  $6D46 Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $6D47 Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $6D48 Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $6D49 #REGa=#REGa|#REGb
  $6D4A POKE #N(23624,4,,1)($),#REGa
  $6D4D #REGhl=#N(23040,4,,1)($)
  $6D50 #REGbc=#N(255,4,,1)($)
  $6D53 #REGd=#REGa
  $6D54 #REGa=PEEK #N(25423,4,,1)($)
  $6D57 #REGa=#REGa-1
  $6D58 Jump to #R28000 if #REGa=0
  $6D5A #REGhl=#N(22528,4,,1)($)
  $6D5D #REGbc=#N(767,4,,1)($)
  $6D60 #REGa=#REGd
  $6D61 #REGd=#REGh
  $6D62 #REGe=#REGl
  $6D63 #REGde=#REGde+1
  $6D64 POKE #REGhl,#REGa
  $6D65 POKE #REGde,PEEK #REGhl; #REGhl=#REGhl+1; #REGde=#REGde+1; #REGbc=#REGbc-1; repeat until #REGbc=0
  $6D67 Pop last item from stack into #REGde
  $6D68 Return
b $6D69
t $6D6A
b $6D6D
t $6D76
b $6D79
t $6D7A
b $6D7D
t $6D88
b $6D91
t $6DB0
b $6DCF
t $6DE3
b $6DE6
t $6DEA
b $6DED
t $6DF0
b $6DF4
t $6DFC
b $6E02
t $6E16
b $6E19
t $6E2C
b $6E2F
c $6E75
  $6E75 Push #REGaf onto the stack
  $6E76 Push #REGbc onto the stack
  $6E77 Push #REGde onto the stack
  $6E78 Push #REGhl onto the stack
  $6E79 Push #REGix onto the stack
  $6E7B #REGhl=#N(28357,4,,1)($)
  $6E7E Push #REGhl onto the stack
  $6E7F #REGl=PEEK #N(25428,4,,1)($); #REGh=PEEK #N(25429,4,,1)($)
  $6E82 #REGde=#N(25430,4,,1)($)
  $6E85 POKE #REGhl,#REGa
  $6E86 Clear the carry flag and set the zero flag if #REGa=0
  $6E87 #REGhl=#REGhl-carry-#REGde
  $6E89 Jump to #R28309 if #REGhl>0
  $6E8B Set the zero flag if #REGa=#N(32,2,,1)($), or the carry flag if #REGa<#N(32,2,,1)($)
  $6E8D Jump to #R28310 if #REGa<#N(32,2,,1)($)
  $6E8F Set the zero flag if #REGa=#N(165,2,,1)($), or the carry flag if #REGa<#N(165,2,,1)($)
  $6E91 Return if #REGa>=#N(165,2,,1)($)
  $6E92 Jump to #R28842
  $6E95 #REGa=PEEK #REGde
  $6E96 #REGb=#REGl
  $6E97 #REGhl=#N(28901,4,,1)($)
  $6E9A Push #REGaf onto the stack
  $6E9B #REGa=PEEK #REGhl
  $6E9C #REGa=#REGa+1
  $6E9D Jump to #R28325 if #REGa>0
  $6E9F Pop last item from stack into #REGaf
  $6EA0 POKE #N(25428,4,,1)($),#REGe; POKE #N(25429,4,,1)($),#REGd
  $6EA4 Return
  $6EA5 Pop last item from stack into #REGaf
  $6EA6 Set the zero flag if #REGa=PEEK #REGhl, or the carry flag if #REGa<PEEK #REGhl
  $6EA7 #REGhl=#REGhl+1
  $6EA8 Jump to #R28335 if the zero flag is set
  $6EAA #REGhl=#REGhl+1
  $6EAB #REGhl=#REGhl+1
  $6EAC #REGhl=#REGhl+1
  $6EAD Jump to #R28314
  $6EAF #REGa=PEEK #REGhl
  $6EB0 Set the zero flag if #REGa=#REGb, or the carry flag if #REGa<#REGb
  $6EB1 Jump to #R28347 if #REGa=#REGb
  $6EB3 #REGl=PEEK #N(25428,4,,1)($); #REGh=PEEK #N(25429,4,,1)($)
  $6EB6 #REGhl=#REGhl+1
  $6EB7 POKE #N(25428,4,,1)($),#REGl; POKE #N(25429,4,,1)($),#REGh
  $6EBA Return
  $6EBB POKE #N(25428,4,,1)($),#REGe; POKE #N(25429,4,,1)($),#REGd
  $6EBF #REGhl=#REGhl+1
  $6EC0 #REGa=PEEK #REGhl
  $6EC1 #REGhl=#REGhl+1
  $6EC2 #REGh=PEEK #REGhl
  $6EC3 #REGl=#REGa
  $6EC4 Jump to #REGhl
c $6EC5
  $6EC5 Pop last item from stack into #REGix
  $6EC7 Pop last item from stack into #REGhl
  $6EC8 Pop last item from stack into #REGde
  $6EC9 Pop last item from stack into #REGbc
  $6ECA Pop last item from stack into #REGaf
  $6ECB Return
c $6ECC
  $6ECC #REGde=#REGde+1
  $6ECD #REGa=PEEK #REGde
  $6ECE Set the zero flag if #REGa=#N(32,2,,1)($), or the carry flag if #REGa<#N(32,2,,1)($)
  $6ED0 Jump to #R28372 if #REGa>=#N(32,2,,1)($)
  $6ED2 #REGa=#N(144,2,,1)($)
  $6ED4 CALL #R28842
  $6ED7 Return
b $6ED8
c $6EFD
  $6EFD CALL #R28803
  $6F00 #REGa=#REGa+1
  $6F01 #REGb=#REGa
  $6F02 #REGa=PEEK #N(25423,4,,1)($)
  $6F05 #REGc=#N(8,2,,1)($)
  $6F07 Set the zero flag if #REGa=#N(2,2,,1)($), or the carry flag if #REGa<#N(2,2,,1)($)
  $6F09 Jump to #R28429 if #REGa<>#N(2,2,,1)($)
  $6F0B #REGc=#N(23,2,,1)($)
  $6F0D #REGa=#REGb
  $6F0E Set the zero flag if #REGa=#REGc, or the carry flag if #REGa<#REGc
  $6F0F Jump to #R28448 if #REGa<#REGc
  $6F11 #REGb=#REGb-1
  $6F12 Push #REGbc onto the stack
  $6F13 #REGb=#REGc
  $6F14 #REGa=#REGb
  $6F15 Set the zero flag if #REGa=#N(23,2,,1)($), or the carry flag if #REGa<#N(23,2,,1)($)
  $6F17 Jump to #R28442 if #REGa=#N(23,2,,1)($)
  $6F19 #REGb=#REGb-1
  $6F1A CALL #R3584
  $6F1D Pop last item from stack into #REGbc
  $6F1E Jump to #R28429
  $6F20 Push #REGaf onto the stack
  $6F21 #REGa=#N(22,2,,1)($)
  $6F23 CALL #R16
  $6F24 Pop last item from stack into #REGaf
  $6F25 CALL #R16
  $6F26 CALL #R28786
  $6F29 CALL #R16
  $6F2A Return
c $6F2B
  $6F2B #REGa=PEEK #N(25423,4,,1)($)
  $6F2E Clear the carry flag and set the zero flag if #REGa=0
  $6F2F Jump to #R28480 if #REGa=0
  $6F31 Set the zero flag if #REGa=#N(2,2,,1)($), or the carry flag if #REGa<#N(2,2,,1)($)
  $6F33 Jump to #R28496 if #REGa=#N(2,2,,1)($)
  $6F35 #REGb=#N(3,2,,1)($)
  $6F37 #REGa=PEEK #N(23624,4,,1)($)
  $6F3A CALL #R28538
  $6F3D Jump to #R28765
  $6F40 #REGb=#N(1,2,,1)($)
  $6F42 #REGa=PEEK #N(23693,4,,1)($)
  $6F45 CALL #R28538
  $6F48 #REGb=#N(2,2,,1)($)
  $6F4A CALL #R28538
  $6F4D Jump to #R28765
  $6F50 #REGb=#N(1,2,,1)($)
  $6F52 #REGa=PEEK #N(23624,4,,1)($)
  $6F55 CALL #R28538
  $6F58 #REGb=#N(2,2,,1)($)
  $6F5A CALL #R28538
  $6F5D #REGb=#N(3,2,,1)($)
  $6F5F CALL #R28538
  $6F62 Reset bits 0, 1 and 2 of #REGa
  $6F64 #REGb=#REGa
  $6F65 Keep only bits 3, 4 and 5 of #REGa
  $6F67 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $6F68 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $6F69 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $6F6A #REGa=#REGa|#REGb
  $6F6B #REGhl=#N(22528,4,,1)($)
  $6F6E #REGde=#N(22529,4,,1)($)
  $6F71 #REGbc=#N(31,4,,1)($)
  $6F74 POKE #REGhl,#REGa
  $6F75 POKE #REGde,PEEK #REGhl; #REGhl=#REGhl+1; #REGde=#REGde+1; #REGbc=#REGbc-1; repeat until #REGbc=0
  $6F77 Jump to #R28765
c $6F7A
  $6F7A Push #REGaf onto the stack
  $6F7B #REGa=#REGb
  $6F7C #REGhl=#N(14336,4,,1)($)
  $6F7F #REGde=#N(2048,4,,1)($)
  $6F82 #REGhl=#REGhl+#REGde
  $6F83 Decrement #REGb and jump to #R28546 if #REGb>0
  $6F85 #REGd=#REGh
  $6F86 #REGe=#N(1,2,,1)($)
  $6F88 #REGbc=#N(2047,4,,1)($)
  $6F8B POKE #REGhl,#N(0,2,,1)($)
  $6F8D POKE #REGde,PEEK #REGhl; #REGhl=#REGhl+1; #REGde=#REGde+1; #REGbc=#REGbc-1; repeat until #REGbc=0
  $6F8F #REGa=#REGa+#N(87,2,,1)($)
  $6F91 #REGh=#REGa
  $6F92 #REGl=#N(0,2,,1)($)
  $6F94 #REGd=#REGa
  $6F95 #REGe=#N(1,2,,1)($)
  $6F97 #REGbc=#N(255,4,,1)($)
  $6F9A Pop last item from stack into #REGaf
  $6F9B POKE #REGhl,#REGa
  $6F9C POKE #REGde,PEEK #REGhl; #REGhl=#REGhl+1; #REGde=#REGde+1; #REGbc=#REGbc-1; repeat until #REGbc=0
  $6F9E Return
c $6F9F
  $6F9F #REGa=#N(22,2,,1)($)
  $6FA1 CALL #R16
  $6FA2 CALL #R28803
  $6FA5 CALL #R16
  $6FA6 #REGa=0
  $6FA7 CALL #R16
  $6FA8 Return
b $6FA9
t $6FBB
b $6FBF
t $6FCB
b $6FD0
t $6FEC
b $6FEF
t $6FF9
b $6FFC
t $6FFE
b $7003
t $703E
b $7041
c $7043
  $7043 #REGde=#REGde+1
  $7044 #REGa=PEEK #REGde
  $7045 POKE #N(25423,4,,1)($),#REGa
  $7048 #REGa=#N($FF,2,,1)($)-#REGa
  $7049 #REGa=#REGa+#N(3,2,,1)($)
  $704B CALL #R27378
  $704E #REGa=PEEK #N(25423,4,,1)($)
  $7051 Set the zero flag if #REGa=#N(2,2,,1)($), or the carry flag if #REGa<#N(2,2,,1)($)
  $7053 #REGa=#N(8,2,,1)($)
  $7055 Jump to #R28761 if the zero flag is not set
  $7057 #REGa=#N(22,2,,1)($)
  $7059 POKE #N(23659,4,,1)($),#REGa
  $705C Return
c $705D
  $705D #REGa=#N(22,2,,1)($)
  $705F CALL #R16
  $7060 #REGa=0
  $7061 CALL #R16
  $7062 #REGa=0
  $7063 CALL #R16
  $7064 Return
c $7065
  $7065 #REGa=#N(22,2,,1)($)
  $7067 CALL #R16
  $7068 #REGde=#REGde+1
  $7069 #REGde=#REGde+1
  $706A #REGa=PEEK #REGde
  $706B #REGa=#REGa-1
  $706C CALL #R16
  $706D #REGde=#REGde-1
  $706E #REGa=PEEK #REGde
  $706F #REGa=#REGa-1
  $7070 CALL #R16
  $7071 Return
c $7072
  $7072 Push #REGhl onto the stack
  $7073 #REGa=PEEK #N(25423,4,,1)($)
  $7076 #REGhl=#N(23690,4,,1)($)
  $7079 Clear the carry flag and set the zero flag if #REGa=0
  $707A Jump to #R28798 if #REGa>0
  $707C #REGhl=#REGhl-1
  $707D #REGhl=#REGhl-1
  $707E #REGa=#N(33,2,,1)($)
  $7080 #REGa=#REGa-PEEK #REGhl
  $7081 Pop last item from stack into #REGhl
  $7082 Return
c $7083
  $7083 Push #REGhl onto the stack
  $7084 #REGa=PEEK #N(25423,4,,1)($)
  $7087 #REGhl=#N(23691,4,,1)($)
  $708A Clear the carry flag and set the zero flag if #REGa=0
  $708B Jump to #R28815 if #REGa>0
  $708D #REGhl=#REGhl-1
  $708E #REGhl=#REGhl-1
  $708F #REGa=#N(24,2,,1)($)
  $7091 #REGa=#REGa-PEEK #REGhl
  $7092 Pop last item from stack into #REGhl
  $7093 Return
b $7094
c $70AA
  $70AA Push #REGaf onto the stack
  $70AB Set the zero flag if #REGa=#N(32,2,,1)($), or the carry flag if #REGa<#N(32,2,,1)($)
  $70AD Jump to #R28898 if #REGa<#N(32,2,,1)($)
  $70AF #REGa=PEEK #N(23690,4,,1)($)
  $70B2 #REGa=#REGa-1
  $70B3 Jump to #R28898 if #REGa>0
  $70B5 #REGa=PEEK #N(25423,4,,1)($)
  $70B8 #REGa=#REGa-1
  $70B9 #REGa=PEEK #N(23691,4,,1)($)
  $70BC Jump to #R28868 if the zero flag is set
  $70BE Set the zero flag if #REGa=#N(2,2,,1)($), or the carry flag if #REGa<#N(2,2,,1)($)
  $70C0 Jump to #R28898 if #REGa<>#N(2,2,,1)($)
  $70C2 Jump to #R28872
  $70C4 Set the zero flag if #REGa=#N(17,2,,1)($), or the carry flag if #REGa<#N(17,2,,1)($)
  $70C6 Jump to #R28898 if #REGa<>#N(17,2,,1)($)
  $70C8 Push #REGbc onto the stack
  $70C9 Push #REGde onto the stack
  $70CA Push #REGhl onto the stack
  $70CB #REGa=#N(256,2,,1)($)-#REGa
  $70CD #REGa=#REGa+#N(24,2,,1)($)
  $70CF #REGb=#REGa
  $70D0 #REGa=#N(22,2,,1)($)
  $70D2 CALL #R16
  $70D3 #REGa=#REGb
  $70D4 Set the zero flag if #REGa=#N(22,2,,1)($), or the carry flag if #REGa<#N(22,2,,1)($)
  $70D6 Jump to #R28889 if #REGa<>#N(22,2,,1)($)
  $70D8 #REGb=#REGb+1
  $70D9 CALL #R16
  $70DA #REGa=0
  $70DB CALL #R16
  $70DC CALL #R3584
  $70DF Pop last item from stack into #REGhl
  $70E0 Pop last item from stack into #REGde
  $70E1 Pop last item from stack into #REGbc
  $70E2 Pop last item from stack into #REGaf
  $70E3 CALL #R16
  $70E4 Return
b $70E5
c $7136
  $7136 #REGa=PEEK #N(25423,4,,1)($)
  $7139 #REGl=PEEK #N(23690,4,,1)($); #REGh=PEEK #N(23691,4,,1)($)
  $713C Clear the carry flag and set the zero flag if #REGa=0
  $713D Jump to #R28994 if #REGa>0
  $713F #REGl=PEEK #N(23688,4,,1)($); #REGh=PEEK #N(23689,4,,1)($)
  $7142 #REGa=#N(34,2,,1)($)
  $7144 #REGa=#REGa-#REGl
  $7145 #REGl=#REGa
  $7146 #REGa=#N(25,2,,1)($)
  $7148 #REGa=#REGa-#REGh
  $7149 #REGh=#REGl
  $714A #REGl=#REGa
  $714B #REGa=PEEK #N(23692,4,,1)($)
  $714E Return
c $714F
  $714F #REGa=#N(2,2,,1)($)
  $7151 CALL #R28741
  $7154 Jump to #R28459
c $7157
  $7157 Push #REGhl onto the stack
  $7158 CALL #R29159
  $715B Jump to #R29036 if the zero flag is not set
  $715D #REGhl=#N(23611,4,,1)($)
  $7160 Reset bit 5 of (#REGhl)
  $7162 Set the zero flag if bit 5 of (#REGhl) is 0
  $7164 CALL #R29257
  $7167 Jump to #R29026 if the zero flag is set
  $7169 #REGa=PEEK #N(23560,4,,1)($)
  $716C Set the zero flag if #REGa=#N(32,2,,1)($), or the carry flag if #REGa<#N(32,2,,1)($)
  $716E Jump to #R29051 if #REGa<>#N(32,2,,1)($)
  $7170 CALL #R8020
  $7173 #REGa=#N(32,2,,1)($)
  $7175 Jump to #R29066 if the carry flag is set
  $7177 #REGa=#N(252,2,,1)($)
  $7179 Jump to #R29066
  $717B Set the zero flag if #REGa=#N(13,2,,1)($), or the carry flag if #REGa<#N(13,2,,1)($)
  $717D Jump to #R29066 if #REGa>=#N(13,2,,1)($)
  $717F #REGa=#REGa-#N(6,2,,1)($)
  $7181 #REGhl=#N(29069,4,,1)($)
  $7184 #REGa=#REGa+#REGl
  $7185 Jump to #R29064 if the carry flag is not set
  $7187 #REGh=#REGh+1
  $7188 #REGl=#REGa
  $7189 #REGa=PEEK #REGhl
  $718A Pop last item from stack into #REGhl
  $718B Set the carry flag
  $718C Return
b $718D
c $7194
  $7194 #REGe=PEEK #N(23674,4,,1)($); #REGd=PEEK #N(23675,4,,1)($)
  $7198 #REGl=PEEK #N(23672,4,,1)($); #REGh=PEEK #N(23673,4,,1)($)
  $719B #REGd=#N(0,2,,1)($)
  $719D Return
c $719E
  $719E #REGhl=#N(23697,4,,1)($)
  $71A1 Keep only bits 0 and 2 of #REGa
  $71A3 #REGb=#REGa
  $71A4 #REGa=PEEK #REGhl
  $71A5 Reset bits 0 and 2 of #REGa
  $71A7 #REGa=#REGa|#REGb
  $71A8 POKE #REGhl,#REGa
  $71A9 Return
c $71AA
  $71AA Push #REGaf onto the stack
  $71AB Push #REGhl onto the stack
  $71AC #REGa=0
  $71AD #REGhl=#N(29136,4,,1)($)
  $71B0 POKE #N(25438,4,,1)($),#REGa
  $71B3 #REGa=PEEK #N(23697,4,,1)($)
  $71B6 Push #REGaf onto the stack
  $71B7 Set bit 0 of #REGa
  $71B9 POKE #N(23697,4,,1)($),#REGa
  $71BC CALL #R26361
  $71BF Pop last item from stack into #REGaf
  $71C0 POKE #N(23697,4,,1)($),#REGa
  $71C3 Pop last item from stack into #REGhl
  $71C4 Pop last item from stack into #REGaf
  $71C5 Return
c $71C6
  $71C6 Push #REGaf onto the stack
  $71C7 Push #REGhl onto the stack
  $71C8 #REGa=#N(1,2,,1)($)
  $71CA #REGhl=#N(29139,4,,1)($)
  $71CD Jump to #R29104
b $71D0
t $71E3
b $71E6
c $71E7
  $71E7 #REGa=PEEK #N(25442,4,,1)($)
  $71EA Clear the carry flag and set the zero flag if #REGa=0
  $71EB Return if #REGa=0
  $71EC #REGhl=#N(25442,4,,1)($)
  $71EF POKE #REGhl,#N(0,2,,1)($)
  $71F1 Return
b $71F2
t $7228
b $722B
c $7249
  $7249 Push #REGaf onto the stack
  $724A Push #REGhl onto the stack
  $724B #REGhl=#N(29275,4,,1)($)
  $724E #REGa=PEEK #REGhl
  $724F Clear the carry flag and set the zero flag if #REGa=0
  $7250 Jump to #R29286 if #REGa=0
  $7252 #REGa=IN (#N(256,,,1)($)*#REGa+#N(254,2,,1)($))
  $7254 #REGhl=#REGhl+1
  $7255 #REGa=#REGa&PEEK #REGhl
  $7256 Jump to #R29339 if #REGa>0
  $7258 #REGhl=#REGhl+1
  $7259 Jump to #R29262
b $725B
t $726C
b $726F
t $728C
b $7291
c $729B
  $729B Pop last item from stack into #REGhl
  $729C Pop last item from stack into #REGaf
  $729D Return
b $729E
t $72A2
b $72A5
c $72AE
  $72AE #REGhl=#N(42215,4,,1)($)
  $72B1 Reset bit 7 of (#REGhl)
  $72B3 Return
c $72B4
  $72B4 #REGhl=#N(38454,4,,1)($)
  $72B7 CALL #R38357
  $72BA Return
c $72BB
  $72BB #REGhl=#N(42215,4,,1)($)
  $72BE Set bit 7 of (#REGhl)
  $72C0 #REGhl=#N(38463,4,,1)($)
  $72C3 CALL #R38357
  $72C6 Return
c $72C7
  $72C7 Pop last item from stack into #REGhl
  $72C8 POKE #N(42241,4,,1)($),#REGsp-lo; POKE #N(42242,4,,1)($),#REGsp-hi
  $72CC Jump to #REGhl
b $72CD
c $72F9
  $72F9 #REGl=PEEK #N(42295,4,,1)($); #REGh=PEEK #N(42296,4,,1)($)
  $72FC Push #REGhl onto the stack
  $72FD Push #REGde onto the stack
  $72FE #REGde=#N(42147,4,,1)($)
  $7301 Clear the carry flag and set the zero flag if #REGa=0
  $7302 #REGhl=#REGhl-carry-#REGde
  $7304 Pop last item from stack into #REGde
  $7305 Pop last item from stack into #REGhl
  $7306 CALL #R32712 if the zero flag is set
  $7309 Do nothing
  $730A Push #REGde onto the stack
  $730B #REGhl=#REGhl-1
  $730C #REGd=PEEK #REGhl
  $730D #REGhl=#REGhl-1
  $730E #REGe=PEEK #REGhl
  $730F POKE #N(42295,4,,1)($),#REGl; POKE #N(42296,4,,1)($),#REGh
  $7312 Pop last item from stack into #REGhl
  $7313 Exchange #REGde and #REGhl
  $7314 Return
c $7315
  $7315 Exchange #REGde and #REGhl
  $7316 Push #REGhl onto the stack
  $7317 #REGl=PEEK #N(42295,4,,1)($); #REGh=PEEK #N(42296,4,,1)($)
  $731A Push #REGhl onto the stack
  $731B Push #REGde onto the stack
  $731C #REGde=#N(42211,4,,1)($)
  $731F Clear the carry flag and set the zero flag if #REGa=0
  $7320 #REGhl=#REGhl-carry-#REGde
  $7322 Pop last item from stack into #REGde
  $7323 Pop last item from stack into #REGhl
  $7324 Jump to #R29482 if the zero flag is not set
  $7326 CALL #R32712
  $7329 #REGbc=#N(9075,4,,1)($)
  $732C POKE #REGhl,#REGd
  $732D #REGhl=#REGhl+1
  $732E POKE #N(42295,4,,1)($),#REGl; POKE #N(42296,4,,1)($),#REGh
  $7331 Pop last item from stack into #REGhl
  $7332 Exchange #REGde and #REGhl
  $7333 Return
c $7334
  $7334 #REGhl=#N(42147,4,,1)($)
  $7337 POKE #N(42295,4,,1)($),#REGl; POKE #N(42296,4,,1)($),#REGh
  $733A Return
b $733B
c $734F
  $734F CALL #R29433
  $7352 CALL #R29461
  $7355 Jump to #R29461
c $7358
  $7358 CALL #R29433
  $735B #REGa=#REGh
  $735C #REGa=#REGa|#REGl
  $735D #REGhl=#N(0,4,,1)($)
  $7360 Jump to #R29539 if the zero flag is not set
  $7362 #REGhl=#REGhl+1
  $7363 Jump to #R29461
b $7366
c $7371
  $7371 CALL #R29433
  $7374 Exchange #REGde and #REGhl
  $7375 CALL #R29433
  $7378 Clear the carry flag and set the zero flag if #REGa=0
  $7379 #REGhl=#REGhl-carry-#REGde
  $737B Jump to #R29461
b $737E
c $738D
  $738D #REGl=PEEK #N(42221,4,,1)($); #REGh=PEEK #N(42222,4,,1)($)
  $7390 Jump to #R29461
c $7393
  $7393 CALL #R29433
  $7396 Exchange #REGde and #REGhl
  $7397 CALL #R29433
  $739A #REGa=#REGh
  $739B #REGa=#REGa&#REGd
  $739C #REGh=#REGa
  $739D #REGa=#REGl
  $739E #REGa=#REGa&#REGe
  $739F #REGl=#REGa
  $73A0 Jump to #R29461
c $73A3
  $73A3 CALL #R29433
  $73A6 Exchange #REGde and #REGhl
  $73A7 CALL #R29433
  $73AA #REGa=#REGh
  $73AB #REGa=#REGa|#REGd
  $73AC #REGh=#REGa
  $73AD #REGa=#REGl
  $73AE #REGa=#REGa|#REGe
  $73AF #REGl=#REGa
  $73B0 Jump to #R29461
c $73B3
  $73B3 CALL #R29433
  $73B6 Exchange #REGde and #REGhl
  $73B7 CALL #R29433
  $73BA #REGa=#REGh
  $73BB #REGa=#REGa^#REGd
  $73BC #REGh=#REGa
  $73BD #REGa=#REGl
  $73BE #REGa=#REGa^#REGe
  $73BF #REGl=#REGa
  $73C0 Jump to #R29461
b $73C3
t $73C6
b $73CA
t $73CB
b $73CE
c $73E1
  $73E1 CALL #R29433
  $73E4 #REGa=#REGh
  $73E5 #REGa=#REGa|#REGl
  $73E6 #REGl=PEEK #N(42216,4,,1)($); #REGh=PEEK #N(42217,4,,1)($)
  $73E9 Jump to #R29683 if the zero flag is set
  $73EB #REGa=PEEK #N(42215,4,,1)($)
  $73EE Set bit 3 of #REGa
  $73F0 POKE #N(42215,4,,1)($),#REGa
  $73F3 Return if the zero flag is not set
  $73F4 Set the zero flag if bit 7 of (#REGhl) is 0
  $73F6 Jump to #R29692 if bit 7 of PEEK #REGhl is reset
  $73F8 #REGhl=#REGhl+1
  $73F9 #REGhl=#REGhl+1
  $73FA Jump to #R29684
  $73FC #REGa=PEEK #REGhl
  $73FD Set the zero flag if #REGa=#N(63,2,,1)($), or the carry flag if #REGa<#N(63,2,,1)($)
  $73FF Jump to #R29703 if #REGa=#N(63,2,,1)($)
  $7401 Clear the carry flag and set the zero flag if #REGa=0
  $7402 Jump to #R29703 if #REGa=0
  $7404 #REGhl=#REGhl+1
  $7405 Jump to #R29684
  $7407 POKE #N(42216,4,,1)($),#REGl; POKE #N(42217,4,,1)($),#REGh
  $740A Return
c $740B
  $740B CALL #R29433
  $740E #REGa=#REGh
  $740F Clear the carry flag and set the zero flag if #REGa=0
  $7410 Jump to #R29718 if #REGa=0
  $7412 CALL #R32712
  $7415 Exchange #REGaf and #REGaf'
  $7416 #REGb=#REGl
  $7417 #REGb=#REGb+1
  $7418 #REGhl=#N(42114,4,,1)($)
  $741B #REGa=#N(128,2,,1)($)
  $741D Rotate #REGa left circular (copying bit 7 into bit 0 and into the carry flag)
  $741E Jump to #R29729 if the carry flag is not set
  $7420 #REGhl=#REGhl+1
  $7421 Decrement #REGb and jump to #R29725 if #REGb>0
  $7423 #REGe=#REGa
  $7424 Flip every bit of #REGa
  $7426 #REGd=#REGa
  $7427 Return
c $7428
  $7428 CALL #R29707
  $742B #REGa=PEEK #REGhl
  $742C #REGa=#REGa|#REGe
  $742D POKE #REGhl,#REGa
  $742E Return
b $742F
c $7436
  $7436 CALL #R29707
  $7439 #REGa=PEEK #REGhl
  $743A #REGa=#REGa&#REGe
  $743B #REGhl=#N(0,4,,1)($)
  $743E Jump to #R29761 if the zero flag is set
  $7440 #REGhl=#REGhl+1
  $7441 Jump to #R29461
c $7444
  $7444 CALL #R29707
  $7447 #REGa=PEEK #REGhl
  $7448 #REGa=#REGa&#REGe
  $7449 #REGhl=#N(0,4,,1)($)
  $744C Jump to #R29775 if the zero flag is not set
  $744E #REGhl=#REGhl+1
  $744F Jump to #R29461
c $7452
  $7452 CALL #R29433
  $7455 #REGa=#REGh
  $7456 Clear the carry flag and set the zero flag if #REGa=0
  $7457 Jump to #R29790 if #REGa>0
  $7459 #REGa=#REGl
  $745A Keep only bit 7 of #REGa
  $745C Jump to #R29794 if #REGa=0
  $745E CALL #R32712
  $7461 Exchange #REGaf and #REGaf'
  $7462 Exchange #REGde and #REGhl
  $7463 #REGhl=#N(41987,4,,1)($)
  $7466 #REGhl=#REGhl+#REGde
  $7467 Return
b $7468
t $7469
b $746C
c $7477
  $7477 CALL #R29778
  $747A Exchange #REGde and #REGhl
  $747B CALL #R29433
  $747E #REGa=#REGl
  $747F POKE #REGde,#REGa
  $7480 Return
b $7481
t $7482
b $7486
c $748A
  $748A CALL #R29778
  $748D Exchange #REGde and #REGhl
  $748E CALL #R29433
  $7491 #REGa=PEEK #REGde
  $7492 Set the zero flag if #REGa=#REGl, or the carry flag if #REGa<#REGl
  $7493 #REGhl=#N(0,4,,1)($)
  $7496 Jump to #R29849 if the zero flag is not set
  $7498 #REGhl=#REGhl+1
  $7499 Jump to #R29461
c $749C
  $749C CALL #R29619
  $749F Jump to #R29528
c $74A2
  $74A2 CALL #R29553
  $74A5 CALL #R29433
  $74A8 Set the zero flag if bit 7 of #REGh is 0
  $74AA #REGhl=#N(0,4,,1)($)
  $74AD Jump to #R29872 if the zero flag is set
  $74AF #REGhl=#REGhl+1
  $74B0 Jump to #R29461
b $74B3
c $74B8
  $74B8 CALL #R29433
  $74BB #REGa=#REGh
  $74BC Clear the carry flag and set the zero flag if #REGa=0
  $74BD Jump to #R29891 if #REGa=0
  $74BF CALL #R32712
  $74C2 #REGb=#REGb-1
  $74C3 Exchange #REGde and #REGhl
  $74C4 #REGhl=#N(41469,4,,1)($)
  $74C7 #REGhl=#REGhl+#REGde
  $74C8 #REGhl=#REGhl+#REGde
  $74C9 Return
b $74CA
c $7508
  $7508 #REGa=#REGh
  $7509 Clear the carry flag and set the zero flag if #REGa=0
  $750A Jump to #R29968 if #REGa=0
  $750C CALL #R32712
  $750F #REGb=#REGb-1
  $7510 #REGc=#REGl
  $7511 #REGl=PEEK #N(42275,4,,1)($); #REGh=PEEK #N(42276,4,,1)($)
  $7514 CALL #R35445
  $7517 Jump to #R29964 if the carry flag is set
  $7519 #REGhl=#REGhl+1
  $751A #REGhl=#REGhl+1
  $751B #REGhl=#REGhl+1
  $751C #REGde=#N(24088,4,,1)($)
  $751F CALL #R34639
  $7522 #REGde=#REGde-1
  $7523 #REGa=#REGa-1
  $7524 POKE #REGde,#REGa
  $7525 #REGhl=#N(24088,4,,1)($)
  $7528 CALL #R34924
  $752B Return
c $752C
  $752C CALL #R29433
  $752F #REGa=#REGh
  $7530 Clear the carry flag and set the zero flag if #REGa=0
  $7531 Jump to #R30007 if #REGa=0
  $7533 CALL #R32712
  $7536 #REGb=#N(77,2,,1)($)
  $7538 #REGl=PEEK #N(42285,4,,1)($); #REGh=PEEK #N(42286,4,,1)($)
  $753B CALL #R35445
  $753E Jump to #R30003 if the carry flag is set
  $7540 #REGde=#N(24088,4,,1)($)
  $7543 CALL #R34639
  $7546 #REGde=#REGde-1
  $7547 #REGa=#REGa-1
  $7548 POKE #REGde,#REGa
  $7549 #REGhl=#N(24088,4,,1)($)
  $754C Jump to #R34924
c $754F
  $754F #REGhl=#N(38577,4,,1)($)
  $7552 CALL #R34924
  $7555 Return
b $7556
t $7568
b $756B
t $756D
b $7570
c $75B6
  $75B6 CALL #R29433
  $75B9 #REGa=PEEK #N(42115,4,,1)($)
  $75BC Keep only bits 1 and 2 of #REGa
  $75BE Jump to #R30163 if #REGa>0
  $75C0 #REGa=PEEK #N(42215,4,,1)($)
  $75C3 Keep only bit 7 of #REGa
  $75C5 Jump to #R30157 if #REGa>0
  $75C7 CALL #R29364
  $75CA CALL #R29376
  $75CD #REGc=#N(251,2,,1)($)
  $75CF CALL #R30008
  $75D2 Return
  $75D3 #REGa=PEEK #N(42115,4,,1)($)
  $75D6 Set bit 0 of #REGa
  $75D8 POKE #N(42115,4,,1)($),#REGa
  $75DB #REGa=PEEK #N(42215,4,,1)($)
  $75DE Keep only bit 7 of #REGa
  $75E0 Jump to #R30221 if #REGa>0
  $75E2 Push #REGhl onto the stack
  $75E3 CALL #R29461
  $75E6 Pop last item from stack into #REGbc
  $75E7 #REGl=PEEK #N(42277,4,,1)($); #REGh=PEEK #N(42278,4,,1)($)
  $75EA CALL #R35391
  $75ED #REGc=PEEK #REGhl
  $75EE #REGhl=#REGhl+1
  $75EF #REGb=PEEK #REGhl
  $75F0 #REGa=#REGb
  $75F1 #REGa=#REGa|#REGc
  $75F2 Jump to #R30209 if #REGa=0
  $75F4 Push #REGbc onto the stack
  $75F5 CALL #R29364
  $75F8 Pop last item from stack into #REGbc
  $75F9 #REGl=PEEK #N(42287,4,,1)($); #REGh=PEEK #N(42288,4,,1)($)
  $75FC CALL #R35417
  $75FF Jump to #R30213
  $7601 CALL #R29376
  $7604 Set the carry flag
  $7605 Jump to #R30218 if the carry flag is set
  $7607 CALL #R30281
  $760A CALL #R29433
  $760D #REGb=#REGh
  $760E #REGc=#REGl
  $760F #REGl=PEEK #N(42277,4,,1)($); #REGh=PEEK #N(42278,4,,1)($)
  $7612 CALL #R35391
  $7615 #REGhl=#REGhl+1
  $7616 #REGhl=#REGhl+1
  $7617 Jump to #R30237 if the carry flag is not set
  $7619 CALL #R32712
  $761C #REGb=#REGb+1
  $761D #REGa=PEEK #REGhl
  $761E Clear the carry flag and set the zero flag if #REGa=0
  $761F Jump to #R30246 if #REGa=0
  $7621 #REGhl=#REGhl+1
  $7622 #REGhl=#REGhl+1
  $7623 #REGhl=#REGhl+1
  $7624 Jump to #R30237
  $7626 #REGhl=#REGhl+1
  $7627 CALL #R29980
  $762A #REGl=PEEK #N(42295,4,,1)($); #REGh=PEEK #N(42296,4,,1)($)
  $762D #REGe=PEEK #REGhl
  $762E #REGhl=#REGhl+1
  $762F #REGd=PEEK #REGhl
  $7630 Exchange #REGde and #REGhl
  $7631 Push #REGhl onto the stack
  $7632 #REGa=#N(201,2,,1)($)
  $7634 POKE #N(25374,4,,1)($),#REGa
  $7637 CALL #R30313
  $763A CALL #R30537
  $763D Pop last item from stack into #REGhl
  $763E Return if the zero flag is set
  $763F Push #REGhl onto the stack
  $7640 #REGc=#N(253,2,,1)($)
  $7642 CALL #R30008
  $7645 Pop last item from stack into #REGhl
  $7646 Jump to #R30313
c $7649
  $7649 Push #REGix onto the stack
  $764B Push #REGhl onto the stack
  $764C Pop last item from stack into #REGix
  $764E CALL #R25398
  $7651 Pop last item from stack into #REGix
  $7653 #REGhl=#N(38457,4,,1)($)
  $7656 CALL #R34924
  $7659 #REGhl=#N(38577,4,,1)($)
  $765C CALL #R34924
  $765F Return
c $7660
  $7660 CALL #R29581
  $7663 Jump to #R30134
b $7666
c $7669
  $7669 #REGa=#REGh
  $766A #REGa=#REGa|#REGl
  $766B Jump to #R30321 if #REGa>0
  $766D CALL #R32712
  $7670 Exchange #REGaf and #REGaf'
  $7671 Exchange #REGde and #REGhl
  $7672 #REGhl=#N(41469,4,,1)($)
  $7675 #REGa=0
  $7676 POKE #N(42224,4,,1)($),#REGa
  $7679 #REGc=PEEK #REGhl
  $767A #REGhl=#REGhl+1
  $767B #REGb=PEEK #REGhl
  $767C #REGhl=#REGhl-1
  $767D Push #REGde onto the stack
  $767E Push #REGhl onto the stack
  $767F Push #REGaf onto the stack
  $7680 #REGa=#REGb
  $7681 #REGa=#REGa^#REGd
  $7682 Jump to #R30363 if #REGa>0
  $7684 #REGa=#REGc
  $7685 #REGa=#REGa^#REGe
  $7686 Jump to #R30363 if #REGa>0
  $7688 #REGa=PEEK #N(42224,4,,1)($)
  $768B CALL #R25374
  $768E Pop last item from stack into #REGaf
  $768F Push #REGaf onto the stack
  $7690 #REGl=#REGa
  $7691 #REGh=#N(0,2,,1)($)
  $7693 CALL #R29960
  $7696 #REGa=#N(44,2,,1)($)
  $7698 POKE #N(42224,4,,1)($),#REGa
  $769B Pop last item from stack into #REGaf
  $769C Pop last item from stack into #REGhl
  $769D Pop last item from stack into #REGde
  $769E #REGhl=#REGhl+1
  $769F #REGhl=#REGhl+1
  $76A0 #REGa=#REGa+1
  $76A1 Jump to #R30329 if #REGa>0
  $76A3 #REGa=PEEK #N(42224,4,,1)($)
  $76A6 Clear the carry flag and set the zero flag if #REGa=0
  $76A7 Return
b $76A8
c $76B3
  $76B3 CALL #R29519
  $76B6 CALL #R29880
  $76B9 #REGe=PEEK #REGhl
  $76BA #REGhl=#REGhl+1
  $76BB #REGd=PEEK #REGhl
  $76BC #REGhl=#REGhl-1
  $76BD Exchange #REGde and #REGhl
  $76BE #REGc=PEEK #N(42221,4,,1)($); #REGb=PEEK #N(42222,4,,1)($)
  $76C2 #REGa=#REGh
  $76C3 Set the zero flag if #REGa=#N(127,2,,1)($), or the carry flag if #REGa<#N(127,2,,1)($)
  $76C5 Jump to #R30432 if #REGa<>#N(127,2,,1)($)
  $76C7 #REGc=#N(245,2,,1)($)
  $76C9 CALL #R30008
  $76CC CALL #R29433
  $76CF Jump to #R30962
b $76D2
c $76E0
  $76E0 Clear the carry flag and set the zero flag if #REGa=0
  $76E1 #REGhl=#REGhl-carry-#REGbc
  $76E3 Jump to #R30454 if #REGhl=0
  $76E5 #REGc=#N(247,2,,1)($)
  $76E7 CALL #R30008
  $76EA Jump to #R30412
b $76EC
c $76F6
  $76F6 Push #REGde onto the stack
  $76F7 CALL #R29519
  $76FA CALL #R29433
  $76FD #REGc=#REGl
  $76FE #REGl=PEEK #N(42275,4,,1)($); #REGh=PEEK #N(42276,4,,1)($)
  $7701 CALL #R35445
  $7704 Jump to #R30474 if the carry flag is not set
  $7706 CALL #R32712
  $7709 #REGb=#REGb-1
  $770A #REGe=PEEK #REGhl
  $770B #REGa=PEEK #N(42223,4,,1)($)
  $770E #REGa=#REGa+#REGe
  $770F #REGhl=#N(42218,4,,1)($)
  $7712 Set the zero flag if #REGa=PEEK #REGhl, or the carry flag if #REGa<PEEK #REGhl
  $7713 Jump to #R30497 if #REGa>=PEEK #REGhl
  $7715 POKE #N(42223,4,,1)($),#REGa
  $7718 Pop last item from stack into #REGhl
  $7719 POKE #REGhl,#N(255,2,,1)($)
  $771B #REGhl=#REGhl+1
  $771C POKE #REGhl,#N(127,2,,1)($)
  $771E Jump to #R29433
  $7721 #REGc=#N(248,2,,1)($)
  $7723 CALL #R30008
  $7726 Jump to #R30533
b $7728
t $772B
b $772E
c $7749
  $7749 Push #REGaf onto the stack
  $774A #REGa=#N(195,2,,1)($)
  $774C POKE #N(25374,4,,1)($),#REGa
  $774F Pop last item from stack into #REGaf
  $7750 Return
c $7751
  $7751 CALL #R29880
  $7754 #REGhl=#REGhl+1
  $7755 #REGa=PEEK #REGhl
  $7756 Set the zero flag if #REGa=#N(127,2,,1)($), or the carry flag if #REGa<#N(127,2,,1)($)
  $7758 #REGhl=#N(0,4,,1)($)
  $775B Jump to #R30558 if the zero flag is not set
  $775D #REGhl=#REGhl+1
  $775E Jump to #R29461
c $7761
  $7761 CALL #R29880
  $7764 #REGe=PEEK #REGhl
  $7765 #REGhl=#REGhl+1
  $7766 #REGd=PEEK #REGhl
  $7767 #REGl=PEEK #N(42221,4,,1)($); #REGh=PEEK #N(42222,4,,1)($)
  $776A Clear the carry flag and set the zero flag if #REGa=0
  $776B #REGhl=#REGhl-carry-#REGde
  $776D Jump to #R30552
b $776F
c $778A
  $778A CALL #R25374
  $778D CALL #R34379
  $7790 Return if the zero flag is not set
  $7791 Push #REGhl onto the stack
  $7792 Push #REGhl onto the stack
  $7793 CALL #R25377
  $7796 #REGb=#REGh
  $7797 Pop last item from stack into #REGhl
  $7798 #REGhl=#REGhl+1
  $7799 #REGa=PEEK #REGhl
  $779A #REGb=#REGb+1
  $779B CALL #R34379
  $779E Jump to #R30626 if the zero flag is set
  $77A0 Set the zero flag if #REGa=#N(255,2,,1)($), or the carry flag if #REGa<#N(255,2,,1)($)
  $77A2 Jump to #R30616 if #REGa<>#N(255,2,,1)($)
  $77A4 #REGa=#REGb
  $77A5 Set the zero flag if #REGa=#N(33,2,,1)($), or the carry flag if #REGa<#N(33,2,,1)($)
  $77A7 CALL #R30031 if #REGa>=#N(33,2,,1)($)
  $77AA Pop last item from stack into #REGhl
  $77AB Return
c $77AC
  $77AC CALL #R29433
  $77AF Push #REGhl onto the stack
  $77B0 CALL #R29880
  $77B3 Pop last item from stack into #REGde
  $77B4 POKE #REGhl,#REGe
  $77B5 #REGhl=#REGhl+1
  $77B6 POKE #REGhl,#REGd
  $77B7 Return
c $77B8
  $77B8 CALL #R30031
  $77BB Jump to #R30008
b $77BE
t $77D0
b $77D3
c $7805
  $7805 CALL #R29433
  $7808 POKE #N(42221,4,,1)($),#REGl; POKE #N(42222,4,,1)($),#REGh
  $780B Jump to #R30304
b $780E
c $7813
  $7813 #REGa=PEEK #N(42213,4,,1)($)
  $7816 Jump to #R30747
b $7818
c $781B
  $781B #REGl=#REGa
  $781C #REGh=#N(0,2,,1)($)
  $781E Jump to #R29461
b $7821
t $78F0
b $78F3
c $7924
  $7924 #REGa=PEEK #N(42211,4,,1)($)
  $7927 Jump to #R31020
b $7929
c $792C
  $792C #REGe=#REGa
  $792D CALL #R29433
  $7930 #REGa=#REGh
  $7931 Clear the carry flag and set the zero flag if #REGa=0
  $7932 Jump to #R31032 if #REGa=0
  $7934 CALL #R32712
  $7937 Exchange #REGaf and #REGaf'
  $7938 #REGa=#REGl
  $7939 Set the zero flag if #REGa=#REGe, or the carry flag if #REGa<#REGe
  $793A #REGhl=#N(0,4,,1)($)
  $793D Jump to #R31040 if the zero flag is not set
  $793F #REGhl=#REGhl+1
  $7940 Jump to #R29461
c $7943
  $7943 CALL #R29433
  $7946 #REGa=#REGh
  $7947 Clear the carry flag and set the zero flag if #REGa=0
  $7948 Jump to #R31054 if #REGa=0
  $794A CALL #R32712
  $794D Exchange #REGaf and #REGaf'
  $794E #REGa=#REGl
  $794F #REGl=PEEK #N(42213,4,,1)($); #REGh=PEEK #N(42214,4,,1)($)
  $7952 Set the zero flag if #REGa=#REGh, or the carry flag if #REGa<#REGh
  $7953 Jump to #R31062 if #REGa=#REGh
  $7955 Set the zero flag if #REGa=#REGl, or the carry flag if #REGa<#REGl
  $7956 Jump to #R31034
c $7958
  $7958 CALL #R29433
  $795B #REGa=#REGh
  $795C Clear the carry flag and set the zero flag if #REGa=0
  $795D Jump to #R31075 if #REGa=0
  $795F CALL #R32712
  $7962 Exchange #REGaf and #REGaf'
  $7963 POKE #N(42218,4,,1)($),#REGl; POKE #N(42219,4,,1)($),#REGh
  $7966 Return
c $7967
  $7967 #REGa=PEEK #N(42215,4,,1)($)
  $796A Reset bits 5 and 6 of #REGa
  $796C POKE #N(42215,4,,1)($),#REGa
  $796F POKE #N(42216,4,,1)($),#REGl; POKE #N(42217,4,,1)($),#REGh
  $7972 CALL #R29492
  $7975 #REGl=PEEK #N(42216,4,,1)($); #REGh=PEEK #N(42217,4,,1)($)
  $7978 Jump to #R33456
c $797B
  $797B Set the zero flag if bit 7 of (#REGhl) is 0
  $797D #REGhl=#REGhl+1
  $797E Jump to #R31137 if the zero flag is not set
  $7980 POKE #N(42216,4,,1)($),#REGl; POKE #N(42217,4,,1)($),#REGh
  $7983 Reset bits 6 and 7 of #REGa
  $7985 #REGl=#REGa
  $7986 #REGh=#N(0,2,,1)($)
  $7988 #REGhl=#REGhl+#REGhl
  $7989 #REGde=#N(41301,4,,1)($)
  $798C #REGhl=#REGhl+#REGde
  $798D #REGix=#N(42271,4,,1)($)
  $7991 #REGe=PEEK #REGhl
  $7992 #REGhl=#REGhl+1
  $7993 #REGd=PEEK #REGhl
  $7994 CALL #R31135
  $7997 #REGa=PEEK #N(42215,4,,1)($)
  $799A Keep only bits 5 and 6 of #REGa
  $799C Jump to #R31093 if #REGa=0
  $799E Return
c $799F
  $799F Push #REGde onto the stack
  $79A0 Return
c $79A1
  $79A1 Reset bit 7 of #REGa
  $79A3 #REGd=#REGa
  $79A4 #REGa=PEEK #REGhl
  $79A5 #REGhl=#REGhl+1
  $79A6 #REGe=#REGa
  $79A7 POKE #N(42216,4,,1)($),#REGl; POKE #N(42217,4,,1)($),#REGh
  $79AA Exchange #REGde and #REGhl
  $79AB CALL #R29461
  $79AE Jump to #R31093
c $79B0
  $79B0 #REGl=PEEK #N(42275,4,,1)($); #REGh=PEEK #N(42276,4,,1)($)
  $79B3 #REGa=PEEK #REGhl
  $79B4 Clear the carry flag and set the zero flag if #REGa=0
  $79B5 Return if #REGa=0
  $79B6 #REGhl=#REGhl+1
  $79B7 #REGe=PEEK #REGhl
  $79B8 #REGd=#N(0,2,,1)($)
  $79BA #REGhl=#REGhl+1
  $79BB Push #REGde onto the stack
  $79BC Push #REGhl onto the stack
  $79BD #REGhl=#REGhl+1
  $79BE #REGc=PEEK #REGhl
  $79BF #REGhl=#REGhl+1
  $79C0 #REGb=PEEK #REGhl
  $79C1 #REGl=#REGa
  $79C2 #REGh=#N(0,2,,1)($)
  $79C4 #REGhl=#REGhl+#REGhl
  $79C5 #REGde=#N(41469,4,,1)($)
  $79C8 #REGhl=#REGhl+#REGde
  $79C9 POKE #REGhl,#REGc
  $79CA #REGhl=#REGhl+1
  $79CB POKE #REGhl,#REGb
  $79CC Pop last item from stack into #REGhl
  $79CD Pop last item from stack into #REGde
  $79CE #REGhl=#REGhl+#REGde
  $79CF Jump to #R31155
c $79D1
  $79D1 Push #REGde onto the stack
  $79D2 #REGl=PEEK #N(42289,4,,1)($); #REGh=PEEK #N(42290,4,,1)($)
  $79D5 #REGe=PEEK #REGhl
  $79D6 #REGa=#REGb
  $79D7 #REGa=#REGa|#REGc
  $79D8 #REGhl=#REGhl+1
  $79D9 Jump to #R31197 if the zero flag is not set
  $79DB Pop last item from stack into #REGde
  $79DC Return
  $79DD #REGd=#N(0,2,,1)($)
  $79DF #REGhl=#REGhl+#REGde
  $79E0 #REGbc=#REGbc-1
  $79E1 Jump to #R31189
c $79E3
  $79E3 #REGa=PEEK #REGhl
  $79E4 Clear the carry flag and set the zero flag if #REGa=0
  $79E5 Return if #REGa=0
  $79E6 Push #REGhl onto the stack
  $79E7 Push #REGde onto the stack
  $79E8 #REGhl=#REGhl+1
  $79E9 #REGc=PEEK #REGhl
  $79EA #REGhl=#REGhl+1
  $79EB #REGa=PEEK #REGhl
  $79EC Keep only bits 0, 1 and 2 of #REGa
  $79EE #REGb=#REGa
  $79EF CALL #R31185
  $79F2 #REGa=PEEK #REGhl
  $79F3 Reset bit 7 of #REGa
  $79F5 #REGc=#REGa
  $79F6 #REGa=PEEK #REGde
  $79F7 Reset bit 7 of #REGa
  $79F9 Set the zero flag if #REGa=#N(97,2,,1)($), or the carry flag if #REGa<#N(97,2,,1)($)
  $79FB Jump to #R31231 if #REGa<#N(97,2,,1)($)
  $79FD Reset bits 5 and 7 of #REGa
  $79FF Set the zero flag if #REGa=#REGc, or the carry flag if #REGa<#REGc
  $7A00 Jump to #R31241 if #REGa=#REGc
  $7A02 Pop last item from stack into #REGde
  $7A03 Pop last item from stack into #REGhl
  $7A04 #REGhl=#REGhl+1
  $7A05 #REGhl=#REGhl+1
  $7A06 #REGhl=#REGhl+1
  $7A07 Jump to #R31203
  $7A09 #REGhl=#REGhl+1
  $7A0A #REGde=#REGde+1
  $7A0B #REGa=PEEK #REGde
  $7A0C CALL #R34379
  $7A0F Jump to #R31218 if the zero flag is not set
  $7A11 Pop last item from stack into #REGde
  $7A12 Pop last item from stack into #REGhl
  $7A13 #REGa=PEEK #REGhl
  $7A14 Return
c $7A15
  $7A15 #REGa=PEEK #N(42211,4,,1)($)
  $7A18 Clear the carry flag and set the zero flag if #REGa=0
  $7A19 Return if #REGa>0
  $7A1A #REGhl=#N(42319,4,,1)($)
  $7A1D CALL #R31203
  $7A20 POKE #N(42211,4,,1)($),#REGa
  $7A23 Clear the carry flag and set the zero flag if #REGa=0
  $7A24 Jump to #R31271 if #REGa=0
  $7A26 Set the carry flag
  $7A27 Return
c $7A28
  $7A28 #REGa=PEEK #N(42212,4,,1)($)
  $7A2B Clear the carry flag and set the zero flag if #REGa=0
  $7A2C Return if #REGa>0
  $7A2D #REGl=PEEK #N(42273,4,,1)($); #REGh=PEEK #N(42274,4,,1)($)
  $7A30 CALL #R31203
  $7A33 POKE #N(42212,4,,1)($),#REGa
  $7A36 Clear the carry flag and set the zero flag if #REGa=0
  $7A37 Jump to #R31290 if #REGa=0
  $7A39 Set the carry flag
  $7A3A Return
c $7A3B
  $7A3B #REGl=PEEK #N(42213,4,,1)($); #REGh=PEEK #N(42214,4,,1)($)
  $7A3E #REGa=#REGl
  $7A3F #REGa=#REGa|#REGh
  $7A40 #REGa=#REGa&#REGh
  $7A41 Return if #REGa>0
  $7A42 #REGl=PEEK #N(42271,4,,1)($); #REGh=PEEK #N(42272,4,,1)($)
  $7A45 CALL #R31203
  $7A48 #REGhl=#N(42213,4,,1)($)
  $7A4B #REGb=#REGa
  $7A4C #REGa=PEEK #REGhl
  $7A4D Clear the carry flag and set the zero flag if #REGa=0
  $7A4E Jump to #R31313 if #REGa=0
  $7A50 #REGhl=#REGhl+1
  $7A51 POKE #REGhl,#REGb
  $7A52 Return
c $7A53
  $7A53 CALL #R31253
  $7A56 Return if the carry flag is set
  $7A57 CALL #R31272
  $7A5A Return if the carry flag is set
  $7A5B Jump to #R31291
b $7A5E
c $7A64
  $7A64 #REGl=PEEK #N(42228,4,,1)($); #REGh=PEEK #N(42229,4,,1)($)
  $7A67 #REGa=PEEK #REGhl
  $7A68 CALL #R34379
  $7A6B Jump to #R31344 if the zero flag is set
  $7A6D #REGhl=#REGhl+1
  $7A6E Jump to #R31335
  $7A70 #REGhl=#REGhl+1
  $7A71 POKE #N(42228,4,,1)($),#REGl; POKE #N(42229,4,,1)($),#REGh
  $7A74 #REGhl=#REGhl-1
  $7A75 Clear the carry flag and set the zero flag if #REGa=0
  $7A76 Return if #REGa=0
  $7A77 Set the zero flag if #REGa=#N(44,2,,1)($), or the carry flag if #REGa<#N(44,2,,1)($)
  $7A79 Return if #REGa=#N(44,2,,1)($)
  $7A7A Set the zero flag if #REGa=#N(46,2,,1)($), or the carry flag if #REGa<#N(46,2,,1)($)
  $7A7C Return if #REGa=#N(46,2,,1)($)
  $7A7D Set the zero flag if #REGa=#N(59,2,,1)($), or the carry flag if #REGa<#N(59,2,,1)($)
  $7A7F Return if #REGa=#N(59,2,,1)($)
  $7A80 Set the zero flag if #REGa=#N(33,2,,1)($), or the carry flag if #REGa<#N(33,2,,1)($)
  $7A82 Return if #REGa=#N(33,2,,1)($)
  $7A83 Reset bits 5 and 7 of #REGa
  $7A85 Set the zero flag if #REGa=#N(65,2,,1)($), or the carry flag if #REGa<#N(65,2,,1)($)
  $7A87 Jump to #R31383 if #REGa=#N(65,2,,1)($)
  $7A89 Set the zero flag if #REGa=#N(84,2,,1)($), or the carry flag if #REGa<#N(84,2,,1)($)
  $7A8B Jump to #R31413 if #REGa=#N(84,2,,1)($)
  $7A8D #REGa=PEEK #REGhl
  $7A8E CALL #R34379
  $7A91 #REGhl=#REGhl+1
  $7A92 #REGa=PEEK #REGhl
  $7A93 Jump to #R31344 if the zero flag is set
  $7A95 Jump to #R31453
  $7A97 Push #REGhl onto the stack
  $7A98 #REGhl=#REGhl+1
  $7A99 #REGa=PEEK #REGhl
  $7A9A Reset bits 5 and 7 of #REGa
  $7A9C Set the zero flag if #REGa=#N(78,2,,1)($), or the carry flag if #REGa<#N(78,2,,1)($)
  $7A9E Jump to #R31410 if #REGa<>#N(78,2,,1)($)
  $7AA0 #REGhl=#REGhl+1
  $7AA1 #REGa=PEEK #REGhl
  $7AA2 Reset bits 5 and 7 of #REGa
  $7AA4 Set the zero flag if #REGa=#N(68,2,,1)($), or the carry flag if #REGa<#N(68,2,,1)($)
  $7AA6 Jump to #R31410 if #REGa<>#N(68,2,,1)($)
  $7AA8 #REGhl=#REGhl+1
  $7AA9 #REGa=PEEK #REGhl
  $7AAA CALL #R34379
  $7AAD Jump to #R31410 if the zero flag is not set
  $7AAF Pop last item from stack into #REGde
  $7AB0 Jump to #R31446
  $7AB2 Pop last item from stack into #REGhl
  $7AB3 Jump to #R31373
  $7AB5 Push #REGhl onto the stack
  $7AB6 #REGhl=#REGhl+1
  $7AB7 #REGa=PEEK #REGhl
  $7AB8 Reset bits 5 and 7 of #REGa
  $7ABA Set the zero flag if #REGa=#N(72,2,,1)($), or the carry flag if #REGa<#N(72,2,,1)($)
  $7ABC Jump to #R31410 if #REGa<>#N(72,2,,1)($)
  $7ABE #REGhl=#REGhl+1
  $7ABF #REGa=PEEK #REGhl
  $7AC0 Reset bits 5 and 7 of #REGa
  $7AC2 Set the zero flag if #REGa=#N(69,2,,1)($), or the carry flag if #REGa<#N(69,2,,1)($)
  $7AC4 Jump to #R31410 if #REGa<>#N(69,2,,1)($)
  $7AC6 #REGhl=#REGhl+1
  $7AC7 #REGa=PEEK #REGhl
  $7AC8 Reset bits 5 and 7 of #REGa
  $7ACA Set the zero flag if #REGa=#N(78,2,,1)($), or the carry flag if #REGa<#N(78,2,,1)($)
  $7ACC Jump to #R31410 if #REGa<>#N(78,2,,1)($)
  $7ACE #REGhl=#REGhl+1
  $7ACF #REGa=PEEK #REGhl
  $7AD0 CALL #R34379
  $7AD3 Jump to #R31410 if the zero flag is not set
  $7AD5 Pop last item from stack into #REGde
  $7AD6 #REGa=0
  $7AD7 POKE #N(42228,4,,1)($),#REGl; POKE #N(42229,4,,1)($),#REGh
  $7ADA #REGa=#N(33,2,,1)($)
  $7ADC Return
  $7ADD #REGhl=#REGhl-1
  $7ADE POKE #N(42228,4,,1)($),#REGl; POKE #N(42229,4,,1)($),#REGh
  $7AE1 Return
c $7AE2
  $7AE2 #REGe=PEEK #REGhl
  $7AE3 #REGhl=#REGhl+1
  $7AE4 #REGd=PEEK #REGhl
  $7AE5 #REGhl=#REGhl+1
  $7AE6 #REGa=#REGd
  $7AE7 #REGa=#REGa|#REGe
  $7AE8 Jump to #R31468 if #REGa>0
  $7AEA Complement the carry flag
  $7AEB Return
  $7AEC #REGa=#REGd
  $7AED Set the zero flag if #REGa=#REGb, or the carry flag if #REGa<#REGb
  $7AEE Jump to #R31475 if #REGa<>#REGb
  $7AF0 #REGa=#REGe
  $7AF1 Set the zero flag if #REGa=#REGc, or the carry flag if #REGa<#REGc
  $7AF2 Return if #REGa=#REGc
  $7AF3 #REGa=PEEK #REGhl
  $7AF4 Keep only bit 7 of #REGa
  $7AF6 Jump to #R31484 if #REGa=0
  $7AF8 #REGhl=#REGhl+1
  $7AF9 #REGhl=#REGhl+1
  $7AFA Jump to #R31475
  $7AFC #REGa=PEEK #REGhl
  $7AFD Clear the carry flag and set the zero flag if #REGa=0
  $7AFE #REGhl=#REGhl+1
  $7AFF Jump to #R31458 if the zero flag is set
  $7B01 Jump to #R31475
c $7B03
  $7B03 #REGa=PEEK #N(42215,4,,1)($)
  $7B06 Reset bit 3 of #REGa
  $7B08 POKE #N(42215,4,,1)($),#REGa
  $7B0B #REGl=PEEK #N(42281,4,,1)($); #REGh=PEEK #N(42282,4,,1)($)
  $7B0E #REGc=PEEK #N(42221,4,,1)($); #REGb=PEEK #N(42222,4,,1)($)
  $7B12 CALL #R31458
  $7B15 Jump to #R31520 if the carry flag is set
  $7B17 CALL #R31079
  $7B1A #REGa=PEEK #N(42215,4,,1)($)
  $7B1D Keep only bits 5 and 6 of #REGa
  $7B1F Return if #REGa>0
  $7B20 #REGl=PEEK #N(42283,4,,1)($); #REGh=PEEK #N(42284,4,,1)($)
  $7B23 CALL #R31079
  $7B26 #REGa=PEEK #N(42215,4,,1)($)
  $7B29 Keep only bit 3 of #REGa
  $7B2B Return if #REGa>0
  $7B2C #REGc=#N(241,2,,1)($)
  $7B2E #REGl=PEEK #N(42211,4,,1)($); #REGh=PEEK #N(42212,4,,1)($)
  $7B31 #REGa=#REGh
  $7B32 #REGa=#REGa|#REGl
  $7B33 #REGl=PEEK #N(42213,4,,1)($); #REGh=PEEK #N(42214,4,,1)($)
  $7B36 #REGa=#REGa|#REGh
  $7B37 #REGa=#REGa|#REGl
  $7B38 Jump to #R31548 if #REGa>0
  $7B3A #REGc=#N(242,2,,1)($)
  $7B3C Jump to #R30008
c $7B3F
  $7B3F #REGhl=#N(41469,4,,1)($)
  $7B42 #REGde=#N(41470,4,,1)($)
  $7B45 #REGbc=#N(754,4,,1)($)
  $7B48 POKE #REGhl,#N(0,2,,1)($)
  $7B4A POKE #REGde,PEEK #REGhl; #REGhl=#REGhl+1; #REGde=#REGde+1; #REGbc=#REGbc-1; repeat until #REGbc=0
  $7B4C CALL #R31152
  $7B4F #REGa=#N(2,2,,1)($)
  $7B51 POKE #N(42115,4,,1)($),#REGa
  $7B54 #REGa=#N(250,2,,1)($)
  $7B56 POKE #N(42218,4,,1)($),#REGa
  $7B59 CALL #R25395
  $7B5C POKE #N(42219,4,,1)($),#REGl; POKE #N(42220,4,,1)($),#REGh
  $7B5F #REGl=PEEK #N(42293,4,,1)($); #REGh=PEEK #N(42294,4,,1)($)
  $7B62 POKE #N(42221,4,,1)($),#REGl; POKE #N(42222,4,,1)($),#REGh
  $7B65 #REGa=#N(1,2,,1)($)
  $7B67 CALL #R25392
  $7B6A #REGa=#N(16,2,,1)($)
  $7B6C POKE #N(42215,4,,1)($),#REGa
  $7B6F CALL #R29492
  $7B72 CALL #R29358
  $7B75 CALL #R30304
  $7B78 Return
c $7B79
  $7B79 #REGc=PEEK #N(42221,4,,1)($); #REGb=PEEK #N(42222,4,,1)($)
  $7B7D #REGl=PEEK #N(42277,4,,1)($); #REGh=PEEK #N(42278,4,,1)($)
  $7B80 CALL #R35391
  $7B83 #REGhl=#REGhl+1
  $7B84 #REGhl=#REGhl+1
  $7B85 Jump to #R31627 if the carry flag is not set
  $7B87 CALL #R32712
  $7B8A #REGb=#REGb+1
  $7B8B #REGa=PEEK #N(42211,4,,1)($)
  $7B8E #REGb=#REGa
  $7B8F #REGa=PEEK #REGhl
  $7B90 Clear the carry flag and set the zero flag if #REGa=0
  $7B91 Return if #REGa=0
  $7B92 Set the zero flag if #REGa=#REGb, or the carry flag if #REGa<#REGb
  $7B93 #REGhl=#REGhl+1
  $7B94 Jump to #R31642 if the zero flag is set
  $7B96 #REGhl=#REGhl+1
  $7B97 #REGhl=#REGhl+1
  $7B98 Jump to #R31631
  $7B9A #REGe=PEEK #REGhl
  $7B9B #REGhl=#REGhl+1
  $7B9C #REGd=PEEK #REGhl
  $7B9D Exchange #REGde and #REGhl
  $7B9E CALL #R30728
  $7BA1 #REGa=0
  $7BA2 #REGa=#REGa+1
  $7BA3 Return
c $7BA4
  $7BA4 #REGa=PEEK #N(42214,4,,1)($)
  $7BA7 #REGl=PEEK #N(42113,4,,1)($); #REGh=PEEK #N(42114,4,,1)($)
  $7BAA #REGhl=#REGhl+1
  $7BAB POKE #N(42113,4,,1)($),#REGl; POKE #N(42114,4,,1)($),#REGh
  $7BAE Clear the carry flag and set the zero flag if #REGa=0
  $7BAF Jump to #R31673 if #REGa=0
  $7BB1 #REGl=PEEK #N(42213,4,,1)($); #REGh=PEEK #N(42214,4,,1)($)
  $7BB4 POKE #N(42225,4,,1)($),#REGl; POKE #N(42226,4,,1)($),#REGh
  $7BB7 Jump to #R31682
  $7BB9 #REGa=PEEK #N(42213,4,,1)($)
  $7BBC Clear the carry flag and set the zero flag if #REGa=0
  $7BBD Jump to #R31682 if #REGa=0
  $7BBF POKE #N(42226,4,,1)($),#REGa
  $7BC2 #REGhl=#N(0,4,,1)($)
  $7BC5 POKE #N(42211,4,,1)($),#REGl; POKE #N(42212,4,,1)($),#REGh
  $7BC8 POKE #N(42213,4,,1)($),#REGl; POKE #N(42214,4,,1)($),#REGh
  $7BCB #REGa=PEEK #N(42215,4,,1)($)
  $7BCE Keep only bit 4 of #REGa
  $7BD0 Jump to #R31730 if #REGa=0
  $7BD2 #REGc=#N(240,2,,1)($)
  $7BD4 CALL #R30648
  $7BD7 #REGhl=#N(23296,4,,1)($)
  $7BDA POKE #N(42228,4,,1)($),#REGl; POKE #N(42229,4,,1)($),#REGh
  $7BDD POKE #REGhl,#N(0,2,,1)($)
  $7BDF CALL #R34268
  $7BE2 Jump to #R31698 if the carry flag is not set
  $7BE4 #REGa=PEEK #N(42215,4,,1)($)
  $7BE7 Reset bit 4 of #REGa
  $7BE9 POKE #N(42215,4,,1)($),#REGa
  $7BEC #REGa=PEEK #N(23296,4,,1)($)
  $7BEF Clear the carry flag and set the zero flag if #REGa=0
  $7BF0 Jump to #R31698 if #REGa=0
  $7BF2 #REGe=PEEK #N(42228,4,,1)($); #REGd=PEEK #N(42229,4,,1)($)
  $7BF6 CALL #R31315
  $7BF9 CALL #R31332
  $7BFC Jump to #R31730 if the zero flag is not set
  $7BFE Clear the carry flag and set the zero flag if #REGa=0
  $7BFF Jump to #R31753 if #REGa>0
  $7C01 #REGa=PEEK #N(42215,4,,1)($)
  $7C04 Set bit 4 of #REGa
  $7C06 POKE #N(42215,4,,1)($),#REGa
  $7C09 Return
c $7C0A
  $7C0A #REGa=PEEK #N(42211,4,,1)($)
  $7C0D Clear the carry flag and set the zero flag if #REGa=0
  $7C0E Jump to #R31763 if #REGa=0
  $7C10 POKE #N(42227,4,,1)($),#REGa
  $7C13 CALL #R31652
  $7C16 #REGa=PEEK #N(42213,4,,1)($)
  $7C19 #REGa=#REGa+1
  $7C1A Jump to #R31778 if #REGa>0
  $7C1C #REGa=PEEK #N(42226,4,,1)($)
  $7C1F POKE #N(42213,4,,1)($),#REGa
  $7C22 #REGa=PEEK #N(42214,4,,1)($)
  $7C25 #REGa=#REGa+1
  $7C26 Jump to #R31790 if #REGa>0
  $7C28 #REGa=PEEK #N(42226,4,,1)($)
  $7C2B POKE #N(42214,4,,1)($),#REGa
  $7C2E Return
c $7C2F
  $7C2F #REGl=PEEK #N(42317,4,,1)($); #REGh=PEEK #N(42318,4,,1)($)
  $7C32 POKE #N(42293,4,,1)($),#REGl; POKE #N(42294,4,,1)($),#REGh
  $7C35 CALL #R31807
  $7C38 #REGhl=#N(25374,4,,1)($)
  $7C3B POKE #N(34930,4,,1)($),#REGl; POKE #N(34931,4,,1)($),#REGh
  $7C3E Return
c $7C3F
  $7C3F CALL #R29383
  $7C42 #REGhl=#N(30602,4,,1)($)
  $7C45 POKE #N(34930,4,,1)($),#REGl; POKE #N(34931,4,,1)($),#REGh
  $7C48 #REGa=#N(1,2,,1)($)
  $7C4A CALL #R25392
  $7C4D #REGa=#N(128,2,,1)($)
  $7C4F POKE #N(42305,4,,1)($),#REGa
  $7C52 #REGa=#N(1,2,,1)($)
  $7C54 CALL #R25392
  $7C57 CALL #R25383
  $7C5A CALL #R31551
  $7C5D #REGl=PEEK #N(42279,4,,1)($); #REGh=PEEK #N(42280,4,,1)($)
  $7C60 CALL #R31079
  $7C63 #REGa=PEEK #N(42215,4,,1)($)
  $7C66 Keep only bit 5 of #REGa
  $7C68 Jump to #R31874 if #REGa>0
  $7C6A CALL #R31754
  $7C6D #REGhl=#N(38577,4,,1)($)
  $7C70 CALL #R34924
  $7C73 CALL #R31609
  $7C76 Jump to #R31837 if the zero flag is not set
  $7C78 CALL #R31491
  $7C7B #REGa=PEEK #N(42215,4,,1)($)
  $7C7E Keep only bit 5 of #REGa
  $7C80 Jump to #R31837 if #REGa=0
  $7C82 #REGc=#N(243,2,,1)($)
  $7C84 CALL #R30008
  $7C87 CALL #R25380
  $7C8A CALL #R25368
  $7C8D Jump to #R31810
b $7C8F
t $7DDF
b $7DE2
t $7ED3
b $7ED6
t $8023
b $8026
t $8042
b $8045
t $8047
b $804C
t $804E
b $8051
t $80CC
b $80D0
t $80DC
b $80E1
c $815B
  $815B Push #REGhl onto the stack
  $815C #REGb=#N(0,2,,1)($)
  $815E #REGa=PEEK #REGhl
  $815F Clear the carry flag and set the zero flag if #REGa=0
  $8160 Jump to #R33135 if #REGa=0
  $8162 #REGa=#N(1,2,,1)($)
  $8164 CALL #R25374
  $8167 #REGa=PEEK #REGhl
  $8168 CALL #R25374
  $816B #REGhl=#REGhl+1
  $816C #REGb=#REGb+1
  $816D Jump to #R33118
  $816F Pop last item from stack into #REGhl
  $8170 Return
c $8171
  $8171 #REGa=#REGb
  $8172 Clear the carry flag and set the zero flag if #REGa=0
  $8173 Return if #REGa=0
  $8174 #REGa=#N(8,2,,1)($)
  $8176 CALL #R25374
  $8179 Decrement #REGb and jump to #R33142 if #REGb>0
  $817B Return
c $817C
  $817C CALL #R33115
  $817F Jump to #R33137
b $8182
c $81BE
  $81BE #REGb=#REGa
  $81BF #REGa=#REGd
  $81C0 Set the zero flag if #REGa=#REGe, or the carry flag if #REGa<#REGe
  $81C1 Jump to #R33224 if #REGa<#REGe
  $81C3 #REGa=#N(7,2,,1)($)
  $81C5 Jump to #R25374
  $81C8 #REGa=#N(1,2,,1)($)
  $81CA CALL #R25374
  $81CD #REGa=#REGb
  $81CE CALL #R25374
  $81D1 Push #REGhl onto the stack
  $81D2 #REGa=PEEK #REGhl
  $81D3 POKE #REGhl,#REGb
  $81D4 #REGhl=#REGhl+1
  $81D5 #REGb=#REGa
  $81D6 Clear the carry flag and set the zero flag if #REGa=0
  $81D7 Jump to #R33234 if #REGa>0
  $81D9 POKE #REGhl,#REGb
  $81DA Pop last item from stack into #REGhl
  $81DB #REGhl=#REGhl+1
  $81DC #REGc=#REGc+1
  $81DD #REGd=#REGd+1
  $81DE Jump to #R33148
c $81E1
  $81E1 Push #REGhl onto the stack
  $81E2 Push #REGde onto the stack
  $81E3 Push #REGbc onto the stack
  $81E4 Push #REGhl onto the stack
  $81E5 #REGd=#N(0,2,,1)($)
  $81E7 #REGa=PEEK #REGhl
  $81E8 Clear the carry flag and set the zero flag if #REGa=0
  $81E9 Jump to #R33263 if #REGa=0
  $81EB #REGhl=#REGhl+1
  $81EC #REGd=#REGd+1
  $81ED Jump to #R33255
  $81EF Pop last item from stack into #REGhl
  $81F0 CALL #R33148
  $81F3 CALL #R25380
  $81F6 CALL #R25368
  $81F9 CALL #R25383
  $81FC Push #REGaf onto the stack
  $81FD Push #REGbc onto the stack
  $81FE Push #REGde onto the stack
  $81FF Push #REGhl onto the stack
  $8200 Push #REGix onto the stack
  $8202 #REGd=#N(0,2,,1)($)
  $8204 #REGa=PEEK #N(23609,4,,1)($)
  $8207 #REGe=#REGa
  $8208 #REGhl=#N(255,4,,1)($)
  $820B CALL #R949
  $820E Pop last item from stack into #REGix
  $8210 Pop last item from stack into #REGhl
  $8211 Pop last item from stack into #REGde
  $8212 Pop last item from stack into #REGbc
  $8213 Pop last item from stack into #REGaf
  $8214 Set the zero flag if #REGa=#N(252,2,,1)($), or the carry flag if #REGa<#N(252,2,,1)($)
  $8216 Jump to #R33332 if #REGa<>#N(252,2,,1)($)
  $8218 CALL #R33115
  $821B #REGa=PEEK #N(23624,4,,1)($)
  $821E Keep only bits 0, 1 and 2 of #REGa
  $8220 Push #REGaf onto the stack
  $8221 #REGhl=#N(39044,4,,1)($)
  $8224 CALL #R34924
  $8227 #REGa=#N(15,2,,1)($)
  $8229 CALL #R25374
  $822C Pop last item from stack into #REGaf
  $822D CALL #R25374
  $8230 Pop last item from stack into #REGbc
  $8231 Pop last item from stack into #REGde
  $8232 Pop last item from stack into #REGhl
  $8233 Return
  $8234 Set the zero flag if #REGa=#N(253,2,,1)($), or the carry flag if #REGa<#N(253,2,,1)($)
  $8236 Jump to #R33346 if #REGa<>#N(253,2,,1)($)
  $8238 #REGa=PEEK #N(23658,4,,1)($)
  $823B Flip bit 3 of #REGa
  $823D POKE #N(23658,4,,1)($),#REGa
  $8240 Jump to #R33267
  $8242 Set the zero flag if #REGa=#N(13,2,,1)($), or the carry flag if #REGa<#N(13,2,,1)($)
  $8244 Jump to #R33353 if #REGa<>#N(13,2,,1)($)
  $8246 Jump to #R33679
  $8249 Set the zero flag if #REGa=#N(127,2,,1)($), or the carry flag if #REGa<#N(127,2,,1)($)
  $824B Jump to #R33362 if #REGa<>#N(127,2,,1)($)
  $824D CALL #R33166
  $8250 Jump to #R33267
  $8252 Set the zero flag if #REGa=#N(16,2,,1)($), or the carry flag if #REGa<#N(16,2,,1)($)
  $8254 Jump to #R33371 if #REGa<>#N(16,2,,1)($)
  $8256 CALL #R33191
  $8259 Jump to #R33360
  $825B Set the zero flag if #REGa=#N(242,2,,1)($), or the carry flag if #REGa<#N(242,2,,1)($)
  $825D Jump to #R33392 if #REGa<>#N(242,2,,1)($)
  $825F #REGa=#REGc
  $8260 Clear the carry flag and set the zero flag if #REGa=0
  $8261 Jump to #R33386 if #REGa>0
  $8263 #REGa=#N(7,2,,1)($)
  $8265 CALL #R25374
  $8268 Jump to #R33369
  $826A #REGhl=#REGhl-1
  $826B #REGc=#REGc-1
  $826C #REGa=#N(8,2,,1)($)
  $826E Jump to #R33381
  $8270 Set the zero flag if #REGa=#N(243,2,,1)($), or the carry flag if #REGa<#N(243,2,,1)($)
  $8272 Jump to #R33413 if #REGa<>#N(243,2,,1)($)
  $8274 #REGa=PEEK #REGhl
  $8275 Clear the carry flag and set the zero flag if #REGa=0
  $8276 Jump to #R33407 if #REGa>0
  $8278 #REGa=#N(7,2,,1)($)
  $827A CALL #R25374
  $827D Jump to #R33384
  $827F #REGhl=#REGhl+1
  $8280 #REGc=#REGc+1
  $8281 #REGa=#N(9,2,,1)($)
  $8283 Jump to #R33402
  $8285 CALL #R33444
  $8288 Jump to #R33405
c $828A
  $828A #REGc=#N(0,2,,1)($)
  $828C Jump to #R33249
b $828F
c $829B
  $829B #REGe=#N(255,2,,1)($)
  $829D Jump to #R33418
b $82A0
c $82A4
  $82A4 Set the zero flag if #REGa=#N(252,2,,1)($), or the carry flag if #REGa<#N(252,2,,1)($)
  $82A6 Return if #REGa=#N(252,2,,1)($)
  $82A7 Set the zero flag if #REGa=#N(128,2,,1)($), or the carry flag if #REGa<#N(128,2,,1)($)
  $82A9 Return if #REGa>=#N(128,2,,1)($)
  $82AA Set the zero flag if #REGa=#N(32,2,,1)($), or the carry flag if #REGa<#N(32,2,,1)($)
  $82AC Return if #REGa<#N(32,2,,1)($)
  $82AD Jump to #R33214
c $82B0
  $82B0 #REGa=PEEK #REGhl
  $82B1 Clear the carry flag and set the zero flag if #REGa=0
  $82B2 Jump to #R31099 if #REGa>0
  $82B5 Push #REGhl onto the stack
  $82B6 #REGhl=#N(0,4,,1)($)
  $82B9 POKE #N(42216,4,,1)($),#REGl; POKE #N(42217,4,,1)($),#REGh
  $82BC Pop last item from stack into #REGhl
  $82BD Return
b $82BE
t $836E
b $8371
c $8378
  $8378 CALL #R29581
  $837B Jump to #R29852
b $837E
c $838F
  $838F CALL #R33115
  $8392 Set the carry flag
  $8393 Jump to #R33328
b $8396
t $839C
b $839F
t $83A6
b $83A9
t $83CC
b $83CF
t $8439
b $843C
t $8455
b $8459
t $848D
b $8490
c $8538
  $8538 #REGhl=#N(34129,4,,1)($)
  $853B POKE #N(23613,4,,1)($),#REGl; POKE #N(23614,4,,1)($),#REGh
  $853E #REGsp=#N(23999,4,,1)($)
  $8541 #REGa=#N(24,2,,1)($)
  $8543 POKE #N(33302,4,,1)($),#REGa
  $8546 #REGhl=#N(65535,4,,1)($)
  $8549 POKE #N(42269,4,,1)($),#REGl; POKE #N(42270,4,,1)($),#REGh
  $854C Jump to #R31791
b $854F
t $8598
b $859B
c $85DC
  $85DC CALL #R33435
  $85DF Return if the carry flag is set
  $85E0 Jump to #R33607
b $85E3
t $8618
b $861B
t $8638
b $863B
c $864B
  $864B Clear the carry flag and set the zero flag if #REGa=0
  $864C Return if #REGa=0
  $864D Set the zero flag if #REGa=#N(32,2,,1)($), or the carry flag if #REGa<#N(32,2,,1)($)
  $864F Return if #REGa=#N(32,2,,1)($)
  $8650 Set the zero flag if #REGa=#N(46,2,,1)($), or the carry flag if #REGa<#N(46,2,,1)($)
  $8652 Return if #REGa=#N(46,2,,1)($)
  $8653 Set the zero flag if #REGa=#N(44,2,,1)($), or the carry flag if #REGa<#N(44,2,,1)($)
  $8655 Return if #REGa=#N(44,2,,1)($)
  $8656 Set the zero flag if #REGa=#N(45,2,,1)($), or the carry flag if #REGa<#N(45,2,,1)($)
  $8658 Return if #REGa=#N(45,2,,1)($)
  $8659 Set the zero flag if #REGa=#N(33,2,,1)($), or the carry flag if #REGa<#N(33,2,,1)($)
  $865B Return if #REGa=#N(33,2,,1)($)
  $865C Set the zero flag if #REGa=#N(63,2,,1)($), or the carry flag if #REGa<#N(63,2,,1)($)
  $865E Return if #REGa=#N(63,2,,1)($)
  $865F Set the zero flag if #REGa=#N(58,2,,1)($), or the carry flag if #REGa<#N(58,2,,1)($)
  $8661 Return
b $8662
t $86D6
b $86D9
c $874F
  $874F Push #REGbc onto the stack
  $8750 #REGc=PEEK #REGhl
  $8751 #REGhl=#REGhl+1
  $8752 #REGa=PEEK #REGhl
  $8753 #REGhl=#REGhl+1
  $8754 #REGb=#REGa
  $8755 Keep only bits 6 and 7 of #REGa
  $8757 Set the zero flag if #REGa=#N(192,2,,1)($), or the carry flag if #REGa<#N(192,2,,1)($)
  $8759 Jump to #R34741 if #REGa=#N(192,2,,1)($)
  $875C Push #REGhl onto the stack
  $875D Push #REGde onto the stack
  $875E Push #REGbc onto the stack
  $875F #REGa=#REGb
  $8760 Keep only bits 0, 1 and 2 of #REGa
  $8762 #REGb=#REGa
  $8763 #REGl=PEEK #N(42289,4,,1)($); #REGh=PEEK #N(42290,4,,1)($)
  $8766 #REGa=#REGb
  $8767 #REGa=#REGa|#REGc
  $8768 Jump to #R34674 if #REGa=0
  $876A #REGe=PEEK #REGhl
  $876B #REGd=#N(0,2,,1)($)
  $876D #REGhl=#REGhl+1
  $876E #REGbc=#REGbc-1
  $876F #REGhl=#REGhl+#REGde
  $8770 Jump to #R34662
  $8772 #REGhl=#REGhl+1
  $8773 Pop last item from stack into #REGbc
  $8774 Pop last item from stack into #REGde
  $8775 #REGa=#REGb
  $8776 Keep only bits 6 and 7 of #REGa
  $8778 Set the zero flag if #REGa=#N(64,2,,1)($), or the carry flag if #REGa<#N(64,2,,1)($)
  $877A Jump to #R34696 if #REGa<>#N(64,2,,1)($)
  $877C #REGa=PEEK #REGhl
  $877D Keep only bit 6 of #REGa
  $877F Set the zero flag if #REGa=#N(64,2,,1)($), or the carry flag if #REGa<#N(64,2,,1)($)
  $8781 #REGa=PEEK #REGhl
  $8782 Jump to #R34706 if the zero flag is not set
  $8784 Set bit 5 of #REGa
  $8786 Jump to #R34706
  $8788 Set the zero flag if #REGa=#N(128,2,,1)($), or the carry flag if #REGa<#N(128,2,,1)($)
  $878A Jump to #R34703 if #REGa<>#N(128,2,,1)($)
  $878C #REGa=PEEK #REGhl
  $878D Jump to #R34706
  $878F #REGa=PEEK #REGhl
  $8790 Set bit 6 of #REGb
  $8792 Reset bit 7 of #REGa
  $8794 POKE #REGde,#REGa
  $8795 #REGa=PEEK #REGhl
  $8796 #REGhl=#REGhl+1
  $8797 #REGde=#REGde+1
  $8798 Keep only bit 7 of #REGa
  $879A Jump to #R34677 if #REGa=0
  $879C #REGa=#REGb
  $879D Keep only bits 3, 4 and 5 of #REGa
  $879F Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $87A0 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $87A1 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $87A2 Push #REGhl onto the stack
  $87A3 #REGhl=#N(41445,4,,1)($)
  $87A6 #REGc=#REGa
  $87A7 #REGb=#N(0,2,,1)($)
  $87A9 #REGhl=#REGhl+#REGbc
  $87AA #REGa=PEEK #REGhl
  $87AB Pop last item from stack into #REGhl
  $87AC POKE #REGde,#REGa
  $87AD #REGde=#REGde+1
  $87AE Pop last item from stack into #REGhl
  $87AF Clear the carry flag and set the zero flag if #REGa=0
  $87B0 Jump to #R34640 if #REGa>0
  $87B3 Pop last item from stack into #REGbc
  $87B4 Return
  $87B5 #REGa=#REGb
  $87B6 Keep only bits 3, 4 and 5 of #REGa
  $87B8 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $87B9 Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $87BA Rotate #REGa right circular (copying bit 0 into bit 7 and into the carry flag)
  $87BB Push #REGbc onto the stack
  $87BC Push #REGhl onto the stack
  $87BD #REGhl=#N(41445,4,,1)($)
  $87C0 #REGc=#REGa
  $87C1 #REGb=#N(0,2,,1)($)
  $87C3 #REGhl=#REGhl+#REGbc
  $87C4 #REGa=PEEK #REGhl
  $87C5 Pop last item from stack into #REGhl
  $87C6 Pop last item from stack into #REGbc
  $87C7 #REGb=#REGc
  $87C8 POKE #REGde,#REGa
  $87C9 #REGde=#REGde+1
  $87CA Clear the carry flag and set the zero flag if #REGa=0
  $87CB Jump to #R34739 if #REGa=0
  $87CD Decrement #REGb and jump to #R34760 if #REGb>0
  $87CF Jump to #R34640
b $87D2
t $87DD
b $87E2
c $886C
  $886C #REGa=PEEK #REGhl
  $886D #REGhl=#REGhl+1
  $886E Set the zero flag if #REGa=#N(255,2,,1)($), or the carry flag if #REGa<#N(255,2,,1)($)
  $8870 Return if #REGa=#N(255,2,,1)($)
  $8871 CALL #R25374
  $8874 Jump to #R34924
b $8876
t $88C9
b $88CD
c $8A24
  $8A24 CALL #R29433
  $8A27 CALL #R35378
  $8A2A Jump to #R35367 if the zero flag is not set
  $8A2C CALL #R35378
  $8A2F Jump to #R35372 if the zero flag is set
  $8A31 Return
c $8A32
  $8A32 #REGa=#REGh
  $8A33 #REGa=#REGa|#REGl
  $8A34 Jump to #R35389 if #REGa=0
  $8A36 Wait for the next interrupt
  $8A37 #REGhl=#REGhl-1
  $8A38 #REGa=PEEK #N(23556,4,,1)($)
  $8A3B #REGa=#REGa+1
  $8A3C Return
  $8A3D Pop last item from stack into #REGhl
  $8A3E Return
c $8A3F
  $8A3F #REGe=PEEK #REGhl
  $8A40 #REGhl=#REGhl+1
  $8A41 #REGd=PEEK #REGhl
  $8A42 #REGhl=#REGhl+1
  $8A43 #REGa=#REGd
  $8A44 #REGa=#REGa|#REGe
  $8A45 Jump to #R35401 if #REGa>0
  $8A47 Set the carry flag
  $8A48 Return
  $8A49 #REGa=#REGe
  $8A4A Set the zero flag if #REGa=#REGc, or the carry flag if #REGa<#REGc
  $8A4B Jump to #R35407 if #REGa<>#REGc
  $8A4D #REGa=#REGd
  $8A4E Set the zero flag if #REGa=#REGb, or the carry flag if #REGa<#REGb
  $8A4F #REGe=PEEK #REGhl
  $8A50 #REGhl=#REGhl+1
  $8A51 #REGd=PEEK #REGhl
  $8A52 #REGhl=#REGhl+1
  $8A53 Do nothing
  $8A54 Do nothing
  $8A55 Return if the zero flag is set
  $8A56 #REGhl=#REGhl+#REGde
  $8A57 Jump to #R35391
c $8A59
  $8A59 #REGa=#N(43,2,,1)($)
  $8A5B POKE #N(35410,4,,1)($),#REGa
  $8A5E POKE #N(35411,4,,1)($),#REGa
  $8A61 POKE #N(35412,4,,1)($),#REGa
  $8A64 CALL #R35391
  $8A67 #REGa=#N(35,2,,1)($)
  $8A69 POKE #N(35410,4,,1)($),#REGa
  $8A6C #REGa=#N(0,2,,1)($)
  $8A6E POKE #N(35411,4,,1)($),#REGa
  $8A71 POKE #N(35412,4,,1)($),#REGa
  $8A74 Return
c $8A75
  $8A75 #REGd=#N(0,2,,1)($)
  $8A77 #REGa=PEEK #REGhl
  $8A78 Clear the carry flag and set the zero flag if #REGa=0
  $8A79 Jump to #R35453 if #REGa>0
  $8A7B Set the carry flag
  $8A7C Return
  $8A7D #REGhl=#REGhl+1
  $8A7E #REGe=PEEK #REGhl
  $8A7F #REGhl=#REGhl+1
  $8A80 Set the zero flag if #REGa=#REGc, or the carry flag if #REGa<#REGc
  $8A81 Return if #REGa=#REGc
  $8A82 #REGhl=#REGhl+#REGde
  $8A83 Jump to #R35447
b $8A85
t $8AA2
b $8AA5
t $8ABE
b $8AC1
t $8B08
b $8B0C
t $8D0B
b $8D0E
t $8D94
b $8D97
t $8DAE
b $8DB1
t $8E07
b $8E0B
t $8E4E
b $8E51
t $8E93
b $8E96
t $8F51
b $8F54
t $8FCE
b $8FD2
t $9017
b $901A
t $903F
b $9042
t $9084
b $9088
t $9095
b $9098
t $90A6
b $90AA
t $90BC
b $90BF
t $910B
b $910E
t $913C
b $9140
t $9261
b $9264
t $9284
b $9288
t $928F
b $9293
t $939D
b $93A0
t $93C2
b $93C6
t $93E4
b $93E8
t $943A
b $943D
t $9464
b $9467
c $95D5
  $95D5 #REGa=PEEK #REGhl
  $95D6 #REGhl=#REGhl+1
  $95D7 Set the zero flag if #REGa=#N(255,2,,1)($), or the carry flag if #REGa<#N(255,2,,1)($)
  $95D9 Return if #REGa=#N(255,2,,1)($)
  $95DA CALL #R25374
  $95DD Jump to #R38357
b $95DF
t $964E
b $9666
t $966A
b $969B
t $96A0
b $96B0
t $96B4
b $96BB
t $96BE
b $96CB
t $96CD
b $96DD
t $96DF
b $96F5
t $9711
s $9719
t $971A
s $9721
t $9722
s $973B
t $973C
s $9741
t $9742
s $9747
t $9748
b $974F
t $9758
b $975E
t $975F
b $9769
t $9771
b $9780
t $9781
s $9798
t $9799
b $97A9
t $97B0
b $97B8
t $97BC
b $97C3
t $97CA
b $97D7
t $97DD
b $97F2
t $97F4
b $9811
t $9813
b $9826
t $982A
b $982D
t $9831
b $9834
t $9846
b $9849
t $984D
b $9850
t $9854
b $9857
t $986B
b $9883
t $9886
b $9889
t $988F
b $98A7
t $98AE
b $98CC
t $98D1
b $98EB
t $98ED
b $98FC
t $9902
b $9911
t $9921
b $993A
t $994B
b $9953
t $9955
b $9959
t $995B
b $995F
t $9960
b $9970
t $9973
b $9983
t $9984
b $998A
t $998D
b $999C
t $99AB
b $99C6
t $99C9
b $99E4
t $99E7
b $99FD
t $9A04
b $9A13
t $9A19
b $9A34
t $9A38
b $9A51
t $9A54
b $9A70
t $9A72
b $9A81
t $9A82
b $9A88
t $9A8E
b $9A9F
t $9AA3
b $9AB5
t $9ABA
b $9AD0
t $9AD2
b $9ADE
t $9AE0
b $9AF8
t $9AFA
b $9B0D
t $9B18
b $9B35
t $9B4E
b $9B5C
t $9B64
b $9B72
t $9B7A
b $9B8A
t $9B8D
b $9BAD
t $9BAF
b $9BC2
t $9BC6
b $9BDE
t $9BE0
b $9BE7
t $9BEC
b $9BFB
t $9C00
b $9C0B
t $9C0F
b $9C25
t $9C27
b $9C2C
t $9C31
b $9C43
t $9C49
b $9C5B
t $9C60
b $9C7E
t $9C82
b $9C9B
t $9C9E
b $9CB2
t $9CB7
b $9CD3
t $9CD6
b $9CE9
t $9CEA
b $9D09
t $9D0B
b $9D14
t $9D17
b $9D27
t $9D30
b $9D39
t $9D40
b $9D47
t $9D4D
b $9D5A
t $9D60
b $9D72
t $9D78
b $9D80
t $9D86
b $9D9E
t $9DA4
b $9DBB
t $9DC1
b $9DC9
t $9DCF
b $9DD4
t $9DDA
b $9DE1
t $9DE7
b $9DF3
t $9DF9
b $9E0A
t $9E10
b $9E1E
t $9E24
b $9E34
t $9E3A
b $9E3F
t $9E45
b $9E56
t $9E5A
b $9E60
t $9E61
b $9E72
t $9E76
b $9E95
t $9E99
b $9EAF
t $9EB3
b $9EB8
t $9EBD
s $9ECE
t $9ECF
s $9EE0
t $9EE1
b $9EE8
t $9EE9
b $9EF5
t $9EFE
b $9F1E
t $9F21
b $9F2F
t $9F31
b $9F3B
t $9F4A
b $9F66
t $9F69
b $9F7D
t $9F7F
b $9F9B
t $9F9D
b $9FA0
t $9FA1
b $9FA4
t $9FA5
b $A0A5
t $A0E8
b $A0F3
t $A0F8
b $A102
t $A107
b $A10E
t $A110
b $A118
t $A11A
b $A11F
t $A121
b $A128
t $A12A
b $A132
t $A135
b $A13D
t $A144
b $A151
t $A15A
b $A15D
t $A162
b $A165
t $A16A
b $A175
t $A176
b $A17B
t $A180
b $A185
t $A190
b $A19B
t $A1A0
b $A1A3
t $A1A4
b $A1A9
t $A1B2
b $A1B9
t $A1C6
b $A1D1
t $A1D2
b $A1D5
t $A1D6
b $A1DE
t $A1DF
b $A1E3
t $A1E6
b $A1ED
t $A689
b $A6A2
t $A6AD
b $A6C4
t $A6CF
b $A6E6
t $A6FC
b $A702
t $A737
b $A740
t $A743
b $A746
t $A75A
b $A75F
t $A7E2
b $A7E9
t $A80F
b $A817
t $A839
b $A841
t $A848
b $A84D
t $A867
b $A86E
t $A88B
b $A88F
t $A890
b $A899
t $A8B5
b $A8BD
t $A8C6
b $A8C9
t $A8E4
b $A8EC
t $A905
b $A908
t $A909
b $A90F
t $A92B
b $A92E
t $A92F
b $A935
t $A94D
b $A950
t $A968
b $A96B
t $A96D
b $A970
t $A971
b $A975
t $A98C
b $A98F
t $A9A4
b $A9A8
t $A9A9
b $A9B0
t $A9DC
b $A9E1
t $A9F5
b $A9F8
t $AA00
b $AA06
t $AA1F
b $AA23
t $AA24
b $AA27
t $AA2A
b $AA2F
t $AA45
b $AA4D
t $AA50
b $AA55
t $AA58
b $AA5B
t $AA83
b $AA89
t $AAA8
b $AAAC
t $AAB0
b $AAB3
t $AACC
b $AAD0
t $AB18
b $AB1B
t $AB2E
b $AB35
t $AB84
b $AB87
t $AB8E
b $AB91
t $ABAE
b $ABB1
t $ABBE
b $ABC1
t $ABC8
b $ABCB
t $ABD1
b $ABD4
t $ABD6
b $ABE1
t $AC0E
b $AC11
t $ACB5
b $ACB8
t $AD1B
b $AD1E
t $ADA9
b $ADAC
t $ADE0
b $ADE3
t $AE41
b $AE44
t $AE79
b $AE7C
t $AE86
b $AE89
t $AEC8
b $AECB
t $AF0C
b $AF0F
t $AF1D
b $AF20
t $AF48
b $AF4B
t $AFA1
b $AFA4
t $B000
b $B003
t $B011
b $B014
t $B055
b $B058
t $B06E
b $B071
t $B07B
b $B07E
t $B0A7
b $B0AA
t $B0BD
b $B0C0
t $B0E8
b $B0EB
t $B112
b $B115
t $B11F
b $B122
t $B1AB
b $B1AE
t $B1C0
b $B1C4
t $B21F
b $B223
t $B22B
b $B234
t $B246
b $B249
t $B28D
b $B290
t $B2A7
b $B2AC
t $B2B7
b $B2BA
t $B2C4
b $B2C7
t $B2C8
b $B2CB
t $B2D6
b $B2D9
t $B2E6
b $B2E9
t $B2F4
b $B2F7
t $B308
b $B30C
t $B38E
b $B391
t $B39C
b $B39F
t $B3B6
b $B3B9
t $B42B
b $B42E
t $B437
b $B43A
t $B443
b $B446
t $B457
b $B45C
t $B46E
b $B472
t $B486
b $B490
t $B4A1
b $B4A4
t $B4A5
b $B4A8
t $B4CE
b $B4D2
t $B4E9
b $B4EE
t $B4FB
b $B4FE
t $B547
b $B54A
t $B55F
b $B562
t $B565
b $B56A
t $B5AB
b $B5B0
t $B5C9
b $B5CC
t $B5E3
b $B5E6
t $B5EF
b $B5F2
t $B5F8
b $B5FB
t $B603
b $B606
t $B60F
b $B612
t $B61F
b $B622
t $B626
b $B629
t $B62B
b $B62E
t $B62F
b $B633
t $B63A
b $B63E
t $B63F
b $B644
t $B648
b $B64C
t $B64D
b $B652
t $B65B
b $B660
t $B667
b $B66A
t $B67F
b $B682
t $B685
b $B688
t $B6A3
b $B6A6
t $B6B5
b $B6B8
t $B6CA
b $B6CE
t $B6CF
b $B6D4
t $B6E6
b $B6EC
t $B6FE
b $B701
t $B704
b $B708
t $B70B
b $B712
t $B713
b $B716
t $B71D
b $B722
t $B723
b $B726
t $B72A
b $B72D
t $B72E
b $B732
t $B735
b $B738
t $B739
b $B73D
t $B73E
b $B742
t $B74D
b $B753
t $B754
b $B762
t $B767
b $B76A
t $B76E
b $B771
t $B777
b $B77A
t $B77B
b $B782
t $B784
b $B788
t $B789
b $B78C
t $B78E
b $B796
t $B7A2
b $B7A5
t $B7A9
b $B7BC
t $B7BF
b $B7C2
t $B7C5
b $B7CB
t $B7D5
b $B7D8
t $B7D9
b $B7DC
t $B7DF
b $B7E6
t $B7E7
b $B7EA
t $B7EF
b $B7F6
t $B7FC
b $B802
t $B807
b $B80F
t $B814
b $B817
t $B81B
b $B81E
t $B81F
b $B824
t $B82F
b $B839
t $B83B
b $B83E
t $B83F
b $B844
t $B84A
b $B84D
t $B85A
b $B866
t $B869
b $B86E
t $B875
b $B87A
t $B87E
b $B881
t $B882
b $B886
t $B889
b $B891
t $B894
b $B898
t $B89B
b $B89E
t $B89F
b $B8A2
t $B8C7
b $B8CB
t $B8D5
b $B8D8
t $B8DD
b $B8E2
t $B8F3
b $B8F6
t $B8F9
b $B8FC
t $B904
b $B908
t $B909
b $B912
t $B927
b $B92A
t $B92D
b $B931
t $B937
b $B93B
t $B950
b $B954
t $B967
b $B96A
t $B96D
b $B974
t $B988
b $B98E
t $B9AC
b $B9AF
t $B9B0
b $B9B8
t $B9BC
b $B9C4
t $B9CB
b $B9CE
t $B9DB
b $B9DE
t $B9E2
b $B9E5
t $B9E7
b $B9EC
t $B9ED
b $B9F6
t $B9F7
b $B9FC
t $B9FD
b $BA00
t $BA07
b $BA0C
t $BA11
b $BA16
t $BA23
b $BA26
t $BA2F
b $BA32
t $BA50
b $BA56
t $BA5A
b $BA5E
t $BA64
b $BA67
t $BA71
b $BA74
t $BA75
b $BA7A
t $BA7B
b $BA82
t $BA86
b $BA89
t $BA95
b $BA98
t $BAA8
b $BAAB
t $BAB5
b $BABA
t $BABB
b $BABE
t $BAC3
b $BACA
t $BACE
b $BAD1
t $BADB
b $BADE
t $BAE1
b $BAEA
t $BAEB
b $BAEF
t $BAF0
b $BAF4
t $BB0C
b $BB0F
t $BB48
b $BB4C
t $BB4F
b $BB54
t $BB5A
b $BB62
t $BB6A
b $BB70
t $BB7F
b $BB86
t $BB89
b $BB90
t $BB9A
b $BBA2
t $BBA7
b $BBAA
t $BBAC
b $BBB4
t $BBBE
b $BBC8
t $BBCD
b $BBD0
t $BBE4
b $BBE8
t $BBEE
b $BBF6
t $BBFF
b $BC02
t $BC08
b $BC12
t $BC13
b $BC18
t $BC19
b $BC1D
t $BC1E
b $BC26
t $BC2A
b $BC2D
t $BC31
b $BC36
t $BC3F
b $BC47
t $BC4F
b $BC56
t $BC5C
b $BC61
t $BC76
b $BC7C
t $BC82
b $BC88
t $BC95
b $BC98
t $BC9F
b $BCA2
t $BCAF
b $BCB2
t $BCBD
b $BCC0
t $BCEC
b $BCF0
t $BCF9
b $BCFC
t $BD07
b $BD0A
t $BD11
b $BD16
t $BD21
b $BD24
t $BD2B
b $BD2E
t $BD33
b $BD37
t $BD3F
b $BD42
t $BD4A
b $BD4E
t $BD5E
b $BD62
t $BD63
b $BD66
t $BD67
b $BD6A
t $BD6B
b $BD6E
t $BD77
b $BD80
t $BD87
b $BD8A
t $BD8D
b $BD90
t $BDA3
b $BDA6
t $BDB3
b $BDB6
t $BDB7
b $BDBA
t $BDBD
b $BDC0
t $BDC1
b $BDC4
t $BDD5
b $BDD8
t $BDE3
b $BDE6
t $BDF3
b $BDF6
t $BDFD
b $BE00
t $BE0B
b $BE14
t $BE33
b $BE36
t $BE3D
b $BE40
t $BE44
b $BE48
t $BE49
b $BE4C
t $BE63
b $BE66
t $BE69
b $BE6C
t $BE71
b $BE74
t $BE87
b $BE8A
t $BEA7
b $BEAA
t $BEB3
b $BEB8
t $BEB9
b $BEBC
t $BEE7
b $BEEE
t $BEF9
b $BEFC
t $BF03
b $BF06
t $BF07
b $BF0C
t $BF0D
b $BF12
t $BF1F
b $BF24
t $BF2D
b $BF32
t $BF33
b $BF3C
t $BF3D
b $BF42
t $BF43
b $BF46
t $BF57
b $BF5A
t $C0D4
b $C0D7
t $C0D8
b $C0DC
t $C0DD
b $C0E1
t $C0E2
b $C0E6
t $C0E7
b $C0EB
t $C0EC
b $C0F0
t $C0F1
b $C0F5
t $C100
b $C104
t $C105
b $C109
t $C10A
b $C10E
t $C10F
b $C113
t $C114
b $C118
t $C244
b $C247
t $C248
b $C24C
t $C24D
b $C251
t $C252
b $C256
t $C257
b $C25B
t $C25C
b $C260
t $C261
b $C265
t $C266
b $C26A
t $C26B
b $C26F
t $C275
b $C279
t $C27A
b $C27E
t $C27F
b $C283
t $C29D
b $C2A1
t $C2A2
b $C2A6
t $C2A7
b $C2AB
t $C2AC
b $C2B0
t $C2B1
b $C2B4
t $C2BB
b $C2BF
t $C2C0
b $C2C4
t $C2C5
b $C2C8
t $C2CF
b $C2D3
t $C2D4
b $C2D8
t $C2D9
b $C2DD
t $C2DE
b $C2E2
t $C2E3
b $C2E7
t $C2EB
b $C2EF
t $C2F0
b $C2F4
t $C2F5
b $C2F9
t $C2FA
b $C2FE
t $C2FF
b $C303
t $C332
b $C335
t $C336
b $C33A
t $C33B
b $C33F
t $C340
b $C344
t $C345
b $C349
t $C34A
b $C34D
t $C354
b $C358
t $C359
b $C35D
t $C380
b $C384
t $C385
b $C388
t $C38F
b $C392
t $C3A3
b $C3A7
t $C3AD
b $C3B1
t $C3B7
b $C3BA
t $C3BC
b $C3C0
t $C3C1
b $C3C5
t $C3CB
b $C3CF
t $C3D0
b $C3D3
t $C457
b $C45A
t $C45C
b $C460
t $C4FC
b $C4FF
t $C500
b $C504
t $C505
b $C509
t $C54E
b $C552
t $C5C6
b $C5C9
t $C5CF
b $C5D3
t $C62A
b $C62D
t $C62E
b $C631
t $C633
b $C637
t $C638
b $C63C
t $C64C
b $C64F
t $C7F3
b $C7F6
t $C87C
b $C87F
t $C885
b $C889
t $C890
b $C893
t $C894
b $C898
t $C899
b $C89D
t $C8BC
b $C8C0
t $C8C1
b $C8C5
t $C945
b $C948
t $C94A
b $C94D
t $C94E
b $C952
t $C953
b $C957
t $C95D
b $C961
t $C962
b $C965
t $C971
b $C975
t $C976
b $C97A
t $C97B
b $C97F
t $C98A
b $C98E
t $C994
b $C998
t $C999
b $C99D
t $C99E
b $C9A2
t $C9A3
b $C9A7
t $C9AD
b $C9B1
t $C9CC
b $C9D0
t $C9D1
b $C9D5
t $C9D6
b $C9DA
t $C9F4
b $C9F8
t $CA15
b $CA19
t $CA1A
b $CA1E
t $CA75
b $CA78
t $CAA9
b $CAAC
t $CABE
b $CAC1
t $CAC2
b $CAC6
t $CAC7
b $CACA
t $CACC
b $CAD0
t $CAE0
b $CAE4
t $CB76
b $CB79
t $CBA2
b $CBA6
t $CBD9
b $CBDD
t $CBDE
b $CBE2
t $CBE3
b $CBE7
t $CBE8
b $CBEC
t $CBED
b $CBF1
t $CBF2
b $CBF6
t $CBF7
b $CBFB
t $CBFC
b $CC00
t $CC01
b $CC05
t $CC06
b $CC0A
t $CC16
b $CC19
t $CC1A
b $CC1E
t $CC1F
b $CC23
t $CC24
b $CC28
t $CC29
b $CC2D
t $CC2E
b $CC32
t $CC33
b $CC37
t $CC38
b $CC3C
t $CC3D
b $CC41
t $CCD8
b $CCDB
t $CCE2
b $CCE5
t $CCEC
b $CCEF
t $CCF6
b $CCFA
t $CCFB
b $CCFE
t $CD0F
b $CD12
t $CD19
b $CD1C
t $CD23
b $CD26
t $CEA3
b $CEA7
t $CEBA
b $CEBD
t $CED3
b $CED6
t $CEFB
b $CEFE
t $CF00
b $CF04
t $CF0B
b $CF0E
t $CF32
b $CF36
t $CF8B
b $CF8E
t $CF8F
b $CF93
t $CF94
b $CF98
t $CF99
b $CF9D
t $CF9E
b $CFA2
t $CFA3
b $CFA7
t $CFA8
b $CFAC
t $CFAD
b $CFB1
t $CFB2
b $CFB6
t $D15C
b $D15F
t $D166
b $D169
t $D17E
b $D182
t $D183
b $D187
t $D226
b $D229
t $D23A
b $D23D
t $D24E
b $D251
t $D258
b $D25C
t $D25D
b $D261
t $D2A4
b $D2A7
t $D2AE
b $D2B2
t $D2B3
b $D2B7
t $D2B8
b $D2BC
t $D2C8
b $D2CB
t $D2CD
b $D2D1
t $D2D2
b $D2D6
t $D2DC
b $D2DF
t $D355
b $D359
t $D35F
b $D362
t $D36C
b $D36F
t $D371
b $D375
t $D377
b $D37A
t $D37E
b $D382
t $D388
b $D38C
t $D38D
b $D391
t $D39B
b $D39E
t $D3A4
b $D3A8
t $D494
b $D497
t $D498
b $D49C
t $D49D
b $D4A1
t $D4A2
b $D4A6
t $D4A7
b $D4AB
t $D4C6
b $D4C9
t $D4CA
b $D4CE
t $D4CF
b $D4D3
t $D4D4
b $D4D8
t $D4D9
b $D4DC
t $D50C
b $D50F
t $D585
b $D588
t $D598
b $D59B
t $D5A2
b $D5A5
t $D5BC
b $D5C0
t $D5D7
b $D5DA
t $D614
b $D617
t $D619
b $D61D
t $D673
b $D677
t $D678
b $D67C
t $D6D1
b $D6D5
t $D704
b $D707
t $D708
b $D70C
t $D70D
b $D711
t $D71F
b $D723
t $D776
b $D779
t $D836
b $D839
t $D83F
b $D843
t $D844
b $D848
t $D84E
b $D852
t $D85D
b $D861
t $D862
b $D866
t $D87C
b $D880
t $D8D0
b $D8D3
t $D8D9
b $D8DD
t $D8DE
b $D8E2
t $D8F8
b $D8FB
t $D906
b $D90A
t $D90B
b $D90F
t $DB38
b $DB3B
t $DB3C
b $DB40
t $DB50
b $DB54
t $DBA8
b $DBAB
t $DBAC
b $DBAF
t $DBCB
b $DBCE
t $DC96
b $DC9A
t $DCA0
b $DCA4
t $DCB9
b $DCBC
t $DD0A
b $DD0D
t $DD0E
b $DD12
t $DD13
b $DD17
t $DD18
b $DD1B
t $DD1D
b $DD21
t $DD22
b $DD26
t $DD27
b $DD2B
t $DD2C
b $DD2F
t $DD3B
b $DD3F
t $DD40
b $DD44
t $DD4A
b $DD4E
t $DD67
b $DD6B
t $DD6C
b $DD70
t $DD71
b $DD75
t $DD80
b $DD84
t $DD8D
b $DD91
t $DD92
b $DD96
t $DD97
b $DD9B
t $DD9C
b $DD9F
t $DDA9
b $DDAD
t $DDAE
b $DDB2
t $DDB3
b $DDB7
t $DDB8
b $DDBC
t $DDBD
b $DDC1
t $DDC2
b $DDC6
t $DDCA
b $DDCD
t $DDD4
b $DDD8
t $DDD9
b $DDDD
t $DDDE
b $DDE2
t $DDE3
b $DDE6
t $DDE8
b $DDEB
t $DFCE
b $DFD1
t $DFD2
b $DFD5
t $DFE7
b $DFEA
t $DFEB
b $DFEF
t $DFF5
b $DFF8
t $E054
b $E058
t $E072
b $E075
t $E08B
b $E08E
t $E1A7
b $E1AB
t $E1AC
b $E1B0
t $E21E
b $E221
t $E27F
b $E283
t $E289
b $E28D
t $E28E
b $E292
t $E293
b $E297
t $E298
b $E29C
t $E29D
b $E2A1
t $E2AC
b $E2AF
t $E2B0
b $E2B4
t $E2B5
b $E2B9
t $E2BA
b $E2BE
t $E2C2
b $E2C6
t $E482
b $E485
t $E5A2
b $E5A6
t $E5B0
b $E5B3
t $E5B7
b $E5BB
t $E5C0
b $E5C5
t $E5CA
b $E5CD
t $E5CF
b $E5D5
t $E5D6
b $E5F6
t $E5F8
b $E5FD
t $E5FF
b $E603
t $E60C
b $E610
t $E612
b $E617
t $E619
b $E61D
t $E61F
b $E623
t $E629
b $E62D
t $E62F
b $E632
t $E634
b $E638
t $E63A
b $E63E
t $E640
b $E643
t $E645
b $E64A
t $E64C
b $E650
t $E658
b $E65C
t $E65E
b $E663
t $E665
b $E669
t $E66B
b $E670
t $E672
b $E67A
t $E67C
b $E67F
t $E684
b $E68D
t $E695
b $E69B
t $E69D
b $E6A2
t $E6A8
b $E6AB
t $E6AD
b $E6B5
t $E6B7
b $E6BD
t $E6BF
b $E6C3
t $E6C9
b $E6CD
t $E6CF
b $E6D9
t $E6DE
b $E6E2
t $E6E8
b $E6ED
t $E6F2
b $E6FB
t $E704
b $E709
t $E70B
b $E710
t $E712
b $E715
t $E717
b $E71A
t $E71C
b $E720
t $E726
b $E72A
t $E730
b $E736
t $E738
b $E743
t $E745
b $E74B
t $E74D
b $E753
t $E755
b $E75A
t $E75C
b $E75F
t $E767
b $E76C
t $E771
b $E775
t $E777
b $E77E
t $E780
b $E786
t $E788
b $E78F
t $E791
b $E795
t $E79B
b $E7A1
t $E7AE
b $E7B2
t $E7B4
b $E7BA
t $E7C0
b $E7C6
t $E7C8
b $E7CE
t $E7D4
b $E7D9
t $E7DB
b $E7E3
t $E7E9
b $E7ED
t $E7EF
b $E7F6
t $E7F8
b $E7FD
t $E7FF
b $E803
t $E805
b $E809
t $E80B
b $E80F
t $E811
b $E814
t $E816
b $E819
t $E81D
b $E820
t $E824
b $E827
t $E829
b $E833
t $E835
b $E839
t $E83B
b $E83F
t $E841
b $E846
t $E848
b $E84E
t $E850
b $E856
t $E858
b $E85B
t $E85D
b $E862
t $E868
b $E86F
t $E871
b $E879
t $E87B
b $E881
t $E887
b $E894
t $E896
b $E89A
t $E89C
b $E8A0
t $E8A4
b $E8E3
t $E8E5
b $E8E8
t $E8EA
b $E8EE
t $E8F0
b $E8F4
t $E8FA
b $E900
t $E902
b $E905
t $E907
b $E912
t $E914
b $E91C
t $E91E
b $E924
t $E926
b $E92E
t $E930
b $E933
t $E935
b $E939
t $E93B
b $E941
t $E943
b $E94A
t $E94C
b $E950
t $E952
b $E959
t $E95B
b $E964
t $E966
b $E96A
t $E96C
b $E974
t $E976
b $E97C
t $E982
b $E986
t $E988
b $E98D
t $E98F
b $E993
t $E999
b $E99F
t $E9A1
b $E9A8
t $E9AA
b $E9B1
t $E9B3
b $E9BA
t $E9BC
b $E9C1
t $E9C3
b $E9CF
t $E9D1
b $E9D5
t $E9D7
b $E9DC
t $E9DE
b $E9E6
t $E9E8
b $E9ED
t $E9EF
b $E9F3
t $E9F7
b $E9FA
t $E9FC
b $EA02
t $EA04
b $EA0D
t $EA0F
b $EA15
t $EA17
b $EA1B
t $EA1D
b $EA27
t $EA29
b $EA30
t $EA32
b $EA35
t $EA37
b $EA3E
t $EA40
b $EA44
t $EA46
b $EA4C
t $EA51
b $EA57
t $EA5D
b $EA61
t $EA6B
b $EA6F
t $EA71
b $EA74
t $EA76
b $EA7C
t $EA7E
b $EA81
t $EA83
b $EA87
t $EA90
b $EA93
t $EA95
b $EA98
t $EAA0
b $EAA4
t $EAAA
b $EAB3
t $EAB5
b $EABB
t $EABD
b $EAC6
t $EAC8
b $EACC
t $EAD2
b $EAD8
t $EADA
b $EAE4
t $EAE8
b $EAEC
t $EAEE
b $EAF3
t $EAF5
b $EAFC
t $EAFE
b $EB04
t $EB06
b $EB0A
t $EB0C
b $EB10
t $EB12
b $EB17
t $EB19
b $EB1E
t $EB20
b $EB27
t $EB29
b $EB2C
t $EB2E
b $EB35
t $EB37
b $EB3B
t $EB3D
b $EB42
t $EB44
b $EB49
t $EB4B
b $EB4F
t $EB51
b $EB54
t $EB56
b $EB60
t $EB62
b $EB66
t $EB68
b $EB6F
t $EB71
b $EB7C
t $EB85
b $EB8D
t $EB92
b $EB97
t $EB99
b $EB9F
t $EBA3
b $EBAC
t $EBAE
b $EBB3
t $EBB5
b $EBBD
t $EBBF
b $EBC6
t $EBC8
b $EBCE
t $EBD0
b $EBE0
t $EBE2
b $EBE7
t $EBE9
b $EBEF
t $EBF4
b $EBF9
t $EBFB
b $EC02
t $EC04
b $EC09
t $EC0B
b $EC11
t $EC13
b $EC19
t $EC1B
b $EC20
t $EC22
b $EC26
t $EC28
b $EC30
t $EC32
b $EC38
t $EC41
b $EC49
t $EC4B
b $EC4E
t $EC50
b $EC56
t $EC58
b $EC5E
t $EC66
b $EC70
t $EC72
b $EC7E
t $EC80
b $EC83
t $EC85
b $EC89
t $EC8B
b $EC8F
t $EC91
b $EC97
t $EC99
b $EC9C
t $EC9E
b $ECA5
t $ECA7
b $ECAD
t $ECAF
b $ECB4
t $ECB6
b $ECBF
t $ECC1
b $ECC5
t $ECC7
b $ECCB
t $ECCD
b $ECD4
t $ECD6
b $ECDA
t $ECDC
b $ECE1
t $ECE5
b $ECEC
t $ECEE
b $ECF3
t $ECF5
b $ECFB
t $ECFD
b $ED06
t $ED08
b $ED0D
t $ED0F
b $ED18
t $ED1A
b $ED23
t $ED25
b $ED2B
t $ED2D
b $ED32
t $ED34
b $ED37
t $ED39
b $ED3D
t $ED3F
b $ED45
t $ED47
b $ED4B
t $ED4D
b $ED54
t $ED56
b $ED59
t $ED5B
b $ED63
t $ED65
b $ED6E
t $ED70
b $ED75
t $ED77
b $ED7D
t $ED7F
b $ED84
t $ED86
b $ED8B
t $ED8D
b $ED93
t $ED9D
b $EDA2
t $EDA4
b $EDAB
t $EDAD
b $EDB2
t $EDB4
b $EDB9
t $EDBB
b $EDBF
t $EDC5
b $EDCB
t $EDCD
b $EDD0
t $EDD2
b $EDD6
t $EDD8
b $EDDC
t $EDDE
b $EDE5
t $EDE7
b $EDEA
t $EDEC
b $EDF0
t $EDF2
b $EDFA
t $EDFC
b $EE03
t $EE05
b $EE0B
t $EE0D
b $EE15
t $EE1A
b $EE1D
t $EE1F
b $EE23
t $EE25
b $EE28
t $EE2A
b $EE2D
t $EE2F
b $EE33
t $EE35
b $EE3A
t $EE3C
b $EE41
t $EE43
b $EE49
t $EE4B
b $EE50
t $EE52
b $EE59
t $EE5B
b $EE60
t $EE66
b $EE6E
t $EE70
b $EE78
t $EE7A
b $EE7E
t $EE80
b $EE86
t $EE88
b $EE92
t $EE94
b $EE9A
t $EE9C
b $EEA1
t $EEA3
b $EEAC
t $EEAE
b $EEB3
t $EEB5
b $EEBC
t $EEBE
b $EEC5
t $EEC7
b $EECB
t $EECD
b $EED3
t $EED5
b $EEDA
t $EEDC
b $EEE0
t $EEE2
b $EEE7
t $EEE9
b $EEF7
t $EEF9
b $EF00
t $EF02
b $EF05
t $EF07
b $EF0C
t $EF0E
b $EF14
t $EF16
b $EF1C
t $EF1E
b $EF24
t $EF26
b $EF29
t $EF2B
b $EF2F
t $EF31
b $EF3A
t $EF3C
b $EF48
t $EF4A
b $EF4F
t $EF51
b $EF54
t $EF56
b $EF66
t $EF68
b $EF6B
t $EF6D
b $EF73
t $EF75
b $EF7C
t $EF7E
b $EF86
t $EF88
b $EF8D
t $EF92
b $EF9A
t $EF9C
b $EF9F
t $EFA1
b $EFA5
t $EFA7
b $EFAA
t $EFAC
b $EFB2
t $EFB4
b $EFBD
t $EFBF
b $EFC6
t $EFC8
b $EFD0
t $EFD2
b $EFD6
t $EFD8
b $EFDC
t $EFDE
b $EFE1
t $EFE3
b $EFE9
t $EFEB
b $EFEE
t $EFF0
b $EFF8
t $EFFA
b $F002
t $F004
b $F008
t $F00A
b $F00D
t $F00F
b $F013
t $F015
b $F01E
t $F020
b $F025
t $F027
b $F02E
t $F030
b $F035
t $F037
b $F03E
t $F040
b $F048
t $F04A
b $F057
t $F059
b $F05D
t $F05F
b $F063
t $F065
b $F069
t $F06B
b $F071
t $F073
b $F07D
t $F07F
b $F084
t $F08A
b $F092
t $F094
b $F099
t $F09B
b $F0A0
t $F0A2
b $F0AA
t $F0AC
b $F0B2
t $F0B4
b $F0B8
t $F0BA
b $F0C1
t $F0C3
b $F0CB
t $F0CD
b $F0D4
t $F0D6
b $F0DC
t $F0DE
b $F0E4
t $F0E6
b $F0EB
t $F0ED
b $F0F7
t $F0F9
b $F0FE
t $F100
b $F105
t $F107
b $F113
t $F115
b $F119
t $F11B
b $F122
t $F124
b $F12C
t $F12E
b $F134
t $F136
b $F13F
t $F141
b $F147
t $F149
b $F14E
t $F150
b $F157
t $F159
b $F165
t $F167
b $F16B
t $F16D
b $F173
t $F175
b $F17D
t $F17F
b $F187
t $F189
b $F190
t $F192
b $F19A
t $F1A0
b $F1A7
t $F1A9
b $F1AE
t $F1B0
b $F1B5
t $F1B7
b $F1C0
t $F1C2
b $F1C8
t $F1CA
b $F1D4
t $F1D6
b $F1DA
t $F1DC
b $F1E3
t $F1E5
b $F1EB
t $F1ED
b $F1F7
t $F1F9
b $F200
t $F202
b $F206
t $F208
b $F20D
t $F20F
b $F213
t $F215
b $F21A
t $F21C
b $F21F
t $F221
b $F224
t $F226
b $F233
t $F235
b $F23D
t $F23F
b $F245
t $F247
b $F24D
t $F24F
b $F252
t $F254
b $F257
t $F259
b $F25C
t $F25E
b $F263
t $F265
b $F26F
t $F279
b $F27E
t $F280
b $F283
t $F285
b $F288
t $F28A
b $F28D
t $F28F
b $F293
t $F295
b $F29D
t $F29F
b $F2A3
t $F2A5
b $F2AE
t $F2B0
b $F2B3
t $F2B5
b $F2B8
t $F2BA
b $F2BE
t $F2C0
b $F2C7
t $F2C9
b $F2D6
t $F2D8
b $F2DC
t $F2DE
b $F2E5
t $F2E7
b $F2EA
t $F2EC
b $F2F3
t $F2F5
b $F2F9
t $F2FB
b $F2FE
t $F300
b $F309
t $F30B
b $F312
t $F314
b $F31B
t $F31D
b $F322
t $F324
b $F32A
t $F32C
b $F335
t $F337
b $F33A
t $F33C
b $F340
t $F342
b $F348
t $F34A
b $F351
t $F353
b $F357
t $F359
b $F35F
t $F360
b $F388
t $F38A
b $F391
t $F393
b $F398
t $F39A
b $F39E
t $F3A0
b $F3A7
t $F3A9
b $F3AE
t $F3B4
b $F3BE
t $F3C0
b $F3C5
t $F3C7
b $F3D1
t $F3D3
b $F3D6
t $F3D8
b $F3DC
t $F3DE
b $F3E6
t $F3E8
b $F3F2
t $F3F4
b $F3F9
t $F3FB
b $F3FF
t $F401
b $F408
t $F40A
b $F414
t $F416
b $F41D
t $F41F
b $F426
t $F428
b $F42D
t $F42F
b $F435
t $F437
b $F43C
t $F43E
b $F442
t $F444
b $F447
t $F449
b $F44E
t $F452
b $F459
t $F45B
b $F45F
t $F461
b $F467
t $F469
b $F46D
t $F46F
b $F476
t $F478
b $F47F
t $F481
b $F486
t $F488
b $F496
t $F498
b $F49C
t $F49E
b $F4A1
t $F4A7
b $F4AE
t $F4B0
b $F4B6
t $F4B8
b $F4BD
t $F4BF
b $F4C3
t $F4C5
b $F4C9
t $F4CB
b $F4D1
t $F4D3
b $F4D7
t $F4D9
b $F4DF
t $F4E1
b $F4EB
t $F4ED
b $F4F2
t $F4F4
b $F4F8
t $F4FA
b $F500
t $F502
b $F507
t $F509
b $F510
t $F515
b $F51A
t $F51C
b $F524
t $F526
b $F529
t $F52B
b $F52E
t $F530
b $F534
t $F536
b $F539
t $F53B
b $F541
t $F543
b $F546
t $F548
b $F54C
t $F551
b $F558
t $F55A
b $F55F
t $F561
b $F566
t $F568
b $F56C
t $F56E
b $F574
t $F576
b $F57C
t $F57E
b $F58B
t $F58D
b $F593
t $F597
b $F59C
t $F59E
b $F5A6
t $F5A8
b $F5AF
t $F5B1
b $F5B4
t $F5B6
b $F5CB
t $F5CD
b $F5EB
t $F5ED
b $F5F4
t $F5FA
b $F5FF
t $F601
b $F605
t $F607
b $F60B
t $F60D
b $F612
t $F614
b $F619
t $F61B
b $F61F
t $F621
b $F624
t $F626
b $F629
t $F62B
b $F62E
t $F630
b $F633
t $F635
b $F63E
t $F640
b $F646
t $F648
b $F64E
t $F653
b $F65C
t $F65E
b $F661
t $F663
b $F66D
t $F66F
b $F674
t $F676
b $F694
t $F696
b $F699
t $F69B
b $F69F
t $F6A1
b $F6A4
t $F6A6
b $F6AE
t $F6B0
b $F6B3
t $F6B5
b $F6BA
t $F6BC
b $F6C0
t $F6C6
b $F6C9
t $F6CB
b $F6D4
t $F6D6
b $F6DF
t $F6E1
b $F6E5
t $F6E7
b $F6EE
t $F6F0
b $F6F9
t $F6FB
b $F702
t $F704
b $F70A
t $F70C
b $F711
t $F713
b $F716
t $F718
b $F71D
t $F71F
b $F725
t $F727
b $F72F
t $F731
b $F738
t $F73A
b $F73F
t $F741
b $F747
t $F749
b $F74F
t $F751
b $F754
t $F756
b $F760
t $F762
b $F769
t $F76B
b $F777
t $F779
b $F77C
t $F77E
b $F783
t $F785
b $F789
t $F78B
b $F795
t $F797
b $F79C
t $F79E
b $F7A3
t $F7A9
b $F7AE
t $F7B0
b $F7B6
t $F7B8
b $F7BC
t $F7BE
b $F7C2
t $F7C4
b $F7C9
t $F7CB
b $F7D3
t $F7D5
b $F7DC
t $F7DE
b $F7E4
t $F7E6
b $F7EE
t $F7F2
b $F7F7
t $F7F9
b $F7FF
t $F801
b $F804
t $F806
b $F80F
t $F811
b $F81B
t $F81D
b $F822
t $F824
b $F82B
t $F82D
b $F831
t $F833
b $F838
t $F83A
b $F840
t $F842
b $F846
t $F848
b $F84D
t $F84F
b $F852
t $F854
b $F85A
t $F85C
b $F861
t $F863
b $F868
t $F86A
b $F872
t $F874
b $F87F
t $F885
b $F88D
t $F88F
b $F895
t $F897
b $F89C
t $F89E
b $F8A4
t $F8A6
b $F8AD
t $F8AF
b $F8B4
t $F8B6
b $F8BD
t $F8BF
b $F8C5
t $F8C7
b $F8CC
t $F8CE
b $F8D3
t $F8D5
b $F8DA
t $F8DC
b $F8E4
t $F8E6
b $F8E9
t $F8EB
b $F8F3
t $F8F5
b $F8FA
t $F8FC
b $F8FF
t $F901
b $F909
t $F90B
b $F90F
t $F911
b $F91A
t $F91F
b $F922
t $F928
b $F92D
t $F92F
b $F938
t $F93A
b $F940
t $F946
b $F94C
t $F94E
b $F955
t $F957
b $F95A
t $F95C
b $F961
t $F963
b $F969
t $F96B
b $F96E
t $F970
b $F974
t $F979
b $F981
t $F983
b $F987
t $F989
b $F98D
t $F98F
b $F995
t $F997
b $F99D
t $F99F
b $F9A4
t $F9A6
b $F9AA
t $F9B0
b $F9B6
t $F9B8
b $F9BE
t $F9C0
b $F9C4
t $F9C6
b $F9C9
t $F9CB
b $F9CF
t $F9D1
b $F9D9
t $F9DB
b $F9DF
t $F9E1
b $F9EB
t $F9F0
b $F9F5
t $F9F7
b $F9FB
t $F9FD
b $FA05
t $FA07
b $FA0B
t $FA0D
b $FA10
t $FA12
b $FA19
t $FA1B
b $FA1F
t $FA21
b $FA26
t $FA28
b $FA31
t $FA33
b $FA37
t $FA39
b $FA40
t $FA42
b $FA48
t $FA4A
b $FA4F
t $FA51
b $FA55
t $FA57
b $FA60
t $FA62
b $FA65
t $FA67
b $FA74
t $FA76
b $FA7B
t $FA7D
b $FA80
t $FA82
b $FA8D
t $FA8F
b $FA96
t $FA98
b $FA9E
t $FAA0
b $FAA4
t $FAAA
b $FAAE
t $FAB0
b $FAB6
t $FAB8
b $FABD
t $FABF
b $FAC6
t $FAC8
b $FACE
t $FAD0
b $FAD4
t $FAD6
b $FAD9
t $FADB
b $FAE4
t $FAE6
b $FAEC
t $FAEE
b $FAF8
t $FAFA
b $FAFE
t $FB00
b $FB05
t $FB07
b $FB11
t $FB13
b $FB16
t $FB18
b $FB1E
t $FB20
b $FB23
t $FB29
b $FB2D
t $FB2F
b $FB32
t $FB34
b $FB39
t $FB3B
b $FB42
t $FB44
b $FB4A
t $FB4C
b $FB53
t $FB55
b $FB5B
t $FB5D
b $FB65
t $FB67
b $FB6B
t $FB6D
b $FB76
t $FB78
b $FB7E
t $FB80
b $FB86
t $FB88
b $FB8D
t $FB8F
b $FB95
t $FB97
b $FB9C
t $FB9E
b $FBA2
t $FBA4
b $FBA9
t $FBAB
b $FBB3
t $FBB9
b $FBBD
t $FBBF
b $FBC3
t $FBC5
b $FBCB
t $FBCD
b $FBD2
t $FBD4
b $FBD7
t $FBD9
b $FBE0
t $FBE2
b $FBE8
t $FBED
b $FBF0
t $FBF2
b $FBF8
t $FBFA
b $FBFD
t $FBFF
b $FC03
t $FC05
b $FC0A
t $FC0C
b $FC12
t $FC14
b $FC1A
t $FC1C
b $FC1F
t $FC21
b $FC29
t $FC2B
b $FC34
t $FC36
b $FC3E
t $FC40
b $FC46
t $FC48
b $FC4C
t $FC4E
b $FC53
t $FC55
b $FC5E
t $FC60
b $FC7A
t $FC7C
b $FC9A
t $FC9C
b $FC9F
t $FCA5
b $FCAB
t $FCAD
b $FCB1
t $FCB3
b $FCB7
t $FCB9
b $FCC3
t $FCC5
b $FCCB
t $FCCD
b $FCD4
t $FCD6
b $FCDE
t $FD32
b $FD36
t $FD81
b $FD84
t $FDC1
b $FDC4
t $FDEF
b $FDF6
t $FE00
b $FE05
t $FE21
b $FE24
t $FE43
b $FE46
t $FE5B
b $FE5E
t $FE69
b $FE6E
t $FE71
b $FE76
t $FE79
b $FE7C
t $FE89
b $FE8C
t $FEA7
b $FEAC
t $FEAF
b $FEB4
t $FEB7
b $FEBC
t $FEBF
b $FEC2
t $FEC3
b $FEC6
t $FF01
b $FF05
t $FF22
b $FF25
t $FF3B
b $FF3E
t $FF6A
b $FF6E
t $FF72
s $FF76
t $FF79
b $FF7E
t $FF89
b $FF8E
t $FFA9
s $FFAE
t $FFB1
b $FFB4
t $FFB9
b $FFBE
t $FFC9
b $FFCC
